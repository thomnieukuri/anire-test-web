## 試合を厚くする仕組み（v0.41.0）
##   11/20 の作者の相談「肝心な試合がやっぱり内容薄すぎる。もっと緊張感のある試合、スキップしすぎないように、
##   スキップするにもゴールシーンは一枚絵挟んだり状況分かりやすくしたい」で作った。まず3回戦（明誠戦）で使う。
##
##   ・時間で選ぶ選択肢（決定機・ピンチだけ。1試合1〜2回）
##       menu (timed=TIMED_CHOICE, habit=("仲間型", "求道型", "野心型")):
##     habit には、答えの順に「どの型の答えか」を書く。8秒たつと、蓮のくせ（これまでの選び方でいちばん多い型）の答えを、
##     蓮が自分で選ぶ（作者の決定。同じ数なら 仲間型 → 求道型 → 野心型 の順）。上にゲージ（考える時間）が出る。
##     「1つ戻る」で戻ってきたときは、時間は数えない（前に選んだ答えしか押せないので）。
##   ・流れのカット（時間を飛ばすときも、何が起きているかを見せる）
##       $ flow("前半", 3, "明誠、いきなりロングボール！", panel="ch3m_p03", of=(1, 3), tag="ピンチ", sfx="鈍い衝突音")
##     漫画のコマ（images/flow/<panel>.jpg）が左から1枚ずつすべりこみ、下に「実況」の帯が出る。3秒で次へ（タップで早送り）。
##     of=(何枚目, 全部で何枚)。最後のコマのあとで、まとめて消える。スコアボードの時計も進む。
##     実況のひとことは、2行（35字）くらいまで。tag は ピンチ／チャンス／流れ。shots（港北, 相手）は小さく出す。
##     （v0.41.1：作者の「得点したのかと勘違いする」「文字しかない」で、コマと実況にした。大事な場面だけ作戦ボード）
##   ・ゴールの一枚絵（得点も失点も全部。作者の決定）
##       scene cg 〜 with goal_flash   のあとに   $ goal(...)

define TIMED_CHOICE = 8.0
define goal_flash = Fade(0.06, 0.0, 0.35, color="#ffffff")

init python:
    BELIEF_ORDER = ("仲間型", "求道型", "野心型")

    def ren_habit():
        """蓮のくせ：これまでの選び方で、いちばん多い型"""
        b = store.belief
        return max(BELIEF_ORDER, key=lambda k: (b.get(k, 0), -BELIEF_ORDER.index(k)))

    def timed_pick(n, habit):
        """時間切れのときに選ぶ答えの番号"""
        if habit:
            h = ren_habit()
            hl = list(habit)
            if h in hl and hl.index(h) < n:
                return hl.index(h)
        return 0

    ## 流れのカットのコマ（漫画のコマ。v0.41.1）
    FLOW_X, FLOW_Y, FLOW_W, FLOW_H, FLOW_GAP = 40, 152, 1200, 340, 20   # 上はスコアボードの下、下は実況の帯の上
    FLOW_ROT = (-1.6, 1.2, -0.9)
    FLOW_TAG = {"ピンチ": "#c8302b", "チャンス": "#2a5bd7", "流れ": "#6b7280"}

    def flow_panel_img(name, pw, ph, cy=0.5):
        """コマの絵（images/flow/<name>.jpg、1200×800）を、コマの大きさに切って返す"""
        sw, sh = 1200.0, 800.0
        z = max(pw / sw, ph / sh)
        cw, ch = pw / z, ph / z
        return Transform("images/flow/%s.jpg" % name, crop=(int((sw - cw) / 2), int((sh - ch) * cy), int(cw), int(ch)), zoom=z)

    def flow(half, mm, line, panel=None, of=(1, 1), tag=None, shots=None, sfx=None, cy=0.5):
        """試合の流れのカット（1コマ）。
        続けて of=(1,3), (2,3), (3,3) と呼ぶと、漫画のコマが左から1枚ずつ増えて、最後のコマのあとで消える。"""
        sb_set(half=half, mm=mm)
        _window_hide(None, auto=True)
        i, n = of
        if i == 1:
            renpy.show_screen("flow_dim")
        if panel:
            if n == 1:
                ## 1枚だけのときは、横に長くしすぎない（寄りすぎて何の絵か分からなくなる）
                pw = 800
                x = FLOW_X + (FLOW_W - pw) // 2
            else:
                pw = int((FLOW_W - (n - 1) * FLOW_GAP) / n)
                x = FLOW_X + (i - 1) * (pw + FLOW_GAP)
            renpy.show_screen("flow_panel", _tag="flow_panel%d" % i,
                              img=flow_panel_img(panel, pw, FLOW_H, cy), x=x, pw=pw,
                              rot=FLOW_ROT[(i - 1) % 3], label="%s %d分" % (half, mm))
        if sfx:
            se(sfx)
        renpy.show_screen("match_flow", half=half, mm=mm, line=line, tag=tag, shots=shots)
        renpy.pause(3.0)
        if i >= n:
            flow_end()

    def flow_end():
        for k in range(1, 4):
            renpy.hide_screen("flow_panel%d" % k)
        renpy.hide_screen("match_flow")
        renpy.hide_screen("flow_dim")

## 流れのカットの間、うしろを少し暗くする
screen flow_dim():
    zorder 42
    add Solid("#0b1020") at flow_dim_in

transform flow_dim_in:
    on show:
        alpha 0.0
        linear 0.25 alpha 0.55
    on hide:
        linear 0.25 alpha 0.0

## 漫画のコマ（1枚）
screen flow_panel(img, x, pw, rot=0.0, label=""):
    zorder 43
    fixed at flow_panel_in(rot):
        xysize (pw, FLOW_H)
        pos (x, FLOW_Y)
        add Solid("#141414") xysize (pw + 14, FLOW_H + 14) pos (-7, -7)
        add Solid("#fdf3ec") xysize (pw + 10, FLOW_H + 10) pos (-5, -5)
        add img
        frame:
            style "tb_caption_frame"
            xpos 10
            ypos FLOW_H - 22
            text label style "tb_caption"

transform flow_panel_in(rot=0.0):
    subpixel True
    rotate rot
    rotate_pad False
    transform_anchor True
    on show:
        alpha 0.0 xoffset 140 zoom 1.04
        easeout 0.22 alpha 1.0 xoffset 0 zoom 1.0
        ## 着いたときに、少しだけ揺れる（カメラが追いつく）
        ease 0.05 yoffset -5
        ease 0.05 yoffset 4
        ease 0.06 yoffset 0
    on hide:
        easein 0.2 alpha 0.0 xoffset -60

## 流れのカットの帯（実況の声）。GOAL の帯とまちがえないよう、細めで、点数のような大きな数字は出さない
screen match_flow(half, mm, line, tag=None, shots=None):
    zorder 44
    fixed at flow_in:
        xysize (1280, 112)
        ypos 512
        add Solid("#10182be8")
        add Solid("#fdf3ec") xysize (1280, 2)
        hbox:
            xpos 40
            yalign 0.5
            spacing 18
            vbox:
                yalign 0.5
                spacing 4
                frame:
                    background Solid("#fdf3ec")
                    padding (10, 2, 10, 3)
                    text "実況" font FONT_JP_B size 16 color "#10182b"
                text "%s %d分" % (half, mm) font FONT_JP_B size 26 color "#fdf3ec"
                if tag:
                    frame:
                        background Solid(FLOW_TAG.get(tag, "#6b7280"))
                        padding (10, 2, 10, 3)
                        text tag font FONT_JP_B size 16 color "#ffffff"
            text "「" + line + "」":
                font FONT_JP_B
                size 25
                color "#fdf3ec"
                yalign 0.5
                xmaximum 880
                line_spacing 4
        if shots:
            text "シュート数　港北 %d／明誠 %d" % (shots[0], shots[1]):
                font FONT_JP_B
                size 15
                color "#9fb0d0"
                xpos 1250
                xanchor 1.0
                ypos 88

transform flow_in:
    on show:
        alpha 0.0 yoffset 30
        easeout 0.22 alpha 1.0 yoffset 0
    on hide:
        easein 0.2 alpha 0.0 yoffset 20

## 時間で選ぶ選択肢のゲージ（choice 画面の中で使う）
screen timed_gauge(t):
    fixed:
        xysize (640, 48)
        xalign 0.5
        ypos 112
        text "考える時間":
            font FONT_JP_B
            size 20
            color "#fdf3ec"
            outlines [(3, "#0b1f52", 0, 0)]
            xalign 0.5
        bar:
            value AnimatedValue(0, t, t, t)
            xsize 640
            ysize 12
            ypos 32
            left_bar Solid("#e8231f")
            right_bar Solid("#0b1f5288")
            thumb None
