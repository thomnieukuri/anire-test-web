## 試合を厚くする仕組み（v0.41.0）
##   11/20 の作者の相談「肝心な試合がやっぱり内容薄すぎる。もっと緊張感のある試合、スキップしすぎないように、
##   スキップするにもゴールシーンは一枚絵挟んだり状況分かりやすくしたい」で作った。まず3回戦（明誠戦）で使う。
##
##   ・時間で選ぶ選択肢（決定機・ピンチだけ。1試合1〜2回）
##       menu (timed=TIMED_CHOICE, habit=("仲間型", "求道型", "野心型")):
##     habit には、答えの順に「どの型の答えか」を書く。8秒たつと、蓮のくせ（これまでの選び方でいちばん多い型）の答えを、
##     蓮が自分で選ぶ（作者の決定。同じ数なら 仲間型 → 求道型 → 野心型 の順）。上にゲージ（考える時間）が出る。
##     「1つ戻る」で戻ってきたときは、時間は数えない（前に選んだ答えしか押せないので）。
##   ・流れのカット（時間を飛ばすときも、何が起きているかを見せる）
##       $ flow("前半", 8, "明誠のロングボール。宮下先輩が転がる", shots=(0, 3))
##     下に紺の帯（時間・ひとこと・シュートの数）を出して、2.6秒で次へ（タップで早送り）。スコアボードの時計も進む。
##     ひとことは24字くらいまで。shots は（港北, 相手）。
##   ・ゴールの一枚絵（得点も失点も全部。作者の決定）
##       scene cg 〜 with goal_flash   のあとに   $ goal(...)

define TIMED_CHOICE = 8.0
define goal_flash = Fade(0.06, 0.0, 0.35, color="#ffffff")

init python:
    BELIEF_ORDER = ("仲間型", "求道型", "野心型")

    def ren_habit():
        """蓮のくせ：これまでの選び方で、いちばん多い型"""
        b = store.belief
        return max(BELIEF_ORDER, key=lambda k: (b.get(k, 0), -BELIEF_ORDER.index(k)))

    def timed_pick(n, habit):
        """時間切れのときに選ぶ答えの番号"""
        if habit:
            h = ren_habit()
            hl = list(habit)
            if h in hl and hl.index(h) < n:
                return hl.index(h)
        return 0

    def flow(half, mm, line, shots=None):
        """試合の流れのカット（1コマ）"""
        sb_set(half=half, mm=mm)
        _window_hide(None, auto=True)
        renpy.show_screen("match_flow", half=half, mm=mm, line=line, shots=shots)
        renpy.pause(2.6)
        renpy.hide_screen("match_flow")

## 流れのカットの帯
screen match_flow(half, mm, line, shots=None):
    zorder 44
    fixed at flow_in:
        xysize (1280, 118)
        ypos 508
        add Solid("#0b1f52e8")
        add Solid("#e8231f") xysize (1280, 4)
        add Solid("#fdf3ec") xysize (1280, 2) ypos 6
        text "%s %d分" % (half, mm):
            font FONT_JP_B
            size 38
            color "#fdf3ec"
            xpos 56
            yalign 0.56
        text line:
            font FONT_JP_B
            size 25
            color "#fdf3ec"
            xpos 290
            yalign 0.56
            xmaximum 700
        if shots:
            vbox:
                xpos 1224
                xanchor 1.0
                yalign 0.56
                spacing 0
                text "シュート" font FONT_JP_B size 17 color "#c9d3ea" xalign 0.5
                text "%d − %d" % (shots[0], shots[1]) font FONT_JP_B size 34 color "#fdf3ec" xalign 0.5

transform flow_in:
    on show:
        alpha 0.0 xoffset -60
        easeout 0.25 alpha 1.0 xoffset 0
    on hide:
        easein 0.2 alpha 0.0 xoffset 60

## 時間で選ぶ選択肢のゲージ（choice 画面の中で使う）
screen timed_gauge(t):
    fixed:
        xysize (640, 48)
        xalign 0.5
        ypos 112
        text "考える時間":
            font FONT_JP_B
            size 20
            color "#fdf3ec"
            outlines [(3, "#0b1f52", 0, 0)]
            xalign 0.5
        bar:
            value AnimatedValue(0, t, t, t)
            xsize 640
            ysize 12
            ypos 32
            left_bar Solid("#e8231f")
            right_bar Solid("#0b1f5288")
            thumb None
