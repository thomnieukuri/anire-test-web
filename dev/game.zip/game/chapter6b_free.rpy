## chapter6b_free.rpy ―― 第6章（ルートB）の自由行動・練習の出来事・夜のトーク（v0.36.0・Claude の第1稿）
##   仕組みは第4・5章Bと同じ（b4_spots・b4_night_send をそのまま使う。表に b6may / b6oct を足す）
##   ① 5月（b6may）：5/8・5/9・5/11・5/13（土）。夏の準決勝（港北戦）の前
##   ② 10月（b6oct）：10/2・10/3・10/5・10/7（土）。選手権予選の前
##   最後の土曜日は港北に帰れる（はやせ食堂・港の防波堤・港北のグラウンドのフェンスの外）
##   麗華は、行動マップ・夜のトークには入れない（第4章Bからの決まり）

init 1 python:
    B4_FREE.update({
        "b6may": (["5月8日（月）", "5月9日（火）", "5月11日（木）", "5月13日（土）"], "放課後", "高3の5月、どこへ行く？"),
        "b6oct": (["10月2日（月）", "10月3日（火）", "10月5日（木）", "10月7日（土）"], "放課後", "選手権の前、どこへ行く？"),
    })
    B4_RECAP.update({
        "b6may": ("高3になった。桜嶺での、最後の一年。\n港北は、今年から、新入生をとらない。\n\n"
                  "6月のインターハイ予選。\n勝ち上がれば、準決勝で港北と当たる。"),
        "b6oct": ("夏のインターハイは、全国でベスト4だった。\n3年のマネージャーは、引退した。\n\n"
                  "10月21日から、選手権予選。\n反対の山のいちばん上に、港北の名前がある。"),
    })
    B4_SPOTS.update({
        "b6may": [
            ("music", "音楽室", 330, 70, "saki", "紗希", "b6_may_saki"),
            ("club", "部室", 640, 170, "ageha", "あげは", "b6_may_ageha"),
            ("wall", "寮の裏の壁", 980, 420, "", "本田", "b6_may_honda"),
            ("office", "監督室の前", 520, 330, "", "真壁", "b6_may_makabe"),
            ("roof", "寮の屋上", 1020, 110, "kamishiro", "神城", "b6_may_kamishiro"),
        ],
        "b6oct": [
            ("music", "音楽室", 330, 70, "saki", "紗希", "b6_oct_saki"),
            ("club", "部室", 640, 170, "ageha", "あげは", "b6_oct_ageha"),
            ("wall", "寮の裏の壁", 980, 420, "", "本田", "b6_oct_honda"),
            ("office", "監督室の前", 520, 330, "", "真壁", "b6_oct_makabe"),
            ("roof", "寮の屋上", 1020, 110, "kamishiro", "神城", "b6_oct_kamishiro"),
        ],
    })
    B4_HOLIDAY_SPOTS.update({
        "b6may": [
            ("shokudo", "はやせ食堂", 850, 460, "mother", "母さん", "b6_hol_mother_may"),
            ("pier", "港の防波堤", 330, 560, "saki", "紗希", "b6_hol_saki_may"),
            ("fence", "港北のグラウンド", 600, 170, "", "フェンスの外", "b6_hol_fence_may"),
        ],
        "b6oct": [
            ("shokudo", "はやせ食堂", 850, 460, "mother", "母さん", "b6_hol_mother_oct"),
            ("pier", "港の防波堤", 330, 560, "saki", "紗希", "b6_hol_saki_oct"),
            ("fence", "港北のグラウンド", 600, 170, "", "フェンスの外", "b6_hol_fence_oct"),
        ],
    })


## 自由行動のくり返し（第5章Bの b5_free_loop と同じ形）
label b6_free_loop(month):
    $ b4_dates, b4_time, b4_banner = B4_FREE[month]
    $ recap_text = B4_RECAP[month]
    scene black
    with dissolve
    window auto hide
    if month == "b6may":
        tuto "自由行動です。5月の放課後は4日。夏の準決勝の前に、いろんな人と話しておけます。最後の土曜日は、港北に帰れます。"
    else:
        tuto "自由行動です。10月の放課後は4日。選手権予選の前の、最後の自由行動です。最後の土曜日は、港北に帰れます。"
    $ b4_day = 1
    while b4_day <= len(b4_dates):
        $ amb_stop()
        $ set_cal(b4_dates[b4_day - 1], b4_time)
        $ bgm("作戦会議っぽい軽快な曲")
        window auto hide
        call practice_day(month)
        if b4_is_holiday(month):
            $ set_cal(b4_dates[b4_day - 1], "午後")
            $ bgm("のんびりした春の曲")
            window auto hide
            "午前の練習が終わると、電車で、港北へ帰った。"
            call screen action_map(b4_spots(month), "港北の町、どこへ行く？（休日）")
        else:
            $ set_cal(b4_dates[b4_day - 1], b4_time)
            $ bgm("作戦会議っぽい軽快な曲")
            window auto hide
            call screen action_map(b4_spots(month), b4_banner + "（残り" + str(len(b4_dates) + 1 - b4_day) + "日）", area="ouryo")
        $ _lab = b4_spot_label(month, _return)
        $ set_flag(_lab)
        call expression _lab
        $ amb_stop()
        call b4_night_send(b4_dates[b4_day - 1], month)
        $ b4_day += 1
    $ amb_stop()
    return


################################################################################
## 5月の行き先（夏の準決勝の前）
################################################################################

## 音楽室：紗希。一ノ瀬先輩が卒業した部屋の話
label b6_may_saki:
    scene bg ouryo_music
    with dissolve
    $ bgm("静かなピアノの旋律")
    "音楽室の戸を開けると、[saki_call]は、ピアノではなく、窓のそばに立っていた。"
    show saki normal
    with dissolve
    saki_v "……来ると思った。今日、白いビブスの練習、早く終わったから"
    saki_v "あんたが来る日、分かるようになった。……グラウンドの声が、一つ、減るから"
    "[saki_call]は、ピアノの前に座って、蓋を開けた。最初の音を鳴らす前に、言った。"
    saki_v "高3は、音楽の授業、ないの。……ここに来る理由、もう、ないんだけど"
    saki_v "でも、来てる。……理由は、聞かないで"
    "それから、[saki_call]は、短い曲を一つ、最後まで弾いた。途中で、一回も止まらなかった。"
    $ heart_up("紗希", "ときめき", 3)
    $ heart_up("紗希", "信頼", 2)
    $ up("メンタル", 1)
    hide saki
    with dissolve
    call b4_saki_late_contact
    return

## 部室：あげは。夏の準決勝の動画の企画
label b6_may_ageha:
    scene bg ouryo_clubroom
    with dissolve
    $ bgm("明るい部活の曲")
    show ageha ouryo
    with dissolve
    ageha "パイセン！　いいとこに！　ちょっと、これ見て"
    "あげはのスマホに、トーナメント表の写真が映っていた。準決勝のところに、赤いペンで、ハートがかいてあった。"
    ageha "桜嶺 対 港北。……あたし、両方のベンチの横、撮りたいんだよね。部のアカウントで"
    ageha "パイセンが、元の仲間と戦うとこ。……あ、でも、パイセンがやだったら、やめる"
    ren "……撮っていい"
    ageha "ほんと？　……じゃあ、いちばんいい顔、撮る。勝っても、負けても"
    "あげはは、スマホを胸の前で、両手で持った。まじめな顔だった。"
    ageha "あたし、港北にいたことないから、パイセンの前の仲間のこと、知らないんだ。……知らないまま撮るの、ちょっと、こわい"
    $ heart_up("あげは", "ときめき", 3)
    $ heart_up("あげは", "信頼", 3)
    $ up("技術", 1)
    hide ageha
    with dissolve
    return

## 寮の裏の壁：本田
label b6_may_honda:
    scene bg ouryo_ground_eve
    with dissolve
    $ bgm("静かな春の曲")
    "寮の裏の壁の前で、本田が、ボールを蹴っていた。去年の春から、ずっと、ここが本田の場所だった。"
    show honda normal
    with dissolve
    honda "……早瀬。今日は、俺から、一つ聞いていい？"
    honda "なんで、桜嶺に来たの。……去年の春に聞いたら、答えなかったろ"
    if b5_surgery:
        ren "ひざがもつうちに、いちばん上で、確かめたかった。……結局、手術したけど"
    else:
        ren "ひざがもつうちに、いちばん上で、確かめたかった。……それと、神城の答えを、近くで聞きたかった"
    honda "……そっか。で、確かめられた？"
    ren "まだだ"
    honda "まだか。……俺も、まだ。白いの、着てないもん"
    "本田は、壁にボールを当てた。返ってきたボールを、今度は、俺のほうに蹴った。"
    $ bond_up("本田", 4)
    $ up("フィジカル", 1)
    return

## 監督室の前：真壁
label b6_may_makabe:
    scene bg ouryo_office
    with dissolve
    $ bgm("少しとがった曲")
    "監督室の前の廊下に、真壁がいた。ドアが開くのを、待っているようだった。"
    show makabe match
    with dissolve
    makabe "……なんだよ。お前も、呼ばれたのか"
    makabe "呼ばれてねえなら、どけよ。監督が話すのは、いつも、俺だ"
    "ドアが開いて、真壁は中に入っていった。閉まる前に、鬼塚監督の声が、少しだけ聞こえた。"
    "――港北の9番。ジュニアユースで、お前より下だったな。"
    "ドアが、閉まった。"
    $ up("戦術眼", 1)
    $ set_flag("b6_真壁と監督")
    hide makabe
    with dissolve
    return

## 寮の屋上：神城
label b6_may_kamishiro:
    scene bg ouryo_rooftop
    with dissolve
    $ bgm("静かな夜の曲")
    show kamishiro normal
    with dissolve
    "屋上で、神城が、左の足首を、片手でさすっていた。"
    kamishiro "……三年目だ。この足首と"
    kamishiro "最後の一年だから、もう、隠すのはやめた。……お前には"
    "神城は、テーピングをほどいて、また巻き直した。手つきは、去年より、ずっと慣れていた。"
    kamishiro "夏、港北とやる。……鷹野は、俺のことを、たぶん、まだ一番、憎んでる"
    kamishiro "お前より、な"
    $ bond_up("神城", 4)
    $ up("メンタル", 1)
    hide kamishiro
    with dissolve
    return

## 休日：はやせ食堂
label b6_hol_mother_may:
    scene bg shokudo_day
    with dissolve
    $ bgm("あたたかいアコースティックギター")
    show mother normal
    with dissolve
    haha "おかえり。……背、また伸びた？"
    "伸びていなかった。母さんは、毎回、同じことを言った。"
    haha "6月、港北とやるんでしょ。……あたし、どっちの席に座ればいいの"
    ren "……好きなほうでいい"
    haha "じゃあ、港北の席。……常連さん、みんな、そっちだから。あんたのこと、裏切ったって言ってる人もいる"
    haha "でも、あたしは、あんたの母さんだから。……青い席で、白いほうを応援する。それで、いいでしょ"
    $ up("メンタル", 2)
    $ up("無理ゲージ", -3)
    hide mother
    with dissolve
    return

## 休日：港の防波堤（紗希）
label b6_hol_saki_may:
    scene bg harbor_sunset
    with dissolve
    $ se("波の音、カモメ")
    $ bgm("静かなピアノの旋律")
    "防波堤の先で、[saki_call]が、膝の上で、手紙を読んでいた。封筒の字は、大人の、男の人の字だった。"
    show saki casual
    with dissolve
    saki_v "……兄さんから。年に一回だけ、来るの"
    saki_v "今は、遠くの町で、子どもにサッカーを教えてるって。……ひざは、走れないけど、教えることはできるって"
    "[saki_call]は、手紙を、ていねいに、封筒に戻した。"
    saki_v "あんたのこと、書いた。去年。……そしたら、今年の手紙に、一行だけ、返事があった"
    saki_v "『その人は、痛いって、言える人か』"
    "[saki_call]は、こっちを見た。"
    saki_v "……言える人だって、返事、書いてもいい？"
    if b5_tell == "saki" or b4_knee == "tell":
        ren "……書いていい"
        saki_v "……うん。書く"
        $ heart_up("紗希", "信頼", 4)
    else:
        ren "……まだ、分からない"
        saki_v "……そう。じゃあ、まだ書かない"
        $ heart_up("紗希", "信頼", 1)
    $ heart_up("紗希", "ときめき", 3)
    hide saki
    with dissolve
    $ amb_stop()
    call b4_saki_late_contact
    return

## 休日：港北のグラウンドのフェンスの外（大門）
label b6_hol_fence_may:
    scene bg kohoku_ground_eve
    with dissolve
    $ bgm("静かな夜の曲")
    "夕方の港北のグラウンドで、大門が、一人で、ゴールの前に立っていた。小早川のシュートを、一本ずつ、止めていた。"
    "最後の一本を止めると、大門は、ボールを持ったまま、フェンスのところまで歩いてきた。"
    show daimon jersey
    with dissolve
    daimon "……早瀬くん"
    daimon "6月、当たりますね。準決勝で"
    daimon "僕、早瀬くんのシュートの癖、全部、知ってます。……三年、いっしょに練習したので"
    daimon "だから、止めます。……それが、いちばん、ちゃんとした、あいさつだと思うので"
    "大門は、頭を下げて、ゴールのほうへ戻っていった。"
    $ bond_up("大門", 3)
    $ up("技術", 1)
    hide daimon
    with dissolve
    return


################################################################################
## 10月の行き先（選手権予選の前）
################################################################################

## 音楽室：紗希。決勝の日の席
label b6_oct_saki:
    scene bg ouryo_music
    with dissolve
    $ bgm("静かなピアノの旋律")
    show saki normal
    with dissolve
    "[saki_call]は、ピアノの前で、スマホの画面を見ていた。スタジアムの座席表だった。"
    saki_v "……見てない。何も"
    saki_v "決勝まで行けば、の話。……行けなかったら、見に行かないし"
    ren "行く"
    saki_v "……知ってる。だから、見てた"
    "[saki_call]は、画面の、いちばん端の席を、指でなぞった。白でも青でもない、通路のそばの席だった。"
    $ heart_up("紗希", "ときめき", 4)
    $ heart_up("紗希", "信頼", 2)
    $ up("メンタル", 1)
    hide saki
    with dissolve
    call b4_saki_late_contact
    return

## 部室：あげは。新しいマネージャーの仕事
label b6_oct_ageha:
    scene bg ouryo_clubroom
    with dissolve
    $ bgm("明るい部活の曲")
    show ageha ouryo
    with dissolve
    ageha "パイセン、見て。これ、新しい評価表。……麗華先輩のやつ、引き継いだ2年の子が、あたしにも手伝ってって"
    ageha "麗華先輩の字、めっちゃきれいなんだよね。ちょっと、こわいくらい"
    "あげはは、黒いバインダーを開いて、すぐに閉じた。"
    ageha "パイセンの欄、見ちゃった。……ないしょ。何が書いてあったかは"
    ageha "でも、一個だけ。……麗華先輩、パイセンの欄だけ、字が、ちょっと、ふるえてた"
    $ heart_up("あげは", "ときめき", 3)
    $ heart_up("あげは", "信頼", 3)
    $ up("戦術眼", 1)
    hide ageha
    with dissolve
    return

## 寮の裏の壁：本田。もも裏
label b6_oct_honda:
    scene bg ouryo_ground_eve
    with dissolve
    $ bgm("静かな春の曲")
    "寮の裏の壁の前で、本田が、左のももの裏を、両手で伸ばしていた。"
    show honda normal
    with dissolve
    honda "……あ。見た？"
    if flags.get("b6_本田のもも裏"):
        honda "夏祭りのときより、ちょっと、ましになった。……ほんとだって"
    else:
        honda "最近、ちょっと張ってるだけ。……トレーナーさんには、言ってない"
    honda "選手権の三十人に、やっと入れそうなんだ。今、名簿に何か書かれたら、終わる"
    menu:
        "「トレーナーに、言え」":
            $ lean("仲間型")
            ren "トレーナーに、言え。……言わないで壊れたやつを、何人も見てきた"
            honda "……分かってる。分かってるけど"
            honda "……全国が終わったら、言う。それまで、早瀬が、見張ってて"
            $ bond_up("本田", 4)
            $ set_flag("b6_本田に言えと言った")
        "何も言わずに、ボールを返す":
            $ lean("求道型")
            "何も言わずに、足もとのボールを、本田に返した。本田は、ほっとした顔で、それを止めた。"
            $ bond_up("本田", 2)
    return

## 監督室の前：真壁
label b6_oct_makabe:
    scene bg ouryo_office
    with dissolve
    $ bgm("少しとがった曲")
    show makabe match
    with dissolve
    makabe "……港北、来るってな。決勝まで"
    makabe "鷹野のやつ、ジュニアユースのとき、俺より下だった。……今、県でいちばん点取ってんの、あいつなんだよ"
    makabe "おかしいだろ。下だったやつが、上にいるの"
    "真壁は、窓の外のグラウンドを見ていた。拳を、ズボンのポケットの中で、にぎっていた。"
    makabe "監督は、言うんだよ。……本物かどうかは、壊れるかどうかで分かる、って"
    makabe "俺は、壊れなかった。だから、ここにいる。……それだけだ"
    $ up("戦術眼", 1)
    hide makabe
    with dissolve
    return

## 寮の屋上：神城
label b6_oct_kamishiro:
    scene bg ouryo_rooftop
    with dissolve
    $ bgm("静かな夜の曲")
    show kamishiro normal
    with dissolve
    kamishiro "……決勝。もし、あの人が、誰かに、合図を出したら"
    kamishiro "俺は、三年前、それを、自分の足でやった。……二度と、見たくない"
    kamishiro "お前が、どこに立つにしても。……俺は、お前のうしろにいる"
    $ bond_up("神城", 4)
    $ up("戦術眼", 1)
    hide kamishiro
    with dissolve
    return

## 休日：はやせ食堂
label b6_hol_mother_oct:
    scene bg shokudo_night
    with dissolve
    $ bgm("あたたかいアコースティックギター")
    show mother normal
    with dissolve
    "閉店の少しあと、店に入ると、母さんは、のれんを下ろしかけていた。"
    haha "……あら。今日は、遅いのね"
    haha "さっきまで、鷹野くんが、来てた。一人で。からあげ定食"
    haha "何も言わないで、食べて、帰った。……帰るとき、あんたの写真の前で、ちょっとだけ、止まってた"
    "店の柱に、一年の春、母さんが貼った写真があった。港北の、十一人。"
    haha "あたし、何も聞かなかった。……あんたも、聞かないでいいよ"
    $ up("メンタル", 2)
    $ up("無理ゲージ", -3)
    $ bond_up("鷹野", 1)
    hide mother
    with dissolve
    return

## 休日：港の防波堤（紗希）
label b6_hol_saki_oct:
    scene bg harbor_winter_eve
    with dissolve
    $ se("波の音、カモメ")
    $ bgm("静かなピアノの旋律")
    "防波堤に、[saki_call]がいた。今日は、楽譜も、手紙も、持っていなかった。"
    show saki casual
    with dissolve
    saki_v "……何も持ってこなかった。今日は"
    saki_v "あんたが来るか、来ないか。それだけ、見に来た"
    "[saki_call]は、防波堤のはしに座って、となりを、少しだけあけた。去年より、少しだけ、せまく。"
    saki_v "決勝の日、あの人は、たぶん、何かする。……娘だから、分かる"
    saki_v "そのとき、あんたが、どうするか。……それを、見に行くの。サッカーじゃなくて"
    $ heart_up("紗希", "ときめき", 4)
    $ heart_up("紗希", "信頼", 3)
    hide saki
    with dissolve
    $ amb_stop()
    call b4_saki_late_contact
    return

## 休日：港北のグラウンドのフェンスの外（夜。鷹野）
label b6_hol_fence_oct:
    scene bg kohoku_fence_night
    with dissolve
    $ bgm("静かな夜の曲")
    "夜の港北のグラウンドに、照明が一つだけついていた。鷹野が、一人で、ゴールに向かって、シュートを打っていた。"
    "一本。二本。三本。……ネットが、揺れるたびに、同じ音がした。"
    "ボールが一つ、こっちに転がってきて、フェンスに当たって止まった。"
    "フェンスの下のすきまから、ボールを、足で押し返した。"
    "鷹野は、ボールを止めた。こっちを、見なかった。"
    if flags.get("b6_鷹野が口をきいた"):
        takano "……冬だ"
        "それだけ言って、鷹野は、また、ゴールに向かって蹴った。"
        $ bond_up("鷹野", 2)
    else:
        "何も言わずに、また、ゴールに向かって蹴った。"
        $ bond_up("鷹野", 1)
    $ up("フィジカル", 1)
    return


################################################################################
## 練習の出来事（第6章B。b6may / b6oct）
################################################################################
define B6_MONTHS = ("b6may", "b6oct")
init 1 python:
    PRACTICE_EVENTS_A4.extend([
        ("b6p_white_two", "技術", B6_MONTHS),
        ("b6p_left_foot", "技術", B6_MONTHS),
        ("b6p_makabe_body", "フィジカル", B6_MONTHS),
        ("b6p_hill_last", "フィジカル", B6_MONTHS),
        ("b6p_kohoku_video", "戦術眼", B6_MONTHS),
        ("b6p_notebook", "戦術眼", B6_MONTHS),
        ("b6p_list_last", "メンタル", B6_MONTHS),
        ("b6p_ageha_live", "メンタル", B6_MONTHS),
    ])
    PRACTICE_ADVICE.update({
        "b6may": ("技術", "港北は、引いて守る。……引いた相手は、最初の一歩で崩せ"),
        "b6oct": ("戦術眼", "決勝の相手は、お前の癖を、全部知っている。……知られていない場所を、探せ"),
    })

label b6p_white_two:
    "白いビブスの練習。前の二人だけで、ゴールまで行く練習を、何度も、何度もやった。"
    kamishiro "……早瀬。今の、半歩、遅い。……いや、俺が、半歩、早かった"
    "神城が、自分のほうを直すのを、初めて聞いた。"
    return

label b6p_left_foot:
    "居残りで、左足だけのシュートを、五十本。右ひざを休ませるために、去年から始めた練習だった。"
    "四十本目から、左足のほうが、右足より、まっすぐ飛ぶようになった。"
    return

label b6p_makabe_body:
    "当たりの練習で、真壁と組まされた。真壁は、今年も、最初の一回で、右ひざのほうから入ってきた。"
    makabe "……へえ。去年より、重くなったな"
    "倒れなかった。真壁は、舌打ちをして、次の相手のところに行った。"
    return

label b6p_hill_last:
    "寮の裏の坂道を、ダッシュで十本。三年目の坂道だった。"
    "十本目、となりで、本田が、坂の上まで、止まらずに走りきった。去年の春は、八本目で座りこんでいたのに。"
    return

label b6p_kohoku_video:
    "監督室の前のモニターで、港北の試合の映像が流れていた。だれが置いていったのかは、分からなかった。"
    "港北は、十一人で、二本の線を作っていた。線のあいだを、鷹野が、一人で、何度も往復していた。"
    "一年の春、黒田がいなかったころ、鷹野と二人で、同じことを話した。……前の二人が、守備もやる。"
    return

label b6p_notebook:
    "寝る前に、一ノ瀬先輩のノートを開いた。三冊目の、最後のほうのページ。"
    "――「早瀬：右で受けると見せて、左の足の裏」。去年の秋に、もう、書いてあった。"
    "一ノ瀬先輩は、俺が自分で気づく前に、俺の癖を、知っていた。……だれかが、どこかで、見ている。"
    return

label b6p_list_last:
    "練習のあと、ロッカーの名札を、一枚ずつ見た。三年前の春に入った名前は、半分になっていた。"
    "残った名前の中に、本田の名札があった。……角が、すり切れていた。"
    return

label b6p_ageha_live:
    "部室の前で、あげはが、部のアカウントの配信をしていた。画面の中で、白いビブスの練習が、映っていた。"
    ageha "……今の、見た？　パイセンの左足。コメント、めっちゃ来てる"
    ageha "『港北にいたころの早瀬、知ってる』って人も、いる。……港北の人かな"
    return


################################################################################
## 夜のトーク（第6章B。b4_night_send の仕組みで、ラベルは b4nc_<id>_b6may / b6oct）
################################################################################

## 紗希
label b4nc_saki_b6may:
    $ talk_start("紗希", "22:41")
    $ talk_me("6月10日、港北と当たる")
    $ talk_wait(9)
    $ talk("紗希", "知ってる。新聞、見た")
    $ talk("紗希", "見に行かない。あの人の試合だから")
    $ talk_wait(3)
    $ talk("紗希", "……結果だけ、教えて。あの人の口からじゃなくて")
    $ heart_up("紗希", "信頼", 2)
    return

label b4nc_saki_b6oct:
    $ talk_start("紗希", "23:05")
    $ talk("紗希", "起きてる？")
    $ talk_me("起きてる")
    $ talk("紗希", "なんでもない。起きてるか、知りたかっただけ")
    $ talk_wait(4)
    $ talk("紗希", "……決勝、行く。言ったっけ")
    $ talk_me("聞いた。夏祭りで")
    $ talk("紗希", "……じゃあ、二回目。おやすみ")
    $ heart_up("紗希", "ときめき", 2)
    return

## あげは
label b4nc_ageha_b6may:
    $ talk_start("あげは", "22:12")
    $ talk("あげは", "パイセン！　部のアカウント、フォロワー千人こえた！")
    $ talk("あげは", "九割、パイセンの左足目当て")
    $ talk_me("左足だけかよ")
    $ talk("あげは", "あとの一割は、あたし")
    $ heart_up("あげは", "ときめき", 2)
    return

label b4nc_ageha_b6oct:
    $ talk_start("あげは", "22:30")
    $ talk("あげは", "パイセン、卒業まで、あと半年")
    $ talk("あげは", "数えちゃった。ごめん")
    $ talk_wait(5)
    $ talk("あげは", "数えないほうが、よかった")
    $ talk_me("決勝、撮って")
    $ talk("あげは", "……撮る。いちばんいい顔")
    $ heart_up("あげは", "信頼", 2)
    return

## ひなた
label b4nc_hinata_b6may:
    $ talk_start("ひなた", "22:50")
    $ talk_me("6月、準決勝で当たる")
    $ talk_wait(25)
    $ talk("ひなた", "知ってる")
    $ talk("ひなた", "わたし、港北のベンチにいるから。テーピングの箱、持って")
    $ talk("ひなた", "蓮のひざは、もう、巻かない。……巻けない")
    $ talk_wait(4)
    $ talk("ひなた", "まだ、怒ってるよ。三年目でも")
    $ heart_up("ひなた", "信頼", 2)
    return

label b4nc_hinata_b6oct:
    $ talk_start("ひなた", "23:20")
    $ talk("ひなた", "決勝で当たったら、わたし、港北のマネージャーとして、ベンチから叫ぶから")
    $ talk("ひなた", "鷹野くん、そこ！　って")
    $ talk_me("聞こえたら、こっちも分かる")
    $ talk("ひなた", "……ずるい。それ、ずるい")
    $ heart_up("ひなた", "信頼", 2)
    return

## 本田
label b4nc_honda_b6may:
    $ talk_start("本田", "22:58")
    $ talk("本田", "早瀬、起きてる？")
    $ talk("本田", "明日の壁、5時半な")
    $ talk_me("毎日だな")
    $ talk("本田", "最後の一年だから。毎日やっても、あと三百回くらいしかない")
    $ bond_up("本田", 2)
    return

label b4nc_honda_b6oct:
    $ talk_start("本田", "22:40")
    $ talk("本田", "三十人、入った")
    $ talk("本田", "選手権の登録")
    $ talk_me("おめでとう")
    $ talk("本田", "早瀬に言われると、ほんとっぽい。……ほんとなんだけど")
    $ bond_up("本田", 3)
    return

## 母さん
label b4nc_mother_b6may:
    $ talk_start("母", "21:10")
    $ talk("母", "ゆずが、あんたのユニフォームの写真、待ち受けにしてた")
    $ talk("母", "白いほう")
    $ talk_me("言わなくていい")
    $ talk("母", "言っとく。あとで、怒られるの、あたしだから")
    $ up("メンタル", 1)
    return

label b4nc_mother_b6oct:
    $ talk_start("母", "21:40")
    $ talk("母", "決勝、行くからね")
    $ talk("母", "青い席で、白いほう応援する。常連さんに、変な顔されても")
    $ up("メンタル", 1)
    return

## 大門
label b4nc_daimon_b6may:
    $ talk_start("大門", "22:20")
    $ talk_me("6月、当たるな")
    $ talk_wait(40)
    $ talk("大門", "当たりますね")
    $ talk("大門", "手加減は、しません。……したら、早瀬くんに、失礼なので")
    $ bond_up("大門", 2)
    return

label b4nc_daimon_b6oct:
    $ talk_start("大門", "22:35")
    $ talk_me("決勝まで、来いよ")
    $ talk_wait(20)
    $ talk("大門", "行きます")
    $ talk("大門", "鷹野くんが、毎晩、一人で、シュート打ってます。……知ってると思いますけど")
    $ bond_up("大門", 2)
    return

## 鷹野（5月は既読がつかない。夏のあとは、一言だけ返ってくる）
label b4nc_takano_b6may:
    $ talk_start("鷹野", "23:01")
    $ talk_me("6月、準決勝で")
    $ talk_wait(60)
    $ talk_system("既読がつかないまま、日付が変わった")
    return

label b4nc_takano_b6oct:
    $ talk_start("鷹野", "23:30")
    $ talk_me("決勝で")
    $ talk_wait(15)
    if flags.get("b6_鷹野が口をきいた"):
        $ talk("鷹野", "寝ろ")
        $ bond_up("鷹野", 2)
    else:
        $ talk_system("既読")
    return
