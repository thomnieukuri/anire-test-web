## chapter5a_3.rpy ―― 第5章（ルートA）の後半②：12〜3月（v0.32.0・Claude の第1稿）
##   自由行動②（12月・4日）→ 12/24 クリスマス（ときめきがいちばん高い一人。冷えたときは、ほかの人の兆し）
##   → 1/1 元日 → 1/10 3年の引退（来年の春、1年生は入ってこない）
##   → 2/14 バレンタイン＋黒田の過去（ほのめかすだけ）
##   → 3/1 千夏の卒業式（恋人／相棒／すれ違い／ひとり）。『港北の記録』の最後のページ → 第5章 完
##
##   ※ 恋愛の場面は Claude の下書き（作者の決定 11/2）。確認帳で1か所ずつ確かめてから、声と一枚絵を作る
##   ※ ヒロインは全員高校生。ドキドキは気持ちの揺れ（照れ・距離・言いかけてやめる・二人だけの秘密）で書く
##   ※ しきい値は第1稿の目安。自動プレイで数字を見てから合わせる

## クリスマスに誘ってくる「ときめき」（いちばん高い一人。割合で比べる）
##   第1稿の自動プレイ（11/2・9回）で、12/24 のときめきは ひなた 43〜66・千夏 28〜42・あげは 15〜48 だった
##   （第4章の終わりで、ひなたは 40〜51、千夏は 28〜38、あげはは 15〜33）。追った人に届き、追わない人にはあまり届かない高さ
define A5_XMAS_NEED = {"ひなた": 48, "千夏": 35, "あげは": 32}
## バレンタインに渡しに来る「ときめき」（いちばん高い一人は場面、ほかの人は一言）
define A5_VAL_NEED = {"ひなた": 48, "千夏": 35, "あげは": 32}
## 千夏の卒業式（3/1）の分かれ方
define A5_GRAD_LOVER = (42, 50)     # ときめき・信頼がどちらも以上で、千夏がいちばん（クリスマスと同じ割合で比べる） → 告白（恋人）
define A5_GRAD_PARTNER = 55         # 信頼が以上 → 相棒（『港北の記録』を託される）
define A5_GRAD_MISS = 42            # ときめきだけ高い → すれ違い

default a5_xmas = ""            # クリスマスにすごした人：hinata / chika / ageha / team
default a5_xmas_answer = ""     # クリスマスの最後に答えたこと
default a5_val = ""             # バレンタインの場面の人：hinata / chika / ageha / ""
default a5_grad = ""            # 千夏の卒業式：lover / partner / miss / alone
default a5_grad_answer = ""     # 千夏の告白への答え：yes（付き合う）/ wait（来年の夏まで待ってもらう）

## 仮の一枚絵（ときめきの場面には、必ず一枚絵をつける：作者の決定）
image cg a5_xmas_hinata = "images/cg/a5_xmas_hinata.jpg"
image cg a5_xmas_hinata_hand = "images/cg/a5_xmas_hinata_hand.jpg"
image bg a5_hinata_house = "images/bg/a5_hinata_house.jpg"
image bg a5_hinata_room = "images/bg/a5_hinata_room.jpg"
image cg a5_xmas_chika = "images/cg/a5_xmas_chika.jpg"
image cg a5_xmas_ageha = "images/cg/a5_xmas_ageha.jpg"
image cg a5_val_hinata = "images/cg/a5_val_hinata.jpg"
image cg a5_val_chika = "images/cg/a5_val_chika.jpg"
image cg a5_val_ageha = "images/cg/a5_val_ageha.jpg"
image cg a5_grad_chika = "images/cg/a5_grad_chika.jpg"
image bg a5_staff_drawer = "images/bg/a5_staff_drawer.jpg"

label chapter5a_3:
    call a5_free_loop("a5dec")
    call a5_christmas
    call a5_newyear
    call a5_retire
    call a5_valentine
    call a5_kuroda_past
    call a5_graduation
    jump a5_end


################################################################################
## 12月24日（金）：クリスマス
################################################################################
label a5_christmas:
    scene black
    with dissolve
    $ set_cal("12月24日（金）", "夕方")
    $ coat_on()
    python:
        a5_xmas = ""
        _best = 0.0
        for _nm, _id in (("ひなた", "hinata"), ("千夏", "chika"), ("あげは", "ageha")):
            _v = heart.get(_nm, {}).get("ときめき", 0)
            _need = A5_XMAS_NEED[_nm]
            if _v >= _need and float(_v) / _need > _best:
                _best = float(_v) / _need
                a5_xmas = _id
        if not a5_xmas:
            a5_xmas = "team"
    if a5_xmas == "hinata":
        call a5_xmas_hinata
    elif a5_xmas == "chika":
        call a5_xmas_chika
    elif a5_xmas == "ageha":
        call a5_xmas_ageha
    else:
        call a5_xmas_team
    return

## ── ひなた：母さんが法事で留守の夜。ひなたの家に泊まる（作者の声 11/3）─────────────
##   ご飯とお風呂を借りて、ひなたの部屋で寝る（ひなたはベッド、蓮は床の布団）。寝る前に、ひざ当てを渡される
##   ひなたのお母さんが家にいる。体の描写はしない。照れと、電気を消したあとの会話で書く
label a5_xmas_hinata:
    scene bg shokudo_day
    with dissolve
    $ bgm("とぼけた日常の曲")
    show mother normal
    with dissolve
    haha "蓮。言ってなかったけど、今日と明日、田舎の法事だから。店も閉める"
    ren "……今、言うのか"
    haha "で、あんたの晩ごはんと寝るとこは、篠宮さんちに頼んどいたから"
    ren "は？"
    show mother smile
    haha "幼稚園のころ、しょっちゅう泊まってたでしょ。おばさん、張り切ってたよ。「ケーキ、二つ買わなきゃ」って"
    hide mother
    with dissolve
    $ se("トークアプリの通知音（連続）")
    window auto hide
    $ talk_start("ひなた", "11:02")
    $ talk("ひなた", "聞いた")
    $ talk("ひなた", "お母さんが、勝手に決めた")
    $ talk("ひなた", "……7時。ごはん。遅れたら、ノートに書く")
    $ talk_me("行く")
    window auto hide
    $ talk_end()
    ## 夜：篠宮家
    scene bg a5_hinata_house
    with dissolve
    $ bgm("あたたかいアコースティックギター")
    "三軒隣の家の玄関に入るのは、小学校以来だった。靴箱の上の、ひなたの小さいころの写真が、増えていた。"
    hmom "蓮くん、いらっしゃい。大きくなって。……ひなた、蓮くん来たよー"
    "階段の上から、「聞こえてる！」と声がした。"
    "晩ごはんは、からあげだった。おばさんは、からあげ定食がうちの店でいちばん好きなメニューだと、なぜか知っていた。"
    show hinata room
    with dissolve
    voice "audio/voice/hinata_a5_xmas_01.mp3"
    hinata "……わたしが言ったんじゃないからね。お母さんが、勝手に調べたの"
    hmom "ひなたが言ったのよ。三回くらい"
    voice "audio/voice/hinata_a5_xmas_02.mp3"
    hinata "お母さん！"
    "風呂を借りて、出ると、ひなたの部屋に布団が敷いてあった。ベッドの横の、床に。"
    hmom "昔みたいに、ひなたの部屋でいいわよね。客間、物置になってるから"
    "おばさんは、それだけ言って、さっさと階段を降りていった。"
    scene bg a5_hinata_room
    with dissolve
    "ひなたの部屋は、思っていたより、ひざのことでいっぱいだった。本棚の一段が、全部、理学療法の本だった。机の上に、「ひざ」のノートが、四冊並んでいた。"
    show hinata room
    with dissolve
    voice "audio/voice/hinata_a5_xmas_03.mp3"
    hinata "……じろじろ見ないで"
    ren "見てない"
    voice "audio/voice/hinata_a5_xmas_04.mp3"
    hinata "眉毛が見てる"
    "ひなたは、ベッドの上で、ひざを抱えて座った。俺は、布団の上にあぐらをかいた。目の高さが、ちょうど同じだった。"
    voice "audio/voice/hinata_a5_xmas_05.mp3"
    hinata "……寝る前に、渡すものがあるの。今日、渡せなかったら、来年まで渡せない気がして"
    "ひなたは、枕の下から、紙袋を出した。最初から、そこに隠してあったらしかった。"
    scene cg a5_xmas_hinata
    with Dissolve(1.0)
    voice "audio/voice/hinata_a5_xmas_06.mp3"
    hinata "あけて"
    "中に入っていたのは、毛糸で編んだ、筒みたいなものだった。灰色と、港北の青のしましま。"
    voice "audio/voice/hinata_a5_xmas_07.mp3"
    hinata "ひざ当て。サポーターの上から、かぶせるやつ。……冬の朝、ひざが冷えると、いちばん痛いでしょ"
    voice "audio/voice/hinata_a5_xmas_08.mp3"
    hinata "編み物、初めてだったの。三回、ほどいた。……しましまが、ずれてるとこあるけど、見ないで"
    "ずれていた。三か所。"
    if a5_surgery:
        voice "audio/voice/hinata_a5_xmas_09.mp3"
        hinata "リハビリのノートを、毎日つけてたら……あったかくしてあげたくなったの。ひざを。……ひざをだよ"
    else:
        voice "audio/voice/hinata_a5_xmas_10.mp3"
        hinata "毎朝、坂の下で止まってるの、見てたら……あったかくしてあげたくなったの。ひざを。……ひざをだよ"
    "ひなたは、「ひざを」を二回言った。二回目のほうが、声が小さかった。"
    "紙袋の底に、もう一つ、小さなものが残っていた。同じしましまの、指の先くらいの毛糸の玉。ストラップのひもがついていた。"
    ren "……これは"
    voice "audio/voice/hinata_a5_xmas_11.mp3"
    hinata "あ、それは、ちがうの。練習で編んだやつ。……入れたつもりなかったのに"
    "ひなたは、ベッドの上のスマホを、そっと裏返した。同じしましまの毛糸の玉が、もうぶら下がっていた。"
    voice "audio/voice/hinata_a5_xmas_12.mp3"
    hinata "……失敗したやつが、二個できちゃったから。……それだけ"
    menu:
        "「……今、つけてもいいか」":
            $ a5_xmas_answer = "wear"
            $ lean("仲間型")
            "ジャージのすそをまくって、サポーターの上からかぶせた。それから、毛糸の玉を、スマホにつけた。"
            "あったかかった。毛糸のちくちくまで、あったかかった。"
            voice "audio/voice/hinata_a5_xmas_13.mp3"
            hinata "……似合う。ひざに似合うって、変だけど。……スマホにも、似合う"
            $ heart_up("ひなた", "ときめき", 6)
            $ heart_up("ひなた", "信頼", 3)
        "「三回ほどいたのも、ずれてるのも、全部うれしい」":
            $ a5_xmas_answer = "words"
            $ lean("求道型")
            voice "audio/voice/hinata_a5_xmas_14.mp3"
            hinata "……見ないでって言ったのに。全部見て、全部うれしいとか言うの、ずるい"
            "ひなたは、ひざを抱えたまま、顔をひざにうずめた。"
            voice "audio/voice/hinata_a5_xmas_15.mp3"
            hinata "……来年は、ずれないように編む。……来年も、もらってくれるなら"
            $ heart_up("ひなた", "ときめき", 7)
            $ heart_up("ひなた", "信頼", 2)
    ## 電気を消したあと
    scene black
    with Dissolve(1.0)
    $ bgm("静かな夜の曲")
    "電気を消すと、窓の外の街灯の明かりだけが、天井に四角く映っていた。"
    "ベッドの上と、床の上。小学生のときは、同じ高さで寝ていた。"
    voice "audio/voice/hinata_a5_xmas_16.mp3"
    hinata "……蓮。まだ、起きてる？"
    ren "起きてる"
    voice "audio/voice/hinata_a5_xmas_17.mp3"
    hinata "幼稚園のとき、ここで寝てて、蓮、夜中に泣いたの、覚えてる？　おばさんがいないって"
    ren "……覚えてない"
    voice "audio/voice/hinata_a5_xmas_18.mp3"
    hinata "わたし、覚えてる。手、にぎってあげたら、泣きやんだの"
    scene cg a5_xmas_hinata_hand
    with Dissolve(1.2)
    "暗いなかで、ベッドのはしから、手が一本、ぶらんと降りてきた。布団の、すぐ横に。"
    voice "audio/voice/hinata_a5_xmas_19.mp3"
    hinata "……今日は、泣いてないから、いらないか"
    menu:
        "その手を、にぎる":
            $ lean("仲間型")
            "手を伸ばして、降りてきた手を、ちゃんとにぎった。"
            "ひなたの手が、一回だけ、びくっとした。それから、ゆっくり、にぎり返してきた。幼稚園のときより、ずっと大きくて、ずっと冷たかった。"
            voice "audio/voice/hinata_a5_xmas_20.mp3"
            hinata "……泣いてないのに"
            ren "……今日は、こっちが、にぎりたかった"
            "ベッドの上で、ひなたが、布団を頭までかぶる音がした。手は、離れなかった。"
            voice "audio/voice/hinata_a5_xmas_21.mp3"
            hinata "……つめたいでしょ。ひざ当ての次は、手袋、編まなきゃ"
            "どっちの手も、それ以上は動かなかった。つないだまま、天井の四角い明かりを見ていた。"
            $ heart_up("ひなた", "ときめき", 6)
        "「……泣いてない」とだけ言う":
            $ lean("求道型")
            voice "audio/voice/hinata_a5_xmas_22.mp3"
            hinata "……知ってる"
            "手は、しばらく、そこにあった。それから、ゆっくり、ベッドの上に戻っていった。"
            voice "audio/voice/hinata_a5_xmas_23.mp3"
            hinata "……おやすみ。メリークリスマス"
            $ heart_up("ひなた", "ときめき", 2)
            $ heart_up("ひなた", "信頼", 2)
    if a4_heart_who == "ひなた":
        voice "audio/voice/hinata_a5_xmas_24.mp3"
        hinata "……ねえ。指切り、まだ有効だからね。蓮が勝ったら、言うってやつ"
        voice "audio/voice/hinata_a5_xmas_25.mp3"
        hinata "高3の選手権まで、言わない。……言わないけど"
    else:
        voice "audio/voice/hinata_a5_xmas_26.mp3"
        hinata "……ねえ。言いたいこと、あるんだけど。……まだ、言わない"
    "それきり、ひなたは何も言わなかった。しばらくして、寝息が聞こえてきた。"
    "ひざの上の毛糸が、あったかかった。なかなか、眠れなかった。"
    $ amb_stop()
    call a5_xmas_others
    return

## ── 千夏：受験の合間、駅前のツリー。記録じゃない一枚 ──────────────────────
label a5_xmas_chika:
    scene bg ren_room_morning
    with dissolve
    $ bgm("静かなピアノの旋律")
    $ se("トークアプリの通知音")
    window auto hide
    $ talk_start("千夏", "16:30")
    $ talk("千夏", "図書館で、過去問を解いています。閉館は6時です")
    $ talk("千夏", "6時5分に、駅前のツリーの前を通る予定です。……予定の報告です")
    $ talk_wait(4)
    $ talk_me("6時5分に、ツリーの前にいます")
    $ talk("千夏", "……報告を受けました")
    window auto hide
    $ talk_end()
    scene bg station_xmas_night
    with dissolve
    $ bgm("あたたかいアコースティックギター")
    "駅前のツリーは、去年より電球が増えていた。6時5分ちょうどに、灰色のコートの千夏先輩が、参考書の入ったトートバッグを肩にかけて現れた。"
    show chika normal
    with dissolve
    voice "audio/voice/chika_a5_xmas_01.mp3"
    chika "……本当に、いました"
    voice "audio/voice/chika_a5_xmas_02.mp3"
    chika "受験生なので、15分だけです。15分たったら、帰って、英語の長文を解きます"
    "先輩は、トートバッグから、カメラを出した。"
    voice "audio/voice/chika_a5_xmas_03.mp3"
    chika "一枚だけ、撮らせてください。……記録ではなく"
    voice "audio/voice/chika_a5_xmas_04.mp3"
    chika "記録は、本当のことを残すものです。でも、この一枚は、わたしが残したいから残すものです。……だから、記録には入れません"
    ren "……文化祭のときの、窓の写真と同じですか"
    show chika soft
    voice "audio/voice/chika_a5_xmas_05.mp3"
    chika "……覚えていたんですね"
    "先輩は、ツリーを背にした俺に、カメラを向けた。ファインダーをのぞいたまま、なかなかシャッターを押さなかった。"
    hide chika
    scene cg a5_xmas_chika
    with Dissolve(1.0)
    "シャッターの音がした。先輩は、カメラを下ろして、笑った。いつもの、記録係の顔じゃなかった。"
    voice "audio/voice/chika_a5_xmas_06.mp3"
    chika "……撮れました。わたしの、いちばん新しい宝物です"
    voice "audio/voice/chika_a5_xmas_07.mp3"
    chika "あ。今の、言わなかったことにしてください。受験生は、勉強のしすぎで、変なことを言います"
    menu:
        "「俺も、先輩を一枚撮っていいですか」":
            $ a5_xmas_answer = "photo"
            $ lean("仲間型")
            voice "audio/voice/chika_a5_xmas_08.mp3"
            chika "……わたしを、ですか"
            "先輩は、少し迷ってから、カメラを渡してくれた。重かった。三年分の重さだと思った。"
            "ファインダーの中の先輩は、ツリーの光で、メガネが光っていた。"
            voice "audio/voice/chika_a5_xmas_09.mp3"
            chika "……撮られる側は、慣れていません。どんな顔をしていましたか"
            ren "受験生の顔じゃなかったです"
            voice "audio/voice/chika_a5_xmas_10.mp3"
            chika "……それは、困ります。15分、過ぎています"
            "先輩は、そう言いながら、帰ろうとしなかった。"
            $ heart_up("千夏", "ときめき", 6)
            $ heart_up("千夏", "信頼", 3)
        "「受験、がんばってください。春に、先輩の笑った写真、見せてください」":
            $ a5_xmas_answer = "spring"
            $ lean("求道型")
            voice "audio/voice/chika_a5_xmas_11.mp3"
            chika "……春に"
            if a4_chika_call == "早瀬くん":
                voice "audio/voice/chika_a5_xmas_12_hy.mp3"
            else:
                voice "audio/voice/chika_a5_xmas_12.mp3"
            chika "はい。受かったら、春に、笑います。……落ちても、[a4_chika_call]の前では、たぶん、笑います"
            "先輩は、15分きっかりで、改札のほうへ歩いていった。一回だけ、振り返った。"
            $ heart_up("千夏", "ときめき", 4)
            $ heart_up("千夏", "信頼", 5)
    scene bg station_xmas_night
    with dissolve
    call a5_xmas_others
    return

## ── あげは：半分光るツリー。ファン、やめていい？ ───────────────────────────
label a5_xmas_ageha:
    scene bg ren_room_morning
    with dissolve
    $ bgm("のんびりした春の曲")
    $ se("トークアプリの通知音（連続）")
    window auto hide
    $ talk_start("あげは", "14:10")
    $ talk("あげは", "パイセン")
    $ talk("あげは", "ケーキ、買った。いちばん小さいやつ")
    $ talk("あげは", "商店街の、半分ツリー。5時")
    $ talk("あげは", "配信はしない。スマホも出さない。……マジで")
    $ talk_me("分かった")
    window auto hide
    $ talk_end()
    scene bg shotengai_eve
    with dissolve
    "商店街のツリーは、今年も、半分しか光っていなかった。"
    "あげはは、ツリーの前のベンチに座って、ケーキの箱をひざにのせていた。スマホは、コートのポケットに入れたまま、その日は一度も出さなかった。"
    show ageha normal
    with dissolve
    voice "audio/voice/ageha_a5_xmas_01.mp3"
    ageha "……来た。推し、来た"
    voice "audio/voice/ageha_a5_xmas_02.mp3"
    ageha "これ、商店街のケーキ屋の、いちばん小さいやつ。二人で食べたら、ちょうどなくなるサイズ"
    "ベンチに並んで、プラスチックのフォークで、ケーキを半分こした。あげはは、いちごを、俺のほうに寄せた。"
    show ageha serious
    if a4_heart_who == "あげは":
        voice "audio/voice/ageha_a5_xmas_03.mp3"
        ageha "……ねえ、パイセン。夏に、推しやめるかもって言ったじゃん"
        voice "audio/voice/ageha_a5_xmas_04.mp3"
        ageha "あれ、逆、って言ったじゃん？"
    else:
        voice "audio/voice/ageha_a5_xmas_05.mp3"
        ageha "……ねえ、パイセン。あたし最近、推しの見方が、分かんなくなってきた"
    voice "audio/voice/ageha_a5_xmas_06.mp3"
    ageha "……スマホ、一回も出さなかったの、初めてなんだよ。パイセンといるとき"
    voice "audio/voice/ageha_a5_xmas_07.mp3"
    ageha "撮ってないと、手が、ひまでさ。何していいか分かんない"
    "あげはは、急に立ち上がった。それから、俺の手首をつかんで、ベンチから引っぱり上げた。"
    voice "audio/voice/ageha_a5_xmas_08.mp3"
    ageha "こっち来て"
    "ツリーの、光っているほうの半分の前まで、引っぱっていかれた。あげはは、自分のマフラーをほどくと、ぐるっと、俺の首と自分の首に、まとめて一周巻いた。"
    hide ageha
    scene cg a5_xmas_ageha
    with Dissolve(1.0)
    voice "audio/voice/ageha_a5_xmas_09.mp3"
    ageha "はい。これで、二人とも、光ってるほうに入った"
    voice "audio/voice/ageha_a5_xmas_10.mp3"
    ageha "撮らないかわりに、こうしとく。……ちゃんと、覚えとくため"
    "マフラーの長さのぶんしか、離れられなかった。あげはは、ツリーを見上げたまま、こっちを見なかった。"
    voice "audio/voice/ageha_a5_xmas_11.mp3"
    ageha "あたし、ファン、やめていい？"
    "ツリーの、ついていないほうの電球が、風で、かちかち鳴った。"
    menu:
        "「……やめて、どうする」":
            $ a5_xmas_answer = "ask"
            $ lean("求道型")
            voice "audio/voice/ageha_a5_xmas_12.mp3"
            ageha "……それは、まだ言わない"
            voice "audio/voice/ageha_a5_xmas_13.mp3"
            ageha "パイセンの卒業式まで、言わない。推しの卒業の日に、推しじゃないって言うの。……エモくない？"
            "あげはは、笑った。笑いながら、マフラーの端で、目のはしを押さえた。"
            $ heart_up("あげは", "ときめき", 7)
            $ heart_up("あげは", "信頼", 3)
        "「マフラー、あげはが寒いだろ」と巻き直そうとする":
            $ a5_xmas_answer = "scarf"
            $ lean("仲間型")
            voice "audio/voice/ageha_a5_xmas_14.mp3"
            ageha "……は？　今、それ？"
            voice "audio/voice/ageha_a5_xmas_15.mp3"
            ageha "ほどかないで。寒くていいの。……ずるい。そういうの、推しポイントなんだけど。ファンやめにくくなるんだけど"
            "あげはは、マフラーの端を、ぎゅっと握ったまま、離さなかった。"
            $ heart_up("あげは", "ときめき", 6)
            $ heart_up("あげは", "信頼", 4)
    scene bg shotengai_eve
    with dissolve
    call a5_xmas_others
    return

## ── だれからも誘われなかった：はやせ食堂で、部のクリスマス会 ─────────────────
label a5_xmas_team:
    scene bg shokudo_night
    with dissolve
    $ bgm("とぼけた日常の曲")
    "24日の夜、店を坂口が貸し切りにした。母さんに、勝手に頼んでいた。"
    sakaguchi "港北サッカー部、クリスマス会！　参加費は、コロッケ券！"
    "大門が、鍋焼きうどんを三杯食べた。赤坂が、倉田にプレゼント交換で負けて、本気で悔しがっていた。小早川は、ずっと、ケーキの切り方のノートを取っていた。"
    show takano casual
    with dissolve
    takano "……お前、今日、誰かに呼ばれなかったのかよ"
    ren "呼ばれてたら、ここにいない"
    takano "……そうか。俺もだ"
    "鷹野は、うどんの汁を、最後まで飲みほした。"
    hide takano
    with dissolve
    $ bond_up("鷹野", 2)
    $ bond_up("坂口", 3)
    $ bond_up("大門", 2)
    call a5_xmas_others
    return

## 冷えたヒロインの兆し（クリスマスの帰り道。選ばれた人のほかに）
label a5_xmas_others:
    if a5_xmas != "hinata" and flags.get("a5_柏木"):
        "帰り道、駅前で、白いニットのコートを見かけた。ひなただった。隣に、背の高い大学生がいた。"
        "ひなたは、笑っていた。俺のほうには、気づかなかった。"
        $ heart_up("ひなた", "さみしさ", 4)
    if a5_xmas != "chika" and flags.get("a5_相良"):
        "図書館の前を通ると、窓ぎわの席に、千夏先輩と相良さんが向かい合って座っていた。参考書を、一冊、二人でのぞきこんでいた。"
    if a5_xmas != "ageha" and flags.get("a5_推し変"):
        $ se("トークアプリの通知音")
        "あげはの部のアカウントが、新しい動画を上げていた。「鷹野パイセンのシュート集・クリスマス編」。再生回数が、いつもより多かった。"
    return


################################################################################
## 1月1日（土）：元日。初詣
################################################################################
label a5_newyear:
    scene black
    with dissolve
    $ set_cal("1月1日（土）", "夜明け前")
    $ coat_on()
    scene bg shrine_steps_night
    with dissolve
    $ bgm("静かな春の曲")
    "元日の夜明け前、母さんと、港の上の神社に行った。店の大晦日の出前が終わって、二人とも、三時間しか寝ていなかった。"
    show mother normal
    with dissolve
    haha "何、お願いした"
    if a5_surgery:
        ren "……右足で、踏み切れますように"
        haha "あたしは、あんたが、一人で抱えませんように。……お父さんにも、ついでに頼んどいた"
    else:
        ren "……夏まで、持ちますように"
        show mother sadsmile
        haha "あたしは、あんたが、痛いって言えますように。……毎年、同じこと頼んでる気がする"
    "石段を下りるとき、母さんが、俺の右側を歩いた。手すりのない側だった。"
    hide mother
    with dissolve
    $ up("メンタル", 1)
    return


################################################################################
## 1月10日（月）：3年の引退（桐生先輩・宮下先輩）。来年の春、1年生は入ってこない
################################################################################
label a5_retire:
    scene black
    with dissolve
    $ set_cal("1月10日（月・祝）", "練習のあと")
    $ coat_on()
    scene bg kohoku_ground_eve
    with dissolve
    $ bgm("静かな春の曲")
    "3年の、最後の練習の日だった。桐生先輩と宮下先輩が、グラウンドの真ん中に立った。"
    show kiryu jersey at gang(0.3)
    show miyashita jersey at gang(0.7)
    with dissolve
    kiryu "……冬まで、残ってよかった"
    miyashita "準決勝、勝てなかったけどね。ふふっ。……でも、2年の春まで名前だけの部員だったのに、最後の試合、一回も歩かなかったよ"
    kiryu "早瀬"
    "桐生先輩は、言葉を選ぶみたいに、少し黙った。"
    kiryu "……来年の夏、全国へ行け。それだけだ"
    hide kiryu
    hide miyashita
    with dissolve
    "二人がいなくなると、部員は、また一人ずつ減った。"
    "春になっても、入部届の箱は、もう使わない。港北の最後の1年生は、小早川たちだ。"
    "最後の世代、と誰かが言った。言われなくても、全員、分かっていた。"
    if a5_surgery:
        "その日、手術から3か月で、初めて、グラウンドを一周、ゆっくり走った。誰も見ていないと思ったら、全員、見ていた。"
        "一周して戻ってくると、坂口が、拍手をした。ひなたは、ストップウォッチを止めて、ノートに何か書いていた。"
        $ up("フィジカル", 2)
    else:
        "冬の練習は、走りこみが中心になった。黒田は、俺にだけ、走る本数を半分にした。半分でも、ひざは、朝、重かった。"
        $ up("無理ゲージ", 2)
    return


################################################################################
## 2月14日（月）：バレンタイン
##   ときめきがいちばん高い一人が、場面。ほかに、しきい値をこえている人は一言
################################################################################
label a5_valentine:
    scene black
    with dissolve
    $ set_cal("2月14日（月）", "放課後")
    $ coat_on()
    python:
        a5_val = ""
        _best = 0.0
        _others = []
        for _nm, _id in (("ひなた", "hinata"), ("千夏", "chika"), ("あげは", "ageha")):
            _v = heart.get(_nm, {}).get("ときめき", 0)
            _need = A5_VAL_NEED[_nm]
            if _v >= _need:
                _others.append(_id)
                if float(_v) / _need > _best:
                    _best = float(_v) / _need
                    a5_val = _id
        if a5_val in _others:
            _others.remove(a5_val)
        a5_val_others = _others
    scene bg kohoku_gate_winter
    with dissolve
    $ bgm("とぼけた日常の曲")
    "バレンタインの日の港北は、男子が全員、朝から、どこか落ち着かなかった。"
    sakaguchi "蓮、聞いて！　俺、今年、2個！　1個はじいちゃんからだけど！"
    "大門は、クラスの女子から義理チョコをもらって、三回お礼を言っていた。鷹野は、下駄箱に入っていた四つを、全部、無言でカバンに入れた。"
    if "hinata" in a5_val_others:
        "朝、部室のロッカーに、小さな袋が入っていた。メモに「テーピングのお礼。今年も」。ひなたの字だった。"
        $ heart_up("ひなた", "ときめき", 2)
    if "chika" in a5_val_others:
        "昼休み、生徒会室の前を通ると、千夏先輩が、ドアのすきまから小さな箱を出した。「受験の、願かけの、あまりです」。それだけ言って、ドアを閉めた。"
        $ heart_up("千夏", "ときめき", 2)
    if "ageha" in a5_val_others:
        "あげはは、部員全員に、同じチョコを配っていた。俺のぶんだけ、リボンの色が、ちがった。"
        $ heart_up("あげは", "ときめき", 2)
    if a5_val == "hinata":
        call a5_val_hinata
    elif a5_val == "chika":
        call a5_val_chika
    elif a5_val == "ageha":
        call a5_val_ageha
    return

default a5_val_others = []

## ひなた：坂のベンチ。今年は、溶かしたまま（ホットチョコ）と、ノートの質問（作者の声 11/3「新しい感じに」）
label a5_val_hinata:
    scene bg slope_eve
    with dissolve
    $ bgm("あたたかいアコースティックギター")
    "練習のあと、坂の途中のベンチで、ひなたが待っていた。ひざの上に、水筒を一本のせていた。"
    show hinata normal
    with dissolve
    if a4_valentine == "hinata":
        voice "audio/voice/hinata_a5_val_01.mp3"
        hinata "今年は、固めてないの。……去年、溶かして固めたでしょ。今年は、溶かしたまま。ホットチョコにしてきた"
    else:
        voice "audio/voice/hinata_a5_val_02.mp3"
        hinata "今年は、固めてないの。……溶かして、ホットチョコにしてきた"
    "水筒のふたに注がれたチョコから、湯気が、坂の上のほうへ流れていった。"
    hide hinata
    scene cg a5_val_hinata
    with Dissolve(1.0)
    voice "audio/voice/hinata_a5_val_03.mp3"
    hinata "飲んでるあいだ、ノートの質問に答えて。……今日は、ひざのノートじゃないやつ"
    "ひなたが開いたのは、見たことのない、うす緑のノートだった。表紙には、何も書いていなかった。"
    voice "audio/voice/hinata_a5_val_04.mp3"
    hinata "質問1。いちばん好きな季節"
    ren "……夏"
    voice "audio/voice/hinata_a5_val_05.mp3"
    hinata "知ってた。質問2。いちばん好きな、食堂のメニュー"
    ren "からあげ定食"
    voice "audio/voice/hinata_a5_val_06.mp3"
    hinata "知ってた。……知ってることしか、聞いてない"
    "ひなたは、ペンの先で、ノートのはしを、とんとんとたたいた。"
    voice "audio/voice/hinata_a5_val_07.mp3"
    hinata "……質問3。来年の今日も、ここで、これ飲む？"
    menu:
        "「飲む。来年も、再来年も」":
            $ lean("仲間型")
            "ひなたのペンが、止まった。"
            voice "audio/voice/hinata_a5_val_08.mp3"
            hinata "……その次の年は、聞いてない"
            voice "audio/voice/hinata_a5_val_09.mp3"
            hinata "でも、書いとく。……質問にないことまで答えるの、ずるいから、太字で"
            "ひなたは、マフラーに顔を半分うずめたまま、ノートに、ゆっくり何か書いた。見せてくれなかった。"
            $ heart_up("ひなた", "ときめき", 6)
            $ heart_up("ひなた", "信頼", 1)
        "「ひなたが持ってくるなら」":
            $ lean("求道型")
            voice "audio/voice/hinata_a5_val_10.mp3"
            hinata "……持ってくる。ぜったい"
            voice "audio/voice/hinata_a5_val_11.mp3"
            hinata "じゃあ、答えは「ひなた次第」って書いとく。……ふふ。いい答え"
            "ひなたは、水筒をぎゅっと抱えた。湯気の向こうで、眉毛が、下がっていた。"
            $ heart_up("ひなた", "ときめき", 5)
            $ heart_up("ひなた", "信頼", 2)
    voice "audio/voice/hinata_a5_val_12.mp3"
    hinata "……そのノートの名前、まだ決めてないの。決まったら、教えるね。……たぶん、だいぶ先"
    scene bg slope_eve
    with dissolve
    return

## 千夏：夜の生徒会室。入試の前の日
label a5_val_chika:
    scene bg student_council_night
    with dissolve
    $ bgm("静かなピアノの旋律")
    "練習のあと、生徒会室に明かりがついていた。千夏先輩は、明日が、大学の入試だった。"
    show chika normal
    with dissolve
    voice "audio/voice/chika_a5_val_01.mp3"
    chika "……入っていいとは、言っていません。でも、出ていけとも、言いません"
    "机の上の参考書の上に、小さな箱が、まっすぐ置いてあった。"
    hide chika
    scene cg a5_val_chika
    with Dissolve(1.0)
    voice "audio/voice/chika_a5_val_02.mp3"
    chika "今日は、2月14日です。明日は、2月15日です。……わたしの中では、明日のほうが大事な日の、はずでした"
    voice "audio/voice/chika_a5_val_03.mp3"
    chika "でも、今日、この箱を渡せないまま明日を迎えたら、たぶん、英語の長文が、一行も読めません"
    voice "audio/voice/chika_a5_val_04.mp3"
    chika "……なので、受け取ってください。わたしの入試のために"
    menu:
        "「先輩の入試のために、受け取ります」":
            $ lean("仲間型")
            voice "audio/voice/chika_a5_val_05.mp3"
            chika "……ありがとうございます。これで、長文が、読めます"
            "先輩は、言ってから、参考書で顔をかくした。参考書は、逆さまだった。"
            $ heart_up("千夏", "ときめき", 5)
            $ heart_up("千夏", "信頼", 2)
        "「入試のためだけ、ですか」":
            $ lean("求道型")
            voice "audio/voice/chika_a5_val_06.mp3"
            chika "……ちがいます"
            if a4_valentine == "chika":
                "先輩は、去年の雪の旅館と同じ言い方をした。それから、同じように、続けた。"
            else:
                "先輩は、参考書のページを、意味もなくめくった。それから、小さな声で、続けた。"
            voice "audio/voice/chika_a5_val_07.mp3"
            chika "…………ちがわない、のは、3月1日に言います"
            $ set_flag("a5_千夏_3月に言う")
            $ heart_up("千夏", "ときめき", 6)
    scene bg student_council_night
    with dissolve
    return

## あげは：港北駅のホーム。両手で突き出す
label a5_val_ageha:
    scene bg kohoku_station_eve
    with dissolve
    $ bgm("のんびりした春の曲")
    "帰りの港北駅のホームで、あげはが、ベンチから立ち上がった。リボンの色が、昼のものとちがった。"
    show ageha normal
    with dissolve
    voice "audio/voice/ageha_a5_val_01.mp3"
    ageha "パイセン。……昼のは、みんなと同じやつ。リボンだけ変えたやつ"
    voice "audio/voice/ageha_a5_val_02.mp3"
    ageha "これは、ちがうやつ"
    hide ageha
    scene cg a5_val_ageha
    with Dissolve(1.0)
    "あげはは、箱を、両手で、まっすぐ突き出した。顔は、下を向いていた。"
    voice "audio/voice/ageha_a5_val_03.mp3"
    ageha "手作り。……推しに手作りって、重いって、ネットに書いてあった。でも、作った。三回失敗した"
    voice "audio/voice/ageha_a5_val_04.mp3"
    ageha "重かったら、ごめん"
    menu:
        "「重くない」と受け取る":
            $ lean("仲間型")
            voice "audio/voice/ageha_a5_val_05.mp3"
            ageha "……マジ？"
            "顔を上げたあげはは、いつものピースをしようとして、途中でやめた。かわりに、両手で、自分のほっぺたを押さえた。"
            voice "audio/voice/ageha_a5_val_06.mp3"
            ageha "……やば。今の、撮っとけばよかった。いや、撮らなくていい。覚えとく"
            $ heart_up("あげは", "ときめき", 6)
            $ heart_up("あげは", "信頼", 2)
        "「三回失敗したの、どうした」":
            $ lean("求道型")
            voice "audio/voice/ageha_a5_val_07.mp3"
            ageha "……全部、自分で食べた"
            voice "audio/voice/ageha_a5_val_08.mp3"
            ageha "失敗作も、推しのために作ったやつだから、捨てられなかったの。……おなか、いっぱい。パイセンのせい"
            $ heart_up("あげは", "ときめき", 4)
            $ heart_up("あげは", "信頼", 4)
    scene bg kohoku_station_eve
    with dissolve
    $ se("駅に着く音・ドアが開く音")
    return


################################################################################
## 2月14日の夜：黒田の過去（ほのめかすだけ。全部明かすのは第6章）
##   毎年、2月14日に届く、名前のない小包。11年分、開けていない
################################################################################
label a5_kuroda_past:
    scene black
    with dissolve
    $ set_cal("2月14日（月）", "夜・職員室", quiet=True)
    scene bg staffroom
    with dissolve
    $ bgm("静かな夜の曲")
    "忘れ物を取りに戻ると、職員室に、まだ明かりがついていた。黒田が、机の前に座っていた。寝ていなかった。"
    "机の上に、小さな小包が一つあった。青いリボン。潮見ブルーマリンズの青だった。"
    show kuroda normal
    with dissolve
    kuroda "……のぞくな"
    ren "チョコですか"
    kuroda "知らん。開けたことがない"
    "黒田は、机のいちばん下の引き出しを開けた。"
    scene bg a5_staff_drawer
    with dissolve
    "同じ青いリボンの小包が、きちんと並んでいた。一つ、二つ……十一。"
    kuroda "……毎年、今日、届く。28の年から。差出人の名前は、書いてない"
    kuroda "誰からかは、知ってる。……開けたら、返事をしなきゃならなくなる"
    "黒田は、今年の一つを、十二番目に並べて、引き出しを閉めた。"
    scene bg staffroom
    with dissolve
    show kuroda normal
    with dissolve
    if flags.get("黒田_ひざだけじゃない"):
        kuroda "ひざだけじゃない、と前に言ったな。……あのとき、俺が止まれなかったせいで、止まった足が、もう一本ある"
    else:
        kuroda "ひざで辞めた、と前に言ったな。……ひざだけじゃない。あのとき、俺が止まれなかったせいで、止まった足が、もう一本ある"
    kuroda "……今日は、ここまでだ"
    if a5_surgery:
        kuroda "お前は、10月に止まった。だから、ここまでは話した"
    elif a5_semi_towel == "go":
        kuroda "準決勝で、篠宮のタオルを見たな。……あれで、ここまでは話す気になった"
    else:
        kuroda "お前は、まだ止まれてない。……本当は、ここまでも話すつもりはなかった"
    kuroda "続きは、来年の夏が終わったら話す"
    hide kuroda
    with dissolve
    $ set_flag("a5_黒田_小包")
    return


################################################################################
## 3月1日（水）：千夏の卒業式
##   恋人（ときめき・信頼どちらも高い）／相棒（信頼が高い）／すれ違い（ときめきだけ高い）／ひとり
##   『港北の記録』の最後のページの写真
################################################################################
label a5_graduation:
    scene black
    with dissolve
    $ set_cal("3月1日（水）", "卒業式")
    scene bg kohoku_gate_march
    with dissolve
    $ bgm("静かな春の曲")
    "卒業式の朝の港北は、去年よりも、静かだった。卒業生も、在校生も、去年より少なかった。"
    "体育館で、卒業生の名前が、一人ずつ呼ばれた。"
    "千夏先輩の名前が呼ばれたとき、先輩は、背中をまっすぐにして、返事をした。マイクがなくても聞こえる声だった。"
    python:
        _t = heart.get("千夏", {}).get("ときめき", 0)
        _r = heart.get("千夏", {}).get("信頼", 0)
        _top = max(("ひなた", "千夏", "あげは"),
                   key=lambda nm: float(heart.get(nm, {}).get("ときめき", 0)) / A5_XMAS_NEED[nm])
        if _t >= A5_GRAD_LOVER[0] and _r >= A5_GRAD_LOVER[1] and _top == "千夏":
            a5_grad = "lover"
        elif _r >= A5_GRAD_PARTNER:
            a5_grad = "partner"
        elif _t >= A5_GRAD_MISS:
            a5_grad = "miss"
        else:
            a5_grad = "alone"
    if a5_grad == "lover":
        call a5_grad_lover
    elif a5_grad == "partner":
        call a5_grad_partner
    elif a5_grad == "miss":
        call a5_grad_miss
    else:
        call a5_grad_alone
    return

## ── 恋人：校門。最後のページ。「数えました」 ───────────────────────────────
label a5_grad_lover:
    scene bg kohoku_gate_march
    with dissolve
    $ bgm("あたたかいアコースティックギター")
    "式のあと、校門の前は、写真を撮る人でいっぱいだった。千夏先輩は、その輪から少し離れて、桜のつぼみの下に立っていた。"
    show chika normal
    with dissolve
    if a4_chika_call == "早瀬くん":
        voice "audio/voice/chika_a5_grad_01_hy.mp3"
    else:
        voice "audio/voice/chika_a5_grad_01.mp3"
    chika "……[a4_chika_call]。来てくれましたね"
    voice "audio/voice/chika_a5_grad_02.mp3"
    chika "頼みたいことがある、と言いました。……二つあります。一つ目から、言います"
    "先輩は、『港北の記録』を開いた。最後のページだけ、何も貼っていなかった。"
    voice "audio/voice/chika_a5_grad_03.mp3"
    chika "最後のページの写真を、いっしょに、撮ってください。……わたしと、あなたの、二人で"
    voice "audio/voice/chika_a5_grad_04.mp3"
    chika "記録係が、記録に写るのは、三年間で、初めてです"
    "先輩は、近くにいた1年の女子にカメラを渡した。それから、俺の隣に立った。半歩、離れて。"
    "1年の女子が、「もうちょっと寄ってくださーい」と言った。先輩は、半歩、寄った。"
    "撮った写真を、先輩は、その場で、最後のページに貼った。のりは、ポケットから出てきた。最初から、持ってきていたらしかった。"
    ## v0.32.3：一枚絵は、いま撮った二人の写真を最後のページに貼ったところ（作者の声「写真の蓮がだれ？」）。貼ったあとに出す
    hide chika
    scene cg a5_grad_chika
    with Dissolve(1.2)
    ## 写真が文字の枠でかくれるので、少しのあいだ枠を消して絵だけ見せる（クリックで次へ）
    window hide
    $ renpy.pause(3.0)
    voice "audio/voice/chika_a5_grad_05.mp3"
    chika "二つ目です"
    voice "audio/voice/chika_a5_grad_06.mp3"
    chika "……わたしの記録に、いちばん多く出てくるのは、あなたです"
    if flags.get("a5_千夏_数えない"):
        voice "audio/voice/chika_a5_grad_07.mp3"
        chika "数えたら、記録係として公平じゃなくなる、と言いました。……卒業したので、数えました。昨日の夜"
    else:
        voice "audio/voice/chika_a5_grad_08.mp3"
        chika "記録係は、数えてはいけないと思っていました。……卒業したので、数えました。昨日の夜"
    voice "audio/voice/chika_a5_grad_09.mp3"
    chika "四百十二枚です"
    "先輩の声が、そこで、ふるえた。"
    voice "audio/voice/chika_a5_grad_10.mp3"
    chika "記録は、本当のことしか書きません。だから、本当のことを言います"
    voice "audio/voice/chika_a5_grad_11.mp3"
    chika "わたしは、あなたが、好きです。……おととしの春、三好先輩が入部届を机に叩きつけた日。その後ろに立っていたあなたを見た日から、ずっと"
    menu:
        "「……俺もです。先輩が、好きです」":
            $ a5_grad_answer = "yes"
            $ lean("仲間型")
            ren "……俺もです。先輩が、好きです"
            "先輩は、目を、大きく開いた。それから、メガネを外して、手の甲で、目をこすった。"
            voice "audio/voice/chika_a5_grad_12.mp3"
            chika "……記録と、ちがいません"
            voice "audio/voice/chika_a5_grad_13.mp3"
            chika "春から、わたしは、県外です。遠いです。……それでも、いいですか"
            ren "遠いのは、慣れてないです。でも、記録します。毎日"
            voice "audio/voice/chika_a5_grad_14.mp3"
            chika "……それは、わたしの台詞です"
            "先輩は、『港北の記録』を、カメラのバッグにそっとしまった。両手が、空いた。"
            "次の瞬間、先輩が、一歩近づいた。気づいたときには、先輩の額が、俺の肩に当たっていた。背中に、細い腕が回っていた。"
            "校門のほうで、だれかが「あ」と言った。先輩は、離れなかった。"
            voice "audio/voice/chika_a5_grad_15.mp3"
            chika "……記録係なので、今のは、記録しません"
            voice "audio/voice/chika_a5_grad_16.mp3"
            chika "覚えておくだけに、します"
            "顔を上げた先輩は、笑っていた。クリスマスのツリーの前と同じ顔だった。それから、敬語を、やっと一つだけ外した。"
            voice "audio/voice/chika_a5_grad_17.mp3"
            chika "……蓮くん。よろしくね"
            $ heart_up("千夏", "ときめき", 10)
            $ heart_up("千夏", "信頼", 5)
            $ set_flag("千夏_恋人")
        "「……来年の夏まで、待ってもらえますか」":
            $ a5_grad_answer = "wait"
            $ lean("求道型")
            ren "……来年の夏まで、待ってもらえますか。最後の夏を走りきってから、ちゃんと答えたい"
            "先輩は、しばらく、俺の顔を見ていた。それから、ゆっくりうなずいた。"
            voice "audio/voice/chika_a5_grad_18.mp3"
            chika "……分かりました。待つのは、得意です。記録係なので"
            voice "audio/voice/chika_a5_grad_19.mp3"
            chika "でも、一つだけ。待つための、前払いをください"
            "先輩は、一歩近づいて、俺の背中に、そっと腕を回した。三秒くらいだった。数えていたのは、たぶん、先輩のほうだった。"
            voice "audio/voice/chika_a5_grad_20.mp3"
            chika "……はい。これで、夏まで待てます"
            voice "audio/voice/chika_a5_grad_21.mp3"
            chika "最後のページの裏を、空けておきます。来年の夏の答えを、貼るために"
            $ heart_up("千夏", "信頼", 6)
            $ heart_up("千夏", "ときめき", 3)
            $ heart_up("千夏", "さみしさ", 3)
            $ set_flag("千夏_夏まで")
    scene bg kohoku_gate_march
    with dissolve
    return

## ── 相棒：『港北の記録』を託される ──────────────────────────────────────
label a5_grad_partner:
    scene bg kohoku_gate_march
    with dissolve
    $ bgm("あたたかいアコースティックギター")
    "式のあと、千夏先輩は、サッカー部の全員を、校門の前に集めた。"
    show chika normal
    with dissolve
    voice "audio/voice/chika_a5_gradp_01.mp3"
    chika "最後のページの写真を、撮ります。港北サッカー部の、全員です"
    voice "audio/voice/chika_a5_gradp_02.mp3"
    chika "……真ん中は、早瀬くんです。……これは、記録係の、命令です"
    "坂口が、「俺、端っこでいいっす！」と言って、真ん中に割りこもうとして、鷹野に押し戻された。"
    "写真を撮り終わると、先輩は、『港北の記録』を、両手で俺に差し出した。"
    show chika soft
    voice "audio/voice/chika_a5_gradp_03.mp3"
    chika "頼みたいことです。……この続きを、書いてください"
    if flags.get("a5_千夏_3月に言う"):
        voice "audio/voice/chika_a5_gradp_04.mp3"
        chika "……2月に、今日言うと言ったこと。記録係として言えるのは、ここまでです"
    voice "audio/voice/chika_a5_gradp_05.mp3"
    chika "あなたたちは、11人で戦える最後の代です。その最後の一年の記録は、わたしには書けません"
    voice "audio/voice/chika_a5_gradp_06.mp3"
    chika "あなたが、書いてください。……わたしの、いちばん信頼している記録係に"
    menu:
        "「……預かります」":
            $ lean("仲間型")
            "受け取ると、重かった。三年分と、これからの一年分の重さだと思った。"
            voice "audio/voice/chika_a5_gradp_07.mp3"
            chika "……ありがとうございます。最後のページに、来年の夏の写真を、貼ってください"
            $ heart_up("千夏", "信頼", 8)
        "「あげはと、二人で書きます」":
            $ lean("求道型")
            voice "audio/voice/chika_a5_gradp_08.mp3"
            chika "……桃井さんと。いいと思います。あの子の動画は、写真より、うそをつきません"
            voice "audio/voice/chika_a5_gradp_09.mp3"
            chika "でも、字は、あなたが書いてください。あの子の字は、少し、まるすぎるので"
            $ heart_up("千夏", "信頼", 6)
            $ heart_up("あげは", "信頼", 2)
    $ set_flag("千夏_相棒_記録")
    scene bg kohoku_gate_march
    with dissolve
    return

## ── すれ違い：言いかけて、言わない ──────────────────────────────────────
label a5_grad_miss:
    scene bg kohoku_gate_march
    with dissolve
    $ bgm("静かなピアノ")
    "式のあと、千夏先輩を探した。校門の前の人ごみの中で、一度だけ、目が合った。先輩のほうから、歩いてきた。"
    show chika normal
    with dissolve
    if a4_chika_call == "早瀬くん":
        voice "audio/voice/chika_a5_gradm_01_hy.mp3"
    else:
        voice "audio/voice/chika_a5_gradm_01.mp3"
    chika "[a4_chika_call]。卒業しました"
    voice "audio/voice/chika_a5_gradm_02.mp3"
    chika "頼みたいことがある、と言いました。……でも、やめます"
    ren "……え"
    voice "audio/voice/chika_a5_gradm_03.mp3"
    chika "あなたの答えが、わたしの記録のどこにも、ありませんでした。分からないものを、頼むことはできません"
    if flags.get("a5_千夏_3月に言う"):
        voice "audio/voice/chika_a5_gradm_04.mp3"
        chika "2月に、今日言うと言ったことも。……言わないことにしました"
    show chika soft
    voice "audio/voice/chika_a5_gradm_05.mp3"
    chika "……一つだけ。わたし、あなたのことが――"
    "先輩は、そこで、口を閉じた。メガネの奥で、一回だけ、まばたきをした。"
    show chika normal
    voice "audio/voice/chika_a5_gradm_06.mp3"
    chika "……いえ。記録にないことは、言いません。それが、わたしです"
    "先輩の後ろから、卒業生の輪が先輩を呼んだ。先輩は、振り返らずに、片手だけ上げて答えた。"
    voice "audio/voice/chika_a5_gradm_07.mp3"
    chika "最後のページは、空けたまま、持っていきます"
    voice "audio/voice/chika_a5_gradm_08.mp3"
    chika "お元気で。……夏の大会は、記録します。遠くからでも"
    hide chika
    with dissolve
    "桜のつぼみの下で、先輩の背中が、人ごみの中に消えた。一度も、振り返らなかった。"
    if flags.get("a5_相良"):
        "校門の外で、相良さんが、先輩の荷物を持って待っていた。"
    $ heart_up("千夏", "さみしさ", 6)
    $ set_flag("千夏_すれ違い")
    return

## ── ひとり：遠くから見る ──────────────────────────────────────────────
label a5_grad_alone:
    scene bg kohoku_gate_march
    with dissolve
    $ bgm("静かな春の曲")
    "式のあと、校門の前の人ごみを、少し離れたところから見ていた。"
    "千夏先輩は、生徒会の後輩たちに囲まれて、何枚も写真を撮られていた。撮られる側の先輩は、少し困った顔をしていた。"
    if flags.get("a5_相良"):
        "最後に、先輩は、相良さんと二人で一枚撮った。先輩は、そのときだけ、困った顔をしなかった。"
    else:
        "最後に、先輩は、自分のカメラで、誰もいない校門を一枚だけ撮った。それから、振り返らずに帰っていった。"
    "『港北の記録』の最後のページに何が貼られたのかは、知らないままだった。"
    $ set_flag("千夏_ひとり")
    return


################################################################################
## 第5章の終わり
################################################################################
label a5_end:
    scene black
    with dissolve
    $ set_cal("3月1日（水）", "夜")
    scene bg ren_room_night
    with dissolve
    $ bgm("静かな夜の曲")
    "机の上に、佐伯さんの名刺が、まだあった。8月から、一度も動かしていなかった。"
    if a5_surgery:
        "その横に、ひなたのノート「リハビリ」の、3冊目。表紙に「4月から、走る」。"
        mono "高2の冬を、手放した。"
        mono "そのかわり、右足で踏み切れる春が、来る。"
    else:
        "その横に、ひなたのノート「冬」。最後のページに、「止まった」が、何回も書いてあった。"
        mono "高2の冬を、取りにいった。"
        mono "手に入ったのは、1−2と、まだ切れていないひざだった。"
    if a5_grad == "lover":
        $ se("トークアプリの通知音")
        "スマホが鳴った。「蓮くん。今日の記録、四百十三枚目です」。写真は、校門の桜のつぼみだった。"
    elif a5_grad == "partner":
        "『港北の記録』を開いた。最後のページの、全員の写真の下に、まだ何も書いていなかった。"
        "ペンを持って、一行だけ書いた。「続きは、高3の夏」。"
    mono "高3の春が、来る。"
    mono "俺たちの、最後の一年。最後の世代の、最後の夏。"
    if a5_tell == "alone" and not flags.get("a5_母と決めた"):
        mono "一人で決めるのは、もうやめた。……やめた、つもりだった。"
    $ up("注目度", 2)
    call show_title("第5章　ひざ", "完")
    jump chapter6a
