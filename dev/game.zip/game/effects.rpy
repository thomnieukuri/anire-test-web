## effects.rpy ―― 試合シーンなどの演出
##   ・カメラの動き（寄る・流す・揺らす）
##   ・映画のような黒帯
##   ・スコアボード（時計は sb_set で決めた時間のまま止まっている。v0.31.0）
##   ・集中線
##   ・カットイン（名前の帯）
##   ・スローモーション（色が抜けて、ゆっくり寄る）
##   ・作戦ボード（マグネットと矢印が動いて、その瞬間の位置関係を見せる）
##   ・失点の帯（GOAL の帯と、新しいスコア）

################################################################################
## カメラの動き（一枚絵や背景に at で付ける）
################################################################################

## ゆっくり寄っていく
transform cam_push(t=10.0, z=1.08):
    subpixel True
    align (0.5, 0.5)
    zoom 1.0
    linear t zoom z

## 決めた場所（顔など）に向かって、ゆっくり寄る。x, y は 0.0〜1.0（左上が 0, 0）
transform cam_push_at(t=10.0, z=1.08, x=0.5, y=0.5):
    subpixel True
    align (x, y)
    zoom 1.0
    linear t zoom z

## 寄った状態から、ゆっくり引く
transform cam_pull(t=8.0, z=1.12):
    subpixel True
    align (0.5, 0.5)
    zoom z
    easeout t zoom 1.0

## 左から右へゆっくり流す（少し拡大して、はみ出した分を動かす）
transform cam_pan_r(t=10.0):
    subpixel True
    zoom 1.1
    yalign 0.5
    xalign 0.0
    linear t xalign 1.0

## 下から上へ見上げていく
transform cam_tilt_up(t=6.0):
    subpixel True
    zoom 1.15
    xalign 0.5
    yalign 1.0
    easein t yalign 0.0

## ぐっと寄る（一瞬で）
transform cam_snap(z=1.25, x=0.5, y=0.5):
    subpixel True
    align (x, y)
    zoom 1.0
    easeout 0.18 zoom z

## 小さく揺れ続ける（走っている、息が上がっている）
transform cam_jog:
    subpixel True
    align (0.5, 0.5)
    zoom 1.04
    block:
        ease 0.22 yoffset -5
        ease 0.22 yoffset 3
        repeat

## スローモーション：色が抜けて、ゆっくり寄る
transform slowmo(t=4.0):
    subpixel True
    align (0.5, 0.5)
    matrixcolor SaturationMatrix(1.0)
    zoom 1.0
    linear 0.6 matrixcolor SaturationMatrix(0.15)
    linear t zoom 1.1

## 一瞬だけ赤く
transform red_hit:
    matrixcolor TintMatrix("#ffffff")
    linear 0.05 matrixcolor TintMatrix("#ff7060")
    linear 0.5 matrixcolor TintMatrix("#ffffff")

## 強い揺れ（ぶつかった瞬間）
define hard_punch = Move((0, 14), (0, -14), .06, bounce=True, repeat=True, delay=.42)

################################################################################
## 黒帯（映画のような上下の黒い帯）
################################################################################

screen letterbox():
    zorder -10      # セリフ枠より下に出す
    add Solid("#000") xysize (1280, 64) at lb_top
    add Solid("#000") xysize (1280, 64) at lb_bottom

transform lb_top:
    ypos -64
    on show:
        easein 0.5 ypos 0
    on hide:
        easeout 0.5 ypos -64

transform lb_bottom:
    ypos 720
    on show:
        easein 0.5 ypos 656
    on hide:
        easeout 0.5 ypos 720

################################################################################
## スコアボード（上の黒帯の中の左上。v0.42.2 からテレビ中継の形）
##   時計は sb_set で決めた時間で止まっていて、勝手には進まない（v0.31.0：セリフやトークを読んでいるあいだに
##   時計だけ進んでいくのが不自然、という作者の声で、1秒ずつ進むのをやめた）
##   出す前に $ sb_set(...) で前半／後半、時間、点数、チームの色、チームの名前を決める。
##   例：$ sb_set("後半", 40, 12, 0, 1, "#7fc4e8", "#f2f2ee", "潮見FC", "桜嶺中")
##   名前は4文字まで（v0.29.3：色の四角だけでは、どっちがどこか分かりにくい、という作者の声で、名前を足した）
##       show screen scoreboard
##   試合の途中で点数や時間を変えるときも、$ sb_set(...) だけでよい（表示はそのまま変わる）
################################################################################

default sb_half = "前半"
default sb_sec = 0
default sb_home = 0
default sb_away = 0
default sb_home_color = "#7fc4e8"
default sb_away_color = "#f2f2ee"
default sb_home_name = "港北"
default sb_away_name = ""
## v0.43.0：ゴールのときに、スコアボードの右にのびるタブ（色, 得点者, チーム・学年）。None で出さない
default sb_tab = None
default sb_tab_n = 0
default sb_flash_on = False
default sb_tab_on = False

init python:
    def sb_set(half=None, mm=None, ss=0, home=None, away=None, home_color=None, away_color=None, home_name=None, away_name=None):
        if half is not None:
            store.sb_half = half
        if mm is not None:
            store.sb_sec = mm * 60 + ss
        if home is not None:
            store.sb_home = home
        if away is not None:
            store.sb_away = away
        if home_color is not None:
            store.sb_home_color = home_color
        if away_color is not None:
            store.sb_away_color = away_color
        if home_name is not None:
            store.sb_home_name = home_name
        if away_name is not None:
            store.sb_away_name = away_name

screen scoreboard():
    ## v0.42.2：テレビ中継のスコア表示の形にして、上の黒帯（高さ64）の中の左上に置いた（作者の声「一枚絵の顔と被る。現実と一緒で左上に」）。
    ##   ［前半 12'］［色｜港北］［1 - 0］［白浜工業｜色］の1行。絵には一切かぶらない
    zorder 45
    hbox at sb_in:
        xpos 22
        ypos 13
        ysize 38
        ## 時計（紺の箱）。時計は進まないので、分だけ出す
        frame:
            background Solid("#0b1f52")
            ysize 38
            padding (10, 0, 12, 0)
            hbox:
                yalign 0.5
                spacing 8
                text sb_half style "sb_half"
                text "{}'".format(sb_sec // 60) style "sb_min"
        ## 港北（白い板の左に、チームの色の帯）
        frame:
            background Solid("#fafaf6")
            ysize 38
            padding (0, 0, 12, 0)
            hbox:
                yalign 0.5
                spacing 9
                add Solid(sb_home_color) xysize (7, 38)
                text sb_home_name style "sb_name"
        ## 点数（黒い箱）
        frame:
            background Solid("#14181f")
            foreground (At(Solid("#ffffff"), sb_flash) if sb_flash_on else None)
            ysize 38
            padding (14, 0, 14, 0)
            text "[sb_home] - [sb_away]" style "sb_score" yalign 0.5 at sb_pulse(sb_home, sb_away)
        ## 相手（白い板の右に、チームの色の帯）
        frame:
            background Solid("#fafaf6")
            ysize 38
            padding (12, 0, 0, 0)
            hbox:
                yalign 0.5
                spacing 9
                text sb_away_name style "sb_name"
                add Solid(sb_away_color) xysize (7, 38)
        ## v0.43.0：ゴールのタブ（中継のスコア表示の「GOAL」。得点者の名前と学年。作者の声「名前、学年も出したい」）
        showif sb_tab_on and sb_tab:
            frame at sb_tab_in:
                background Solid(sb_tab[0] if sb_tab else "#000")
                ysize 38
                padding (14, 0, 16, 0)
                hbox:
                    yalign 0.5
                    spacing 12
                    text "GOAL" style "sb_goal" color (sb_tab_fg() if sb_tab else "#fff")
                    if sb_tab and sb_tab[1]:
                        text sb_tab[1] style "sb_name" color sb_tab_fg()
                    if sb_tab:
                        text sb_tab[2] style "sb_tabsub" color sb_tab_fg()
    if sb_tab_on:
        timer 3.8 action SetVariable("sb_tab_on", False)
    if sb_flash_on:
        timer 0.7 action SetVariable("sb_flash_on", False)

## 点が入ったとき、数字がぽんと大きくなる。
##   点数が変わると引数が変わるので、この動きが最初からやり直しになる（pause の長さはそのためのしかけ）
## v0.43.0：ゴールのとき、点数の箱が白く光る（goal() が sb_flash_on を立てて、0.7秒で下ろす）
transform sb_flash:
    alpha 0.85
    linear 0.55 alpha 0.0

transform sb_pulse(h=0, a=0):
    subpixel True
    pause (0.0001 * (h * 20 + a))
    zoom 1.7
    easein 0.45 zoom 1.0

transform sb_tab_in:
    on show:
        crop (0, 0, 0.0, 1.0) alpha 1.0
        easein 0.35 crop (0, 0, 1.0, 1.0)
    on hide:
        easeout 0.3 alpha 0.0

transform sb_in:
    on show:
        alpha 0.0 yoffset -20
        easein 0.4 alpha 1.0 yoffset 0
    on hide:
        easeout 0.4 alpha 0.0 yoffset -20

################################################################################
## 集中線（2枚を交互に出して、ちらつかせる）
################################################################################

image fx_speed:
    "gui/fx_speed_a.png"
    pause 0.08
    "gui/fx_speed_b.png"
    pause 0.08
    repeat

screen speedlines():
    zorder -5       # セリフ枠より下に出す（文字が読みにくくならないように）
    add "fx_speed" at speed_in

transform speed_in:
    on show:
        alpha 0.0 zoom 1.15 align (0.5, 0.5)
        easein 0.2 alpha 0.85 zoom 1.0
    on hide:
        easeout 0.3 alpha 0.0

################################################################################
## カットイン（斜めの帯に名前）
##   例：show screen cutin("神城 凌", "U-15 日本代表")
################################################################################

screen cutin(name, sub=""):
    zorder 46
    on "show" action Function(telop_sound)      # テロップが出たときの小さな音
    fixed at cutin_band:
        xysize (1500, 150)
        add "gui/fx_cutin.png"
        hbox:
            xpos 420
            yalign 0.5
            spacing 26
            text name style "cutin_name"
            if sub:
                text sub style "cutin_sub"

transform cutin_band:
    rotate -6
    rotate_pad False
    xpos 1280 ypos 345
    on show:
        easein 0.25 xpos -110
        linear 3.0 xpos -150
    on hide:
        easeout 0.25 xpos -1600

################################################################################
## 作戦ボード（要所で、ピッチを上から見た図を出す）
##   位置はメートルで書く。左から右へ 0〜105、上から下へ 0〜68。味方は右へ攻める。
##   （右へ攻めるとき、画面の下側が「右」、上側が「左」になる）
##
##   マグネット：("種類", "名前", (はじめの位置), (動いた先), 動き出すまでの秒, 動く秒)
##     種類 … "h" 味方 / "a" 相手 / "ren" 蓮（赤い輪） / "kami" 神城（金の輪） / "ball" ボール
##     動かないときは、動いた先を None にする。名前がいらないときは "" にする。
##   矢印：((始まり), (終わり), 出るまでの秒, 色)
##     色 … "w" 白（人の動き） / "y" 黄（味方のパス・シュート） / "r" 赤（危ない動き）
##
##   例：$ tactics(dots=[("ren", "蓮", (60, 38), (66, 40), 0.3, 0.8)],
##                 arrows=[((60, 38), (72, 54), 0.2, "y")], caption="前半39分　0−3")
##       $ tactics_off()
##   出したまま、もう一度 tactics(...) を呼ぶと、ボードはそのままで、変わったマグネットだけが動き直す。
##   文に合わせて動かすとき（v0.41.6）：1文目は tactics(dots=tb_still(D)) で止めておき、
##   次の文の前に tactics(dots=D) を呼ぶ（作者「次の文章に行ったら動いて欲しい」「字幕と合わせて動かして」）。
##   選択肢の前には、tactics_off() で消しておく（選択肢と重なるので）。
################################################################################

define TB_W = 660
define TB_H = 400
define TB_TOP = 104                     # スコアボードのすぐ下。下はセリフ枠の上まで
define TB_PITCH = (34, 30, 626, 370)    # board.png の中の、ピッチの白線（tools/make_tactics_assets.py と同じ）

init python:
    import math

    def tb_xy(p):
        """メートルの位置 → ボードの中の位置（ピクセル）"""
        x0, y0, x1, y1 = TB_PITCH
        return (int(x0 + p[0] * (x1 - x0) / 105.0), int(y0 + p[1] * (y1 - y0) / 68.0))

    def tb_arrows(arrows):
        """矢印を、点線のかけらと矢じりに分ける。始まりの側から順に出てくる"""
        out = []
        for a in arrows:
            p0, p1 = tb_xy(a[0]), tb_xy(a[1])
            delay = a[2] if len(a) > 2 else 0.0
            col = a[3] if len(a) > 3 else "w"
            dx, dy = p1[0] - p0[0], p1[1] - p0[1]
            L = math.hypot(dx, dy)
            if L < 4:
                continue
            ux, uy = dx / L, dy / L
            ang = math.degrees(math.atan2(dy, dx))
            start, end = 16.0, L - 18.0           # マグネットに重ならないよう、少しあける
            n = max(1, int((end - start) / 15.0))
            draw = 0.35 + L / 900.0                # 線が伸びきるまでの秒
            for i in range(n):
                t = start + (end - start) * (i + 0.5) / n
                out.append(("gui/tactics/dash_%s.png" % col, int(p0[0] + ux * t), int(p0[1] + uy * t),
                            ang, delay + draw * i / n))
            out.append(("gui/tactics/head_%s.png" % col, int(p0[0] + ux * (L - 11)), int(p0[1] + uy * (L - 11)),
                        ang, delay + draw))
        return out

    ## 名前 → 顔のマグネット（gui/tactics/face_<id>.png。tools/make_tactics_faces.py で作る）
    TB_FACE = {
        "蓮": "ren", "大門": "daimon", "三好": "miyoshi", "鷹野": "takano", "坂口": "sakaguchi",
        "小早川": "kobayakawa", "神城": "kamishiro", "桐生": "kiryu", "宮下": "miyashita",
        "江藤": "eto", "小池": "koike", "野口": "noguchi", "森": "mori",
        }

    def tb_dots(dots, home="navy"):
        """マグネットを、絵と位置の並びにする"""
        out = []
        for d in dots:
            kind, label, p0 = d[0], d[1], d[2]
            p1 = d[3] if len(d) > 3 and d[3] is not None else p0
            delay = d[4] if len(d) > 4 else 0.0
            dur = d[5] if len(d) > 5 else 0.6
            ring = None
            face = TB_FACE.get(label) if kind in ("h", "ren", "kami") else None
            if face and renpy.loadable("gui/tactics/face_%s.png" % face):
                ## 顔のマグネット（v0.41.1）。ふちの色で、港北・蓮・神城が分かる
                out.append(("gui/tactics/face_%s.png" % face, None, label, tb_xy(p0), tb_xy(p1), delay, max(0.01, dur)))
                continue
            if kind == "ball":
                img = "gui/tactics/ball.png"
            elif kind in ("a", "kami"):
                img = "gui/tactics/mag_white.png"
            else:
                img = "gui/tactics/mag_%s.png" % home
            if kind == "ren":
                ring = "gui/tactics/ring_ren.png"
            elif kind == "kami":
                ring = "gui/tactics/ring_kami.png"
            out.append((img, ring, label, tb_xy(p0), tb_xy(p1), delay, max(0.01, dur)))
        ## ボールは、いちばん上に重ねる
        out.sort(key=lambda o: o[0] == "gui/tactics/ball.png")
        return out

    def tb_still(dots):
        """動きを取った、はじめの位置だけのマグネット（v0.41.6。1文目は止めて、次の文で tactics(...) を呼んで動かす）"""
        return [(d[0], d[1], d[2]) for d in dots]

    def tactics(dots=(), arrows=(), caption="", home="navy"):
        """作戦ボードを出す（出ていれば、中身を入れかえる）"""
        renpy.show_screen("tactics_board", dots=list(dots), arrows=list(arrows), caption=caption, home=home)

    def tactics_off():
        renpy.hide_screen("tactics_board")

screen tactics_board(dots=[], arrows=[], caption="", home="navy"):
    zorder 40
    fixed at tb_in:
        xysize (TB_W, TB_H)
        xalign 0.5
        ypos TB_TOP
        add "gui/tactics/board.png"

        for img, x, y, ang, d in tb_arrows(arrows):
            add img at tb_dash(x, y, ang, d)

        for img, ring, label, p0, p1, d, t in tb_dots(dots, home):
            fixed at tb_move(p0, p1, d, t):
                xysize (48, 48)
                add img align (0.5, 0.5)
                if ring:
                    add ring align (0.5, 0.5)
                if label:
                    text label style "tb_label"

        if caption:
            frame:
                style "tb_caption_frame"
                text caption style "tb_caption"

transform tb_in:
    on show:
        alpha 0.0 yoffset 24 zoom 0.96
        easein 0.28 alpha 1.0 yoffset 0 zoom 1.0
    on hide:
        easeout 0.22 alpha 0.0 yoffset 16

## マグネットが、すべるように動く
transform tb_move(p0, p1, d=0.0, t=0.6):
    subpixel True
    anchor (0.5, 0.5)
    pos p0
    pause d
    ease t pos p1

## 矢印の点線は、ひとつずつ現れる
transform tb_dash(x, y, ang, d=0.0):
    subpixel True
    anchor (0.5, 0.5)
    pos (x, y)
    rotate ang
    alpha 0.0
    pause d
    linear 0.06 alpha 1.0

################################################################################
## ゴール（v0.43.0 からスコアボードのタブ。4秒ほどで勝手に消える）
##   例：$ goal("桜嶺B", away=1, mm=3)   …スコアボードも、ネットの音もいっしょに
################################################################################

init python:
    ## 得点者（港北の人）：表示する名前と、入学した年（学年は、そのときの年と月から数える）
    SCORER = {"蓮": ("早瀬 蓮", 2026), "鷹野": ("鷹野 迅", 2026), "大門": ("大門 剛", 2026), "三好": ("三好 大地", 2024),
              "坂口": ("坂口", 2026), "森": ("森", 2026), "小池": ("小池", 2026), "江藤": ("江藤", 2026), "野口": ("野口", 2026),
              "桐生": ("桐生", 2025), "宮下": ("宮下", 2025), "小早川": ("小早川 陸", 2027), "倉田": ("倉田", 2027), "赤坂": ("赤坂", 2027)}

    def school_year():
        mo = _month_of(store.cal_date)
        return store.cal_year - (1 if (mo is not None and mo < 4) else 0)

    def scorer_label(by, team):
        """(名前, 下の小さい字)。港北の人は「港北・1年」、相手は背番号や名前をそのまま（作者の声「相手はざっくりでよい」）"""
        if not by:
            return ("", team)
        if by in SCORER:
            nm, y = SCORER[by]
            g = max(1, min(3, school_year() - y + 1))
            return (nm, "%s・%d年" % (team, g))
        return (by, team)

    def sb_tab_fg():
        """タブの文字の色（白いユニフォームの相手なら、黒い字）"""
        c = (store.sb_tab or ("#000",))[0].lstrip("#")
        try:
            r, g, b = int(c[0:2], 16), int(c[2:4], 16), int(c[4:6], 16)
        except Exception:
            return "#ffffff"
        return "#14181f" if (r * 299 + g * 587 + b * 114) / 1000 > 150 else "#ffffff"

    def goal(team, home=None, away=None, mm=None, ss=0, by=None):
        """v0.43.0：帯をやめて、スコアボードの点数が光ってめくれ、右に「GOAL・得点者」のタブがのびる（中継の形）。
        by：得点者。港北の人は名字（"鷹野"）、相手は "9番" や "神城" のように見せたい字をそのまま"""
        sb_set(mm=mm, ss=ss, home=home, away=away)
        se("ネットが揺れる音")
        own = (team == store.sb_home_name) or (team == "港北")
        col = store.sb_home_color if own else store.sb_away_color
        nm, sub = scorer_label(by, team)
        store.sb_tab = (col, nm, sub)
        store.sb_tab_n += 1
        store.sb_flash_on = True
        store.sb_tab_on = True
        if not renpy.get_screen("scoreboard"):
            renpy.show_screen("scoreboard")
        renpy.restart_interaction()
        ## タブがのびるあいだに文字が先へ進まないよう、少しだけ止める（クリックで飛ばせる）
        renpy.pause(1.2)

## v0.42 までの斜めの帯（いまは使っていない。古いセーブの画面に残っていても困らないように、形だけ置いておく）
screen goal_banner(team="", home=0, away=0):
    zorder 46
    timer 3.8 action Hide("goal_banner")
    fixed at goal_band:
        xysize (1500, 150)
        add "gui/fx_cutin.png"
        hbox:
            xpos 330
            yalign 0.5
            spacing 34
            text "GOAL" style "goal_big" at goal_pop
            vbox:
                yalign 0.5
                spacing 0
                text team style "goal_team"
                text "[home] − [away]" style "goal_score"

transform goal_band:
    rotate -4
    rotate_pad False
    xpos 1280 ypos 250
    on show:
        easein 0.18 xpos -110
        linear 3.4 xpos -160
    on hide:
        easeout 0.2 xpos -1600

transform goal_pop:
    subpixel True
    zoom 1.5 alpha 0.0
    pause 0.1
    easein 0.22 zoom 1.0 alpha 1.0

################################################################################
## 勝利の帯（WIN の帯）。GOAL の帯より長く出して、ゆっくり消える
##   例：$ win("港北", "PK 4−3")
################################################################################

init python:
    def win(team, score):
        renpy.show_screen("win_banner", team=team, score=score)

screen win_banner(team="", score=""):
    zorder 46
    on "show" action Function(telop_sound)
    timer 3.6 action Hide("win_banner")
    fixed at win_band:
        xysize (1500, 170)
        add "gui/fx_cutin.png" yzoom 1.13
        hbox:
            xpos 330
            yalign 0.5
            spacing 34
            text "WIN" style "win_big" at goal_pop
            vbox:
                yalign 0.5
                spacing 0
                text team style "goal_team"
                text score style "goal_score"

transform win_band:
    rotate -4
    rotate_pad False
    xpos 1280 ypos 240
    on show:
        easein 0.25 xpos -110
        linear 3.2 xpos -150
    on hide:
        easeout 0.3 xpos -1600

################################################################################
## PK 戦の表（スコアボードの下に、5人ずつの〇×）
##   $ pk_reset("港北", "白浜工業")      … 表をからにして出す
##   $ pk_kick("home", True)            … 港北が決めた（False で外した）
##   $ pk_off()                         … 消す
################################################################################

default pk_names = ["", ""]
default pk_marks = [[], []]

init python:
    def pk_reset(home, away):
        store.pk_names = [home, away]
        store.pk_marks = [[], []]
        renpy.show_screen("pk_board")

    def pk_kick(side, ok, kick=True):
        """1本ぶんを表に書く。kick=True なら、蹴る音 → 少し間をあけて → 決まった（ネット）／外れた（鈍い音）"""
        if kick:
            se("ボールを蹴る音")
            renpy.pause(0.45, hard=True)
        i = 0 if side == "home" else 1
        m = [list(store.pk_marks[0]), list(store.pk_marks[1])]
        m[i].append(bool(ok))
        store.pk_marks = m
        se("ネットが揺れる音" if ok else "鈍い衝突音")

    def pk_off():
        renpy.hide_screen("pk_board")

screen pk_board():
    zorder 44
    frame at sb_in:
        style "pk_frame"
        vbox:
            spacing 4
            for i in (0, 1):
                hbox:
                    spacing 10
                    text pk_names[i] style "pk_name"
                    for k in range(max(5, len(pk_marks[0]), len(pk_marks[1]))):
                        if k < len(pk_marks[i]):
                            text ("○" if pk_marks[i][k] else "×") style ("pk_ok" if pk_marks[i][k] else "pk_ng")
                        else:
                            text "・" style "pk_wait"

################################################################################
## PK の1本（ゴールの正面の画面で、ボールがコースへ飛ぶ）
##   call pk_shot("home", "港北　1人目　鷹野", "mid_hi", "goal")
##     side   … "home"（港北が蹴る。相手のキーパー）／"away"（相手が蹴る。大門）
##     course … PK_TARGETS のコース（bl 左下・br 右下・tl 左上・tr 右上・mid_hi 真ん中の上 など）
##     result … "goal" 決まる／"save" 止められる／"post" ポストやバーに当たる・枠を外れる
##   〇×の表（pk_board）にも自動で書きこむ
################################################################################

image pk_ball = "gui/pk_ball.png"

define PK_TARGETS = {
    "away": {"bg": "bg pk_away_eve", "start": (640, 560), "z": 0.42,
             "bl": (395, 425), "br": (1110, 425), "tl": (390, 185), "tr": (1115, 185),
             "mid_hi": (760, 200), "mid": (760, 330), "post_r": (1196, 250), "over": (820, 30)},
    ## v0.32.2：味方が蹴る絵を、相手が蹴る絵と同じ距離・同じゴールの大きさに描き直した
    "home": {"bg": "bg pk_home_eve", "start": (640, 560), "z": 0.42,
             "bl": (395, 425), "br": (1110, 425), "tl": (390, 185), "tr": (1115, 185),
             "mid_hi": (760, 200), "mid": (760, 330), "bar": (980, 142), "over": (820, 30),
             "bl_center": (560, 425)},
}

transform pk_fly(x0, y0, x1, y1, z, t=0.38):
    subpixel True
    anchor (0.5, 0.5)
    pos (x0, y0) zoom 1.0 rotate 0
    linear t pos (x1, y1) zoom z rotate 540

transform pk_bounce(x0, y0, x1, y1, x2, y2, z, t=0.38):
    subpixel True
    anchor (0.5, 0.5)
    pos (x0, y0) zoom 1.0 rotate 0 alpha 1.0
    linear t pos (x1, y1) zoom z rotate 540
    parallel:
        easeout 0.45 pos (x2, y2)
    parallel:
        linear 0.45 rotate 900 zoom (z * 0.8)
    linear 0.15 alpha 0.0

screen pk_name(label=""):
    zorder 45
    frame at goal_pop:
        xpos 40
        ypos 112
        background Frame("gui/banner_tape.png", 20, 10)
        padding (26, 6, 26, 10)
        text label style "tb_caption"

screen pk_stamp(word="GOAL", good=True):
    zorder 46
    text word at pk_stamp_pop:
        style ("goal_big" if good else "pk_stamp_ng")
        xalign 0.5
        ypos 300

transform pk_stamp_pop:
    subpixel True
    anchor (0.5, 0.5)
    zoom 1.8 alpha 0.0
    easein 0.18 zoom 1.0 alpha 1.0

label pk_shot(side, label, course, result):
    python:
        _t = PK_TARGETS[side]
        _x0, _y0 = _t["start"]
        _x1, _y1 = _t[course]
        _z = _t["z"]
    scene expression _t["bg"] at cam_snap(1.04, 0.5, 0.4)
    with Dissolve(0.3)
    show screen pk_name(label)
    pause 0.7
    $ se("ボールを蹴る音")
    if result == "goal":
        show pk_ball at pk_fly(_x0, _y0, _x1, _y1, _z)
        pause 0.38
        $ se("ネットが揺れる音")
        $ renpy.with_statement(hpunch)
        show screen pk_stamp("GOAL", True)
    elif result == "save":
        show pk_ball at pk_bounce(_x0, _y0, _x1, _y1, _x1 + (160 if _x1 < 640 else -160), _y1 + 150, _z)
        pause 0.4
        $ se("鈍い衝突音")
        show screen pk_stamp("SAVE", False)
    else:
        show pk_ball at pk_bounce(_x0, _y0, _x1, _y1, _x1 + 220, _y1 - 160, _z)
        pause 0.4
        $ se("鈍い衝突音")
        show screen pk_stamp("NO GOAL", False)
    $ pk_kick(side, result == "goal", kick=False)
    pause 0.9
    hide screen pk_stamp
    hide screen pk_name
    hide pk_ball
    return

################################################################################
## 画面の真ん中に出す独白（黒い画面の上などで使う）
################################################################################

define mono = Character(None, what_style="mono_text", window_background=None,
                        window_yalign=0.5, window_xalign=0.5, ctc="ctc_blink", ctc_position="nestled")


################################################################################
## 文字のスタイル
##   フォントや色（FONT_JP_B・INK など）は screens.rpy で決めている。
##   ファイルは名前順に読み込まれ、このファイルは screens.rpy より先に読まれるので、
##   init 1 にして screens.rpy のあとで作る。
################################################################################

init 1:
    style sb_half:
        yalign 0.5
        font FONT_JP_B
        size 15
        color "#f2c84b"

    style sb_min:
        yalign 0.5
        font ("fonts/BebasNeue-Regular.ttf" if renpy.loadable("fonts/BebasNeue-Regular.ttf") else FONT_JP_B)
        size 30
        color "#ffffff"

    style sb_score:
        font ("fonts/BebasNeue-Regular.ttf" if renpy.loadable("fonts/BebasNeue-Regular.ttf") else FONT_JP_B)
        size 34
        color "#ffffff"

    style sb_goal:
        yalign 0.5
        font ("fonts/BebasNeue-Regular.ttf" if renpy.loadable("fonts/BebasNeue-Regular.ttf") else FONT_JP_B)
        size 30
        color "#ffffff"

    style sb_tabsub:
        yalign 0.5
        font FONT_JP_B
        size 14
        color "#ffffff"

    style sb_name:
        yalign 0.5
        font FONT_JP_B
        size 19
        color "#14181f"

    style cutin_rt:
        font FONT_JP_B
        size 18
        color PEN_RED
        yoffset -50

    style cutin_name:
        yalign 0.5
        font FONT_JP_B
        size 54
        color INK
        ruby_style style.cutin_rt
        line_leading 18

    style cutin_sub:
        yalign 0.5
        yoffset 6
        size 24
        color PEN_RED

    style tb_label:
        xalign 0.5
        ypos 44
        layout "nobreak"      # 3文字の名前（小早川など）が、マグネットの幅で改行されないように
        font FONT_JP_B
        size 17
        color "#ffffff"
        outlines [(3, "#1c2a1e", 0, 0)]

    style tb_caption_frame:
        xpos 22
        ypos -16
        background Frame("gui/banner_tape.png", 20, 10)
        padding (22, 4, 22, 8)

    style tb_caption:
        font FONT_JP_B
        size 21
        color INK

    style goal_big:
        yalign 0.5
        font FONT_JP_B
        size 92
        italic True
        color PEN_RED
        outlines [(4, "#fffaf2", 0, 0)]

    style win_big:
        yalign 0.5
        font FONT_JP_B
        size 104
        italic True
        color "#d8a21c"
        outlines [(5, "#fffaf2", 0, 0), (2, "#7a4a08", 0, 0)]

    style pk_frame:
        xalign 0.5
        ypos 108
        background Frame("gui/note_small.png", 14, 14)
        padding (26, 12, 30, 16)

    style pk_name:
        font FONT_JP_B
        size 20
        color INK
        min_width 112

    style pk_ok:
        font FONT_JP_B
        size 22
        color PEN_RED
        min_width 26
        text_align 0.5

    style pk_ng:
        font FONT_JP_B
        size 22
        color INK_SOFT
        min_width 26
        text_align 0.5

    style pk_wait:
        size 22
        color INK_SOFT
        min_width 26
        text_align 0.5

    style pk_stamp_ng:
        yalign 0.5
        font FONT_JP_B
        size 80
        italic True
        color "#eef2f6"
        outlines [(4, "#1e2a3a", 0, 0)]

    style goal_team:
        font FONT_JP_B
        size 24
        color INK_SOFT

    style goal_score:
        font FONT_JP_B
        size 44
        color INK

    style mono_text:
        font FONT_JP_B
        size 34
        color "#f4f1e8"
        xalign 0.5
        text_align 0.5
        outlines [(2, "#00000080", 0, 0)]
        ruby_line_leading 14
        ruby_style style.ruby_text


################################################################################
## 回想の小窓：昔の場面を、セピア色の小さな写真のように右上に重ねる
##   $ memory("cg daimon_pk")  ……出す
##   $ memory_off()            ……消す
################################################################################
init python:
    def memory(img, caption=""):
        renpy.show_screen("memory_window", img=img, caption=caption)
        renpy.with_statement(Dissolve(0.4))

    def memory_off():
        if renpy.get_screen("memory_window"):
            renpy.hide_screen("memory_window")
            renpy.with_statement(Dissolve(0.4))

screen memory_window(img, caption=""):
    zorder 20
    fixed at memory_in:
        xpos 1236
        ypos 48
        xanchor 1.0
        yanchor 0.0
        xysize (424, 279)
        add Solid("#f6f1e4")
        add Transform(img, matrixcolor=SepiaMatrix(tint="#ffeec2") * BrightnessMatrix(0.04), xysize=(400, 225), fit="cover") pos (12, 12)
        if caption:
            text caption size 18 color "#6b5a44" font FONT_JP_B xalign 0.5 ypos 244

transform memory_in:
    on show:
        alpha 0.0 rotate -1.5 yoffset 12
        easein 0.45 alpha 1.0 rotate -3.0 yoffset 0
    on hide:
        easeout 0.35 alpha 0.0 yoffset -8

## 照明：同じ背景のまま、時間がたって暗くなる（または少し明るくなる）
##   scene bg gym_night at lights(-0.12)
transform lights(b=-0.1):
    matrixcolor BrightnessMatrix(b)

## 小物のアップ：一枚絵を、ゆっくり寄りながら見せる（ひざ、写真、ボールなど）
transform item_close:
    xalign 0.5 yalign 0.5 zoom 1.0
    linear 8.0 zoom 1.05
