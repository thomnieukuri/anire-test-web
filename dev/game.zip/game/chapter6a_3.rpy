## chapter6a_3.rpy ―― 第6章（ルートA）の③：11月の選手権予選決勝・港北 対 桜嶺（v0.33.0・Claude の第1稿）
##   11/11 前夜：黒田が、佐伯さんとの十二年と、青いリボンの小包のことを話す → 運命の選択③「最初から出る／ベンチから後半に懸ける」
##   11/12 朝：揺れる場面②（付き合っている人がいないとき）→ ひなたのテーピング → 決勝
##   決勝は必ず勝つ（作者の決定 11/4。正史）。勝ち方（2−1 の決める人／PK）と、蓮が最後までピッチにいるかが分かれる
##   後半20分：鬼塚の合図で真壁が蓮の右ひざを狙い、神城が間に入って左足首で受ける。蓮には「神城のファウル」にしか見えない
##   ひざの再発：最初から出て、手術をしておらず、無理ゲージが A6_KNEE_BREAK 以上だと、後半38分にひざが止まる（勝ちはベンチで聴く）

define A6_KNEE_BREAK = 70

default a6_start = ""             # 運命の選択③：full（最初から最後まで出る）/ bench（ベンチから始めて、後半に懸ける）
default a6_final = ""             # 決勝のスコア（"2−1" / "1−1（PK 5−3）"）
default a6_final_scorer = ""      # 決勝点：ren / takano / koba / pk
default a6_knee_broke = False     # 決勝で、ひざが止まったか（結末「ベンチの向こう側」へ）
default a6_final_react = ""       # 神城が倒れたあと：grab（つかみかかる）/ back（背を向けてプレーに戻る）
default a6_morning = ""           # 決勝の朝、持っていったもの：ひなた / 千夏 / あげは / ""（揺れる場面がなかった）
default a6_power = 0              # 決勝の判定を越えた数（勝ち方を決める）


label chapter6a_3:
    call a6_final_eve
    call a6_final_morning
    call a6_final
    call a6_final_after
    jump chapter6a_4


################################################################################
## 11月11日（土）：決勝の前夜。黒田と、十二年分の小包
################################################################################
label a6_final_eve:
    scene black
    with dissolve
    $ set_cal("11月11日（土）", "夜")
    scene bg a5_staff_drawer
    with dissolve
    $ bgm("重く静かな曲")
    "夜の職員室。黒田に呼ばれて行くと、机の上に、青いリボンの小包が、12個並べてあった。"
    show kuroda serious
    with dissolve
    kuroda "……前に言ったな。止まれなかったせいで、止まった足が、もう一本ある、と"
    kuroda "佐伯の、右ひざだ"
    scene cg a6_kuroda_box
    with Dissolve(1.0)
    kuroda "佐伯とは、潮見FCで、小5から一緒だった。二人とも、ブルーマリンズに入った。……あいつのほうが、うまかった"
    kuroda "28のとき、練習の紅白戦で、こぼれ球に二人で飛びこんだ。俺は、止まれた。止まらなかった。……勝ちたかったからだ"
    kuroda "佐伯のひざは、それで終わった。あいつは選手をやめて、スカウトになった。俺も、その年にやめた"
    kuroda "次の年の2月14日に、最初の小包が届いた。あいつが、引退した日だ"
    kuroda "……12年、一回も開けてない。開けたら、許される気がした。許されるのが、こわかった"
    if flags.get("a6_佐伯と黒田_聞いた"):
        "夏の終わりの夜、佐伯さんは「俺のひざは、もう怒ってない」と言っていた。黒田は、「だから開けられない」と言っていた。"
    kuroda "……今日、一個だけ、開ける。今年のやつだ"
    "黒田は、いちばん新しい小包のリボンを、ほどいた。中には、写真が一枚と、メモが一枚。"
    if a5_surgery:
        "写真は、去年の冬の準決勝の、俺だった。松葉杖で、黒田の隣に立っている俺。"
    else:
        "写真は、去年の冬の準決勝の、俺だった。ひざが止まって、芝に手をついている俺。"
    "メモには、佐伯さんの字で、一行。「見つけた。今度は、×をつけなかった」"
    kuroda "……毎年、一枚ずつ、入ってるんだろうな。あいつが見つけた、まだ蹴ってるやつの写真が"
    kuroda "壊したほうも、止まるんだよ、早瀬。……壊されたほうが、先に、歩き出してても"
    scene bg a5_staff_drawer
    with dissolve
    show kuroda normal
    with dissolve
    if a5_tell == "alone":
        kuroda "去年の秋、お前は、だれにも言わずに決めた。……今度は、俺に言え"
        kuroda "右ひざは、今、何点だ。10点満点で"
        menu:
            "本当の点数を言う":
                $ _knee_pt = 10 - min(9, hidden["無理ゲージ"] // 10)
                ren "……[_knee_pt]点です"
                kuroda "そうか。……言えたな"
                $ up("無理ゲージ", -4)
                $ set_flag("a6_黒田に点数を言った")
            "「8点です」と言う":
                ren "……8点です"
                kuroda "……そうか"
                "黒田は、それ以上、聞かなかった。聞かなかったのが、いちばん重かった。"
    kuroda "明日の話だ。……お前に、決めさせる"
    kuroda "最初から最後まで出るか。ベンチから始めて、後半に懸けるか"
    kuroda "おととしは、11人しかいなかった。選べなかった。……今年は、選べる"
    if not a5_surgery and hidden["無理ゲージ"] >= A6_KNEE_BREAK:
        kuroda "言っておく。……今のお前のひざで90分走れば、どこかで止まる。俺の目は、そう言ってる"
    scene black
    with dissolve
    window auto hide
    tuto "ここは「運命の選択」です。決勝の戦い方と、この先の結末が変わります。"
    tuto "あとからは変えられません。迷ったら、選ぶ前にセーブしておきましょう。"
    call screen save_prompt
    menu:
        "最初から最後まで出る":
            $ a6_start = "full"
            $ lean("野心型")
            ren "最初から出ます。……一年の春から、決勝の最初の笛は、ピッチで聞くって決めてました"
            kuroda "……分かった。止まったら、止まれ。それだけは、約束しろ"
            $ up("無理ゲージ", 4)
        "ベンチから始めて、後半に懸ける":
            $ a6_start = "bench"
            $ lean("求道型")
            ren "ベンチから始めます。……前半、桜嶺を、外から見ます。後半の45分で、全部、返します"
            kuroda "……三年で、いちばん監督の仕事が楽な返事だ"
            $ up("無理ゲージ", -6)
            $ up("戦術眼", 2)
    $ set_flag("a6_運命の選択③")
    return

################################################################################
## 11月12日（日）朝：揺れる場面②と、ひなたのテーピング
################################################################################
label a6_final_morning:
    scene black
    with dissolve
    $ set_cal("11月12日（日）", "朝")
    scene bg stadium_gate_morning
    with dissolve
    $ bgm("張りつめた静かな曲")
    "決勝の会場は、一年の冬、準決勝で桜嶺に負けたのと、同じ県の競技場だった。門の前に、バスが着いた。"
    if not a6_lover:
        $ _sw = sway_pair(["ひなた", "千夏", "あげは"])
        if _sw:
            call a6_morning_sway
    ## テーピング
    scene bg locker_room
    with dissolve
    $ bgm("静かな緊張感のある曲")
    show hinata serious
    with dissolve
    "ロッカールームで、ひなたが、右ひざにテーピングを巻いた。18本のロールの、16本目だった。"
    if flags.get("a6_ひなた_10分"):
        voice "audio/voice/hinata_a6_tape_01.mp3"
        hinata "……10分ちょうだいって、言ったでしょ。巻きながら、言う"
    else:
        voice "audio/voice/hinata_a6_tape_02.mp3"
        hinata "……10分だけ、ちょうだい。巻きながら、言う"
    voice "audio/voice/hinata_a6_tape_03.mp3"
    hinata "三年前の冬、蓮がひざを壊した日、わたし、スタンドで、何もできなかった"
    voice "audio/voice/hinata_a6_tape_04.mp3"
    hinata "だから、勉強した。巻き方も、ノートも。……今日は、何かできる。それが、うれしいの"
    if a4_heart_who == "ひなた" or flags.get("ひなた_指切り"):
        voice "audio/voice/hinata_a6_tape_05.mp3"
        hinata "指切り、まだ有効だからね。……勝ったら、言う"
    else:
        voice "audio/voice/hinata_a6_tape_06.mp3"
        hinata "勝ったら、言いたいことがあるの。……今は、言わない。眉毛、見られたくないから"
    "最後の一周を巻き終えて、ひなたは、テーピングの上から、ひざを、手のひらで一回だけ押した。"
    show hinata smile
    voice "audio/voice/hinata_a6_tape_07.mp3"
    hinata "はい。いってらっしゃい"
    $ heart_up("ひなた", "信頼", 2)
    hide hinata
    with dissolve
    return

## 揺れる場面②：門の前で、2人が待っている
label a6_morning_sway:
    $ _sa, _sb = _sw
    "バスを降りたところで、二人に、同時に呼び止められた。"
    python:
        _gift = {"ひなた": "白いタオル", "千夏": "写真のお守り", "あげは": "手作りのお守り"}
        _gift_line = {
            "ひなた": ("「タオル。……去年の冬は、上げたけど、今日は、上げない。首にかけて、持ってって」" if a5_semi_towel == "go" else "「タオル。……首にかけて、持ってって。今日は、上げないから」"),
            "千夏": "「お守りです。中に、6月に清翔に勝った日の集合写真を入れました。……縁起がいいので」",
            "あげは": "「お守り。『必勝』って縫ったの、あたし。……字、ゆがんでるけど、気持ちはまっすぐ」",
        }
        _push = {
            "ひなた": "「……わたしのにして。10年、横にいたの、わたしだから」",
            "千夏": "「……わたしのを、持っていってください。今日だけは、ゆずりません」",
            "あげは": "「あたしのにしてよ、パイセン。……推しが、ほかの子のお守り持ってるとこ、配信に映したくないもん」",
        }
        _call = {"千夏": "千夏先輩"}
        _sa_call = _call.get(_sa, _sa)
        _sb_call = _call.get(_sb, _sb)
        _sa_gift = _gift[_sa]
        _sb_gift = _gift[_sb]
        _sa_line = _gift_line[_sa]
        _sb_line = _gift_line[_sb]
        _sa_push = _push[_sa]
        _sb_push = _push[_sb]
    "[_sa_call]は、[_sa_gift]を持っていた。[_sa_line]"
    "[_sb_call]は、[_sb_gift]を持っていた。[_sb_line]"
    "二人は、お互いの手の中を見た。……それから、どっちも、引かなかった。"
    "[_sa_call]が、一歩、前に出た。[_sa_push]"
    "[_sb_call]も、負けずに、一歩、前に出た。[_sb_push]"
    "……二人とも、知っている顔だった。相手も、同じ気持ちで、ここに立っていることを。"
    "ピッチに持っていけるのは、ベンチのカバンに入る、どちらか一つだった。"
    menu:
        "[_sa_call]の[_sa_gift]を持っていく":
            $ a6_morning = _sa
            $ sway_pick(_sa, _sb)
            "[_sa_call]の[_sa_gift]を受け取った。[_sb_call]は、自分の手の中のものを、そっとポケットにしまった。"
        "[_sb_call]の[_sb_gift]を持っていく":
            $ a6_morning = _sb
            $ sway_pick(_sb, _sa)
            "[_sb_call]の[_sb_gift]を受け取った。[_sa_call]は、自分の手の中のものを、そっとポケットにしまった。"
        "「両方、終わってから受け取る」":
            $ a6_morning = ""
            $ sway_none(_sa, _sb)
            ren "……両方、試合が終わってから受け取る。今は、何も持たないで行く"
            "二人とも、少しだけ、さみしそうに笑った。"
    return


################################################################################
## 11月12日（日）選手権予選決勝：港北 対 桜嶺学園
################################################################################
label a6_final:
    scene black
    with dissolve
    $ set_cal("11月12日（日）", "選手権予選決勝")
    scene bg stadium_stand_day
    with dissolve
    $ se("スタンドの応援（太鼓）")
    $ bgm("張りつめた静かな曲")
    "スタンドは、一年の春の何倍も埋まっていた。港北の側に、母さんとゆず。作業着の三好先輩。この春に卒業した、桐生と宮下。"
    if a6_lover == "千夏":
        "いちばん前の列に、千夏先輩。カメラを、もう構えていた。……恋人の顔で、記録係の顔をしていた。"
    elif a6_chika_reply == "end":
        "スタンドの奥に、カメラを下ろしたままの千夏先輩がいた。"
    else:
        "いちばん前の列に、千夏先輩。大学のカメラを、首から下げていた。"
    "スタンドの端に、色素の薄い短い髪の女の子が、一人で座っていた。……紗希だった。桜嶺の側でも、港北の側でもない場所に。"
    "ベンチの横で、あげはが、スマホをスタンドに固定した。画面の上に「LIVE」の赤い字。"
    ## 入場
    scene cg a6_final_entrance
    with Dissolve(1.0)
    $ bgm("見せ場の曲")
    "入場の通路で、桜嶺の列と、港北の列が並んだ。となりの列の、いちばん前に、神城がいた。"
    if a4_kamishiro == "final":
        ren "……返しに来た"
        "神城は、こっちを見ないまま、小さく「ああ」とだけ言った。"
    elif a4_kamishiro == "grab":
        "去年の春、あいつの胸ぐらを、つかんだ。神城は、今日も、こっちを見なかった。……見ないことに、少しだけ、ほっとした自分がいた。"
    else:
        "去年の春、この背中に、背を向けた。今日は、前を向いた。神城の左の足首に、白いテーピングが、見えた。"
    "神城のうしろに、真壁がいた。真壁だけが、まっすぐ、俺の右ひざを見ていた。"
    if a6_start == "bench":
        call a6_final_bench_first
    else:
        call a6_final_first_half
    call a6_final_halftime
    call a6_final_incident
    call a6_final_last
    return

## 前半（最初から出る）
label a6_final_first_half:
    $ se("キックオフの笛")
    $ sb_set("前半", 0, 0, 0, 0, "#2a5bd7", "#c9a227", "港北", "桜嶺")
    scene bg stadium_winter_eve at cam_jog
    with dissolve
    show screen letterbox
    show screen scoreboard
    $ bgm("緊迫した試合の曲")
    "笛が鳴った瞬間、真壁が、俺の右側に立った。"
    if flags.get("a6_真壁_右側"):
        "……黒田の言ったとおりだった。"
        "右側に来ると分かっていた。だから、最初の一本は、左で受けた。真壁の足が、半歩、空を切った。"
        $ _need1 = 68
    else:
        "右側に、ずっと、体を当てられた。右足に体重をのせるたびに、真壁の肩が来た。"
        $ _need1 = 72
    $ sb_set(mm=18)
    if check("戦術眼", _need1):
        "前半18分。真壁を右に引きつけたまま、左の小早川に戻した。小早川から、坂口のクロス。鷹野のヘディングは、バーの上だった。"
        "でも、桜嶺のベンチで、鬼塚が、初めて腕組みをほどいた。"
        $ a6_power += 1
    else:
        "前半18分。真壁に押されて、ボールを失った。桜嶺の速い縦パスが、港北の陣地に三本、続けて刺さった。"
    $ sb_set(mm=31)
    $ se("ボールを蹴る音")
    "前半31分。神城が、大門の前で、左足を振り抜いた。左足首にテーピングをした、その左足で。"
    $ goal("桜嶺", home=0, away=1, mm=31)
    with vpunch
    "0−1。神城は、喜ばなかった。ゴールの前で、一回だけ、左足首に手をやった。"
    $ se("前半終了の笛")
    hide screen scoreboard
    return

## 前半（ベンチから）
label a6_final_bench_first:
    $ se("キックオフの笛")
    $ sb_set("前半", 0, 0, 0, 0, "#2a5bd7", "#c9a227", "港北", "桜嶺")
    scene bg stadium_winter_eve
    with dissolve
    show screen scoreboard
    $ bgm("緊迫した試合の曲")
    "ベンチから見ると、真壁が、最初の笛からずっと、俺がいるはずの場所に立っているのが見えた。……右側だ。"
    "俺がいないと分かると、真壁は、一度だけ、ベンチのほうを見た。それから、鬼塚のほうを見た。"
    "鬼塚は、何も言わなかった。真壁は、しかたなく、小早川に体を当てに行った。"
    $ sb_set(mm=31)
    $ se("ボールを蹴る音")
    "前半31分。神城の左足のシュートが、大門の指先をこえた。0−1。"
    $ goal("桜嶺", home=0, away=1, mm=31)
    with vpunch
    "神城は、左足首に、一回だけ手をやった。……外から見ると、それが、はっきり見えた。"
    if check("戦術眼", 66):
        "神城は、左足で蹴るたびに、着地を右足でしていた。……かばっている。ベンチのメモに書いた。"
        $ a6_power += 1
    $ se("前半終了の笛")
    hide screen scoreboard
    return

## ハーフタイム：だれで取り返すか
label a6_final_halftime:
    scene bg locker_room
    with dissolve
    $ bgm("静かな緊張感のある曲")
    show kuroda board
    with dissolve
    kuroda "0−1だ。……おととしの春は、前半で0−3だった"
    kuroda "だれで取り返す。……早瀬、お前が決めろ"
    if a6_start == "bench":
        kuroda "後半から、お前が入る。赤坂と代わる"
    menu:
        "鷹野で取り返す":
            $ lean("仲間型")
            ren "鷹野です。……三年、俺の前を走ってくれた"
            $ _ht = "takano"
        "小早川で取り返す":
            $ lean("求道型")
            ren "小早川です。……あいつの「見ないパス」で、桜嶺の真ん中を割ります"
            $ _ht = "koba"
        "自分で取り返す":
            $ lean("野心型")
            ren "俺です"
            $ _ht = "ren"
            $ up("無理ゲージ", 2)
    hide kuroda
    with dissolve
    $ sb_set("後半", 45)
    show screen scoreboard
    scene bg stadium_winter_eve at cam_jog
    with dissolve
    $ bgm("試合の曲（終盤）")
    $ sb_set(mm=57)
    if _ht == "takano":
        "後半12分。鷹野を、桜嶺の最終ラインの裏へ。……三年、何百回も蹴ったボールを、もう一回だけ蹴った。"
        if check_bond("鷹野", 80):
            "鷹野は、振り向かなかった。振り向かずに、ボールが来る場所に、先にいた。"
            $ a6_power += 1
        else:
            "鷹野は、半歩遅れて、それでも、体ごと押しこんだ。"
        $ goal("港北", home=1, away=1, mm=57)
        with vpunch
        takano "……蓮！！　一年の春の、借りだ！！"
        $ _eq = "早瀬　→　鷹野（裏へ抜けて同点）"
    elif _ht == "koba":
        "後半12分。小早川が、首を三回振って、目を閉じたみたいな顔で、縦に蹴った。"
        if check("戦術眼", 72):
            "ボールは、桜嶺の二人のあいだを、まっすぐ割った。その先に、俺がいた。……小早川は、俺を、見ていなかった。"
            $ a6_power += 1
        else:
            "ボールは、少しだけ長かった。追いついたのは、坂口だった。"
        $ goal("港北", home=1, away=1, mm=57)
        with vpunch
        kobayakawa "……見ないで、出せました！"
        $ _eq = "小早川の「見ないパス」　→　同点"
    else:
        "後半12分。真壁を、右に背負ったまま、ボールを受けた。右足で、踏ん張った。"
        if check("技術", 72):
            "真壁の体が、離れた。左足で、ゴールの左すみ。"
            $ a6_power += 1
        else:
            if a6_start == "bench":
                "真壁に体を当てられながら、それでも打った。キーパーがはじいたボールを、鷹野が押しこんだ。"
            else:
                "真壁に体を当てられながら、それでも打った。キーパーがはじいたボールを、赤坂が押しこんだ。"
        $ goal("港北", home=1, away=1, mm=57)
        with vpunch
        $ _eq = "早瀬が真壁を背負って　→　同点"
        $ up("無理ゲージ", 3)
    "1−1。スタンドの港北の側が、地面ごと揺れた。"
    return

## 後半20分：鬼塚の合図、真壁、神城
label a6_final_incident:
    $ sb_set(mm=65)
    "後半20分。ボールが、タッチラインの外に出た。プレーが止まった、そのとき。"
    scene cg a6_onizuka_sign
    with Dissolve(0.6)
    "（桜嶺のベンチで、鬼塚が、腕組みのまま、右手の指を一本だけ立てた）"
    "（真壁の目が、港北のトップ下の、右ひざに落ちた）"
    scene bg stadium_winter_eve at cam_jog
    with dissolve
    "スローインから、こぼれ球が、俺の前に転がってきた。右足で、止めた。"
    $ se("スパイクが芝をえぐる音")
    "横から、真壁が、スパイクの裏を見せて飛びこんできた。……右ひざの高さに。"
    scene cg a6_kamishiro_block
    with hpunch
    "そのあいだに、だれかが、体ごと割りこんできた。"
    "神城だった。神城の肩が、横から、俺を突き飛ばした。真壁のスパイクがどこに入ったのかは、見えなかった。"
    $ se("鈍い衝突音")
    "芝の上に、転がった。顔を上げると、神城が、左足首を押さえてうずくまっていた。"
    $ se("笛の音")
    shinpan "桜嶺、10番！　イエロー！"
    "審判は、神城にカードを出した。……俺を、横から突き飛ばしたファウル。審判には、そう見えた。俺にも、そう見えた。"
    "また、か。三年前の冬と、同じだ。……あいつは、また、俺を倒した。"
    menu:
        "立ち上がって、神城につかみかかる":
            $ a6_final_react = "grab"
            $ lean("野心型")
            "立ち上がって、うずくまる神城の胸ぐらに、手をのばした。"
            "その手を、うしろから、鷹野がつかんだ。"
            takano "やめろ！　……お前がカードもらったら、終わりだ！"
            "神城は、何も言わなかった。胸ぐらをつかまれかけても、顔を上げなかった。"
            $ bond_up("鷹野", 3)
        "背を向けて、プレーに戻る":
            $ a6_final_react = "back"
            $ lean("求道型")
            "背を向けた。神城のほうは、見なかった。……見たら、止まる気がした。"
            $ up("メンタル", 2)
    "神城は、担架を断って、片足で歩いてピッチを出た。真壁は、神城のうしろ姿を見て、舌打ちをした。"
    "鬼塚は、ベンチで、腕を組み直しただけだった。"
    onizuka "……本物は、壊れない"
    "その言葉が、だれに向けたものなのか、俺には分からなかった。"
    "スタンドの端で、紗希が、立ち上がっていた。……「やっぱり」と、口が動いた気がした。"
    $ set_flag("正史_神城がかばった")
    return

## 最後の10分と、決着
label a6_final_last:
    $ sb_set(mm=80)
    $ bgm("試合の曲（終盤）")
    "後半35分。1−1のまま。神城のいない桜嶺は、それでも、強かった。"
    ## ひざが止まる：最初から出て、手術をしておらず、無理ゲージが高い
    if a6_start == "full" and not a5_surgery and hidden["無理ゲージ"] >= A6_KNEE_BREAK:
        $ sb_set(mm=83)
        $ se("スパイクが芝をえぐる音")
        "後半38分。右足で踏み切った瞬間、ひざが、止まった。去年の冬と、同じ止まり方だった。"
        "芝に、手をついた。ベンチで、ひなたが、立ち上がるのが見えた。"
        "黒田が、手を上げた。……止まったら、止まれ。約束だった。"
        "担架の上で、空を見た。一年の春の0−9の日と、同じ色の空だった。"
        $ a6_knee_broke = True
        $ up("無理ゲージ", 15)
        $ set_flag("a6_決勝でひざが止まった")
        hide screen scoreboard
        scene bg stadium_winter_eve
        with dissolve
        "ベンチで、氷をのせたまま、残りの7分を見た。"
        $ sb_set(mm=89)
        show screen scoreboard
        if check_bond("鷹野", 80):
            "後半44分。鷹野が、俺がいた場所から、ゴールの右すみへ。……ベンチを、一回だけ、振り返った。"
            $ goal("港北", home=2, away=1, mm=89)
            with vpunch
            $ a6_final = "2−1"
            $ a6_final_scorer = "takano"
        else:
            "後半44分。小早川が、俺がいた場所まで走って、そこから打った。ボールは、キーパーの手をはじいて、入った。"
            $ goal("港北", home=2, away=1, mm=89)
            with vpunch
            $ a6_final = "2−1"
            $ a6_final_scorer = "koba"
        jump a6_final_whistle
    menu:
        "怒りのまま、前へ出る":
            $ lean("野心型")
            "神城の顔が、頭から離れなかった。離れないまま、前へ出た。"
            $ _last_ok = check("技術", 74 - a6_power * 2)
            $ _last_who = "ren"
        "鷹野に預けて、走る":
            $ lean("仲間型")
            "ボールを、鷹野に預けた。預けて、走った。一年の春から、それしかしてこなかった。"
            $ _last_ok = check_bond("鷹野", 88 - a6_power * 2)
            $ _last_who = "takano"
        "待つ。桜嶺の足が止まる瞬間を":
            $ lean("求道型")
            "待った。桜嶺の選手の足が、神城の分だけ、少しずつ遅くなっていくのを。"
            $ _last_ok = check("メンタル", 72 - a6_power * 2)
            $ _last_who = "ren"
    $ sb_set(mm=88)
    if _last_ok:
        if _last_who == "takano":
            "後半43分。鷹野が、真壁を背負ったまま、ヒールで俺の前に落とした。……振り抜いた。"
        else:
            "後半43分。真壁の足が、半歩遅れた。その半歩で、足りた。右足で、ゴールの左上。"
        scene cg a6_final_goal
        with vpunch
        $ goal("港北", home=2, away=1, mm=88)
        "2−1。"
        "ネットが揺れたのを、見なかった。スタンドの音で、分かった。"
        $ a6_final = "2−1"
        $ a6_final_scorer = "ren"
        jump a6_final_whistle
    "後半43分のシュートは、ポストに当たった。……1−1のまま、延長に入った。延長の20分も、どちらも点を取れなかった。"
    hide screen scoreboard
    scene bg stadium_winter_eve
    with dissolve
    $ bgm("張りつめた静かな曲")
    "PK戦。港北の5人目は、俺だった。一年の夏、PKの5人目で、最後に蹴ったのも俺だった。"
    "大門が、桜嶺の3人目を止めた。真壁だった。"
    "4−3。5人目。……ボールを置いた。"
    $ se("ボールを蹴る音")
    $ se("ネットが揺れる音")
    $ a6_final = "1−1（PK 5−3）"
    $ a6_final_scorer = "pk"
    $ bond_up("大門", 4)
label a6_final_whistle:
    $ se("試合終了の笛")
    pause 1.0
    hide screen scoreboard
    hide screen letterbox
    $ bgm("見せ場の曲")
    ## 笛のあとは、4枚を順に見せる（マネージャー2人 → 大門 → 坂口 → 蓮と鷹野）
    scene cg a6_fw_managers
    with Dissolve(1.2)
    if a6_knee_broke:
        "笛が鳴ったとき、ベンチで、ひなたに肩をかりて立っていた。立てた。……立って、聞けた。"
        "ひなたの肩が、俺の腕からすり抜けた。あげはが、ひなたに飛びついていた。二人とも、制服のまま、声をあげて泣いていた。"
    else:
        "笛が鳴った。"
        "ベンチの前で、ひなたとあげはが、制服のまま抱き合っていた。二人とも、声をあげて泣いていた。"
    scene cg a6_fw_daimon
    with dissolve
    "大門が、ゴールの前で、両手を広げて、空に向かって吠えていた。"
    scene cg a6_fw_sakaguchi
    with dissolve
    "坂口が、泥だらけのひざをついて、鼻水まで垂らして泣いていた。……いちばんダサくて、いちばんかっこよかった。"
    "小早川が、来年7人になる後輩たちと、輪になって跳んでいた。"
    if a6_knee_broke:
        "鷹野が、ベンチまで歩いてきて、何も言わずに、右手を差し出した。握ると、思いきり握り返された。……手が、熱かった。"
    else:
        scene cg a6_fw_ren
        with dissolve
        "気づいたら、芝に倒れこんでいた。一年の冬、準決勝で倒れこんだのと、同じ芝だった。"
        "鷹野が、何も言わずに、右手を差し出した。握ると、思いきり握り返されて、芝から引っぱり起こされた。……手が、熱かった。"
    mono "港北、選手権予選、優勝。"
    mono "一年の春、11人ぎりぎりで始めた部が、桜嶺に勝った。"
    $ up("注目度", 12)
    $ up("メンタル", 3)
    $ bond_up("鷹野", 5)
    $ bond_up("大門", 4)
    $ bond_up("坂口", 4)
    $ bond_up("三好", 3)
    $ set_flag("正史_決勝勝利")
    return


################################################################################
## 決勝のあと：スタンドと、通路の神城
################################################################################
label a6_final_after:
    scene bg stadium_stand_day
    with dissolve
    $ bgm("あたたかいアコースティックギター")
    "スタンドの前に行くと、母さんが、手すりにつかまって泣いていた。ゆずが、その横で、母さんの背中をさすっていた。"
    yuzu "お兄ちゃん！　お母さん、ずっと泣いてて、試合、半分見てない！"
    haha "……見てたよ。全部、見てた"
    if a6_miyoshi == "zenkoku":
        "三好先輩が、作業着のまま、手すりを乗りこえそうになって、警備の人に止められていた。"
        miyoshi "全国だぞ、蓮！！　有効だったな、あれ！！"
    else:
        "三好先輩が、作業着のまま、手すりから身を乗り出していた。"
        miyoshi "蓮！！　……よく走った！！　三年、よく走った！！"
    if a6_chika_reply == "end":
        "千夏先輩は、スタンドの奥で、一回だけ、カメラを持ち上げて、下ろした。"
        jump a6_after_ageha
    show chika normal
    with dissolve
    if a4_merger == "zenkoku":
        if a6_chika_call == "早瀬くん":
            voice "audio/voice/chika_a6_fin_01_hy.mp3"
        else:
            voice "audio/voice/chika_a6_fin_01.mp3"
        chika "……約束、守りましたね。統合が決まった日に、[a6_chika_call]が言った「全国」"
        voice "audio/voice/chika_a6_fin_02.mp3"
        chika "記録に、書きます。今、書きます"
    else:
        voice "audio/voice/chika_a6_fin_03.mp3"
        chika "……記録しました。今日の一枚は、おととしの0−9の日と、同じ場所から撮りました"
    if a6_lover == "千夏":
        voice "audio/voice/chika_a6_fin_04.mp3"
        chika "……四百、何枚目かは、分からなくなりました。今日だけで、百枚、撮ったので"
        $ heart_up("千夏", "ときめき", 4)
    $ heart_up("千夏", "信頼", 2)
    hide chika
    with dissolve
label a6_after_ageha:
    show ageha normal
    with dissolve
    if flags.get("a6_相棒_あげは"):
        voice "audio/voice/ageha_a6_fin_01.mp3"
        ageha "配信、二万人見てた。……あたし、泣かないって約束したじゃん"
    else:
        voice "audio/voice/ageha_a6_fin_02.mp3"
        ageha "配信、二万人見てた。……あたし、"
    show ageha serious
    voice "audio/voice/ageha_a6_fin_03.mp3"
    ageha "……泣いた。手ぶれ、ひどい。でも、消さない。一生、回す"
    $ heart_up("あげは", "信頼", 2)
    hide ageha
    with dissolve
    ## 通路の神城
    scene bg stadium_gate_eve
    with dissolve
    $ bgm("静かなピアノ")
    "着替えて、通路に出た。向こうから、松葉杖の音がした。"
    show kamishiro pained
    with dissolve
    "神城だった。左足首に、氷のパックを巻いていた。"
    "目が合った。神城は、何も言わなかった。……俺も、何も言わなかった。"
    if a6_final_react == "grab":
        "三年前の冬から、言いたいことは、いくらでもあった。胸ぐらに、もう一回、手をのばしかけて、やめた。"
    else:
        "三年前の冬から、言いたいことは、いくらでもあった。でも、もう、ボールで言った。"
    "神城は、俺の横を、松葉杖で通り過ぎた。通り過ぎるとき、一回だけ、俺の右ひざを見た。"
    "……なんで、ひざを見たのか。分からなかった。"
    hide kamishiro
    with dissolve
    "通路の奥で、紗希が待っていた。神城に、何か短く言って、松葉杖の反対側に回った。二人は、こっちを振り返らなかった。"
    "そのうしろを、鬼塚が、黒いコートで通っていった。鬼塚は、俺の前で、一度だけ立ち止まった。"
    show onizuka normal
    with dissolve
    if a6_knee_broke:
        onizuka "……おめでとう。ベンチで聞く勝ちも、勝ちだ"
        "鬼塚は、それだけ言って、歩いていった。"
    else:
        onizuka "……おめでとう。今日は、壊れなかったな"
        "鬼塚は、それだけ言って、歩いていった。……「今日は」の意味は、分からなかった。"
    hide onizuka
    with dissolve
    python:
        _rows = [("スコア", a6_final + "（勝ち）"),
                 ("前半31分", "神城のゴール（左足）"),
                 ("後半12分", _eq),
                 ("後半20分", "神城が早瀬を突き飛ばす（神城にイエロー）。神城は負傷で交代")]
        if a6_final_scorer == "pk":
            _rows.append(("PK戦", "大門が真壁を止める。5人目の早瀬が決める"))
        elif a6_final_scorer == "ren":
            _rows.append(("後半43分", "早瀬の決勝点"))
        elif a6_final_scorer == "takano":
            _rows.append(("後半44分", "鷹野の決勝点（早瀬はひざが止まり、ベンチ）"))
        else:
            _rows.append(("後半44分", "小早川の決勝点（早瀬はひざが止まり、ベンチ）"))
        _memo = ("ひなた：いちばん新しいノートの、最後のページ。……「勝った」って書いた。字、ふるえてる"
                 if not a6_knee_broke else
                 "ひなた：「勝った」と「止まった」、両方書いた。……どっちも、ほんとだから")
    call screen match_report("選手権予選決勝　港北 対 桜嶺学園", _rows, _memo)
    $ bgm("（なし）")
    mono "全国大会へ。"
    mono "神城が、なぜ、あのとき割りこんできたのか。……俺は、それを、考えないことにした。"
    return
