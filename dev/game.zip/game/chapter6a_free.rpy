## chapter6a_free.rpy ―― 第6章（ルートA）の自由行動・練習の出来事・夜のトーク（v0.33.0・Claude の第1稿）
##   ① 5月（a6may）：5/8・5/10・5/12・5/13 の4日。インターハイ予選の前
##   ② 10月（a6oct）：10/2・10/4・10/6・10/7 の4日。最後の選手権の前
##   第4章の仕組み（chapter4a_free.rpy の a4_spots・chapter4a_night.rpy の a4_night_send）をそのまま使う
##   夜のトークのラベルは a4nc_<人>_a6may / a4nc_<人>_a6oct
##   ヒロインの行き先は、その人らしい能力も少し上がる（ひなた＝フィジカル・無理ゲージ−、千夏＝戦術眼、あげは＝技術）

init 1 python:
    A4_SPOTS["a6may"] = [
        ("roof", "屋上", 330, 45, "takano", "鷹野", "a6_may_takano"),
        ("clubroom", "部室", 600, 170, "kobayakawa", "2年生たち", "a6_may_club"),
        ("staff", "職員室", 480, 250, "kuroda", "黒田", "a6_may_kuroda"),
        ("slope", "港への坂道", 870, 330, "hinata", "ひなた", "a6_may_hinata"),
        ("station", "港北駅（土曜だけ）", 1050, 120, "chika", "千夏", "a6_may_chika"),
        ("shotengai", "商店街", 1170, 300, "ageha", "あげは", "a6_may_ageha"),
    ]
    A4_SPOTS["a6oct"] = [
        ("roof", "屋上", 330, 45, "takano", "鷹野", "a6_oct_takano"),
        ("clubroom", "部室", 600, 170, "daimon", "大門・坂口たち", "a6_oct_club"),
        ("staff", "職員室", 480, 250, "kuroda", "黒田", "a6_oct_kuroda"),
        ("slope", "港への坂道", 870, 330, "hinata", "ひなた", "a6_oct_hinata"),
        ("shokudo", "はやせ食堂", 850, 460, "mother", "母さん", "a6_oct_mother"),
        ("station", "港北駅", 1050, 120, "ageha", "あげは", "a6_oct_ageha"),
    ]

## 第6章の練習の出来事（PRACTICE_EVENTS_A4 に足す。practice_pick がそのまま拾う）
define A6_MONTHS = ("a6may", "a6oct")
init 1 python:
    PRACTICE_EVENTS_A4.extend([
        ("a6p_akasaka_shoot", "技術", A6_MONTHS),
        ("a6p_left_foot", "技術", A6_MONTHS),
        ("a6p_kurata_long", "フィジカル", A6_MONTHS),
        ("a6p_hinata_stopwatch", "フィジカル", A6_MONTHS),
        ("a6p_board_last", "戦術眼", A6_MONTHS),
        ("a6p_ageha_slow", "戦術眼", A6_MONTHS),
        ("a6p_pier_three", "メンタル", A6_MONTHS),
        ("a6p_daimon_voice", "メンタル", A6_MONTHS),
    ])


################################################################################
## 練習の出来事（短い場面。上がるのは信頼か絆だけ）
################################################################################
label a6p_akasaka_shoot:
    "シュート練習。赤坂が、こぼれ球ばかり狙って、ゴール前に立っていた。"
    show akasaka jersey
    with dissolve
    akasaka "先輩のシュート、だいたい、キーパーの右手に当たるんすよ。だから、ここにいます"
    ren "……それは、ほめてるのか"
    akasaka "めちゃくちゃ、ほめてます！"
    hide akasaka
    with dissolve
    return

label a6p_left_foot:
    "左足だけで、壁あてを百本。一年の春は、二十本で、ふくらはぎがつった。"
    "百本目は、右足と同じ音がした。……同じ音がするまで、三年かかった。"
    return

label a6p_kurata_long:
    "フィジカルの日。倉田が、ゴールキックを、ハーフウェーラインの向こうまで蹴った。"
    show kurata jersey
    with dissolve
    kurata "大門先輩に、追いつきたいんです。……来年、港北のゴールは、僕だけなので"
    hide kurata
    with dissolve
    $ bond_up("大門", 1)
    return

label a6p_hinata_stopwatch:
    "坂道ダッシュ。坂の上で、ひなたが、ストップウォッチを二つ持っていた。"
    show hinata normal
    with dissolve
    voice "audio/voice/hinata_a6_prac_01.mp3"
    hinata "一個は、タイム。もう一個は、蓮が「まだ行ける」って言ってから、ほんとに止まるまで"
    voice "audio/voice/hinata_a6_prac_02.mp3"
    hinata "……二個目のほうが、だんだん短くなってるよ。いいことだよ、それ"
    hide hinata
    with dissolve
    $ heart_up("ひなた", "信頼", 1)
    return

label a6p_board_last:
    "練習のあと、黒田のホワイトボードの前で、小早川と並んだ。11個の丸の外に、黒田が、小さな丸を一つ描いた。"
    show kuroda board
    with dissolve
    kuroda "これは、来年の港北だ。……お前たちが卒業したら、この丸は、7つになる"
    kuroda "7人で、どう戦うか。……小早川、それを、今年のうちに見ておけ"
    hide kuroda
    with dissolve
    return

label a6p_ageha_slow:
    "あげはが撮った練習の動画を、部室でスローにして見た。"
    show ageha normal
    with dissolve
    voice "audio/voice/ageha_a6_prac_01.mp3"
    ageha "ほら、ここ。パイセン、ボールもらう前に、首、四回振ってる。小早川くんは三回"
    voice "audio/voice/ageha_a6_prac_02.mp3"
    ageha "……推しの首の回数、数えてるマネ、県であたしだけだと思う"
    hide ageha
    with dissolve
    $ heart_up("あげは", "信頼", 1)
    return

label a6p_pier_three:
    scene bg harbor_sunset
    with dissolve
    "防波堤で、夕方の海を見ながら、三回だけ深呼吸をした。ピアノの音は、もう聞こえなかった。"
    "一年の春、ここで、一人でボールを蹴っていた。……今は、グラウンドに17人いる。"
    return

label a6p_daimon_voice:
    "メンタルの日。大門が、ゴール前で、ひとりで声を出す練習をしていた。"
    show daimon jersey
    with dissolve
    daimon "早瀬くん。僕、一年の春、声が小さすぎて、柔道部で「いないのか」って言われてたんです"
    daimon "今は、グラウンドの反対側まで届きます。……届くように、なりました"
    hide daimon
    with dissolve
    $ bond_up("大門", 1)
    return


################################################################################
## 5月の行き先
################################################################################

## 屋上：鷹野と、最後の夏
label a6_may_takano:
    scene bg rooftop
    with dissolve
    $ bgm("少しとがった曲")
    show takano normal
    with dissolve
    "屋上で、鷹野が、インターハイ予選の組み合わせ表を見ていた。準決勝の欄に、清翔学園の名前。"
    takano "……順当にいけば、準決勝で、また結城さんだ"
    takano "去年の冬、俺は、あの人の前で一点も取れなかった。……今年、取る"
    menu:
        "「二人で取ろう」":
            $ lean("仲間型")
            ren "二人で取ろう。……一年の春から、そういう約束だ"
            takano "……覚えてたのかよ"
            $ bond_up("鷹野", 4)
        "「お前が取れ。俺は消える」":
            $ lean("求道型")
            ren "お前が取れ。俺は、清翔の二人を連れて、消える"
            takano "……かっこつけやがって。でも、それ、たぶん効く"
            $ bond_up("鷹野", 3)
            $ up("戦術眼", 1)
    hide takano
    with dissolve
    return

## 部室：2年になった小早川たち
label a6_may_club:
    scene bg clubroom
    with dissolve
    $ bgm("明るい部活の曲")
    show kobayakawa jersey
    with dissolve
    "部室で、小早川と倉田と赤坂が、来年の練習メニューを書いていた。まだ一年先の話だった。"
    kobayakawa "先輩たちが卒業したら、僕らは7人です。紅白戦も、できません"
    kobayakawa "だから、今のうちに、7人でできる練習を、全部書いておこうと思って"
    if flags.get("a6_小早川に残す"):
        kobayakawa "……先輩、4月に「一個、残す」って言いましたよね。それ、もう決まりました？"
        ren "まだだ"
        kobayakawa "じゃあ、決まるまで、ここ、空けておきます"
        "小早川は、ノートの一番最後のページに、「早瀬先輩から」とだけ書いて、あとは白いままにした。"
    $ up("戦術眼", 1)
    hide kobayakawa
    with dissolve
    return

## 職員室：黒田と、佐伯さん
label a6_may_kuroda:
    scene bg staffroom
    with dissolve
    $ bgm("静かな緊張感のある曲")
    show kuroda normal
    with dissolve
    "職員室の黒田の机の引き出しが、少しだけ開いていた。青いリボンの小包が、ひとつ見えた。"
    kuroda "……見たな"
    ren "2月に、見ました。12個"
    kuroda "……数えてたのか"
    menu:
        "「佐伯さんからですか」":
            ren "……佐伯さんから、ですか"
            "黒田は、答えなかった。答えないまま、小包を、引き出しの奥に押しこんだ。"
            kuroda "夏が終わったら話す、と言ったはずだ。……それまで、待て"
            $ set_flag("a6_小包_聞いた")
        "何も聞かない":
            "聞かなかった。黒田は、少しだけ、肩の力を抜いた。"
            kuroda "……助かる"
    hide kuroda
    with dissolve
    return

## 港への坂道：ひなた
label a6_may_hinata:
    scene bg slope_eve
    with dissolve
    $ bgm("あたたかいアコースティックギター")
    show hinata normal
    with dissolve
    "坂道の途中で、ひなたが、理学療法の学校のパンフレットを読んでいた。来年の春に入る学校の。"
    voice "audio/voice/hinata_a6_may_01.mp3"
    hinata "……オープンキャンパス、7月なんだ。行ってみようと思う"
    voice "audio/voice/hinata_a6_may_02.mp3"
    hinata "蓮のひざのこと、ノートに書いてたら、もっとちゃんと知りたくなった。……蓮のせいだよ"
    menu:
        "「行けよ。聞きたいこと、山ほどあるだろ」":
            ren "行けよ。俺のひざで三年練習したんだ。先生に聞きたいこと、山ほどあるだろ"
            show hinata smile
            voice "audio/voice/hinata_a6_may_03.mp3"
            hinata "ふふ。……それ、質問コーナーで言っていい？「幼なじみのひざで三年練習しました」って"
            $ heart_up("ひなた", "ときめき", 3)
        "「そのころ、俺は、どこにいるんだろうな」":
            ren "……来年の春、俺は、どこにいるんだろうな"
            show hinata serious
            voice "audio/voice/hinata_a6_may_04.mp3"
            hinata "知らない。……でも、どこにいても、ひざは、わたしが見る。それは決めてる"
            $ heart_up("ひなた", "信頼", 3)
    $ up("フィジカル", 2)
    $ up("無理ゲージ", -2)
    hide hinata
    with dissolve
    return

## 港北駅（土曜だけ）：千夏
label a6_may_chika:
    scene bg kohoku_station_eve
    with dissolve
    $ bgm("静かな春の曲")
    show chika normal
    with dissolve
    "土曜の夕方、港北駅の改札から、千夏先輩が出てきた。大学のトートバッグに、カメラが入っていた。"
    if a6_lover == "千夏":
        voice "audio/voice/chika_a6_may_01.mp3"
        chika "……ただいま、です。蓮くん"
        voice "audio/voice/chika_a6_may_02.mp3"
        chika "大学の写真部、入りました。でも、撮りたいものは、こっちにしかなくて。だから、土曜は帰ってきます"
        "千夏先輩は、改札の前で、俺を一枚撮った。シャッターの音は、前より、少しだけ小さかった。"
        voice "audio/voice/chika_a6_may_03.mp3"
        chika "……四百二十枚目。数えるのは、やめられませんでした"
        $ heart_up("千夏", "ときめき", 4)
    elif a5_grad_answer == "wait":
        voice "audio/voice/chika_a6_may_04.mp3"
        chika "……待ってます、まだ。夏まで、って言いましたから"
        voice "audio/voice/chika_a6_may_05.mp3"
        chika "今日は、それを言いに来たんじゃありません。練習、見に来ただけです。……記録係なので"
        "千夏先輩は、カメラを構えて、すぐ下ろした。俺を撮るのは、夏まで我慢する、という顔だった。"
        $ heart_up("千夏", "信頼", 3)
    else:
        if a6_chika_call == "早瀬くん":
            voice "audio/voice/chika_a6_may_06_hy.mp3"
        else:
            voice "audio/voice/chika_a6_may_06.mp3"
        chika "[a6_chika_call]。……元・生徒会長が、元・記録係として、練習を見に来ました"
        if flags.get("千夏_相棒_記録"):
            voice "audio/voice/chika_a6_may_07.mp3"
            chika "『港北の記録』、続きは書いてくれていますか。……最後のページは、あなたの冬です"
        else:
            voice "audio/voice/chika_a6_may_08.mp3"
            chika "『港北の記録』、大学で、本にしようと思っています。最後のページは、まだ空けてあります"
        $ heart_up("千夏", "信頼", 3)
    $ up("戦術眼", 2)
    hide chika
    with dissolve
    return

## 商店街：あげは
label a6_may_ageha:
    scene bg shotengai_eve
    with dissolve
    $ bgm("とぼけた日常の曲")
    show ageha normal
    with dissolve
    "商店街のコロッケ屋の前で、あげはが、スマホを横にして構えていた。"
    voice "audio/voice/ageha_a6_may_01.mp3"
    ageha "パイセン、ちょうどいい。今、「推しの地元」の動画撮ってんの。ほら、コロッケ持って、こっち見て"
    menu:
        "コロッケを持って、カメラを見る":
            "コロッケを持って、カメラを見た。あげはは、三秒撮って、急に止めた。"
            show ageha serious
            voice "audio/voice/ageha_a6_may_02.mp3"
            ageha "……ちょ、今の、近すぎた。編集で使えない。あたしが無理"
            $ heart_up("あげは", "ときめき", 4)
        "「動画より、練習を撮れ」":
            ren "動画より、練習を撮れ。……清翔の左サイド、見たい"
            voice "audio/voice/ageha_a6_may_03.mp3"
            ageha "出た、真面目。……でも、そういうとこが推しなんだよなー。わかった、撮る"
            $ heart_up("あげは", "信頼", 3)
    $ up("技術", 2)
    hide ageha
    with dissolve
    return


################################################################################
## 10月の行き先
################################################################################

## 屋上：鷹野と、桜嶺
label a6_oct_takano:
    scene bg rooftop_winter
    with dissolve
    $ bgm("少しとがった曲")
    show takano normal
    with dissolve
    "屋上の風が、冷たくなっていた。鷹野は、桜嶺の試合の動画を見ていた。画面の中で、神城が、左足首をかばわずに走っていた。"
    takano "……あいつ、去年の冬より、速えぞ"
    takano "神城が、決勝に出てくる。……今度は、逃げねえだろ"
    if a4_kamishiro == "final":
        takano "お前、「決勝で返す」って言ったんだってな。……あいつに"
        takano "じゃあ、返せ。俺が、全部、お前の前に転がす"
        $ bond_up("鷹野", 4)
    elif a4_kamishiro == "grab":
        takano "去年、お前、あいつの胸ぐらつかんだだろ。……今度は、ボールで、つかめ"
        $ bond_up("鷹野", 3)
    else:
        takano "去年、お前、あいつに背中向けたろ。……決勝では、前を向け。あいつのほうを"
        $ bond_up("鷹野", 3)
    hide takano
    with dissolve
    return

## 部室：大門と坂口たち
label a6_oct_club:
    scene bg clubroom
    with dissolve
    $ bgm("明るい部活の曲")
    show daimon jersey at left
    show sakaguchi jersey at right
    with dissolve
    "部室で、大門と坂口たちが、一年の春の写真を見ていた。0−9で負けた日の、泥だらけの集合写真。"
    sakaguchi "うわ、俺ら、ひでえ顔！　これ、だれが撮ったんだっけ"
    daimon "七瀬先輩です。……あのとき、早瀬くんだけ、カメラを見てなかったんです"
    sakaguchi "なに見てたんだよ、蓮"
    menu:
        "「桜嶺のベンチ」":
            $ lean("野心型")
            ren "……桜嶺のベンチ"
            sakaguchi "一年のときから、ずっとそれかよ！　……いいぜ。今年、見返そうぜ"
            $ bond_up("坂口", 3)
        "「お前らの顔」":
            $ lean("仲間型")
            ren "……お前らの顔。辞めるなよって思って、見てた"
            "坂口は、写真を伏せて、天井を見た。森が、鼻をすすった。"
            sakaguchi "……辞めてねえよ。三年、辞めてねえ"
            $ bond_up("坂口", 4)
            $ bond_up("大門", 2)
    hide daimon
    hide sakaguchi
    with dissolve
    return

## 職員室：黒田と、最後の並び
label a6_oct_kuroda:
    scene bg staffroom
    with dissolve
    $ bgm("静かな緊張感のある曲")
    show kuroda board
    with dissolve
    kuroda "……桜嶺の真壁を、見たか"
    ren "去年の夏、俺をマークしたやつです"
    kuroda "今年は、マークじゃない。……鬼塚は、真壁を、お前の右側に置く"
    kuroda "右側だ。分かるな"
    "黒田は、それ以上言わなかった。ホワイトボードの、俺の丸の右に、小さな×を一つ書いて、すぐ消した。"
    $ up("戦術眼", 2)
    $ set_flag("a6_真壁_右側")
    hide kuroda
    with dissolve
    return

## 港への坂道：ひなた
label a6_oct_hinata:
    scene bg slope_eve
    with dissolve
    $ bgm("あたたかいアコースティックギター")
    show hinata normal
    with dissolve
    "坂道で、ひなたが、テーピングのロールを両手に持って、数えていた。"
    voice "audio/voice/hinata_a6_oct_01.mp3"
    hinata "決勝まで勝ったら、あと6試合。……6試合分、テーピング、買っておいた"
    voice "audio/voice/hinata_a6_oct_02.mp3"
    hinata "途中で負けたら、余るでしょ。余ったら、来年の倉田くんにあげる。……だから、余らせないで"
    menu:
        "「全部、使い切る」":
            ren "全部、使い切る"
            show hinata smile
            voice "audio/voice/hinata_a6_oct_03.mp3"
            hinata "うん！　……全部、わたしが巻くからね。最後の1本まで"
            $ heart_up("ひなた", "ときめき", 4)
        "「余ったら、お前の練習用にしろ。来年、学校で使うだろ」":
            ren "余ったら、お前の練習用にしろ。来年、学校で使うだろ"
            show hinata pout
            voice "audio/voice/hinata_a6_oct_04.mp3"
            hinata "……もう、そういうとこ。ちゃんと、わたしの来年まで考えてる"
            $ heart_up("ひなた", "信頼", 4)
    $ up("フィジカル", 2)
    $ up("無理ゲージ", -2)
    hide hinata
    with dissolve
    return

## はやせ食堂：母さん
label a6_oct_mother:
    scene bg shokudo_night
    with dissolve
    $ bgm("日常の静かな曲")
    show mother normal
    with dissolve
    "店を閉めたあと、母さんが、柱の父さんの写真の横に、新しい写真を一枚、画びょうでとめていた。"
    "インターハイ予選の、港北の集合写真だった。"
    if a6_lover == "千夏" or flags.get("千夏_相棒_記録"):
        haha "千夏ちゃんが、焼いて持ってきてくれたの。……お父さんの横、空いてたから"
    else:
        haha "あげはちゃんが、焼いて持ってきてくれたの。……お父さんの横、空いてたから"
    haha "決勝、見に行くからね。ゆずも連れて。……店は、閉める。張り紙、もう書いた"
    menu:
        "「来なくていい。……いや、来てくれ」":
            ren "来なくていい。……いや、来てくれ"
            show mother smile
            haha "どっちだい。……行くよ。最初から、行くつもりだった"
            $ up("メンタル", 2)
        "「ひざのこと、まだ心配か」":
            ren "……ひざのこと、まだ、心配か"
            show mother serious
            haha "心配だよ。一生、心配する。……でもね、心配してるって、言えるようになった。あんたも、あたしも"
            haha "それで、いいんだよ"
            $ up("メンタル", 2)
            $ up("無理ゲージ", -2)
    hide mother
    with dissolve
    return

## 港北駅：あげは
label a6_oct_ageha:
    scene bg kohoku_station_gate_eve
    with dissolve
    $ bgm("とぼけた日常の曲")
    show ageha normal
    with dissolve
    "港北駅の改札で、あげはが、決勝の会場までの乗りかえを、スマホでしらべていた。まだ1回戦も始まっていなかった。"
    voice "audio/voice/ageha_a6_oct_01.mp3"
    ageha "気が早い？　……推しの決勝の行き方、今から覚えとくのは、オタクのたしなみ"
    voice "audio/voice/ageha_a6_oct_02.mp3"
    ageha "あとさ。決勝、配信するから。部のアカで。……パイセンが勝つとこ、何万人に見せるって決めてんの"
    menu:
        "「負けるとこは、撮るな」":
            ren "負けるとこは、撮るな"
            show ageha serious
            voice "audio/voice/ageha_a6_oct_03.mp3"
            ageha "撮る。……負けても、撮る。それが、マネの仕事でしょ。パイセンたちが一年のときの切り抜きも、負けてたじゃん"
            voice "audio/voice/ageha_a6_oct_04.mp3"
            ageha "あたし、負けてるパイセンを見て、ここに来たんだよ"
            $ heart_up("あげは", "信頼", 4)
        "「じゃあ、勝つとこを撮れ」":
            ren "じゃあ、勝つとこを撮れ。……一回だけだ"
            voice "audio/voice/ageha_a6_oct_05.mp3"
            ageha "……一回でいい。一回で、一生、回すから"
            $ heart_up("あげは", "ときめき", 4)
    $ up("技術", 2)
    hide ageha
    with dissolve
    return


################################################################################
## 夜のトーク（第6章）。蓮から送る形（a4_night_send）
################################################################################

## ── ひなた ──
label a4nc_hinata_a6may:
    $ talk_start("ひなた", "22:10")
    $ talk_me("オープンキャンパス、何日だ")
    $ talk("ひなた", "7月23日。……なんで？")
    $ _r = talk_choose([("練習、抜けていいぞ", "a"), ("覚えておく", "b")])
    if _r == "a":
        $ talk_me("その日、練習、抜けていいぞ")
        if a4_captain == "takano":
            $ talk("ひなた", "キャプテンみたいなこと言う")
        else:
            $ talk("ひなた", "キャプテンみたいなこと言う。……キャプテンだった")
        $ heart_up("ひなた", "信頼", 2)
    else:
        $ talk_me("覚えておく")
        $ talk("ひなた", "……覚えなくていいのに。でも、ちょっとうれしい")
        $ heart_up("ひなた", "ときめき", 2)
    return

label a4nc_hinata_a6oct:
    $ talk_start("ひなた", "22:30")
    $ talk_me("ロール、何本あった")
    $ talk("ひなた", "18本。6試合×3本。")
    $ talk("ひなた", "あとさ、決勝の日、テーピングの前に、10分だけちょうだい")
    $ set_flag("a6_ひなた_10分")
    $ talk_me("なんで")
    $ talk("ひなた", "ないしょ。……勝ってから言うって、決めてることがあるから。その前の準備")
    $ heart_up("ひなた", "ときめき", 2)
    return

## ── 千夏 ──
label a4nc_chika_a6may:
    $ talk_start("千夏", "21:50")
    $ talk_me("大学、どうですか")
    if a6_lover == "千夏":
        $ talk("千夏", "広いです。……蓮くんが、どこにもいないので、広すぎます")
        $ talk("千夏", "土曜、また帰ります。……待っていてください、って言うのは、まだ慣れません")
        $ heart_up("千夏", "ときめき", 2)
    else:
        $ talk("千夏", "相良さんが、写真部の部長でした。……世間は、せまいです")
        $ talk("千夏", "インターハイ予選、準決勝は見に行きます。記録係として")
        $ heart_up("千夏", "信頼", 2)
    return

label a4nc_chika_a6oct:
    $ talk_start("千夏", "21:35")
    $ talk_me("決勝、来ますか")
    $ talk("千夏", "行きます。スタンドの、いちばん前で")
    if a4_merger == "zenkoku":
        $ talk("千夏", "統合が決まった日、%sは「全国」って言いました。……わたし、まだ、それを記録に書いていません" % a6_chika_call)
        $ talk("千夏", "書かせてください。冬に")
    $ heart_up("千夏", "信頼", 2)
    return

## ── あげは ──
label a4nc_ageha_a6may:
    $ talk_start("あげは", "23:05")
    $ talk("あげは", "コロッケの動画、伸びた")
    $ talk_me("あれ、使えないって言ってただろ")
    $ talk("あげは", "パイセンの手だけ使った。顔は、あたし専用フォルダ")
    $ talk("あげは", "……今の、忘れて")
    $ heart_up("あげは", "ときめき", 2)
    return

label a4nc_ageha_a6oct:
    $ talk_start("あげは", "23:20")
    $ talk("あげは", "パイセン、卒業したら、どこ行くの")
    $ _r = talk_choose([("まだ決めてない", "a"), ("お前は、どうするんだ", "b")])
    if _r == "a":
        $ talk_me("まだ決めてない")
        $ talk("あげは", "ふーん。……決まったら、最初にあたしに言って。推しの進路は、マネが最初に知るの")
        $ heart_up("あげは", "信頼", 2)
    else:
        $ talk_me("お前は、どうするんだ。来年")
        $ talk("あげは", "港北の最後の日まで、マネやる。前に言ったじゃん")
        $ talk("あげは", "……パイセンがいない港北で。ちょっと、こわい")
        $ heart_up("あげは", "ときめき", 2)
    return

## ── 鷹野 ──
label a4nc_takano_a6may:
    $ talk_start("鷹野", "22:40")
    $ talk("鷹野", "結城さんから、トークが来た")
    $ talk("鷹野", "「準決勝で会えるのを楽しみにしてる」だと")
    $ talk_me("返したのか")
    $ talk("鷹野", "「俺もです」って返した。……返してから、手が震えた")
    $ bond_up("鷹野", 2)
    return

label a4nc_takano_a6oct:
    $ talk_start("鷹野", "23:00")
    $ talk("鷹野", "決勝まで、あと5試合")
    $ talk_me("数えるな")
    $ talk("鷹野", "数えねえと、寝れねえんだよ。……お前も、数えてるだろ")
    $ bond_up("鷹野", 2)
    return

## ── 大門 ──
label a4nc_daimon_a6may:
    $ talk_start("大門", "21:30")
    $ talk("大門", "早瀬くん、床屋のお客さんに、インターハイ予選のことを聞かれました")
    $ talk("大門", "「キーパーの大門くん」って呼ばれました。……柔道部の大門、じゃなくて")
    $ bond_up("大門", 2)
    return

label a4nc_daimon_a6oct:
    $ talk_start("大門", "21:45")
    $ talk("大門", "決勝、もしPKになったら、僕、全部止めるつもりです")
    $ talk_me("全部は無理だろ")
    $ talk("大門", "一年の春、早瀬くんは、11人集めるのは無理だって、言われてました")
    $ bond_up("大門", 2)
    return

## ── 小早川 ──
label a4nc_koba_a6may:
    $ talk_start("小早川", "22:00")
    $ talk("小早川", "先輩、来年の練習メニュー、7人用が12個できました")
    $ talk_me("多いな")
    if flags.get("a6_小早川に残す"):
        $ talk("小早川", "あと1個は、先輩が決めるやつなので、空けてあります")
    else:
        $ talk("小早川", "全部、先輩たちの練習を見て作りました。……7人でも、同じ練習ができるように")
    return

label a4nc_koba_a6oct:
    $ talk_start("小早川", "22:20")
    $ talk("小早川", "先輩。決勝で、僕が先輩を見ないでパスを出しても、怒らないでください")
    $ talk_me("怒らない。……見ないで出せるなら、出せ")
    $ talk("小早川", "はい。一年半、見てきたので。たぶん、見なくても分かります")
    return
