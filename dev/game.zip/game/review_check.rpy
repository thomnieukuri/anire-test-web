## ===========================================================================
## 見直しチェック（v0.44.1〜。全体の見直し 第2回の、直した場面を1つずつ遊んで確かめる）
##   ・作者の確認用（Web の dev/）と開発中の PC だけ。タイトル画面の「見直しチェック」から
##   ・場面ジャンプのしくみを使う：章の頭の状態にして、直した場面だけ流して、一覧に戻る
##   ・最後まで遊ぶと「済」になる。気になったら「気になる」を押しておく（次に話すときの目印）
##   ・場面をもう一度直したら、REV_ITEMS の2つ目（版）を1つ上げる → その場面だけ「未」にもどる
##   ・各場面には通し番号（No.1〜）がつく。会話では「No.3 が気になる」のように番号で呼べる
##     番号は REV_ITEMS の並び順。足すときは必ずいちばん下に足す（消さない・並べかえない。番号がずれるため）
##     やめた場面は消さずに、はじめるラベルを "" にすると一覧から消える（番号はそのまま空き番になる）
##   ・「未にもどす」で、済・気になるを消して「未」にもどせる
##   ・声と一枚絵は、あとでまとめて作る（それまでは声なし・前の絵のまま）
## ===========================================================================

default persistent.rev_marks = {}     # id -> {"rev": 版, "st": "done" / "ng"}
default persistent.rev_tab = 0
default rev_testing = ""
default _rev_stack = None
default _rev_keep = None
default _rev_auto = []          # 机の上のテスト用：ここにidを入れると、一覧を出さずに順に遊ぶ

init python:
    ## (id, 版, 章, 章の頭の状態, はじめるラベル, 題, 変えたところ, 前提)
    ##   前提："trial_cleared" = 2周目として遊ぶか（遊び終わったら元にもどす）
    REV_ITEMS = [
        ("pro_jan10", 1, "プロローグ", "1", "pro_jan10",
         "1月10日　はやせ食堂　黒いコートの男",
         "推薦取り消しの電話のあと、休みの店に黒いコートの白い髪の男が来て、柱の写真と蓮を見て「……似てきたな」。母「……昔の、お客さん」",
         {}),
        ("pro_feb_mother1", 1, "プロローグ", "1", "pro_feb_mother",
         "2月の自由行動　はやせ食堂",
         "父さんの写真の右はしが折り返してある（だれかと肩を組んでいた）。「その写真、まだ貼ってるんだな」を選ぶと、母「……折れちゃったのよ。昔から」",
         {}),
        ## No.3 は v0.44.2 でやめた（周回で中身を変えないことにした）。番号を空けておくため消さない
        ("pro_feb_mother2", 1, "プロローグ", "1", "",
         "2月の自由行動　はやせ食堂（2周目）",
         "2周目だけ、折り目のすきまから組んだ腕の先と黒い短い髪がのぞく",
         {"trial_cleared": True}),
        ("pro_feb_hinata", 1, "プロローグ", "1", "pro_feb_hinata",
         "2月の自由行動　港への坂道（ひなた）",
         "「平気だって。春には走れる」を選んだときの、ひなたの「……右の眉毛」をやめた",
         {}),
        ("pro_march", 1, "プロローグ", "1", "pro_march",
         "3月19日　合格発表",
         "最後のひなたの「右の眉毛、上がってるよ」を「……ふーん。じゃあ、勝手にやるね」に（声はあとで作る）",
         {}),
        ## ---- v0.44.2：鬼塚は 5/31 に「店に来た男」と分かる（案B）／周回で中身を変えない ----
        ("pro_final", 1, "プロローグ", "1", "prologue",
         "12月14日　県大会決勝　スタンドの最前列",
         "最前列で腕を組んだ大人が小さくうなずく一文を、1周目から出す（前は2周目だけ）",
         {}),
        ("c1_m531_bench", 2, "第1章", "1", "ch1_m531",
         "5月31日　桜嶺のグラウンド　ベンチの監督",
         "ベンチの鬼塚を見て「顔を見るのは、初めてのはずだった。……はずなのに、どこかで見た気がした」。1月10日に店に来た男だと、覚えている人だけが気づく（v0.44.3 で、説明しすぎを直した）",
         {}),
        ("c2_album", 1, "第2章", "2", "ch2_album_scene",
         "7月8日　部室のアルバム",
         "4年前の写真で旗を振る女の子の首に、フィルムカメラ。この一文を1周目から出す（前は2周目だけ）",
         {}),
        ("c3_onizuka", 1, "第3章", "3", "ch3_after_semi",
         "11月14日　試合のあと　神城と鬼塚",
         "「面と向かうのは、推薦の面談以来」を「言葉を交わすのは、初めてだった。冬の日に店で見たのと、5月の雨の日にベンチで見たのと、同じ細い目」に",
         {}),
        ## ---- v0.44.3：第1章（全体の見直し）。仲間集めのミニゲーム（大門・鷹野・坂口たち）は確認帳のあとで足す ----
        ("c1_moii", 1, "第1章", "1", "ch1_moii",
         "4月8日〜9日　「もういい」を選んだ人の入学式の次の日",
         "グラウンドに行かず家に帰る。次の昼休み、三好先輩が1年の教室まで来て頭を下げる。窓ぎわの5人（坂口たち）に笑われる（言い返す／聞こえないふり）",
         {}),
        ("c1_scout", 1, "第1章", "1", "ch1_hinata_scout",
         "4月10日（金）　ひなたとして遊ぶ：部員さがし",
         "蓮の知らないところで、ひなたが候補を見に行く。柔道場・屋上・ゲーセンから2か所。名簿は千夏先輩に借りた",
         {}),
        ("c1_intro", 1, "第1章", "1", "ch1_clubroom413",
         "4月13日　部室：ひなたの候補の紹介（屋上→柔道場の順に見た場合）",
         "ひなたが見に行った順に紹介する。見に行った相手は中身がくわしく、行けなかった相手（この確認ではゲーセン）はうわさだけ",
         {"vars": {"hinata_scout": ["takano", "daimon"]}}),
        ("c1_arcade_moii", 1, "第1章", "1", "ch1_arcade",
         "4月　ゲーセン：「もういい」の人（教室で言い返した場合）",
         "坂口「あ。昼休みの『潮見FCの10番さま』じゃん」「こわい顔の人。……なに、文句言いに来たの？」（坂口の絆−3）",
         {"vars": {"flags": {"ch1_坂口_教室": True, "ch1_坂口_にらんだ": True}}}),
        ("c1_520", 1, "第1章", "1", "ch1_entry520",
         "5月20日　生徒会室：エントリーの締め切り",
         "千夏の「試合までに、という言葉を記録しておきます」を「……試合までに、という言葉、覚えておきます」に（口ぐせを減らす）",
         {}),
        ("c1_council", 1, "第1章", "1", "ch1_council",
         "5月の自由行動　生徒会室：千夏のカメラ",
         "「記録の仕事ですから」を「生徒会の仕事ですから」に（口ぐせを減らす）",
         {}),
        ("c1_walk", 1, "第1章", "1", "ch1_walk_hinata",
         "5月の自由行動　港への坂道：ひなたのリハビリの本",
         "「痛くない」を選んだとき：眉毛と『蓮のうそ　一覧』のメモをやめて、ひなたが黙ってもう一度ひざを押す形に（声はあとで）",
         {}),
        ("c1_first_daimon", 1, "第1章", "1", "ch1_m531",
         "5月31日　最初に誘った仲間が助ける（大門）",
         "前半30分、目をつぶったまま大門が顔でシュートを止める",
         {"vars": {"ch1_join": {"大門": 1, "鷹野": 2, "5人組": 3}}}),
        ("c1_first_takano", 1, "第1章", "1", "ch1_m531",
         "5月31日　最初に誘った仲間が助ける（鷹野）",
         "前半30分、白の二人に挟まれた蓮のうしろに、鷹野が下りてくる（「……うしろ」）",
         {"vars": {"ch1_join": {"鷹野": 1, "大門": 2, "5人組": 3}}}),
        ("c1_first_arcade", 1, "第1章", "1", "ch1_m531",
         "5月31日　最初に誘った仲間が助ける（坂口）",
         "前半30分、ひざが遅れた蓮のかわりに、坂口が戻る（「蓮！　そこ、俺が行く！」）",
         {"vars": {"ch1_join": {"5人組": 1, "大門": 2, "鷹野": 3}}}),
        ("c1_goal19", 1, "第1章", "1", "ch1_m531",
         "5月31日　まれな1点（前半39分に「鷹野にパスを出す」を選ぶ）",
         "鷹野を自分で誘った人だけ、鷹野のシュートが入って1−9になる。鬼塚が初めて腕組みをほどいて鷹野を見る（一枚絵と声はあとで）",
         {"vars": {"ch1_join": {"鷹野": 1, "大門": 2, "5人組": 3}}}),
        ("c1_daimon", 1, "第1章", "1", "ch1_daimon",
         "4月の仲間集め　柔道場：大門（待つ会話）",
         "大門の言葉に、3回答える。何も押さずに待つと、大門のほうから続きを話す（待つほど入り方がよくなる。急ぎすぎると柔道部の先輩に止められる）",
         {}),
        ("c1_takano", 1, "第1章", "1", "ch1_takano",
         "4月の仲間集め　屋上→グラウンド：鷹野（2対1の勝負）",
         "蓮と三好先輩 対 鷹野、ミニゴールで先に2点。スコアボード・作戦ボード・時間で選ぶ2回（三好先輩に出す／自分で抜く／引きつける、本気で止める／二人で挟む／わざと抜かせる）",
         {}),
        ("c1_arcade", 1, "第1章", "1", "ch1_arcade",
         "4月の仲間集め　ゲーセン：坂口たちとサッカーゲーム",
         "3本目の残り10秒を本当に遊ぶ。横の味方をタップでパス、ゴールの上か下をタップでシュート。負けても5人は入る（入り方が変わる）",
         {}),
        ## ---- 第2章（v0.44.4） ----
        ("c2_saikai", 1, "第2章", "2", "ch2_saikai",
         "7月4日　西海戦：三好先輩の夏（朝〜ロッカー）",
         "朝6時の河川敷を走る三好先輩と、土手の父さん（工務店）。バスで一人ずつ声をかける。10番に三度抜かれて三度追いつく。最後のコーナーを、つった足でゴールライン上ではじき出す（見せ場）。最後にピッチを出る。ロッカーで「来年、頼むな」（返事は3つ）",
         {}),
        ("c2_kami_pov", 1, "第2章", "2", "ch2_kami_pov",
         "7月4日　一方そのころ：土手の上の神城（神城として遊ぶ）",
         "桜嶺の練習を抜けて、キャップを深くかぶって見に来ている（左の足首にテーピング）。ハーフタイムに蓮が見上げる→顔を上げる／目をそらす。出口で三好先輩とすれちがう→声をかける（「見に来てくれて、ありがとな」。三好は気づかない）／黙って行かせる",
         {}),
        ("c2_kami_takano", 1, "第2章", "2", "ch2_kami_pov",
         "7月4日　土手の神城：鷹野を見る桜嶺のコーチ（5/31 が 1−9 の人だけ）",
         "5月31日に鷹野が1点を返していると、ベンチ裏の桜嶺のスカウト担当が、鷹野だけを目で追って手帳に書いている（移籍の種）",
         {"vars": {"flags": {"531_鷹野ゴール": True}}}),
        ("c2_train", 1, "第2章", "2", "ch2_train_home",
         "7月4日　帰りの電車：三好先輩とタオル",
         "眠ったふりの三好先輩の肩が、トンネルで一回だけ震える。ひなたが、何も言わずにタオルをかける",
         {}),
        ("c2_aug_day", 1, "第2章", "2", "ch2_aug_day",
         "8月6日　夏休みの1日（昼・夕方・夜）",
         "8月の自由行動を1日にした。朝の練習→昼（食堂のひなた／柔道場の大門）→夕方（生徒会室の千夏／部室の三好）→夜（グラウンドの鷹野／家で休む）。会わなかった人は「一方そのころ」で見える。最後に桜嶺の寮の神城（足首を冷やす）。夜は、会っていない人にだけトークを送れる",
         {}),
        ("c2_fest_home", 1, "第2章", "2", "ch2_fest_home",
         "8月15日　夏祭りのあと：母さんの包丁",
         "蓮が「港で会った子、鬼塚っていうらしい」と言うと、仕込みの包丁の音が一回だけ止まる。母「……そう」。こっちを見ない",
         {}),
        ("c2_tics", 1, "第2章", "2", "ch2_saikai",
         "第2章の口ぐせを減らした（通しで遊んで確かめる）",
         "ひなたの「眉毛」を3か所やめた（ノートは残す）。千夏の「記録」は夏合宿明けの「昨夜のことは、記録にありません」だけ残して、ほかは言いかえた",
         {}),        ## ---- 試合中のボード（v0.44.4） ----
        ("tb_saikai21", 1, "第2章", "2", "ch2_saikai",
         "試合中のボード：西海戦 前半21分（10番との1対1・選ぶあいだ）",
         "ボードが起き上がって選手が降りてくる。はずむ動き・走った跡・浮いて飛ぶボール・流れる矢印。カメラが2人に寄って比べ札（軽め。10番はライバルではないのでカットインなし）。選ぶあいだは2人のまわりだけ照らして、選択肢は右に",
         {}),
        ("tb_semi8", 1, "第3章", "3", "ch3_semi",
         "試合中のボード：準決勝 前半8分（神城のカットイン「目の帯」）",
         "神城との最初の1対1で、目の帯のカットイン（ゆっくり）→ 比べ札がたたきつけられる。後半40分の2回目は短い。相手の丸は桜嶺の白（背番号は黒い字）",
         {}),        ## ---- 第3章（v0.44.5） ----
        ("c3_month_day", 1, "第3章", "3", "ch3_month_day",
         "第3章の自由行動：月に「1日」（9月）",
         "放課後と夕方で行き先を選ぶ。会えなかった人は「一方そのころ」。夜は、会っていない人にだけトーク。練習は前の日数ぶん上がる",
         {}),
        ("c3_swap", 1, "第3章", "3", "ch3_slump",
         "9月19日〜26日：潮見北に負けたあと、黒田が3週間だけ並びを入れかえる",
         "坂口たちの「やめかける」をやめた。蓮はうしろの真ん中（言い返す／黙って下がる）、坂口は右サイドバック。ビブスを大門が拾う。江藤のトーク → 坂口の1日 → 9/26 の坂口の答え。10/9 に元に戻す",
         {}),
        ("c3_saka_pov", 1, "第3章", "3", "ch3_saka_pov",
         "9月24日：坂口の1日（坂口として遊ぶ）",
         "ゲーセンでサイドバックを選ぶ（ネタだって）。夜：4人とラーメン／一人でグラウンドに戻る（蓮が首を振る練習をしている）",
         {}),
        ## ---- 第3章（v0.44.6） ----
        ("c3_prematch", 1, "第3章", "3", "ch3_rev_prematch",
         "準決勝の試合前の紹介（中継の形）",
         "実況 大川・解説 戸田。港北（黒田を右に・11人が降りる・戦い方）→ 桜嶺（鬼塚を左に・番号で出る・神城と真壁の顔の札・戦い方）→ 注目の対決（斜めの分割）→ KICK OFF。約60秒。タップで次へ、右上のスキップで全部飛ばす。続けて2回目の短い版",
         {}),
        ("c3_semi_et", 1, "第3章", "3", "ch3_rev_semi_et",
         "準決勝：まれな延長（1−1で最後のコーナー）",
         "ひざを残す作戦＋紗希の情報のときだけ、座ったままの鬼塚の指が見える。「ニアだ！」と叫ぶと大門がはじいて延長 → 延長前半に鬼塚がはじめて立ち上がる → 延長後半7分に神城（負けのまま）。通路の鬼塚のセリフも変わる",
         {}),
    ]

    def rev_no(it):
        """通し番号（REV_ITEMS の何番目か。1から）"""
        return REV_ITEMS.index(it) + 1

    def rev_shown(it):
        """一覧に出す場面か（はじめるラベルが "" の、やめた場面は出さない）"""
        return bool(it[4]) and renpy.has_label(it[4])

    def rev_tabs():
        out = []
        for it in REV_ITEMS:
            if rev_shown(it) and it[2] not in out:
                out.append(it[2])
        return out

    def rev_st(it):
        m = persistent.rev_marks.get(it[0])
        if not m or m.get("rev", 0) < it[1]:
            return ""
        return m.get("st", "")

    def rev_count(tab):
        its = [it for it in REV_ITEMS if it[2] == tab and rev_shown(it)]
        return len([it for it in its if rev_st(it)]), len(its)

    def rev_mark(rid, st):
        d = dict(persistent.rev_marks or {})
        for it in REV_ITEMS:
            if it[0] == rid:
                if st:
                    d[rid] = {"rev": it[1], "st": st}
                else:
                    d.pop(rid, None)
        persistent.rev_marks = d
        renpy.save_persistent()
        renpy.restart_interaction()

    def rev_clear(rid):
        """「未」にもどす"""
        rev_mark(rid, "")

    def rev_toggle_ng(rid):
        for it in REV_ITEMS:
            if it[0] == rid:
                rev_mark(rid, "done" if rev_st(it) == "ng" else "ng")

    def rev_end(rid):
        """直した場面の終わりの目印。見直しチェックでこの場面を遊んでいるときだけ、一覧にもどる"""
        if store.rev_testing == rid:
            renpy.jump("rev_after")

    def rev_prepare(it):
        pre = it[7]
        store._rev_keep = None
        ## 西暦（学年の計算に使う）。プロローグの決勝だけ2025年、ほかは2026年（v0.44.3：鷹野との勝負で三好先輩が「2年」と出ていた）
        store.cal_year = 2025 if it[4] == "prologue" else 2026
        ## 前提の "vars"：遊ぶ前に入れておく値（例：最初に誘った仲間・ひなたが見に行った相手）。flags は足し合わせる
        for k, v in pre.get("vars", {}).items():
            if k == "flags":
                store.flags.update(v)
            else:
                setattr(store, k, v)
        if "trial_cleared" in pre:
            store._rev_keep = bool(persistent.trial_cleared)
            persistent.trial_cleared = pre["trial_cleared"]

    def rev_restore():
        if store._rev_keep is not None:
            persistent.trial_cleared = store._rev_keep
            store._rev_keep = None

screen rev_list():
    modal True
    add "gui/menu_bg.png"
    $ _tabs = rev_tabs()
    $ _ti = persistent.rev_tab if 0 <= persistent.rev_tab < len(_tabs) else 0
    $ _tab = _tabs[_ti] if _tabs else ""
    frame:
        xpos 296
        ypos 34
        xsize 920
        ysize 640
        background None
        vbox:
            spacing 6
            hbox:
                spacing 14
                text "見直しチェック（作者用）" size 26 color PEN_RED
                text "直した場面だけ流して、ここに戻る。最後まで遊ぶと「済」" size 15 color INK_SOFT yalign 0.5
            hbox:
                spacing 10
                for _i, _t in enumerate(_tabs):
                    $ _d, _n = rev_count(_t)
                    textbutton "%s %d/%d" % (_t, _d, _n):
                        action SetField(persistent, "rev_tab", _i)
                        text_size 16
                        text_color (PEN_RED if _i == _ti else INK_SOFT)
                        text_hover_color PEN_RED
                textbutton "タイトルへ":
                    action Return(None)
                    text_size 16
                    text_color INK
                    text_hover_color PEN_RED
            text "声と一枚絵は、あとでまとめて作ります（今は声なし・前の絵のまま）。" size 14 color INK_SOFT
            viewport:
                ysize 520
                mousewheel True
                draggable True
                scrollbars "vertical"
                vbox:
                    spacing 6
                    for _it in REV_ITEMS:
                        if _it[2] == _tab and rev_shown(_it):
                            $ _st = rev_st(_it)
                            frame:
                                style "roster_card"
                                xsize 880
                                hbox:
                                    spacing 12
                                    text "No.%d" % rev_no(_it):
                                        size 20
                                        min_width 66
                                        yalign 0.5
                                        color INK
                                    text {"": "未", "done": "済", "ng": "気になる"}[_st]:
                                        size 18
                                        min_width 80
                                        yalign 0.5
                                        color (INK_SOFT if _st == "" else (PEN_RED if _st == "ng" else "#23854a"))
                                    vbox:
                                        xsize 500
                                        spacing 2
                                        text _it[5] size 18 color INK
                                        text _it[6] size 13 color INK_SOFT
                                    vbox:
                                        spacing 4
                                        yalign 0.5
                                        textbutton "遊ぶ":
                                            action Return(_it[0])
                                            text_size 18
                                            text_color INK
                                            text_hover_color PEN_RED
                                        if _st:
                                            textbutton ("気になる を外す" if _st == "ng" else "気になる"):
                                                action Function(rev_toggle_ng, _it[0])
                                                text_size 14
                                                text_color INK_SOFT
                                                text_hover_color PEN_RED
                                            textbutton "未にもどす":
                                                action Function(rev_clear, _it[0])
                                                text_size 14
                                                text_color INK_SOFT
                                                text_hover_color PEN_RED

label rev_start:
    $ quick_menu = True
    $ persistent.save_guide_seen = True
    if persistent.choice_hints is None:
        $ persistent.choice_hints = True
label rev_loop:
    ## 試合の途中から戻ったとき、スコアボードや作戦ボードが一覧に残らないように（v0.44.3）
    python:
        for _sn in ("scoreboard", "letterbox", "speedlines", "goal_banner", "match_flow", "flow_dim",
                    "flow_panel1", "flow_panel2", "flow_panel3", "timed_gauge"):
            renpy.hide_screen(_sn)
        try:
            tactics_off()
        except Exception:
            pass
    scene black
    window hide
    $ music_stop(0.5)
    $ amb_stop()
    $ rev_restore()
    $ rev_testing = ""
    $ sj_testing = False
    $ hs_testing = False
    if _rev_auto:
        $ _rid = _rev_auto.pop(0)
    else:
        $ _rid = renpy.call_screen("rev_list")
    if _rid is None:
        $ renpy.full_restart()
    $ _rit = [it for it in REV_ITEMS if it[0] == _rid][0]
    call expression ("cs_state" + _rit[3])
    $ sj_prepare(_rit[3], ("", "", 0, "", "", ""))
    $ rev_prepare(_rit)
    $ rev_testing = _rid
    $ _rev_stack = renpy.get_return_stack()
    call expression _rit[4]
    ## ラベルの終わりまで遊んだとき
    $ rev_mark(_rid, "ng" if rev_st(_rit) == "ng" else "done")
    window hide
    jump rev_loop

## 場面の途中の rev_end(...) から来たとき
label rev_after:
    $ renpy.set_return_stack(_rev_stack or [])
    $ _rit = [it for it in REV_ITEMS if it[0] == rev_testing][0]
    $ rev_mark(rev_testing, "ng" if rev_st(_rit) == "ng" else "done")
    window hide
    jump rev_loop
