## ===========================================================================
## 見直しチェック（v0.44.1〜。全体の見直し 第2回の、直した場面を1つずつ遊んで確かめる）
##   ・作者の確認用（Web の dev/）と開発中の PC だけ。タイトル画面の「見直しチェック」から
##   ・場面ジャンプのしくみを使う：章の頭の状態にして、直した場面だけ流して、一覧に戻る
##   ・最後まで遊ぶと「済」になる。気になったら「気になる」を押しておく（次に話すときの目印）
##   ・場面をもう一度直したら、REV_ITEMS の2つ目（版）を1つ上げる → その場面だけ「未」にもどる
##   ・各場面には通し番号（No.1〜）がつく。会話では「No.3 が気になる」のように番号で呼べる
##     番号は REV_ITEMS の並び順。足すときは必ずいちばん下に足す（消さない・並べかえない。番号がずれるため）
##     やめた場面は消さずに、はじめるラベルを "" にすると一覧から消える（番号はそのまま空き番になる）
##   ・「未にもどす」で、済・気になるを消して「未」にもどせる
##   ・声と一枚絵は、あとでまとめて作る（それまでは声なし・前の絵のまま）
## ===========================================================================

default persistent.rev_marks = {}     # id -> {"rev": 版, "st": "done" / "ng"}
default persistent.rev_tab = 0
default rev_testing = ""
default _rev_stack = None
default _rev_keep = None
default _rev_auto = []          # 机の上のテスト用：ここにidを入れると、一覧を出さずに順に遊ぶ

init python:
    ## (id, 版, 章, 章の頭の状態, はじめるラベル, 題, 変えたところ, 前提)
    ##   前提："trial_cleared" = 2周目として遊ぶか（遊び終わったら元にもどす）
    REV_ITEMS = [
        ("pro_jan10", 1, "プロローグ", "1", "pro_jan10",
         "1月10日　はやせ食堂　黒いコートの男",
         "推薦取り消しの電話のあと、休みの店に黒いコートの白い髪の男が来て、柱の写真と蓮を見て「……似てきたな」。母「……昔の、お客さん」",
         {}),
        ("pro_feb_mother1", 1, "プロローグ", "1", "pro_feb_mother",
         "2月の自由行動　はやせ食堂（1周目）",
         "父さんの写真の右はしが折り返してある（だれかと肩を組んでいた）。「その写真、まだ貼ってるんだな」を選ぶと、母「……折れちゃったのよ。昔から」",
         {"trial_cleared": False}),
        ("pro_feb_mother2", 1, "プロローグ", "1", "pro_feb_mother",
         "2月の自由行動　はやせ食堂（2周目）",
         "2周目だけ、折り目のすきまから組んだ腕の先と黒い短い髪がのぞく",
         {"trial_cleared": True}),
        ("pro_feb_hinata", 1, "プロローグ", "1", "pro_feb_hinata",
         "2月の自由行動　港への坂道（ひなた）",
         "「平気だって。春には走れる」を選んだときの、ひなたの「……右の眉毛」をやめた",
         {}),
        ("pro_march", 1, "プロローグ", "1", "pro_march",
         "3月19日　合格発表",
         "最後のひなたの「右の眉毛、上がってるよ」を「……ふーん。じゃあ、勝手にやるね」に（声はあとで作る）",
         {}),
    ]

    def rev_no(it):
        """通し番号（REV_ITEMS の何番目か。1から）"""
        return REV_ITEMS.index(it) + 1

    def rev_tabs():
        out = []
        for it in REV_ITEMS:
            if it[2] not in out:
                out.append(it[2])
        return out

    def rev_st(it):
        m = persistent.rev_marks.get(it[0])
        if not m or m.get("rev", 0) < it[1]:
            return ""
        return m.get("st", "")

    def rev_count(tab):
        its = [it for it in REV_ITEMS if it[2] == tab]
        return len([it for it in its if rev_st(it)]), len(its)

    def rev_mark(rid, st):
        d = dict(persistent.rev_marks or {})
        for it in REV_ITEMS:
            if it[0] == rid:
                if st:
                    d[rid] = {"rev": it[1], "st": st}
                else:
                    d.pop(rid, None)
        persistent.rev_marks = d
        renpy.save_persistent()
        renpy.restart_interaction()

    def rev_clear(rid):
        """「未」にもどす"""
        rev_mark(rid, "")

    def rev_toggle_ng(rid):
        for it in REV_ITEMS:
            if it[0] == rid:
                rev_mark(rid, "done" if rev_st(it) == "ng" else "ng")

    def rev_end(rid):
        """直した場面の終わりの目印。見直しチェックでこの場面を遊んでいるときだけ、一覧にもどる"""
        if store.rev_testing == rid:
            renpy.jump("rev_after")

    def rev_prepare(it):
        pre = it[7]
        store._rev_keep = None
        if "trial_cleared" in pre:
            store._rev_keep = bool(persistent.trial_cleared)
            persistent.trial_cleared = pre["trial_cleared"]

    def rev_restore():
        if store._rev_keep is not None:
            persistent.trial_cleared = store._rev_keep
            store._rev_keep = None

screen rev_list():
    modal True
    add "gui/menu_bg.png"
    $ _tabs = rev_tabs()
    $ _ti = persistent.rev_tab if 0 <= persistent.rev_tab < len(_tabs) else 0
    $ _tab = _tabs[_ti] if _tabs else ""
    frame:
        xpos 296
        ypos 34
        xsize 920
        ysize 640
        background None
        vbox:
            spacing 6
            hbox:
                spacing 14
                text "見直しチェック（作者用）" size 26 color PEN_RED
                text "直した場面だけ流して、ここに戻る。最後まで遊ぶと「済」" size 15 color INK_SOFT yalign 0.5
            hbox:
                spacing 10
                for _i, _t in enumerate(_tabs):
                    $ _d, _n = rev_count(_t)
                    textbutton "%s %d/%d" % (_t, _d, _n):
                        action SetField(persistent, "rev_tab", _i)
                        text_size 16
                        text_color (PEN_RED if _i == _ti else INK_SOFT)
                        text_hover_color PEN_RED
                textbutton "タイトルへ":
                    action Return(None)
                    text_size 16
                    text_color INK
                    text_hover_color PEN_RED
            text "声と一枚絵は、あとでまとめて作ります（今は声なし・前の絵のまま）。" size 14 color INK_SOFT
            viewport:
                ysize 520
                mousewheel True
                draggable True
                scrollbars "vertical"
                vbox:
                    spacing 6
                    for _it in REV_ITEMS:
                        if _it[2] == _tab and _it[4] and renpy.has_label(_it[4]):
                            $ _st = rev_st(_it)
                            frame:
                                style "roster_card"
                                xsize 880
                                hbox:
                                    spacing 12
                                    text "No.%d" % rev_no(_it):
                                        size 20
                                        min_width 66
                                        yalign 0.5
                                        color INK
                                    text {"": "未", "done": "済", "ng": "気になる"}[_st]:
                                        size 18
                                        min_width 80
                                        yalign 0.5
                                        color (INK_SOFT if _st == "" else (PEN_RED if _st == "ng" else "#23854a"))
                                    vbox:
                                        xsize 500
                                        spacing 2
                                        text _it[5] size 18 color INK
                                        text _it[6] size 13 color INK_SOFT
                                    vbox:
                                        spacing 4
                                        yalign 0.5
                                        textbutton "遊ぶ":
                                            action Return(_it[0])
                                            text_size 18
                                            text_color INK
                                            text_hover_color PEN_RED
                                        if _st:
                                            textbutton ("気になる を外す" if _st == "ng" else "気になる"):
                                                action Function(rev_toggle_ng, _it[0])
                                                text_size 14
                                                text_color INK_SOFT
                                                text_hover_color PEN_RED
                                            textbutton "未にもどす":
                                                action Function(rev_clear, _it[0])
                                                text_size 14
                                                text_color INK_SOFT
                                                text_hover_color PEN_RED

label rev_start:
    $ quick_menu = True
    $ persistent.save_guide_seen = True
    if persistent.choice_hints is None:
        $ persistent.choice_hints = True
label rev_loop:
    scene black
    window hide
    $ music_stop(0.5)
    $ amb_stop()
    $ rev_restore()
    $ rev_testing = ""
    $ sj_testing = False
    $ hs_testing = False
    if _rev_auto:
        $ _rid = _rev_auto.pop(0)
    else:
        $ _rid = renpy.call_screen("rev_list")
    if _rid is None:
        $ renpy.full_restart()
    $ _rit = [it for it in REV_ITEMS if it[0] == _rid][0]
    call expression ("cs_state" + _rit[3])
    $ sj_prepare(_rit[3], ("", "", 0, "", "", ""))
    $ rev_prepare(_rit)
    $ rev_testing = _rid
    $ _rev_stack = renpy.get_return_stack()
    call expression _rit[4]
    ## ラベルの終わりまで遊んだとき
    $ rev_mark(_rid, "ng" if rev_st(_rit) == "ng" else "done")
    window hide
    jump rev_loop

## 場面の途中の rev_end(...) から来たとき
label rev_after:
    $ renpy.set_return_stack(_rev_stack or [])
    $ _rit = [it for it in REV_ITEMS if it[0] == rev_testing][0]
    $ rev_mark(rev_testing, "ng" if rev_st(_rit) == "ng" else "done")
    window hide
    jump rev_loop
