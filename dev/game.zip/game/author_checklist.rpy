## ===========================================================================
## 作者用の検証リスト（v0.35.1）。作者メニューの「検証リスト」から開く
##   ・「このルート・この分かれ方・この数字の状態で、最後まで遊んだか」をざっくり並べたタスク表
##   ・ふつうに遊んで章の終わり（下の「たしかめる場所」のラベル）に来たとき、その時点の状態を見て、自動で「済」になる
##     （場面ジャンプで流したときは数えない。手で「済」にもできる）
##   ・項目ごとにメモを書ける。「メモをまとめてコピー」で、チャットに貼って Claude に渡す
##   ・項目を足すときは CHK_ITEMS に1行（グループ, ID, 項目, たしかめる場所のラベル, 条件の式）
## ===========================================================================

default persistent.chk_done = {}       # ID → "auto"（遊んで済）/ "hand"（手で済）
default persistent.chk_memo = {}       # ID → メモ
default persistent.chk_tab = 0
default check_fail_n = 0               # 章のあいだに、能力の判定で失敗した回数（章の終わりで数えなおす）
default chk_played = []                # この周で、頭から遊んだ章（章の頭のラベル）。章えらびで途中から始めたとき、遊んでいない章を数えないため

define CHK_GROUPS = ["体験版", "第4章A", "第5章A", "第6章A", "第4章B", "第5章B"]

define CHK_ITEMS = [
    ## 体験版：第1章（第2章の頭でたしかめる）
    ("体験版", "c1_531_dribble", "第1章 5/31 前半の終わり：自分で持ち出した", "chapter2", "m531_play == 'dribble'"),
    ("体験版", "c1_531_pass", "第1章 5/31 前半の終わり：鷹野にパス", "chapter2", "m531_play == 'pass'"),
    ("体験版", "c1_531_back", "第1章 5/31 前半の終わり：一度下げた", "chapter2", "m531_play == 'back'"),
    ("体験版", "c1_takano_real", "第1章 鷹野との勝負：本気で止めた", "chapter2", "not flags.get('鷹野_わざと負け')"),
    ("体験版", "c1_takano_let", "第1章 鷹野との勝負：わざと抜かせた", "chapter2", "flags.get('鷹野_わざと負け')"),
    ("体験版", "c1_fail", "第1章 能力の判定で失敗したところを見た", "chapter2", "check_fail_n > 0"),
    ## 第2章（第3章の頭でたしかめる）
    ("体験版", "c2_shot_shoot", "第2章 IH1回戦 残り5分：自分で撃つ", "chapter3", "ch2_shot == 'shoot'"),
    ("体験版", "c2_shot_onetwo", "第2章 IH1回戦 残り5分：鷹野とワンツー", "chapter3", "ch2_shot == 'onetwo'"),
    ("体験版", "c2_shot_back", "第2章 IH1回戦 残り5分：三好先輩に下げて裏へ", "chapter3", "ch2_shot == 'back'"),
    ("体験版", "c2_shot_look", "第2章 IH1回戦 残り5分：覚えたプレー「首振り」", "chapter3", "ch2_shot == 'look'"),
    ("体験版", "c2_pk_read", "第2章 PK：「左だ！」で軸足を読めた（覚えたプレー「軸足を見る」）", "chapter3", "ch2_pk_read"),
    ("体験版", "c2_pk_left", "第2章 PK：「左だ！」で読めなかった", "chapter3", "ch2_shout == 'left' and not ch2_pk_read"),
    ("体験版", "c2_pk_right", "第2章 PK：「右だ！」", "chapter3", "ch2_shout == 'right'"),
    ("体験版", "c2_pk_none", "第2章 PK：何も言わない", "chapter3", "ch2_shout == 'none'"),
    ("体験版", "c2_2nd_attack", "第2章 西海学院：全員で攻めた", "chapter3", "ch2_2nd == 'attack'"),
    ("体験版", "c2_2nd_hold", "第2章 西海学院：耐えて最後の10分", "chapter3", "ch2_2nd == 'hold'"),
    ("体験版", "c2_fest_hinata", "第2章 夏祭り：ひなた", "chapter3", "ch2_fest == 'hinata'"),
    ("体験版", "c2_fest_chika", "第2章 夏祭り：千夏", "chapter3", "ch2_fest == 'chika'"),
    ("体験版", "c2_fest_boys", "第2章 夏祭り：男子と／一人", "chapter3", "ch2_fest in ('boys', 'alone')"),
    ("体験版", "c2_fail", "第2章 能力の判定で失敗したところを見た", "chapter3", "check_fail_n > 0"),
    ## 第3章（体験版の終わりでたしかめる）
    ("体験版", "c3_full", "第3章 準決勝：最初から全力", "trial_end", "ch3_knee_plan == 'full'"),
    ("体験版", "c3_half", "第3章 準決勝：前半は下がり目", "trial_end", "ch3_knee_plan == 'half'"),
    ("体験版", "c3_push", "第3章 準決勝：ひざが痛んでも黙って走った", "trial_end", "ch3_knee_push"),
    ("体験版", "c3_goal", "第3章 準決勝：港北が1点取った", "trial_end", "ch3_semi_goal"),
    ("体験版", "c3_nogoal", "第3章 準決勝：1点も取れなかった", "trial_end", "not ch3_semi_goal"),
    ("体験版", "c3_play_use", "第3章 覚えたプレーを準決勝で使えた", "trial_end", "plays_used.get('seoi') or plays_used.get('jikuashi') or plays_used.get('kubifuri', 0) >= 2"),
    ("体験版", "c3_xmas_hinata", "第3章 クリスマス：ひなた", "trial_end", "ch3_xmas == 'hinata'"),
    ("体験版", "c3_xmas_chika", "第3章 クリスマス：千夏", "trial_end", "ch3_xmas == 'chika'"),
    ("体験版", "c3_xmas_saki", "第3章 クリスマス：紗希", "trial_end", "ch3_xmas == 'saki'"),
    ("体験版", "c3_xmas_boys", "第3章 クリスマス：男子と", "trial_end", "ch3_xmas == 'boys'"),
    ("体験版", "c3_nye_hinata", "第3章 大晦日：ひなた", "trial_end", "ch3_nye == 'hinata'"),
    ("体験版", "c3_nye_chika", "第3章 大晦日：千夏", "trial_end", "ch3_nye == 'chika'"),
    ("体験版", "c3_nye_saki", "第3章 大晦日：紗希", "trial_end", "ch3_nye == 'saki'"),
    ("体験版", "c3_nye_other", "第3章 大晦日：鷹野か母さん", "trial_end", "ch3_nye in ('takano', 'mother')"),
    ("体験版", "c3_stay", "第3章 大晦日：港北に残る", "trial_end", "ch3_route == 'stay'"),
    ("体験版", "c3_move", "第3章 大晦日：桜嶺へ移る", "trial_end", "ch3_route == 'move'"),
    ("体験版", "c3_top_hinata", "体験版の終わり：ひなたのときめきがいちばん高い", "trial_end", "chk_top() == 'ひなた'"),
    ("体験版", "c3_top_chika", "体験版の終わり：千夏のときめきがいちばん高い", "trial_end", "chk_top() == '千夏'"),
    ("体験版", "c3_top_saki", "体験版の終わり：紗希のときめきがいちばん高い", "trial_end", "chk_top() == '紗希'"),
    ("体験版", "c3_muri80", "体験版の終わり：無理ゲージ80以上", "trial_end", "hidden.get('無理ゲージ', 0) >= 80"),
    ("体験版", "c3_fail", "第3章 能力の判定で失敗したところを見た", "trial_end", "check_fail_n > 0"),
    ## 第4章A
    ("第4章A", "a4_fes_hinata", "夏祭り：ひなた", "a4_end", "a4_festival == 'hinata'"),
    ("第4章A", "a4_fes_chika", "夏祭り：千夏", "a4_end", "a4_festival == 'chika'"),
    ("第4章A", "a4_fes_ageha", "夏祭り：あげは", "a4_end", "a4_festival == 'ageha'"),
    ("第4章A", "a4_fes_team", "夏祭り：チームと", "a4_end", "a4_festival == 'team'"),
    ("第4章A", "a4_val_hinata", "バレンタイン：ひなた", "a4_end", "a4_valentine == 'hinata'"),
    ("第4章A", "a4_val_chika", "バレンタイン：千夏", "a4_end", "a4_valentine == 'chika'"),
    ("第4章A", "a4_heart_hinata", "告白の前ぶれ：ひなた", "a4_end", "a4_heart_who == 'ひなた'"),
    ("第4章A", "a4_heart_chika", "告白の前ぶれ：千夏", "a4_end", "a4_heart_who == '千夏'"),
    ("第4章A", "a4_heart_ageha", "告白の前ぶれ：あげは", "a4_end", "a4_heart_who == 'あげは'"),
    ("第4章A", "a4_takano_push", "鷹野の編入：背中を押した", "a4_end", "a4_takano == 'push'"),
    ("第4章A", "a4_takano_stay", "鷹野の編入：引き留めた", "a4_end", "a4_takano == 'stay'"),
    ("第4章A", "a4_qf_akasaka", "準々決勝：赤坂を入れた", "a4_end", "a4_qf_sub == 'akasaka'"),
    ("第4章A", "a4_qf_me", "準々決勝：自分が下がった", "a4_end", "a4_qf_sub == 'me'"),
    ("第4章A", "a4_muri80", "第4章の終わり：無理ゲージ80以上", "a4_end", "hidden.get('無理ゲージ', 0) >= 80"),
    ("第4章A", "a4_fail", "能力の判定で失敗したところを見た", "a4_end", "check_fail_n > 0"),
    ## 第5章A
    ("第5章A", "a5_surgery", "運命の選択②：手術した", "a5_end", "a5_surgery is True"),
    ("第5章A", "a5_nosurgery", "運命の選択②：手術しなかった", "a5_end", "a5_surgery is False"),
    ("第5章A", "a5_fest_hinata", "文化祭：ひなた", "a5_end", "a5_fest_with == 'hinata'"),
    ("第5章A", "a5_fest_chika", "文化祭：千夏", "a5_end", "a5_fest_with == 'chika'"),
    ("第5章A", "a5_fest_ageha", "文化祭：あげは", "a5_end", "a5_fest_with == 'ageha'"),
    ("第5章A", "a5_xmas_hinata", "クリスマス：ひなた", "a5_end", "a5_xmas == 'hinata'"),
    ("第5章A", "a5_xmas_chika", "クリスマス：千夏", "a5_end", "a5_xmas == 'chika'"),
    ("第5章A", "a5_xmas_ageha", "クリスマス：あげは", "a5_end", "a5_xmas == 'ageha'"),
    ("第5章A", "a5_val_any", "バレンタイン：だれかから", "a5_end", "a5_val != ''"),
    ("第5章A", "a5_grad_lover", "千夏の卒業式：恋人", "a5_end", "a5_grad == 'lover'"),
    ("第5章A", "a5_grad_partner", "千夏の卒業式：相棒", "a5_end", "a5_grad == 'partner'"),
    ("第5章A", "a5_grad_miss", "千夏の卒業式：すれ違い／一人", "a5_end", "a5_grad in ('miss', 'alone')"),
    ("第5章A", "a5_muri80", "第5章の終わり：無理ゲージ80以上", "a5_end", "hidden.get('無理ゲージ', 0) >= 80"),
    ("第5章A", "a5_fail", "能力の判定で失敗したところを見た", "a5_end", "check_fail_n > 0"),
    ## 第6章A
    ("第6章A", "a6_full", "運命の選択③：最初から出る", "a6_end", "a6_start == 'full'"),
    ("第6章A", "a6_bench", "運命の選択③：ベンチから", "a6_end", "a6_start == 'bench'"),
    ("第6章A", "a6_broke", "決勝で、ひざが止まった", "a6_end", "a6_knee_broke"),
    ("第6章A", "a6_win_ren", "決勝点：蓮", "a6_end", "a6_final_scorer == 'ren'"),
    ("第6章A", "a6_win_other", "決勝点：鷹野・小早川・PK", "a6_end", "a6_final_scorer in ('takano', 'koba', 'pk')"),
    ("第6章A", "a6_lover_chika", "恋人：千夏", "a6_end", "a6_lover == '千夏'"),
    ("第6章A", "a6_lover_hinata", "恋人：ひなた", "a6_end", "a6_lover == 'ひなた'"),
    ("第6章A", "a6_lover_ageha", "恋人：あげは", "a6_end", "a6_lover == 'あげは'"),
    ("第6章A", "a6_lover_none", "恋人なし", "a6_end", "a6_lover == ''"),
    ("第6章A", "a6_hina_partner", "初詣のひなた：専属トレーナー", "a6_end", "a6_hinata_end == 'partner'"),
    ("第6章A", "a6_hina_miss", "初詣のひなた：すれ違い／一人", "a6_end", "a6_hinata_end in ('miss', 'alone')"),
    ("第6章A", "a6_fail", "能力の判定で失敗したところを見た", "a6_end", "check_fail_n > 0"),
    ## 第4章B
    ("第4章B", "b4_reika_lover", "麗華：最後まで付き合っている", "b4_end", "b4_reika == 'lover'"),
    ("第4章B", "b4_reika_refused", "麗華：4/9 に断った", "b4_end", "b4_reika == 'refused'"),
    ("第4章B", "b4_reika_gone", "麗華：離れた／蓮から終わらせた", "b4_end", "b4_reika in ('dumped', 'broke')"),
    ("第4章B", "b4_a_pass", "7/17 Aチームに上がった", "b4_end", "b4_test_a == 'pass'"),
    ("第4章B", "b4_a_fail", "7/17 Aチームに上がれなかった", "b4_end", "b4_test_a == 'fail'"),
    ("第4章B", "b4_fes_saki", "夏祭り：紗希", "b4_end", "b4_fes == 'saki'"),
    ("第4章B", "b4_fes_ageha", "夏祭り：あげは", "b4_end", "b4_fes == 'ageha'"),
    ("第4章B", "b4_fes_other", "夏祭り：本田／一人", "b4_end", "b4_fes in ('honda', 'alone')"),
    ("第4章B", "b4_trust_saki", "7/30 紗希の「相棒」", "b4_end", "'紗希' in b4_trust_answer"),
    ("第4章B", "b4_trust_ageha", "7/30 あげはの「相棒」", "b4_end", "'あげは' in b4_trust_answer"),
    ("第4章B", "b4_kami_grab", "8月 神城の告白：つかみかかった", "b4_end", "b4_kamishiro == 'grab'"),
    ("第4章B", "b4_kami_other", "8月 神城の告白：黙って聞いた／一緒に倒す", "b4_end", "b4_kamishiro in ('listen', 'together')"),
    ("第4章B", "b4_honda_tell", "6/30 本田の弱点を言った", "b4_end", "b4_honda == 'tell'"),
    ("第4章B", "b4_honda_stay", "6/30 本田と居残りした", "b4_end", "b4_honda == 'stay'"),
    ("第4章B", "b4_knee_tell", "8/30 ひざのことを鬼塚に話した", "b4_end", "b4_knee == 'tell'"),
    ("第4章B", "b4_knee_hide", "8/30「問題ありませんでした」", "b4_end", "b4_knee == 'hide'"),
    ("第4章B", "b4_fail", "能力の判定で失敗したところを見た", "b4_end", "check_fail_n > 0"),
    ## 第5章B
    ("第5章B", "b5_tell_saki", "10/3 紗希に話した", "b5_end", "b5_tell == 'saki'"),
    ("第5章B", "b5_tell_mother", "10/3 母さんに話した", "b5_end", "b5_tell == 'mother'"),
    ("第5章B", "b5_tell_kami", "10/3 神城に話した", "b5_end", "b5_tell == 'kamishiro'"),
    ("第5章B", "b5_tell_alone", "10/3 だれにも言わなかった", "b5_end", "b5_tell == 'alone'"),
    ("第5章B", "b5_surgery", "運命の選択②：手術した", "b5_end", "b5_surgery is True"),
    ("第5章B", "b5_nosurgery", "運命の選択②：手術しなかった", "b5_end", "b5_surgery is False"),
    ("第5章B", "b5_final_tell", "県の決勝：神城に「走れない」", "b5_end", "b5_final == 'tell'"),
    ("第5章B", "b5_final_silent", "県の決勝：黙って走った", "b5_end", "b5_final == 'silent'"),
    ("第5章B", "b5_fest_saki", "桜嶺祭：紗希", "b5_end", "b5_fest_with == 'saki'"),
    ("第5章B", "b5_fest_ageha", "桜嶺祭：あげは", "b5_end", "b5_fest_with == 'ageha'"),
    ("第5章B", "b5_fest_reika", "桜嶺祭：麗華", "b5_end", "b5_fest_with == 'reika'"),
    ("第5章B", "b5_xmas_saki", "クリスマス：紗希", "b5_end", "b5_xmas == 'saki'"),
    ("第5章B", "b5_xmas_ageha", "クリスマス：あげは", "b5_end", "b5_xmas == 'ageha'"),
    ("第5章B", "b5_xmas_reika", "クリスマス：麗華", "b5_end", "b5_xmas == 'reika'"),
    ("第5章B", "b5_xmas_hug", "クリスマス：麗華を抱きしめた", "b5_end", "flags.get('b5_麗華_クリスマスのハグ')"),
    ("第5章B", "b5_xmas_dorm", "クリスマス：寮の食堂", "b5_end", "b5_xmas == 'dorm'"),
    ("第5章B", "b5_val_saki", "バレンタイン：紗希", "b5_end", "b5_val == 'saki'"),
    ("第5章B", "b5_val_ageha", "バレンタイン：あげは", "b5_end", "b5_val == 'ageha'"),
    ("第5章B", "b5_reika_kept", "第5章の終わりまで、麗華と付き合っている", "b5_end", "b4_reika == 'lover'"),
    ("第5章B", "b5_muri80", "第5章の終わり：無理ゲージ80以上", "b5_end", "hidden.get('無理ゲージ', 0) >= 80"),
    ("第5章B", "b5_fail", "能力の判定で失敗したところを見た", "b5_end", "check_fail_n > 0"),
]

init python:
    CHK_AT = {}
    for _g, _id, _t, _at, _c in CHK_ITEMS:
        CHK_AT.setdefault(_at, []).append((_id, _c))

    def chk_top():
        best, who = -1, ""
        for h in ("ひなた", "千夏", "紗希", "あげは"):
            v = store.heart.get(h, {}).get("ときめき", 0)
            if v > best:
                best, who = v, h
        return who

    ## たしかめる場所 → その章の頭のラベル（この周でその章を頭から遊んだときだけ数える）
    CHK_REQ = {"chapter2": "chapter1", "chapter3": "chapter2", "trial_end": "chapter3",
               "a4_end": "chapter4a", "a5_end": "chapter5a", "a6_end": "chapter6a",
               "b4_end": "chapter4b", "b5_end": "chapter5b"}
    CHK_START = set(CHK_REQ.values())

    def _chk_eval(at):
        """たしかめる場所 at の項目を、いまの状態で見て「済」にする"""
        done = dict(persistent.chk_done or {})
        for cid, cond in CHK_AT.get(at, []):
            try:
                if cid not in done and eval(cond, store.__dict__):
                    done[cid] = "auto"
            except Exception:
                pass
        persistent.chk_done = done

    def chk_label_cb(name, abnormal):
        """章の終わりのラベルに来たとき、その時点の状態で項目を「済」にする（場面ジャンプ・ヒロイン場面では数えない）"""
        if not author_tools_on():
            return
        if getattr(store, "sj_testing", False) or getattr(store, "hs_testing", False):
            return
        ## 製品版の続きを遊ぶときは、体験版の終わり（trial_end）を通らずに第4章へ行くので、第4章の頭で第3章の項目を見る
        at = "trial_end" if name in ("chapter4a", "chapter4b") else name
        if at in CHK_AT and CHK_REQ.get(at) in store.chk_played:
            _chk_eval(at)
            store.check_fail_n = 0
        if name in CHK_START:
            if name not in store.chk_played:
                store.chk_played = store.chk_played + [name]
            store.check_fail_n = 0
    config.label_callbacks.append(chk_label_cb)

    def chk_toggle(cid):
        done = dict(persistent.chk_done or {})
        if cid in done:
            del done[cid]
        else:
            done[cid] = "hand"
        persistent.chk_done = done
        renpy.restart_interaction()

    def chk_edit_memo(cid, title):
        memo = dict(persistent.chk_memo or {})
        _ss = renpy.game.interface.screenshot
        _sss = renpy.game.interface.screenshot_surface
        v = renpy.invoke_in_new_context(renpy.input, "メモ：" + title, default=memo.get(cid, ""), length=200)
        renpy.game.interface.screenshot = _ss
        renpy.game.interface.screenshot_surface = _sss
        v = (v or "").strip()
        if v:
            memo[cid] = v
        elif cid in memo:
            del memo[cid]
        persistent.chk_memo = memo
        renpy.restart_interaction()

    def chk_export_text():
        lines = ["【アンイレ 検証リストのメモ】（ver.%s）" % config.version]
        done = persistent.chk_done or {}
        memo = persistent.chk_memo or {}
        for g in CHK_GROUPS:
            items = [(i, t) for (gg, i, t, a, c) in CHK_ITEMS if gg == g]
            n = sum(1 for i, t in items if i in done)
            lines.append("")
            lines.append("■ %s（済 %d／%d）" % (g, n, len(items)))
            for i, t in items:
                if i in memo:
                    lines.append("・%s%s：%s" % (t, "（済）" if i in done else "（まだ）", memo[i]))
        if (persistent.chk_memo or {}).get("_free"):
            lines.append("")
            lines.append("■ そのほか")
            lines.append(persistent.chk_memo["_free"])
        return "\n".join(lines)

    def chk_export():
        txt = chk_export_text()
        if renpy.emscripten:
            import emscripten, json as _j
            emscripten.run_script("(function(t){try{navigator.clipboard.writeText(t)}catch(e){}})(%s)" % _j.dumps(txt))
            renpy.notify("メモをコピーしました。チャットに貼ってください")
        else:
            p = os.path.join(config.basedir, "検証メモ.txt")
            io.open(p, "w", encoding="utf-8").write(txt)
            try:
                import pygame_sdl2.scrap as _scrap
                _scrap.put(_scrap.SCRAP_TEXT, txt.encode("utf-8"))
            except Exception:
                pass
            renpy.notify("メモを「検証メモ.txt」に書き出しました（コピーもしました）")

init python:
    import io, os

screen chk_list():
    modal True
    zorder 210
    add "gui/menu_bg.png"
    $ _gi = persistent.chk_tab if 0 <= persistent.chk_tab < len(CHK_GROUPS) else 0
    $ _g = CHK_GROUPS[_gi]
    $ _done = persistent.chk_done or {}
    $ _memo = persistent.chk_memo or {}
    $ _rows = [(i, t, a) for (gg, i, t, a, c) in CHK_ITEMS if gg == _g]
    frame:
        xpos 296
        ypos 34
        xsize 920
        ysize 640
        background None
        vbox:
            spacing 6
            hbox:
                spacing 14
                text "検証リスト（作者用）" size 26 color PEN_RED
                text "章の終わりまで遊ぶと、自動で「済」になります" size 15 color INK_SOFT yalign 0.5
            hbox:
                spacing 8
                for _i, _gg in enumerate(CHK_GROUPS):
                    $ _n = sum(1 for (g2, i2, t2, a2, c2) in CHK_ITEMS if g2 == _gg and i2 in _done)
                    $ _m = sum(1 for (g2, i2, t2, a2, c2) in CHK_ITEMS if g2 == _gg)
                    textbutton "%s %d/%d" % (_gg, _n, _m):
                        action SetField(persistent, "chk_tab", _i)
                        text_size 16
                        text_color (PEN_RED if _i == _gi else INK_SOFT)
                        text_hover_color PEN_RED
            hbox:
                spacing 22
                textbutton "メモをまとめてコピー" action Function(chk_export) text_size 18 text_color INK text_hover_color PEN_RED
                textbutton "そのほかのメモ" action Function(chk_edit_memo, "_free", "そのほか（どこでもない気づき）") text_size 18 text_color INK text_hover_color PEN_RED
                textbutton "閉じる" action Hide("chk_list") text_size 18 text_color INK text_hover_color PEN_RED
            viewport:
                ysize 520
                mousewheel True
                draggable True
                scrollbars "vertical"
                vbox:
                    spacing 4
                    for _id, _t, _a in _rows:
                        frame:
                            style "roster_card"
                            xsize 880
                            hbox:
                                spacing 12
                                textbutton ("済" if _id in _done else "□"):
                                    action Function(chk_toggle, _id)
                                    text_size 20
                                    text_color (PEN_TEAL if _id in _done else INK_SOFT)
                                    text_hover_color PEN_RED
                                    xminimum 40
                                vbox:
                                    spacing 0
                                    xsize 680
                                    text _t size 18 color INK
                                    if _id in _memo:
                                        text "メモ：" + _memo[_id] size 15 color PEN_RED
                                textbutton ("メモを直す" if _id in _memo else "メモ") action Function(chk_edit_memo, _id, _t) text_size 15 text_color INK_SOFT text_hover_color PEN_RED yalign 0.5
