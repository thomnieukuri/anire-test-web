## mobile.rpy ―― スマホ向けの調整
##   スマホ（画面が小さい／タッチ操作）で遊ぶときだけ使う画面とスタイル。
##   Ren'Py は、スマホでは "small" と "touch" という「バリアント」で動く。
##   ここに書いたものは、そのときだけ、PC 用の同じ名前の画面・スタイルの代わりに使われる。
##
##   PC で確かめるとき：ランチャーの「Android」→「Emulation」の「Phone」で起動する。


################################################################################
## メニューボタン（右上の三本線の付箋）と、付箋のメニュー
##   ボタンを出しっぱなしにすると絵が見えにくいので、画面の右上に
##   「三本線の付箋」（メニューボタン）だけを置く。押すと右側に付箋のメニューが開く。
##   スマホでは、セリフ枠のボタン（ログ・オート・スキップ）も出さない。
################################################################################

## セリフ枠のボタンは、スマホでは出さない（右上のメニューボタンにまとめる）
screen quick_buttons():
    variant "small"
    null

## 右上のメニューボタン（PC・スマホ共通）
screen menu_tab():
    zorder 60
    if quick_menu and not renpy.get_screen("quick_drawer"):
        imagebutton:
            idle "gui/menu_icon.png"
            hover "gui/menu_icon_hover.png"
            xalign 1.0
            xoffset -10
            ypos 8
            action Show("quick_drawer")
        ## v0.29.12：スマホでは、メニューを開かなくても1つ戻れるように、メニューボタンの左に「戻る」を置く
        if renpy.variant("small") or renpy.variant("touch"):
            textbutton "戻る":
                style "back_tab"
                text_style "back_tab_text"
                xalign 1.0
                xoffset -104
                ypos 18
                action Rollback()

## メニューボタンを押すと開く付箋のメニュー。外側をタップすると閉じる
screen quick_drawer():
    zorder 190
    modal True

    ## 外側（暗いところ）をタップしたら閉じる
    button:
        xysize (1280, 720)
        background "#00000066"
        action Hide("quick_drawer")

    frame:
        style "drawer_frame"
        vbox:
            style_prefix "drawer"
            textbutton "1つ戻る" action [Hide("quick_drawer"), Rollback()]
            textbutton "スキップ" action [Hide("quick_drawer"), Skip()]
            textbutton "次の選択肢へ" action [Hide("quick_drawer"), Skip(fast=True, confirm=True)]
            textbutton "オート" action [Hide("quick_drawer"), Preference("auto-forward", "toggle")]
            ## セーブとロードは、横に並べて色を分け、上下にすき間をあける（押しまちがい防止）
            null height 12
            hbox:
                spacing 18
                textbutton "セーブ" style "drawer_file_button" text_style "drawer_save_text" action [Hide("quick_drawer"), ShowMenu("save")]
                textbutton "ロード" style "drawer_file_button" text_style "drawer_load_text" action [Hide("quick_drawer"), ShowMenu("load")]
            null height 12
            textbutton "ログ" action [Hide("quick_drawer"), ShowMenu("history")]
            textbutton "ステータス" action [Hide("quick_drawer"), ShowMenu("status")]
            textbutton "相関図" action [Hide("quick_drawer"), ShowMenu("relations")]
            textbutton "設定" action [Hide("quick_drawer"), ShowMenu("preferences")]

    ## 閉じるボタン（メニューボタンと同じ場所）
    textbutton "×":
        style "drawer_close"
        action Hide("quick_drawer")

init python:
    config.overlay_screens.append("menu_tab")


################################################################################
## セーブ・ロード（スマホ）
##   テスターの声「iPhone でセーブ・ロードを押しまちがえる」への対応（v0.28.0）。
##   ・枠を「2列×3段」の横長のカードにして、1枠を大きく、すき間も広くする
##   ・ページのボタン（オート・1〜3。v0.31.1 でクイックを外した。v0.31.0 で9ページから3ページに）を大きな付箋にする
##   ・枠ごとに「消す」ボタンを出す（スマホには Delete キーがないため。押すと確認が出る）
##   ・見出しの横に、何をする画面かを色を変えて出す（セーブ＝赤、ロード＝青緑。screens.rpy の file_hint）
##   枠の番号は PC と同じ（1ページ6枠）なので、PC とスマホで同じセーブが同じ場所に出る。
################################################################################

screen file_slots(title):
    variant "small"
    $ _hint, _hcol = file_hint(title)
    use game_menu(title):
        vbox:
            spacing 10

            hbox:
                spacing 4
                style_prefix "page"
                textbutton "オート" action FilePage("auto")
                for page in range(1, 4):
                    textbutton "[page]" action FilePage(page)

            grid 2 3:
                xspacing 22
                yspacing 14
                for i in range(6):
                    $ slot = i + 1
                    button:
                        style "fcard_button"
                        action slot_action(title, slot)
                        fixed:
                            ## 写真（空きのときは灰色の四角）
                            if FileLoadable(slot):
                                add FileScreenshot(slot) pos (14, 14) size (192, 108)
                            else:
                                add Solid("#ddd6cb") pos (14, 14) size (192, 108)
                            text "No.%d" % slot style "fcard_no"
                            text FileTime(slot, format="%m/%d %H:%M", empty="― 空き ―") style "fcard_time"
                            $ _memo = FileJson(slot, "memo", missing="") or ""
                            if _memo:
                                text _memo style "fcard_name" color PEN_RED
                            else:
                                text FileSaveName(slot) style "fcard_name"
                            if FileLoadable(slot):
                                textbutton "消す" style "fcard_delete" action FileDelete(slot)

    text _hint style "file_hint" color _hcol


################################################################################
## 文字とボタンの大きさ（スマホ）
##   色やフォントは screens.rpy で決めているので、init 1 にしてそのあとで作る。
################################################################################

init 1:

    ## 能力値の変化などの付箋
    style toast_text:
        variant "small"
        size 21

    ## 左上の日付
    style hud_date:
        variant "small"
        size 23

    style hud_time:
        variant "small"
        size 21

    style hud_year:
        variant "small"
        size 18

    ## 行動マップの行き先のタグ
    style map_spot_event:
        variant "small"
        size 20

    style map_spot_done:
        variant "small"
        size 20

    ## セーブ枠
    style slot_time:
        variant "small"
        size 21

    style slot_name:
        variant "small"
        size 18

    style page_button:
        variant "small"
        xminimum 66
        ysize 56
        padding (12, 0, 12, 4)
        background "#ece6d6"
        hover_background "#f6e7a6"
        selected_background "#f2c230"

    style page_button_text:
        variant "small"
        xalign 0.5
        yalign 0.5
        font FONT_JP_B
        size 25
        color INK_SOFT
        selected_color INK

    ## セーブ枠（スマホの横長カード）
    style fcard_button:
        xysize (440, 150)
        padding (0, 0, 0, 0)
        background Frame("gui/grid/card.png", 4, 4)
        hover_background Frame("gui/grid/card_hover.png", 4, 4)

    style fcard_no:
        pos (222, 12)
        size 18
        color INK_SOFT

    style fcard_time:
        pos (222, 36)
        font FONT_JP_B
        size 27
        color INK

    style fcard_name:
        pos (222, 76)
        xsize 206
        size 17
        line_spacing 0
        color INK_SOFT

    style fcard_delete:
        xpos 428
        xanchor 1.0
        ypos 140
        yanchor 1.0
        padding (14, 6, 14, 6)
        hover_background "#ffffff88"

    style fcard_delete_text:
        size 20
        font FONT_JP_B
        color PEN_RED
        hover_color INK
        underline True

    ## ログ
    style history_name:
        variant "small"
        size 22

    style history_text:
        variant "small"
        size 26

    ## トーク画面
    style bubble_text:
        variant "small"
        size 21

    style talk_meta:
        variant "small"
        size 14

    style talk_sender:
        variant "small"
        size 16

    style talk_pill_text:
        variant "small"
        size 16

    style talk_title:
        variant "small"
        size 21

    style talk_status:
        variant "small"
        size 16

    ## 返信の選択肢
    style talk_choice_text:
        variant "small"
        size 23

    ## 右上のメニュー（付箋）
    style drawer_frame:
        xalign 1.0
        xoffset -12
        ypos 8
        xysize (330, 676)
        background "gui/drawer.png"
        padding (20, 76, 30, 22)    # 上は「×」ボタンを置く「のり」の部分

    style drawer_vbox:
        spacing 0

    style drawer_button:
        xfill True
        ysize 57
        padding (14, 0, 14, 4)
        hover_background "#ffffff55"

    style drawer_button_text:
        yalign 0.5
        font FONT_JP_B
        size 30
        color INK
        hover_color PEN_RED
        selected_color PEN_RED

    style drawer_file_button:
        xysize (131, 68)
        padding (0, 0, 0, 4)
        background "#ffffff66"
        hover_background "#ffffffaa"

    style drawer_save_text:
        xalign 0.5
        yalign 0.5
        font FONT_JP_B
        size 30
        color PEN_RED
        hover_color INK

    style drawer_load_text is drawer_save_text:
        color PEN_TEAL

    ## スマホの右上の「戻る」（メニューボタンの左）
    style back_tab:
        xysize (92, 64)
        background Frame(Solid("#fff4baee"), 0, 0)
        hover_background Frame(Solid("#fff8d0"), 0, 0)
        insensitive_background Frame(Solid("#fff4ba88"), 0, 0)
        padding (0, 0, 0, 4)
    style back_tab_text:
        xalign 0.5
        yalign 0.5
        font FONT_JP_B
        size 28
        color INK
        hover_color PEN_RED
        insensitive_color "#3c2d2366"

    style drawer_close is drawer_button
    style drawer_close:
        xalign 1.0
        xoffset -22
        ypos 14
        xfill False
        xsize 64
        ysize 64
        padding (0, 0, 0, 0)

    style drawer_close_text:
        xalign 0.5
        yalign 0.5
        size 34
        color INK_SOFT
        hover_color PEN_RED

