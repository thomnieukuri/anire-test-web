## chapter6a.rpy ―― 第6章「潮風の決勝」ルートA（港北に残る）・高3の4〜6月（v0.33.0・Claude の第1稿。作者が読んで直す）
##   構成案：ルートA 第6章「潮風の決勝」構成案（Claude Docs）。決まったことは「第6章_決定事項」
##   4/7 始業式（新入生のいない春）→ 4/10 フェンスの外の佐伯 → 自由行動①（5月・4日）→ 5/20 三好先輩
##   → 6/10 インターハイ予選準決勝・清翔へのリベンジ → 6/11 決勝
##   7〜10月は chapter6a_2.rpy、11月の決勝（桜嶺戦）は chapter6a_3.rpy、12〜1月は chapter6a_4.rpy、
##   自由行動・練習の出来事・夜のトークは chapter6a_free.rpy
##
##   ※ 製品版（有料）の部分。第5章の最後（3/1）から続く
##   ※ ヒロインの取り合い：揺れる場面（sway_pair）は、8/5 の夏祭りと 11/12 の決勝の朝に置いた。告白は来た順に答える（第6章_決定事項）
##   ※ 新しい一枚絵は、まだ描いていない（下の「仮の絵」。今ある絵に「準備中」の文字をのせて出す）

default a6_chika_call = "早瀬くん"    # 千夏が蓮を呼ぶ名前（恋人なら「蓮くん」。ほかは第4章の a4_chika_call のまま）
default a6_lover = ""             # 付き合っている人（"千夏" など。第5章の卒業式で「付き合う」、または 7/22 に答えた人）
default a6_ih = ""                # インターハイ予選の結果："win"（優勝）/ "final"（決勝で負け）
default a6_ih_semi = ""           # インターハイ予選準決勝（清翔）のスコア
default a6_miyoshi = ""           # 5/20 三好先輩に言ったこと：zenkoku / honest / thanks

## 第6章の仮の絵（今ある絵に「準備中」の文字をのせる。本番の絵ができたら同じ名前で差し替え）
init python:
    def a6_tmp(path, note):
        return Fixed(path,
                     Solid("#0006", xysize=(1280, 96)),
                     Text("（絵は準備中）" + note, font=FONT_JP_B, size=26, color="#ffffff", xalign=0.5, ypos=30),
                     xysize=(1280, 720))

image cg a6_empty_class = a6_tmp("images/bg/kohoku_hall_spring.jpg", "　空っぽの1年の教室")
image cg a6_ih_win = a6_tmp("images/cg/ch3_armband.jpg", "　インハイ予選の優勝")
image cg a6_fes_hinata = a6_tmp("images/cg/a4_fes_hinata.jpg", "　最後の夏祭り・ひなた")
image cg a6_fes_chika = a6_tmp("images/cg/a4_fes_chika.jpg", "　最後の夏祭り・千夏")
image cg a6_fes_ageha = a6_tmp("images/cg/a4_fes_ageha.jpg", "　最後の夏祭り・あげは")
image cg a6_kuroda_box = a6_tmp("images/cg/a5_mother_night.jpg", "　黒田と青いリボンの小包")
image cg a6_final_entrance = a6_tmp("images/cg/ch3_entrance.jpg", "　決勝の入場")
image cg a6_kamishiro_block = a6_tmp("images/cg/ch3_kamishiro_ankle_pitch.jpg", "　神城が間に入る")
image cg a6_onizuka_sign = a6_tmp("images/cg/ch3_kamishiro_face.jpg", "　鬼塚の合図と真壁の目")
image cg a6_final_goal = a6_tmp("images/cg/ch3_entrance8.jpg", "　決勝の決勝点")
image cg a6_final_win = a6_tmp("images/cg/ch3_newyear.jpg", "　桜嶺に勝った瞬間")
image cg a6_nat_stadium = a6_tmp("images/bg/stadium_winter_eve.jpg", "　全国大会のスタジアム")
image cg a6_hatsumode_hinata = a6_tmp("images/cg/a5_val_hinata.jpg", "　初詣のひなた")

## ---------------------------------------------------------------------------
## 第6章のカレンダーと、自由行動の表（第4章の仕組みをそのまま使う。月の名前は a6may / a6oct）
## ---------------------------------------------------------------------------
init 1 python:
    CHAPTER_YEAR["chapter6a"] = 2028
    CAL_SCHEDULE.update({
        (2028, 4, 7): ("始業式", False, True),
        (2028, 5, 20): ("三好先輩", False, (2028, 5, 13)),
        (2028, 6, 3): ("インハイ予選", True, (2028, 4, 10)),
        (2028, 6, 10): ("準決勝", True, (2028, 6, 4)),
        (2028, 6, 11): ("決勝", True, (2028, 6, 4)),
        (2028, 7, 29): ("最後の合宿", False, (2028, 6, 12)),
        (2028, 8, 5): ("夏祭り", False, True),
        (2028, 10, 9): ("選手権予選", True, (2028, 9, 1)),
        (2028, 11, 4): ("準決勝", True, (2028, 10, 29)),
        (2028, 11, 12): ("決勝", True, (2028, 10, 29)),
        (2028, 12, 30): ("全国大会", True, (2028, 11, 12)),
        (2029, 1, 1): ("元日", False, True),
    })
    CAL_EVENTS.extend([
        ((2028, 6, 10), "インハイ予選準決勝"),
        ((2028, 11, 12), "選手権予選決勝"),
    ])
    A4_FREE["a6may"] = (["5月8日（月）", "5月10日（水）", "5月12日（金）", "5月13日（土）"], "放課後", "高3の5月、どこへ行く？")
    A4_FREE["a6oct"] = (["10月2日（月）", "10月4日（水）", "10月6日（金）", "10月7日（土）"], "放課後", "選手権の前、どこへ行く？")
    A4_RECAP["a6may"] = ("高3になった。港北に、新入生は来なかった。\n\n"
                         "最後の新入生は、小早川たち。\n俺たちは、11人で戦える、最後の代だ。\n\n"
                         "6月3日から、インターハイ予選。")
    A4_RECAP["a6oct"] = ("最後の冬が来る。\n選手権予選は、10月9日から。\n\n"
                         "決勝まで行けば、桜嶺と当たる。\n神城と。")
    PRACTICE_ADVICE["a6may"] = ("戦術眼", "清翔は、こっちの「見る」を消しにくる。……消されても見えるやつだけが、6月に残る")
    PRACTICE_ADVICE["a6oct"] = ("", "最後の練習の重点は、お前が決めろ。……三年、見てきた。もう、俺が決めることじゃない")


################################################################################
## 第6章の入口（第5章の a5_end のあとから）
################################################################################
label chapter6a:
    $ quick_menu = True
    $ play_marks["chapter6a"] = renpy.get_game_runtime()   # 古いセーブで続きが見つからないとき、ここから続ける
    $ a6_lover = "千夏" if (a5_grad == "lover" and a5_grad_answer == "yes") else ""
    $ a6_chika_call = "蓮くん" if a6_lover == "千夏" else a4_chika_call
    call show_title("第6章", "潮風の決勝")
    call a6_april
    call a6_saeki_fence
    call a6_free_loop("a6may")
    call a6_miyoshi_day
    call a6_ih_semi
    call a6_ih_final
    jump chapter6a_2


################################################################################
## 4月7日：始業式。新入生のいない春
################################################################################
label a6_april:
    scene black
    with dissolve
    $ set_cal("4月7日（金）", "朝")
    scene bg kohoku_gate_morning
    with dissolve
    $ bgm("静かな春の曲")
    "校門の桜は、去年と同じように咲いていた。去年と違うのは、新入生の列が、どこにもないことだった。"
    "体育館の入口に「入学式」の看板はなく、かわりに「始業式」とだけ書いた紙が貼ってあった。"
    scene cg a6_empty_class
    with dissolve
    "1年の教室の前を通った。机も椅子も、うしろの壁にそろえて積んであった。黒板には、何も書いていなかった。"
    show kobayakawa uniform
    with dissolve
    kobayakawa "……僕らが、いちばん下のままですね"
    kobayakawa "先輩たちが卒業しても、来年、この教室には、だれも来ないんです"
    menu:
        "「だから、お前たちに何か残す」":
            $ lean("仲間型")
            ren "だから、お前たちに、何か残す。……一個でいいから"
            kobayakawa "……はい。一個、ください"
            $ set_flag("a6_小早川に残す")
        "「教室じゃなくて、グラウンドを見ろ」":
            $ lean("求道型")
            ren "教室じゃなくて、グラウンドを見ろ。……あっちは、まだ満員だ"
            "小早川は、廊下の窓から、グラウンドを見た。朝練の片づけをする15人が、豆みたいに見えた。"
            kobayakawa "……満員、ですね"
    hide kobayakawa
    with dissolve
    ## ひざ：手術した人は「走る」日、しなかった人は痛み止め
    scene bg kohoku_ground_eve
    with dissolve
    $ set_cal("4月7日（金）", "放課後")
    $ bgm("あたたかいアコースティックギター")
    if a5_surgery:
        "放課後、グラウンドの端で、ひなたがストップウォッチを持って立っていた。手術から、半年だった。"
        show hinata normal
        with dissolve
        hinata "今日から、走っていいって。……先生が言ったの、ちゃんと聞いたからね。わたしも、横で"
        hinata "ノート、4冊目。最後のページ、まだ白いの。今日、書くから"
        "ゆっくり走った。右足で地面を蹴ると、ひざは、何も言わなかった。半年ぶりに、何も言わなかった。"
        show hinata teary
        hinata "……っ、いま、右で蹴った。ちゃんと、蹴った"
        "ひなたは、ノートの最後のページに、大きく一文字だけ書いた。「走」。"
        $ heart_up("ひなた", "信頼", 3)
        $ up("フィジカル", 2)
        $ up("無理ゲージ", -5)
    else:
        "部室で、カバンの奥から、白い錠剤のシートを出した。1年前は1列だった。今は、3列あった。"
        show hinata stare
        with dissolve
        hinata "……今日も、飲むの"
        ren "練習のあとだけだ"
        hinata "うそ。前だよ。……前に飲まないと、ダッシュのとき、眉毛が寄るもん"
        "ひなたは、シートを取り上げなかった。かわりに、テーピングを、去年より一周多く巻いた。"
        show hinata serious
        hinata "高3の冬まで、行くって決めたのは、蓮だよ。……だから、わたしは、最後まで巻く"
        hinata "でも、止まったら、止める。それだけは、決めてるから"
        $ heart_up("ひなた", "信頼", 2)
        $ up("無理ゲージ", 3)
    hide hinata
    with dissolve
    ## 黒田の最後の並び
    scene bg clubroom
    with dissolve
    $ bgm("作戦会議っぽい軽快な曲")
    show kuroda board
    with dissolve
    kuroda "……今年の並びだ"
    "ホワイトボードに、4−2−3−1の丸が11個。去年と同じ形で、名前が二つ、入れかわっていた。"
    kuroda "ボランチは、小早川と小池。トップ下、早瀬。前は鷹野。……形は、去年と同じだ"
    kuroda "違うのは、交代の欄だ。今年は、名前が6つ書ける"
    "ホワイトボードの右下に、小さな枠が6つ。倉田、赤坂……2年になった後輩たちの名前が、書きこまれた。"
    kuroda "おととしの春、ここには、十一個の丸しかなかった。……それを、覚えておけ"
    if a4_captain == "takano":
        show takano normal at right
        with dissolve
        takano "キャプテンは、俺のままでいいのか"
        kuroda "お前が決めろ。……腕章は、もうお前の腕だ"
        hide takano
    else:
        kuroda "キャプテンは、早瀬。……変える理由は、ない"
    hide kuroda
    with dissolve
    ## あげは：2年になった
    show ageha normal
    with dissolve
    ageha "パイセン、見て見て。部のアカ、フォロワー、ついに四桁！"
    ageha "去年の「最後の世代」の動画、まだ回ってんの。……で、今年のタイトル、決めた"
    ageha "「最後の世代、最後の一年」。……どう？　エモくない？"
    if a5_secret == "keep" or a5_ageha_saw == "hush":
        ## あげはは、蓮のひざのことを知っている
        show ageha serious
        if a5_surgery:
            ageha "……あと。リハビリの回数、あたし、数えてるからね。言わないけど、数えてる"
        else:
            ageha "……あと。痛み止めの数、あたし、数えてるからね。言わないけど、数えてる"
    hide ageha
    with dissolve
    mono "高3の春。"
    mono "11人で戦える、最後の一年が、始まった。"
    return


################################################################################
## 4月10日：フェンスの外の佐伯さん
################################################################################
label a6_saeki_fence:
    scene black
    with dissolve
    $ set_cal("4月10日（月）", "夕方")
    scene bg kohoku_ground_eve
    with dissolve
    $ bgm("静かな緊張感のある曲")
    "紅白戦の途中で、フェンスの外に、見覚えのある男の人が立っているのに気づいた。手帳とペン。佐伯さんだった。"
    "佐伯さんは、声をかけてこなかった。グラウンドの中の黒田と、一度だけ、目を合わせた。"
    "黒田は、目をそらさなかった。そらさないまま、ストップウォッチを押した。"
    show saeki normal
    with dissolve
    saeki "……練習の邪魔をしに来たんじゃない。見に来ただけだ"
    saeki "去年の夏、名刺を渡したな。……あれは、まだ使わなくていい。最後の冬が終わってからだ"
    if a5_surgery:
        saeki "右で踏み切れるようになったんだな。……見る目がなかったのは、やっぱり俺のほうだ"
    else:
        saeki "右に、体重をのせてない。……黒田さんは、気づいてるだろう。あの人は、そういうのを、見逃さない"
    "佐伯さんは、手帳に何か書いて、閉じた。帰りぎわ、黒田のほうに、少しだけ頭を下げた。"
    hide saeki
    with dissolve
    show kuroda normal
    with dissolve
    ren "……知り合い、なんですか"
    kuroda "昔の、チームメイトだ"
    kuroda "それ以上は、今は言わん。……紅白戦、続けるぞ"
    hide kuroda
    with dissolve
    $ set_flag("a6_佐伯_フェンス")
    $ up("注目度", 2)
    return


################################################################################
## 自由行動のくり返し（第5章の a5_free_loop と同じ形）
################################################################################
label a6_free_loop(month):
    $ a4_dates, a4_time, a4_banner = A4_FREE[month]
    $ recap_text = A4_RECAP[month]
    scene black
    with dissolve
    window auto hide
    if month == "a6may":
        tuto "自由行動です。5月の放課後は4日。インターハイ予選の前に、いろんな人と話しておけます。"
    else:
        tuto "自由行動です。10月の放課後は4日。最後の選手権の前です。"
    $ a4_day = 1
    while a4_day <= len(a4_dates):
        $ amb_stop()
        $ set_cal(a4_dates[a4_day - 1], a4_time)
        $ bgm("作戦会議っぽい軽快な曲")
        window auto hide
        call practice_day(month)
        $ set_cal(a4_dates[a4_day - 1], a4_time)
        $ bgm("作戦会議っぽい軽快な曲")
        window auto hide
        call screen action_map(a4_spots(month), a4_banner + "（残り" + str(len(a4_dates) + 1 - a4_day) + "日）")
        $ _lab = a4_spot_label(month, _return)
        $ set_flag(_lab)
        call expression _lab
        $ amb_stop()
        call a4_night_send(a4_dates[a4_day - 1], month)
        $ a4_day += 1
    $ amb_stop()
    return


################################################################################
## 5月20日：三好先輩が、作業着で来る
################################################################################
label a6_miyoshi_day:
    scene black
    with dissolve
    $ set_cal("5月20日（土）", "夕方")
    scene bg kohoku_ground_eve
    with dissolve
    $ bgm("あたたかいアコースティックギター")
    "練習が終わるころ、フェンスの向こうで、作業着の大きな人が手を振っていた。"
    show miyoshi work
    with dissolve
    miyoshi "よう！　……うわ、人数、多いな！　俺のころ、ここ、11人ぴったりだったのに"
    sakaguchi "三好先輩！　作業着、似合いすぎっす！"
    miyoshi "だろ。……工務店、二年目だ。今は、体育館の雨もりを直してる。この学校の"
    miyoshi "あと二年で閉まる校舎だけどな。……閉まる日まで、雨はもらさねえ"
    "三好先輩は、グラウンドの真ん中まで来て、芝のはげたところを、作業靴のつま先でならした。"
    if a4_miyoshi == "zenkoku":
        miyoshi "卒業式の日、お前、俺に「全国、行きます」って言ったな"
        miyoshi "……あれ、まだ有効か？"
    elif a4_miyoshi == "left":
        miyoshi "卒業式の日、お前、「残ってくれて、ありがとうございました」って言ったな"
        miyoshi "残ったのは、お前のほうだ。……で、どうだ。残った一年は"
    else:
        miyoshi "卒業式の日、お前、「ありがとうございました」しか言わなかったな"
        miyoshi "……あれは、あれで、うれしかったぞ。で、今年は、どうする"
    menu:
        "「全国、行きます」":
            $ a6_miyoshi = "zenkoku"
            $ lean("野心型")
            ren "全国、行きます。……今年こそ"
            show miyoshi smile
            miyoshi "よし。じゃあ俺は、冬の決勝のスタンドで、いちばんでかい声を出す。仕事、休んで"
            $ bond_up("三好", 3)
        "「正直、こわいです」":
            $ a6_miyoshi = "honest"
            $ lean("求道型")
            ren "正直、こわいです。……最後だから"
            miyoshi "……そうか。俺も、こわかったぞ。最後の夏は、ずっと"
            miyoshi "こわいって言えるやつは、最後まで走れる。言えねえやつは、途中で止まる。……お前は、もう大丈夫だ"
            $ bond_up("三好", 4)
            $ up("メンタル", 2)
        "「先輩がいたから、ここまで来ました」":
            $ a6_miyoshi = "thanks"
            $ lean("仲間型")
            ren "先輩がいたから、ここまで来ました"
            miyoshi "ばか。……泣かせんな、作業着で"
            "三好先輩は、軍手で目をこすって、ついた砂で、もっと目をこすった。"
            $ bond_up("三好", 4)
    hide miyoshi
    with dissolve
    return


################################################################################
## 6月10日（土）インターハイ予選準決勝：港北 対 清翔学園（去年の冬のリベンジ）
################################################################################
label a6_ih_semi:
    scene black
    with dissolve
    $ set_cal("6月10日（土）", "インターハイ予選準決勝")
    scene bg pref_ground_day
    with dissolve
    $ bgm("張りつめた静かな曲")
    "1回戦から準々決勝までの3試合は、どれも1点差だった。準決勝の相手は、去年の冬に負けた、清翔学園だった。"
    "桜嶺は、もう、いなかった。2軍で出た桜嶺は、反対の山の2回戦で、県立高校に負けていた。"
    show kuroda board
    with dissolve
    kuroda "鬼塚は、夏を捨てた。……冬だけを見てる"
    kuroda "だから、この夏は、俺たちと清翔の夏だ。……去年の冬、何をされたか、覚えてるな"
    if a5_surgery:
        ren "……ベンチから、見てました。トップ下の右に、必ず一人"
    else:
        ren "右側に、必ず一人"
    kuroda "そうだ。今年も、来る。……結城は、同じことを二回やる監督じゃない。二回やるなら、もっと上手にやる"
    hide kuroda
    with dissolve
    ## 試合前：鷹野と結城
    show takano match
    with dissolve
    "アップの途中、清翔のベンチの前で、結城さんが鷹野に声をかけていた。鷹野は、帽子をとるみたいに、軽く頭を下げた。"
    if a4_takano == "push":
        takano "……「元気そうだな」って言われた。それだけだ"
        takano "去年、お前は背中を押した。行けって言った。……ここを選んだのは、俺だ。今日、それを見せる"
        $ bond_up("鷹野", 2)
    else:
        takano "……「まだ、迷ってるか」って聞かれた"
        takano "迷ってねえ、って言った。……言ったけどな。お前が去年、止めなかったら、俺は今、あっちのベンチにいた"
        takano "止めてくれてよかったのか。……今日、分かる"
    hide takano
    with dissolve
    $ se("キックオフの笛")
    $ sb_set("前半", 0, 0, 0, 0, "#2a5bd7", "#7a1f2b", "港北", "清翔")
    scene bg pref_ground_day at cam_jog
    with dissolve
    show screen letterbox
    show screen scoreboard
    $ bgm("緊迫した試合の曲")
    if a5_surgery:
        "清翔は、去年の冬にベンチから見たのと同じ形で、俺の右側に一人を立たせた。……違ったのは、左側にも、もう一人いたことだった。"
    else:
        "清翔は、去年と同じように、俺の右側に一人を立たせた。……違ったのは、左側にも、もう一人いたことだった。"
    "二人に挟まれると、前が見えなかった。見えないまま、前半の20分が過ぎた。"
    $ sb_set(mm=24)
    "前半24分。小早川が、首を三回振ってから、俺を見ないで、右の大外へ蹴った。……俺を、使わなかった。"
    menu:
        "二人を引きつけたまま、真ん中に立ち続ける":
            $ lean("求道型")
            "動かなかった。二人の清翔の選手は、俺から離れなかった。真ん中に、穴があいた。"
            if check("戦術眼", 68):
                "その穴に、鷹野が、下りてきた。坂口のクロスを、鷹野は胸で落として、振り向きざまに打った。"
                $ goal("港北", home=1, away=0, mm=26)
                with vpunch
                takano "……お前、何もしてねえのに、いちばん仕事したな"
                $ _ih1 = "早瀬が二人を引きつける　→　鷹野が空いた真ん中で決める"
            else:
                "穴に気づくのが、半拍遅れた。坂口のクロスは、清翔のキーパーにつかまれた。"
                "でも、清翔のコーチが、ベンチで初めて立ち上がった。……効いてる、と分かった。"
                $ _ih1 = ""
        "右に流れて、二人をはがしにいく":
            $ lean("野心型")
            $ up("無理ゲージ", 2)
            "右に、流れた。一人がついてきた。もう一人は、ついてこなかった。……その一人を、外した。"
            if check("技術", 68):
                "右のタッチライン沿いで、半身になった。左足のアウトで、鷹野の前に転がした。鷹野は、流しこむだけだった。"
                $ goal("港北", home=1, away=0, mm=27)
                with vpunch
                $ _ih1 = "早瀬が右に流れて一人をはがす　→　左足のアウトで鷹野へ"
            else:
                "外したつもりの一人に、つま先でボールをつつかれた。ボールは、ラインを割った。"
                $ _ih1 = ""
    if not _ih1:
        $ sb_set(mm=41)
        "前半41分。ペナルティエリアの外から、小早川が、初めて自分で打った。ボールは、ポストの内側に当たって、入った。"
        $ goal("港北", home=1, away=0, mm=41)
        with vpunch
        kobayakawa "……う、打っちゃいました"
        $ _ih1 = "小早川のミドルシュート（ポストの内側）"
    $ se("前半終了の笛")
    hide screen scoreboard
    scene bg pref_ground_day
    with dissolve
    $ bgm("静かな緊張感のある曲")
    "ハーフタイム。1−0。清翔のベンチでは、結城さんが、怒鳴らずに、一人ずつ選手の目を見て話していた。"
    $ sb_set("後半", 45)
    show screen scoreboard
    scene bg pref_ground_day at cam_jog
    with dissolve
    $ bgm("試合の曲（終盤）")
    $ sb_set(mm=68)
    $ se("ボールを奪われる音")
    "後半23分。清翔の10番に、大門の前で、ボールを浮かされた。……1−1。"
    $ goal("清翔", home=1, away=1, mm=68)
    with vpunch
    daimon "……すみません！　僕のところです！"
    if check_bond("大門", 70):
        "大門は、それきり、一本も入れさせなかった。最後の10分、清翔のシュートを、三本、体で止めた。"
    else:
        "最後の10分、清翔のシュートが二本、ポストをたたいた。三本目は、ベンチの倉田がコースを叫んで、大門が指先ではじいた。"
    $ sb_set(mm=89)
    "後半44分。鷹野が、右サイドで倒されながら、ボールを残した。そのボールが、俺の前に、転がってきた。"
    $ se("ボールを蹴る音")
    if check("メンタル", 62):
        "迷わなかった。……迷う時間を、三年かけて、なくしてきた。"
        $ goal("港北", home=2, away=1, mm=89)
        with vpunch
        $ a6_ih_semi = "2−1"
        $ _ih2 = "後半44分　早瀬の決勝点（鷹野が倒されながら残したボール）"
    else:
        "打った。ボールは、キーパーの指先に当たって、上に跳ねた。……そこに、赤坂がいた。"
        $ goal("港北", home=2, away=1, mm=90)
        with vpunch
        akasaka "先輩のこぼれ球、全部、俺のっす！！"
        $ a6_ih_semi = "2−1"
        $ _ih2 = "後半45分　早瀬のシュートのこぼれ球　→　赤坂の決勝点"
    $ se("試合終了の笛")
    pause 1.0
    hide screen scoreboard
    hide screen letterbox
    scene bg pref_ground_day
    with Dissolve(1.0)
    python:
        _rows = [("スコア", "2−1（勝ち）"), ("前半", _ih1), ("後半23分", "清翔の10番のゴール"), ("最後", _ih2)]
        _memo = "ひなた：去年の冬の、借りを返した。……ノートに、そう書いていい？"
    call screen match_report("インターハイ予選準決勝　港北 対 清翔学園", _rows, _memo)
    $ bgm("（なし）")
    "試合のあと、結城さんが港北のベンチまで来て、黒田と短く握手をした。"
    "それから鷹野の前で止まり、先に頭を下げた鷹野の肩を、一回だけたたいて、戻っていった。"
    mono "清翔に、勝った。"
    mono "去年の冬の1−2は、ノートの中で、2−1になった。"
    $ bond_up("鷹野", 4)
    $ bond_up("大門", 2)
    $ up("注目度", 4)
    $ up("戦術眼", 1)
    return


################################################################################
## 6月11日（日）インターハイ予選決勝：港北 対 鳴海（短く）
################################################################################
label a6_ih_final:
    scene black
    with dissolve
    $ set_cal("6月11日（日）", "インターハイ予選決勝")
    scene bg pref_ground_eve
    with dissolve
    $ bgm("緊迫した試合の曲")
    "決勝の相手は、鳴海高校だった。去年の夏、後ろに9人並べたチーム。今年は、もう、前から来るチームになっていた。"
    "前の日に90分走った足は、だれのも重かった。それでも、走った。"
    if check("フィジカル", 58):
        "後半30分、鳴海の足が、先に止まった。坂口のクロスに、鷹野が頭で合わせた。1−0。"
        $ se("試合終了の笛")
        $ a6_ih = "win"
        scene cg a6_ih_win
        with Dissolve(1.0)
        "試合終了の笛のあと、だれも、すぐには喜ばなかった。……喜び方を、知らなかった。"
        "坂口が、最初に泣いた。森が、それにつられた。一年のとき、部を辞めかけた5人が、輪の真ん中で泣いていた。"
        mono "港北、インターハイ予選、優勝。"
        mono "創部以来、初めての、県の一番だった。"
        $ up("注目度", 8)
        $ bond_up("坂口", 5)
        $ up("メンタル", 2)
        "8月の全国では、1回戦で、九州の強豪に0−3で負けた。それでも、全国の芝は、思っていたより、普通の芝だった。"
    else:
        "後半30分、先に足が止まったのは、港北のほうだった。鳴海の9番に、うしろから抜け出された。0−1。"
        $ se("試合終了の笛")
        $ a6_ih = "final"
        mono "インターハイ予選、準優勝。"
        mono "県の二番。……一年の春の0−9から、二番まで来た。"
        $ up("注目度", 4)
        $ up("フィジカル", 1)
    return


################################################################################
## 章えらび（作者の確認用）：第6章から始める
################################################################################
label cs_chapter6a:
    $ quick_menu = True
    $ music_stop(1.5)
    call cs_state4a
    python:
        met = met + ["あげは", "小早川", "倉田", "赤坂", "佐伯", "真壁", "結城"]
        stats = {"技術": 72, "フィジカル": 64, "戦術眼": 74, "メンタル": 68}
        hidden = {"無理ゲージ": 48, "注目度": 58}
        bond = {"鷹野": 82, "大門": 72, "三好": 60, "坂口": 58, "神城": 14}
        heart = {"ひなた": {"ときめき": 62, "信頼": 86, "さみしさ": 3},
                 "千夏": {"ときめき": 55, "信頼": 64, "さみしさ": 4},
                 "紗希": {"ときめき": 22, "信頼": 30, "さみしさ": 0},
                 "あげは": {"ときめき": 50, "信頼": 46, "さみしさ": 2}}
        flags.update({"鷹野_相棒": True, "a4_3年_冬まで": True, "千夏_記録": True, "港北の記録_聞いた": True,
                      "あげは_アカウント": True, "ひなた_トレーナー": True})
        a4_members = 17
        a4_captain = "ren"
        a4_takano = "push"
        a4_kamishiro = "final"
        a4_miyoshi = "zenkoku"
        a4_merger = "zenkoku"
    scene black
    if iap_testable():
        tuto "（作者の確認用）第6章の場面は、第5章で選んだことで変わります。"
    menu:
        "第5章で、ひざの手術は？"
        "した":
            $ a5_surgery = True
            $ a5_tell = "hinata"
            $ hidden["無理ゲージ"] = 30
        "しなかった（痛み止めで続けた）":
            $ a5_surgery = False
            $ a5_tell = "alone"
            $ a5_secret = "keep"
            $ hidden["無理ゲージ"] = 72
    menu:
        "千夏先輩の卒業式では？"
        "付き合うと答えた":
            $ a5_grad = "lover"
            $ a5_grad_answer = "yes"
            $ heart["千夏"]["ときめき"] = 70
        "来年の夏まで待ってもらった":
            $ a5_grad = "lover"
            $ a5_grad_answer = "wait"
        "相棒として送り出した":
            $ a5_grad = "partner"
        "告白はなかった":
            $ a5_grad = "alone"
            $ heart["千夏"]["ときめき"] = 30
    jump chapter6a
