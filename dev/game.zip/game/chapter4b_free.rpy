## chapter4b_free.rpy ―― 第4章（ルートB）の自由行動・練習の出来事（v0.34.0・Claude の第1稿）
##   仕組みはルートAと同じ（月のはじめに練習の重点 → 1日のはじめに練習の出来事 → 行動マップで会いに行く人 → 夜のトーク）
##   ちがうところ
##     ・地図は「桜嶺の学校と寮」（map_ouryo）。行き先は 音楽室（紗希）・5軍の部室（あげは）・寮の裏の壁（本田）・監督室の前（一ノ瀬）・寮の屋上（神城）
##     ・その月の最後の日は土曜日（休日）。港北に帰れて、地図が港北の町になる（はやせ食堂・港の防波堤・港北のグラウンドのフェンスの外）。
##       港北の仲間には避けられる。千夏とは、ほぼ縁がない（11/5 作者の決定：ルートBの蓮は、みんなを裏切ったことになる）
##     ・鬼塚のメニューは、ルートAより能力が少し多く上がる（毎日+3）が、どのメニューでも、ひざの無理ゲージが +1 多くたまる（practice.rpy）
##   ① 4月（b4apr）：4/12・4/13・4/15・4/17（土）  ② 5月（b4may）：5/17・5/18・5/20・5/22（土）  ③ 7月（b4jul）：7/5・7/6・7/8・7/10（土）
##   ヒロインの行き先は、その人らしい能力が少し上がる（紗希＝メンタル、あげは＝技術）

define B4_FREE = {
    "b4apr": (["4月12日（月）", "4月13日（火）", "4月15日（木）", "4月17日（土）"], "放課後", "4月、どこへ行く？"),
    "b4may": (["5月17日（月）", "5月18日（火）", "5月20日（木）", "5月22日（土）"], "放課後", "5月、どこへ行く？"),
    "b4jul": (["7月5日（月）", "7月6日（火）", "7月8日（木）", "7月10日（土）"], "放課後", "7月、どこへ行く？"),
}

define B4_RECAP = {
    "b4apr": "桜嶺に来た。部員は百十二人。俺は、灰色のビブス――5軍から。\n寮の部屋は、神城と同じだった。\n\n転校して半年は、公式戦に出られない。\n月に一度のテストで、上を目指す。",
    "b4may": "5軍から、上がった。\n夜中、神城が、左の足首にテーピングを巻いていた。\n\n6月のインターハイ予選。俺は、スタンドから見る。",
    "b4jul": "インターハイ予選の準決勝で、桜嶺が港北に勝った。神城は、右足だけで鷹野を外した。\n\n監督に、本田の弱点を言えと言われた。\n17日に、Aチームへの昇格テスト。",
}

init python:
    B4_SPOTS = {
        "b4apr": [
            ("music", "音楽室", 330, 70, "saki", "紗希", "b4_apr_saki"),
            ("club", "5軍の部室", 640, 170, "ageha", "あげは", "b4_apr_ageha"),
            ("wall", "寮の裏の壁", 980, 420, "", "本田", "b4_apr_honda"),
            ("office", "監督室の前", 520, 330, "", "一ノ瀬", "b4_apr_ichinose"),
            ("roof", "寮の屋上", 1020, 110, "kamishiro", "神城", "b4_apr_kamishiro"),
        ],
        "b4may": [
            ("music", "音楽室", 330, 70, "saki", "紗希", "b4_may_saki"),
            ("club", "3軍の部室", 640, 170, "ageha", "あげは", "b4_may_ageha"),
            ("wall", "寮の裏の壁", 980, 420, "", "本田", "b4_may_honda"),
            ("office", "監督室の前", 520, 330, "", "一ノ瀬", "b4_may_ichinose"),
            ("roof", "寮の屋上", 1020, 110, "kamishiro", "神城", "b4_may_kamishiro"),
        ],
        "b4jul": [
            ("music", "音楽室", 330, 70, "saki", "紗希", "b4_jul_saki"),
            ("club", "部室", 640, 170, "ageha", "あげは", "b4_jul_ageha"),
            ("wall", "寮の裏の壁", 980, 420, "", "本田", "b4_jul_honda"),
            ("office", "監督室の前", 520, 330, "", "一ノ瀬", "b4_jul_ichinose"),
        ],
    }
    ## 休日（その月の最後の土曜日）：港北に帰る。港北の町の地図
    B4_HOLIDAY_SPOTS = {
        "b4apr": [
            ("shokudo", "はやせ食堂", 850, 460, "mother", "母さん", "b4_hol_mother_apr"),
            ("fence", "港北のグラウンド", 600, 170, "", "フェンスの外", "b4_hol_fence_apr"),
        ],
        "b4may": [
            ("shokudo", "はやせ食堂", 850, 460, "mother", "母さん・ゆず", "b4_hol_mother_may"),
            ("pier", "港の防波堤", 330, 560, "saki", "紗希", "b4_hol_saki_may"),
            ("fence", "港北のグラウンド", 600, 170, "", "フェンスの外", "b4_hol_fence_may"),
        ],
        "b4jul": [
            ("pier", "港の防波堤", 330, 560, "saki", "紗希", "b4_hol_saki_jul"),
            ("shokudo", "はやせ食堂", 850, 460, "mother", "母さん", "b4_hol_mother_jul"),
        ],
    }

    def b4_is_holiday(month):
        return store.b4_day == len(B4_FREE[month][0])

    def b4_spots(month):
        f = store.flags
        table = B4_HOLIDAY_SPOTS[month] if b4_is_holiday(month) else B4_SPOTS[month]
        out = []
        for sid, name, x, y, face, ev, lab in table:
            ## 麗華の行き先は、麗華と付き合っているときだけ（chapter4b_reika.rpy）
            if lab.endswith("_reika") and not b4_reika_on():
                continue
            done = f.get(lab)
            d = {"id": sid, "name": name, "x": x, "y": y,
                 "event": "" if done else ev, "enabled": not done}
            if face:
                d["face"] = face
            out.append(d)
        return out

    def b4_spot_label(month, sid):
        table = B4_HOLIDAY_SPOTS[month] if b4_is_holiday(month) else B4_SPOTS[month]
        for s in table:
            if s[0] == sid:
                return s[6]
        return ""

default b4_day = 1
default b4_dates = []
default b4_time = ""
default b4_banner = ""

label b4_free_loop(month):
    $ b4_dates, b4_time, b4_banner = B4_FREE[month]
    $ recap_text = B4_RECAP[month]
    scene black
    with dissolve
    window auto hide
    if month == "b4apr":
        tuto "自由行動です。練習メニューを選んでから、行動マップで会いに行く人を選びます。4月は4日。"
        tuto "その月の最後の日は土曜日です。港北に帰れて、地図が港北の町になります。"
        tuto "桜嶺の練習（鬼塚のメニュー）は、能力が毎日少し多く上がりますが、ひざにも、いつもより負担がかかります。"
    else:
        tuto "自由行動です。4日のうち、最後の土曜日は、港北に帰れます。"
    $ b4_day = 1
    while b4_day <= len(b4_dates):
        $ amb_stop()
        $ set_cal(b4_dates[b4_day - 1], b4_time)
        $ bgm("作戦会議っぽい軽快な曲")
        window auto hide
        if b4_is_holiday(month):
            ## 土曜日：練習は午前中だけ。午後は港北へ
            call practice_day(month)
            $ set_cal(b4_dates[b4_day - 1], "午後")
            $ bgm("のんびりした春の曲")
            window auto hide
            "午前の練習が終わると、電車で、港北へ帰った。"
            call screen action_map(b4_spots(month), "港北の町、どこへ行く？（休日）")
        else:
            call practice_day(month)
            $ set_cal(b4_dates[b4_day - 1], b4_time)
            $ bgm("作戦会議っぽい軽快な曲")
            window auto hide
            call screen action_map(b4_spots(month), b4_banner + "（残り" + str(len(b4_dates) + 1 - b4_day) + "日）", area="ouryo")
        $ _lab = b4_spot_label(month, _return)
        $ set_flag(_lab)
        call expression _lab
        $ amb_stop()
        ## 夜のトーク（chapter4b_night.rpy。送れるのは月の最後の夜だけ）
        call b4_night_send(b4_dates[b4_day - 1], month)
        $ b4_day += 1
    $ amb_stop()
    return


################################################################################
## 4月の行き先
################################################################################

## 音楽室：紗希。ピアノのある昼休み、話さない約束
label b4_apr_saki:
    scene bg ouryo_music
    with dissolve
    $ bgm("静かなピアノの旋律")
    "放課後の音楽室から、同じ曲の、同じ8小節だけが、何度も聞こえていた。"
    show saki normal
    with dissolve
    "戸を開けても、[saki_call]は、手を止めなかった。俺は、いちばん後ろの席に座った。"
    "九回目で、やっと、8小節が最後までつながった。"
    saki_v "……話さないって、言ったでしょ"
    ren "話してない。聞いてるだけだ"
    saki_v "……屁理屈"
    "十回目が始まった。今度は、最初から、最後までつながった。"
    "弾き終わって、[saki_call]は、振り向かずに言った。"
    saki_v "灰色のビブス、似合ってない。……早く、脱いで"
    hide saki
    with dissolve
    $ heart_up("紗希", "信頼", 3)
    $ up("メンタル", 2)
    call b4_saki_late_contact
    return

## 5軍の部室：あげは。ドリンク二十本
label b4_apr_ageha:
    scene bg ouryo_clubroom
    with dissolve
    $ bgm("とぼけた日常の曲")
    "部室の前で、あげはが、ドリンクのボトルを二十本、両腕にかかえて立っていた。"
    show ageha ouryo
    with dissolve
    ageha "パイセン！　ちょうどいい！　半分持って！"
    ageha "5軍って、ボトルの数がいちばん多いの。人数いちばん多いから。……マネの先輩たち、Aのほう行っちゃうし"
    ren "一人でやってるのか"
    ageha "だって、あたしもいちばん下だもん。……推しと同じ。灰色同士"
    "ボトルを運び終わると、あげはは、スマホで、俺の足もとを撮った。"
    ageha "パイセンさ、ボール止めるとき、右足のつま先、ちょっとだけ外に逃がしてる。……ひざ、かばってるっしょ"
    ageha "スローにすると、分かるんだよね。あたし、動画だけは得意だから"
    hide ageha
    with dissolve
    "言い返せなかった。誰にも、言われたことがなかった。"
    $ heart_up("あげは", "信頼", 4)
    $ up("技術", 2)
    return

## 寮の裏の壁：本田。一年、ずっと壁
label b4_apr_honda:
    scene bg ouryo_ground_eve
    with dissolve
    $ bgm("静かな春の曲")
    "寮の裏の、コンクリートの壁。ボールの跡が、一か所だけ、黒くなっていた。"
    "本田が、そこに、左足でボールを当てていた。"
    show honda normal
    with dissolve
    honda "……あ、早瀬。ここ、俺の場所なんだ。一年、ずっと"
    honda "5軍は、ボールに触れる時間が少ないから。……壁なら、何回でも返ってくる"
    "黒い跡は、ボール一個ぶんの大きさしかなかった。一年、同じところに当てつづけた跡だった。"
    ren "……左のクロス、すごいな"
    honda "左だけな。右は、てんでだめ"
    honda "でも、左だけじゃ、Aには上がれないんだって。コーチが言ってた"
    "本田は、笑って、もう一回、壁に蹴った。ボールは、黒い跡の、ど真ん中に当たった。"
    $ bond_up("本田", 4)
    $ up("技術", 1)
    return

## 監督室の前：一ノ瀬。壁に貼られた名簿
label b4_apr_ichinose:
    scene bg ouryo_office
    with dissolve
    $ bgm("張りつめた静かな曲")
    "監督室の前の廊下には、百十二人の名簿が、段ごとに貼られていた。"
    "Aチームの欄のいちばん上に、「一ノ瀬透」。その下に、「神城凌」。"
    show ichinose normal
    with dissolve
    ichinose "……名簿を見に来る2年は、だいたい、上がってくる"
    "一ノ瀬先輩が、うしろに立っていた。手に、ノートを一冊持っていた。"
    ichinose "1年のとき、僕も、毎日見に来た。自分の名前が、どこにあるか"
    ichinose "Aに上がった日、名簿を見たら、一人、名前が消えてた。僕の代わりに、落ちた人"
    ichinose "その人は、次の月に、部をやめた。……ここは、そういう場所だよ"
    "一ノ瀬先輩は、ノートを、俺に渡した。表紙に、「5軍の一年」と書いてあった。"
    ichinose "僕が5軍にいたときの、練習のメモ。……要らなかったら、捨てていい"
    $ bond_up("一ノ瀬", 4)
    $ up("戦術眼", 2)
    return

## 寮の屋上：神城。何も話さない
label b4_apr_kamishiro:
    scene bg ouryo_rooftop
    with dissolve
    $ bgm("静かな夜の曲")
    "寮の屋上には、洗濯物を干すための、物干し竿が並んでいた。"
    "その端で、神城が、フェンスにもたれて、海のほうを見ていた。"
    show kamishiro normal
    with dissolve
    kamishiro "……何だ"
    ren "春になったら、話すって言った"
    "神城は、少しだけ、こっちを見た。それから、また、海のほうを見た。"
    kamishiro "……まだ、春だ"
    kamishiro "終わってない"
    "それきり、神城は、何も言わなかった。夕焼けが沈みきるまで、二人とも、屋上にいた。"
    hide kamishiro
    with dissolve
    $ bond_up("神城", 3)
    return


################################################################################
## 4月の休日（4/17）：港北に帰る
################################################################################

## はやせ食堂：母さん。カウンターの、蓮の席
label b4_hol_mother_apr:
    scene bg shokudo_day
    with dissolve
    $ bgm("あたたかいアコースティックギター")
    "二週間ぶりの店は、いつもと同じ、しょうゆと油のにおいがした。"
    show mother smile
    with dissolve
    haha "あら。……おかえり。お昼、まだでしょ"
    "母さんは、何も聞かずに、生姜焼き定食を出してきた。ごはんが、いつもの倍、盛ってあった。"
    haha "寮のごはん、どう"
    ren "量は多い。味は、薄い"
    haha "そう。……じゃあ、こっちは、濃くしとくわね"
    "カウンターのいちばん端の席に、常連のおじさんが座っていた。俺を見て、新聞を下ろした。"
    jouren "……おう、蓮"
    "おじさんは、それきり、新聞に目を戻した。去年の冬は、試合のたびに、店で大きな声を出していた人だった。"
    haha "……気にしなくていいの。町の人は、港北のサッカー部が好きなだけだから"
    hide mother
    with dissolve
    $ up("メンタル", 2)
    $ up("無理ゲージ", -2)
    return

## 港北のグラウンド（フェンスの外）：小早川
label b4_hol_fence_apr:
    scene bg kohoku_ground_eve
    with dissolve
    $ bgm("静かな春の曲")
    "港北のグラウンドの、フェンスの外に立った。土曜の午後の練習は、まだ続いていた。"
    "知らない1年生が、何人か混ざっていた。一人が、パスを受ける前に、首を何度も振っていた。振りすぎて、ボールが来たときには、反対を向いていた。"
    "笛が鳴って、休憩になった。その1年生が、水を飲みながら、こっちを見た。目が、まるくなった。"
    show kobayakawa jersey
    with dissolve
    kobayakawa "……早瀬先輩、ですよね"
    kobayakawa "1年の、{rb}小早川{/rb}{rt}こばやかわ{/rt}です。……先輩の試合を見て、港北にしました。去年の冬の、桜嶺戦"
    "フェンスの網ごしに、小早川は、まっすぐこっちを見ていた。"
    kobayakawa "なんで、いないんですか"
    "答えられなかった。グラウンドの向こうから、鷹野の声がした。"
    takano "小早川。……戻れ"
    "小早川は、何か言いたそうな顔のまま、走っていった。"
    hide kobayakawa
    with dissolve
    "鷹野は、一度も、フェンスのほうを見なかった。"
    $ up("メンタル", 1)
    $ set_flag("b4_小早川に会った")
    return

## 港北のグラウンド（フェンスの外）：大門だけが
label b4_hol_fence_may:
    scene bg kohoku_ground_eve
    with dissolve
    $ bgm("静かな春の曲")
    "港北のグラウンドは、練習が終わって、もう誰もいなかった。ゴールの前に、一人だけ、大きな背中が残っていた。"
    show daimon jersey
    with dissolve
    "大門が、1年のキーパーに、ボールを投げていた。倉田、と呼んでいた。"
    "大門は、フェンスの外の俺に気づいて、手を止めた。それから、ゆっくり歩いてきた。"
    daimon "……来ないでください、とは、言いません"
    daimon "でも、みんなの前では、話せません。……僕も、まだ、怒ってるので"
    daimon "倉田は、僕より、手が大きいです。……二年後、早瀬くんのシュートを止めるのは、たぶん、あいつです"
    "大門は、それだけ言って、ゴールのほうへ戻っていった。"
    hide daimon
    with dissolve
    $ bond_up("大門", 2)
    $ up("メンタル", 1)
    return

################################################################################
## 5月の行き先
################################################################################

## 音楽室：紗希。連絡先（4月に交換していなければ、ここで）
label b4_may_saki:
    scene bg ouryo_music
    with dissolve
    $ bgm("静かなピアノの旋律")
    "音楽室の窓が開いていて、グラウンドの声が、少しだけ入ってきていた。"
    show saki normal
    with dissolve
    saki_v "……3軍？　4軍？　ビブスの色、変わったね"
    ren "見てたのか"
    saki_v "見てない。窓から見えるだけ"
    "[saki_call]は、鍵盤の上で、指を止めた。"
    saki_v "あの人、5軍のテストを、見に来たんだってね。……今まで、一回もなかったのに"
    saki_v "気に入られてる。……気をつけて。気に入られた人から、使われるから"
    if b4_reika_on():
        saki_v "……西園寺さんと、付き合ってるんだってね。あの人の、いちばんの信者と"
        saki_v "別に。関係ないけど"
        "[saki_call]は、鍵盤の上で、一つだけ、強く音を鳴らした。"
    if not b4_saki_contact:
        "帰りぎわ、[saki_call]が、スマホをこっちに向けた。"
        saki_v "……連絡、してこなくていいから。するなら、夜にして"
        $ b4_saki_contact = True
        $ set_flag("紗希_連絡先")
        $ heart_up("紗希", "ときめき", 2)
        window auto hide
        tuto "紗希と連絡先を交換しました。夜のトークで、紗希にも送れるようになります。"
    hide saki
    with dissolve
    $ heart_up("紗希", "信頼", 3)
    $ up("メンタル", 2)
    return

## 部室：あげは。マネの先輩に怒られた日
label b4_may_ageha:
    scene bg ouryo_clubroom
    with dissolve
    $ bgm("静かな夜の曲")
    "部室の裏の水道で、あげはが、ボトルを一本ずつ洗っていた。いつもより、静かだった。"
    show ageha serious
    with dissolve
    ageha "……あ、パイセン。今、見ないで"
    ageha "Aのマネの先輩に、怒られた。スマホ見すぎ、って。……動画撮ってただけなのに"
    ageha "桜嶺のマネって、選手の名前、百十二人分、覚えなきゃいけないんだって。あたし、まだ半分も覚えてない"
    "あげはは、ボトルを洗う手を止めなかった。"
    if b4_reika_on():
        ageha "てか、パイセン、西園寺パイセンと付き合ってるってマジ？　理事長の孫の？　部の女子、全員ざわついてんだけど"
        ageha "……推しに彼女。しかも、ラスボス。……無理、勝てん。ウケる。ウケない"
    ageha "……3か月で、やめるかと思った？"
    ren "思ってない"
    ageha "うそ。……あたしは、ちょっと思った"
    ageha "でも、パイセンが灰色じゃなくなったから。あたしも、残り、全部覚える"
    show ageha ouryo
    ageha "……百十二人、覚えたら、ジュースおごって"
    hide ageha
    with dissolve
    $ heart_up("あげは", "信頼", 5)
    $ up("技術", 2)
    return

## 寮の裏の壁：本田。右足
label b4_may_honda:
    scene bg ouryo_ground_eve
    with dissolve
    $ bgm("静かな春の曲")
    "寮の裏の壁に、黒い跡が、二つになっていた。新しいほうは、右足の高さだった。"
    show honda normal
    with dissolve
    honda "……見られた。右、練習してんの"
    honda "早瀬が上がったから。……置いてかれるの、さすがに、こたえた"
    "本田の右足のボールは、三回に一回、壁の跡から、大きく外れた。"
    ren "右に来たら、蹴る前に、相手の足を見ろ。ボールじゃなくて"
    honda "……ボール見ないで、蹴れるかよ"
    "本田は、そう言いながら、次の一本、ボールを見なかった。跡の、少し右に当たった。"
    honda "……今の、近かった"
    $ bond_up("本田", 4)
    $ up("戦術眼", 1)
    return

## 監督室の前：一ノ瀬。なくしたもの
label b4_may_ichinose:
    scene bg ouryo_office
    with dissolve
    $ bgm("張りつめた静かな曲")
    "監督室の前で、一ノ瀬先輩が、名簿の前に立っていた。今度は、自分の名前ではなく、5軍の欄を見ていた。"
    show ichinose normal
    with dissolve
    ichinose "……三年前、僕と同じ中学から、四人来た。今、残ってるのは、僕だけ"
    ichinose "一人は、ひざ。一人は、腰。一人は、言わなかった。……痛いって"
    ichinose "鬼塚さんは、言ったやつは休ませる。言わなかったやつは、使う。使って、壊れたら、それまで"
    "一ノ瀬先輩は、自分の左手の指を、一本ずつ、折りまげた。四本目で、止めた。"
    ichinose "僕がなくしたのは、そういうのを、何とも思わなくなる前の、自分かな"
    ichinose "……君は、まだ、何とも思うだろう？"
    $ bond_up("一ノ瀬", 4)
    $ up("戦術眼", 2)
    return

## 寮の屋上：神城。中学のころの話（真相の手前）
label b4_may_kamishiro:
    scene bg ouryo_rooftop
    with dissolve
    $ bgm("静かな夜の曲")
    "屋上の物干し竿に、白いユニフォームが、十枚並んでいた。その一枚の下に、神城がしゃがんでいた。"
    show kamishiro normal
    with dissolve
    kamishiro "……また来たのか"
    ren "ここ、風が気持ちいいから"
    "神城は、何も言わずに、少しだけ横にずれた。"
    kamishiro "……中1のとき、ここから、高校のAチームの練習を見てた"
    kamishiro "背番号10の人がいた。いちばん、うまかった。……いちばん、走らされてた"
    kamishiro "その人が、いなくなった日も、ここから見てた"
    "神城は、それ以上、言わなかった。誰の話なのか、聞けなかった。"
    hide kamishiro
    with dissolve
    $ bond_up("神城", 3)
    $ set_flag("b4_神城_10番の人")
    return


################################################################################
## 5月の休日（5/22）：港北に帰る
################################################################################

## はやせ食堂：母さんとゆず。障子とボール
label b4_hol_mother_may:
    scene bg shokudo_day
    with dissolve
    $ bgm("あたたかいアコースティックギター")
    "店の裏の空き地で、ゆずが、サッカーボールを蹴っていた。俺の、中学のときのボールだった。"
    show yuzu normal
    with dissolve
    yuzu "お兄ちゃん！　見て！　リフティング、五回できる！"
    "四回目で、ボールは、店の窓のほうへ飛んでいった。母さんの「こら！」が、店の中から聞こえた。"
    hide yuzu
    with dissolve
    show mother normal
    with dissolve
    haha "……あんたの小さいころと、同じことしてる"
    haha "あんたが寮に行ってから、ゆず、毎日、それ蹴ってるのよ。お兄ちゃんの代わりに練習するんだって"
    "母さんは、ボールについた泥を、エプロンで拭いた。"
    haha "……ひざ、どう"
    menu:
        "「大丈夫」":
            ren "大丈夫"
            haha "そう。……あんたの「大丈夫」は、六割よね"
        "「……前より、重い」":
            $ lean("求道型")
            ren "……前より、重い"
            "母さんは、エプロンを握ったまま、しばらく黙った。"
            haha "言ってくれて、よかった。……お父さんは、言わない人だったから"
            $ up("無理ゲージ", -2)
            $ set_flag("b4_母に重いと言った")
    hide mother
    with dissolve
    $ up("メンタル", 2)
    return

## 港の防波堤：紗希。祖母の家の帰り
label b4_hol_saki_may:
    scene bg harbor_sunset
    with dissolve
    $ se("波の音、カモメ")
    $ bgm("静かなピアノの旋律")
    "防波堤の先に、私服の[saki_call]がいた。学校で見るより、少しだけ、小さく見えた。"
    show saki casual
    with dissolve
    saki_v "……なんで、土曜まで、あんたの顔を見なきゃいけないの"
    ren "ここは、俺の町だ"
    saki_v "……私の町でもある。おばあちゃんの家、そこだから"
    "[saki_call]は、防波堤の上に、楽譜を一枚広げた。風で飛ばないように、石を四つ、角に置いた。"
    saki_v "去年の春、ここで、楽譜、拾ってくれたでしょ"
    saki_v "あのとき、あんた、桜嶺の制服見て、変な顔してた。……今、自分が着てるの、どんな気分？"
    menu:
        "「重い」":
            ren "重い"
            saki_v "……正直。あの人の家の子は、みんな、そう言う"
            $ heart_up("紗希", "信頼", 4)
        "「軽い。勝てる場所に来たから」":
            ren "軽い。……勝てる場所に、来たから"
            saki_v "……そう。最初は、みんな、そう言う"
            $ heart_up("紗希", "信頼", 1)
            $ heart_up("紗希", "さみしさ", 3)
    "風が吹いて、石の下の楽譜の端が、ぱたぱたと鳴った。"
    hide saki
    with dissolve
    $ amb_stop()
    $ up("メンタル", 2)
    call b4_saki_late_contact
    return


################################################################################
## 7月の行き先
################################################################################

## 音楽室：紗希。コンクールの練習と、兄のジャージ
label b4_jul_saki:
    scene bg ouryo_music
    with dissolve
    $ bgm("静かなピアノの旋律")
    "夏の音楽室は、暑かった。[saki_call]は、ブレザーを脱いで、椅子の背にかけていた。"
    "その椅子の背に、もう一枚、色のあせた、白いジャージがかかっていた。背中に、「10」と書いてあった。"
    show saki normal
    with dissolve
    saki_v "……見ないで。冷房、きついから、ひざにかけてるだけ"
    "[saki_call]は、ジャージを、ひざの上に引きよせた。"
    saki_v "あんた、Aのテスト、受けるんでしょ。……真壁、いるよ"
    saki_v "あいつ、相手のひざを狙うの。……あの人が、そう教えたから"
    if b4_honda == "stay":
        saki_v "本田くんと、毎晩、壁のところにいるの、見えてる。……ここの窓から"
        saki_v "ああいうの、この学校で、見たことなかった"
        $ heart_up("紗希", "ときめき", 3)
    hide saki
    with dissolve
    $ heart_up("紗希", "信頼", 3)
    $ up("メンタル", 2)
    call b4_saki_late_contact
    return

## 部室：あげは。名前、百十二人
label b4_jul_ageha:
    scene bg ouryo_clubroom
    with dissolve
    $ bgm("明るい部活の曲")
    "部室の戸を開けると、あげはが、ホワイトボードの前で、腕を組んでいた。"
    show ageha ouryo
    with dissolve
    ageha "パイセン、ちょっと、テストして。誰か、選手の名前言って。背番号と、ポジション、言うから"
    ren "……本田"
    ageha "本田航、2年、5軍、左のサイドバック。左のクロスがえぐい。右が苦手。寮の207の隣"
    ren "一ノ瀬"
    ageha "一ノ瀬透、3年、A、真ん中。ノートがいつも同じメーカー。……あと、たまに、5軍の練習を見に来てる"
    "あげはは、ホワイトボードに、正の字を、一本、足した。"
    ageha "百十二人、全員、言える。……先輩たちより、先に、全部覚えた"
    ageha "約束。ジュース"
    "自販機で、いちばん高いジュースを買った。あげはは、それを、飲まないで、写真に撮った。"
    hide ageha
    with dissolve
    $ heart_up("あげは", "信頼", 5)
    $ heart_up("あげは", "ときめき", 2)
    $ up("技術", 2)
    return

## 寮の裏の壁：本田。テストの前の晩
label b4_jul_honda:
    scene bg ouryo_ground_eve
    with dissolve
    $ bgm("静かな夜の曲")
    "寮の裏の壁に、黒い跡が、二つ並んでいた。右足のほうも、だいぶ黒くなっていた。"
    show honda normal
    with dissolve
    honda "……テスト、受けることになった。Aの。コーチに言われた"
    honda "一年三か月、灰色で、いきなり、Aのテスト。……笑えるだろ"
    if b4_honda == "tell":
        honda "でも、コーチに言われたんだ。右に追いこまれたら、下を見るクセ、まだ直ってないなって"
        honda "……なんで、知ってたんだろうな。あんなの、壁しか知らないのに"
        "答えられなかった。本田は、答えを待たずに、もう一本、右で蹴った。"
        $ bond_up("本田", -2)
    else:
        honda "右から追いこまれたら、下見ないで、前。……お前の声、頭の中で鳴るようになった"
        honda "うるさいんだよ、それ。夢にまで出てくる"
        $ bond_up("本田", 4)
    $ up("フィジカル", 1)
    return

## 監督室の前：一ノ瀬。席を譲る話
label b4_jul_ichinose:
    scene bg ouryo_office
    with dissolve
    $ bgm("張りつめた静かな曲")
    "監督室の前の名簿の、Aの欄。一ノ瀬先輩の名前の横に、鉛筆で、小さな丸がついていた。"
    show ichinose normal
    with dissolve
    ichinose "……ああ、それ。引退の印だよ。3年は、選手権で終わりだから"
    ichinose "君が、Aのテストに通ったら、真ん中は、君と僕の取り合いになる。……鬼塚さんは、そういう並べ方が好きなんだ"
    ichinose "だから、先に言っておく。……僕は、譲らないよ"
    "一ノ瀬先輩は、珍しく、笑った。"
    ichinose "譲られて上がった場所は、すぐ、誰かに取られるから"
    $ bond_up("一ノ瀬", 4)
    $ up("戦術眼", 2)
    return


################################################################################
## 7月の休日（7/10）：港北に帰る
################################################################################

## 港の防波堤：紗希。兄の名前
label b4_hol_saki_jul:
    scene bg harbor_sunset
    with dissolve
    $ se("波の音、カモメ")
    $ bgm("静かなピアノの旋律")
    "防波堤の先で、[saki_call]が、海に向かって、何かを言っていた。近づくと、やめた。"
    show saki casual
    with dissolve
    saki_v "……聞いてた？"
    ren "聞こえなかった"
    saki_v "……兄の誕生日なの。今日"
    "[saki_call]は、防波堤のコンクリートの上に、缶のジュースを一本、置いた。"
    saki_v "サッカーやめてから、家を出たの。今、どこにいるかも、知らない"
    saki_v "あの人は、兄の名前を、一回も言わなくなった。……最初から、いなかったみたいに"
    "[saki_call]は、缶を海のほうに向けて、少しだけ、押した。"
    saki_v "……あんたは、いなくならないで。サッカー、やめても、やめなくても"
    hide saki
    with dissolve
    $ amb_stop()
    $ heart_up("紗希", "信頼", 3)
    $ heart_up("紗希", "ときめき", 3)
    $ up("メンタル", 2)
    call b4_saki_late_contact
    return

## はやせ食堂：母さん。ひなたが来ていた
label b4_hol_mother_jul:
    scene bg shokudo_day
    with dissolve
    $ bgm("あたたかいアコースティックギター")
    "店に入ると、カウンターの上に、テーピングの箱が三つ、置いてあった。"
    show mother normal
    with dissolve
    haha "それ、ひなたちゃんが置いてったの。昨日"
    haha "蓮が帰ってきたら、渡しといてって。……自分で渡せばいいのにね"
    "箱の一つに、付箋が貼ってあった。ひなたの字だった。"
    if flags.get("b4_ひなた_怒り"):
        "――余ったから。それだけ。"
    else:
        "――ひざの形、忘れてないから。下手に巻かないでね。"
    haha "……あの子、毎週、店に来てるのよ。蓮のいないときに"
    hide mother
    with dissolve
    $ heart_up("ひなた", "信頼", 3)
    $ up("無理ゲージ", -2)
    return


################################################################################
## 練習の出来事（ルートBの桜嶺。practice.rpy の PRACTICE_EVENTS_A4 に足す。月は "b4apr" / "b4may" / "b4jul"）
################################################################################
define B4_MONTHS = ("b4apr", "b4may", "b4jul")
init 1 python:
    PRACTICE_EVENTS_A4.extend([
        ("b4p_honda_wall", "技術", B4_MONTHS),
        ("b4p_coach_cone", "技術", B4_MONTHS),
        ("b4p_makabe_shoulder", "フィジカル", B4_MONTHS),
        ("b4p_ageha_bottle", "フィジカル", B4_MONTHS),
        ("b4p_ichinose_note", "戦術眼", B4_MONTHS),
        ("b4p_far_field", "戦術眼", B4_MONTHS),
        ("b4p_ballboy", "メンタル", B4_MONTHS),
        ("b4p_saki_window", "メンタル", B4_MONTHS),
    ])
    PRACTICE_ADVICE.update({
        "b4apr": ("", "灰色に、教えることはない。……自分で、いちばん弱いところを潰せ"),
        "b4may": ("技術", "テストは紅白戦だ。……足もとで止まるやつは、上がれん"),
        "b4jul": ("フィジカル", "Aは、当たりが違う。……当たられて倒れるやつは、要らん"),
    })

## 本田と、壁の前で
label b4p_honda_wall:
    "練習のあと、本田と並んで、寮の裏の壁にボールを当てた。本田の左足は、毎回、同じところに当たった。"
    show honda normal
    with dissolve
    honda "早瀬のは、ばらばらだな。……でも、一回も、同じ強さじゃない。わざと？"
    ren "試合で、同じボールは来ないから"
    honda "……そっか。壁は、来るけどな"
    return

## コーチのコーン
label b4p_coach_cone:
    "5軍の練習は、コーンの間を、ボールを運ぶだけで、一時間だった。"
    coach_b "遅い。……Aのやつらは、これを、半分の時間でやる"
    "三十本目。コーンを、一つも倒さずに、抜けた。コーチは、ストップウォッチを見て、何も言わなかった。"
    return

## 真壁の肩
label b4p_makabe_shoulder:
    "グラウンドの端で、Aと5軍の合同の当たりの練習があった。相手は、真壁だった。"
    makabe "おら、港北。踏ん張れよ。……ひざ、大丈夫かぁ？"
    "真壁の肩が、右ひざの外側に、わざと当たった。倒れなかった。倒れなかったのを、真壁は、つまらなそうに見ていた。"
    return

## あげはのドリンク
label b4p_ageha_bottle:
    "坂道の十本走のあと、あげはが、ボトルを投げてよこした。"
    ageha "パイセンのだけ、ちょっと薄めてある。……甘いの、苦手っしょ。動画で、顔しかめてたから"
    "飲むと、ほんとうに、少しだけ薄かった。"
    return

## 一ノ瀬のノート
label b4p_ichinose_note:
    "一ノ瀬先輩のノートを、消灯の前に開いた。5軍のときの練習が、一日も欠けずに書いてあった。"
    "最後のページに、一行だけ、ちがう色のペンで書いてあった。――「上を見るより、横を見ろ。隣のやつが、いちばんの教科書」"
    return

## 遠いグラウンド
label b4p_far_field:
    "人工芝の端から、天然芝のAチームの練習が見えた。遠すぎて、声は聞こえない。"
    "それでも、神城がボールを受ける前に、首を三回振るのは、ここからでも分かった。三回目に、必ず、右を見た。"
    return

## 5軍の球拾い
label b4p_ballboy:
    "Aチームのシュート練習の、球拾いを任された。ゴールの裏で、白いビブスの蹴ったボールを、一時間、拾いつづけた。"
    "神城のシュートだけは、拾いに行く前に、ネットの中で止まっていた。"
    "拾いながら、数えていた。百本のうち、神城は、九十一本、決めた。左足は、一本も使わなかった。"
    return

## 音楽室の窓
label b4p_saki_window:
    "グラウンドの整備をしていると、校舎の三階の窓が、一つだけ開いていた。"
    "ピアノの音が、風に乗って、とぎれとぎれに降ってきた。トンボを引く手が、自然と、曲の速さになった。"
    return


################################################################################
## 紗希の連絡先を、あとからも交換できる（11/7 作者の決定）
##   紗希の場面（音楽室・港の防波堤）に行けば、まだ交換していない人は、その帰りに交換する
################################################################################
label b4_saki_late_contact:
    if b4_saki_contact:
        return
    "別れぎわ、[saki_call]が、スマホをこっちに向けた。画面に、二次元コードが出ていた。"
    saki_v "……何回も来るなら、こっちのほうが早い。来る前に、言って"
    saki_v "連絡、してこなくていいから。……するなら、夜にして"
    $ b4_saki_contact = True
    $ set_flag("b4_紗希_あとから連絡先")
    return
