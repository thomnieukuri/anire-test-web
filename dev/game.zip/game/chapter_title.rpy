################################################################################
## 章の始まりと終わりの画面（v0.44.6・章の始まりの画面の確認帳 第1回で決まったもの）
##   作者のメモ「各章の初めはノートデザインだが、リザルト画面とデザイン合わせてモーションやエフェクトつけよ」
##   ・始まり：案D「スタジアムの光」。暗いところに左から右へ光の筋 → 紺の一枚絵（リザルトと同じ2色）がゆっくり寄る →
##     うしろに線だけの大きな章の番号 → 英字（CHAPTER 1）→ 題名がぼやけたところからはっきり → 時期 → 光のつぶ。約4秒
##   ・終わり（「完」）：案E2「CHAPTER 1 CLEAR」。白く光って、大きな英字がたたきつけられる → 下に題名 →
##     斜めの紺の帯（リザルトのページの切りかえと同じ）でリザルトへ。約3秒
##   ・次章予告は「NEXT CHAPTER」、番外編は「EXTRA」、終章は「FINAL CHAPTER」で同じ形。体験版の終わり・結末は今のノートのまま
##   ・タップで飛ばせる。始まりは「笛の音」を1回。曲は今までどおり止める
##   使い方は今までどおり call show_title("第1章", "はじまりの十一人") ／ call show_title("第1章　はじまりの十一人", "完")
################################################################################

default ttl_cleared = False     # 章の終わり（CLEAR）を見せた直後か（まとめを2ページ目から出す）

init 2 python:
    import random as _ttr

    ## 章の題名 → (時期, 紺の一枚絵)
    TTL_INFO = {
        "止まった冬": ("中3の冬〜春", "op_breath"),
        "はじまりの十一人": ("4月〜5月", "practice_chaos"),
        "泥だらけの夏": ("6月〜9月", "kuroda_kick"),
        "冬の扉": ("9月〜大晦日", "ch3_entrance8"),
        "最後の世代": ("1月〜7月", "a4_train_takano"),
        "5軍からの再出発": ("1月〜7月", "b4_bibs"),
        "潮風の決勝": ("4月〜1月", "a6_final_entrance"),
        "かつての仲間へ": ("4月〜1月", "b6_final_entrance"),
        "どこで、だれと": ("1月〜3月", "fin_b_gate"),
        "雪と卓球と、三好先輩": ("", "a4_pong"),
    }
    _TTL_ZEN = "０１２３４５６７８９"

    def _ttl_num(s):
        return "".join(str(_TTL_ZEN.index(c)) if c in _TTL_ZEN else c for c in s)

    def _ttl_chap(t):
        """「第3章」→ "3"。ちがえば None"""
        if t.startswith("第") and t.endswith("章"):
            return _ttl_num(t[1:-1])
        return None

    def _ttl_look(title):
        per, duo = TTL_INFO.get(title, ("", "ch3_newyear"))
        if title == "ひざ":
            per, duo = ("9月〜3月", "b5_final_knee" if store.ch3_route == "move" else "a5_bench_kuroda")
        if not renpy.loadable("gui/chres/duo/%s.jpg" % duo):
            duo = "ch3_newyear"
        return per, "gui/chres/duo/%s.jpg" % duo

    def ttl_info(main, sub):
        """show_title の文から、新しい画面の中身を作る。ノートのままのときは None"""
        if sub == "完":
            head, _, title = main.partition("　")
            n = _ttl_chap(head)
            if head == "プロローグ":
                en = "PROLOGUE"
            elif n:
                en = "CHAPTER " + n
            else:
                return None
            per, duo = _ttl_look(title)
            return {"kind": "clear", "en": en, "title": title, "duo": duo}
        if main == "次章予告":
            head, _, title = sub.partition("　")
            n = _ttl_chap(head)
            per, duo = _ttl_look(title)
            return {"kind": "open", "en": "NEXT CHAPTER", "num": n, "title": title, "per": per, "duo": duo}
        if main == "番外編":
            per, duo = _ttl_look(sub)
            return {"kind": "open", "en": "EXTRA", "num": "EX", "title": sub, "per": per, "duo": duo}
        if main == "終章":
            per, duo = _ttl_look(sub)
            return {"kind": "open", "en": "FINAL CHAPTER", "num": None, "title": sub, "per": per, "duo": duo}
        if main == "プロローグ":
            per, duo = _ttl_look(sub)
            return {"kind": "open", "en": "PROLOGUE", "num": "0", "title": sub, "per": per, "duo": duo}
        n = _ttl_chap(main)
        if n:
            per, duo = _ttl_look(sub)
            return {"kind": "open", "en": "CHAPTER " + n, "num": n, "title": sub, "per": per, "duo": duo}
        return None

    def ttl_size(title):
        return 120 if len(title) <= 6 else (104 if len(title) <= 9 else 80)

    ## 光のつぶ（場所と動きは毎回同じ）
    _r = _ttr.Random(7)
    TTL_DOTS = [(int(_r.random() * 1280), int(380 + _r.random() * 330), round(0.6 + _r.random() * 0.8, 2),
                 int(160 + _r.random() * 200), round(3.0 + _r.random() * 2.5, 2), round(_r.random() * 1.2, 2)) for _i in range(22)]

## 始まり（案D）
screen ttl_open(ti):
    zorder 60
    $ _sz = ttl_size(ti["title"])
    fixed at ttl_fade_out:
        xysize (1280, 720)
        add Solid("#000000")
        add ti["duo"] at ttl_duo_in
        add Solid("#06133a61")
        if ti.get("num") and renpy.loadable("gui/ttl/num_%s.png" % ti["num"]):
            add ("gui/ttl/num_%s.png" % ti["num"]) xanchor 1.0 xpos 1240 ypos 70 at ttl_num_in
        add "gui/ttl/flare.png" ypos 300 at ttl_flare
        add "gui/ttl/streak.png" ypos 358 at ttl_streak
        for _x, _y, _z, _dy, _t, _d in TTL_DOTS:
            add "gui/ttl/dot.png" pos (_x, _y) zoom _z at ttl_dot(_dy, _t, _d)
        text ti["en"] style "ttl_en" xalign 0.5 ypos 236 at ttl_en_in
        text ti["title"] style "chres3_hd" size _sz xalign 0.5 ypos 300 at ttl_title_in
        if ti.get("per"):
            text ti["per"] style "ttl_per" xalign 0.5 ypos (300 + _sz + 58) at ttl_per_in

## 終わり（案E2）
screen ttl_clear(ti):
    zorder 60
    fixed:
        xysize (1280, 720)
        add Solid("#000000")
        add ti["duo"] at ttl_duo_clear
        add Solid("#06133a61")
        fixed at chres_skew(-0.18):
            xysize (1280, 720)
            text (ti["en"] + " CLEAR") style "ttl_clear" xalign 0.5 ypos 250 at ttl_clear_slam
        text ti["title"] style "ttl_clear_sub" xalign 0.5 ypos 420 at ttl_per_in2
        add Solid("#ffffff") at ttl_white

## リザルトと同じ、斜めの紺の帯
screen ttl_wipe():
    zorder 200
    add "gui/chres/wipe.png" at chres_wipe_t
    timer 0.62 action Hide("ttl_wipe")

transform ttl_fade_out:
    on hide:
        linear 0.6 alpha 0.0

transform ttl_duo_in:
    align (0.5, 0.5) zoom 1.16 alpha 0.0
    parallel:
        easeout 5.2 zoom 1.0
    parallel:
        linear 1.4 alpha 1.0

transform ttl_duo_clear:
    align (0.5, 0.5) zoom 1.06
    easeout 3.0 zoom 1.0

transform ttl_num_in:
    alpha 0.0 xoffset 80
    easeout 4.2 alpha 1.0 xoffset 0

transform ttl_flare:
    xpos -700 alpha 1.0
    easein_cubic 1.5 xpos 1400

transform ttl_streak:
    xpos 0 alpha 0.0
    linear 0.45 alpha 1.0
    linear 1.05 alpha 0.0

transform ttl_dot(dy=200, t=4.0, d=0.0):
    alpha 0.0 yoffset 0
    pause d
    parallel:
        linear t yoffset (-dy)
    parallel:
        linear (t * 0.3) alpha 0.8
        linear (t * 0.7) alpha 0.0

transform ttl_en_in:
    alpha 0.0 xzoom 1.6
    pause 0.7
    easeout 1.3 alpha 1.0 xzoom 1.0

transform ttl_title_in:
    alpha 0.0 blur 10.0 zoom 1.08
    pause 1.1
    easeout 1.3 alpha 1.0 blur 0.0 zoom 1.0

transform ttl_per_in:
    alpha 0.0
    pause 1.9
    linear 0.7 alpha 1.0

transform ttl_per_in2:
    alpha 0.0
    pause 0.5
    linear 0.4 alpha 1.0

transform ttl_clear_slam:
    alpha 0.0 zoom 2.2
    pause 0.25
    easein 0.25 alpha 1.0 zoom 0.95
    easeout 0.17 zoom 1.0

transform ttl_white:
    alpha 1.0
    linear 0.5 alpha 0.0

init 2:
    style ttl_en:
        font CHRES_F_NUM
        size 40
        color "#ffffff"
        kerning 7
    style ttl_per:
        font CHRES_F_BODY
        size 24
        color "#ffffff"
        kerning 7
    style ttl_clear:
        font CHRES_F_NUM
        size 132
        color "#ffffff"
        kerning 6
        outlines [(0, CHRES_RED, 0, 6)]
    style ttl_clear_sub:
        font CHRES_F_BODY
        size 30
        color CHRES_CREAM


## 見直しチェック用：章の始まりと終わりの画面（第1章の始まり → 第1章の終わり → リザルト）
label ttl_rev:
    scene black
    call show_title("第1章", "はじまりの十一人")
    scene black
    call show_title("第1章　はじまりの十一人", "完")
    call chres_show("ch1")
    $ rev_end("ttl_new")
    jump chapter1
