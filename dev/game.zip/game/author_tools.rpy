## ===========================================================================
## 作者用の検証道具（v0.35.1）。作者の確認用（Web の dev/。author_build.txt があるとき）と開発中の PC だけに出る
##   ・場面ジャンプ：タイトル画面から。章ごとのタブ → 場面を押すと、その章の頭の状態にして、その場面だけ流す
##       一覧は tools/make_scene_jump.py が作る（game/scene_jump_data.rpy）。章や場面を足したら流しなおす
##       「気持ちを高く」「手術した」「麗華と付き合っている」で、場面の前の状態を変えられる
##   ・作者メニュー：遊んでいる途中、クイックメニューの「作者」から。能力・ヒロインの気持ち・無理ゲージをその場で上げ下げ、
##       未読もスキップ、次の選択肢まで飛ばす
## ===========================================================================

default persistent.sj_tab = 0
default persistent.sj_high = True
default persistent.sj_surgery = False
default persistent.sj_reika = True
default sj_testing = False

init python:
    def author_tools_on():
        return bool(AUTHOR_BUILD or config.developer)

    SJ_HIGH = {"ひなた": (70, 95), "千夏": (70, 90), "紗希": (50, 60), "あげは": (50, 50), "麗華": (50, 50)}

    def sj_prepare(state, ent):
        lab, desc, year, date, tm, f = ent
        heart_fill()
        if state in ("4a", "5a", "6a"):
            store.play_marks["chapter4a"] = 0
        if state in ("4b", "5b"):
            store.play_marks["chapter4b"] = 0
        if state in ("5a", "6a", "5b"):
            store.play_marks["chapter5" + state[-1]] = 0
        if state == "6a":
            store.play_marks["chapter6a"] = 0
        ## 前提の切りかえ
        store.a5_surgery = bool(persistent.sj_surgery)
        store.b5_surgery = bool(persistent.sj_surgery)
        if persistent.sj_surgery:
            store.hidden["無理ゲージ"] = min(store.hidden.get("無理ゲージ", 0), 35)
        if state in ("4b", "5b"):
            store.b4_reika = "lover" if persistent.sj_reika else "refused"
            b4_reika_heart()
        if persistent.sj_high:
            for who, (t, s) in SJ_HIGH.items():
                if who in store.heart and (who in store.met or who == "麗華"):
                    store.heart[who]["ときめき"] = max(store.heart[who]["ときめき"], t)
                    store.heart[who]["信頼"] = max(store.heart[who]["信頼"], s)
                    store.heart[who]["さみしさ"] = 0
        store.sj_testing = True
        store.hs_testing = True
        if date:
            store.cal_year = year
            store.cal_date = ""
            set_cal(date, tm, quiet=True)

screen sj_list():
    modal True
    add "gui/menu_bg.png"
    $ _ti = persistent.sj_tab if 0 <= persistent.sj_tab < len(SJ_TABS) else 0
    $ _tab, _state, _rows = SJ_TABS[_ti]
    frame:
        xpos 296
        ypos 34
        xsize 920
        ysize 640
        background None
        vbox:
            spacing 6
            hbox:
                spacing 14
                text "場面ジャンプ（作者用）" size 26 color PEN_RED
                text "押した場面だけ流して、ここに戻る" size 15 color INK_SOFT yalign 0.5
            hbox:
                spacing 6
                for _i, (_t, _s, _r) in enumerate(SJ_TABS):
                    textbutton _t:
                        action SetField(persistent, "sj_tab", _i)
                        text_size 16
                        text_color (PEN_RED if _i == _ti else INK_SOFT)
                        text_hover_color PEN_RED
            hbox:
                spacing 24
                textbutton ("■ 気持ちを高く" if persistent.sj_high else "□ 気持ちを高く"):
                    action ToggleField(persistent, "sj_high")
                    text_size 18
                    text_color INK
                    text_hover_color PEN_RED
                textbutton ("■ 手術した" if persistent.sj_surgery else "□ 手術した"):
                    action ToggleField(persistent, "sj_surgery")
                    text_size 18
                    text_color INK
                    text_hover_color PEN_RED
                textbutton ("■ 麗華と付き合っている" if persistent.sj_reika else "□ 麗華と付き合っている"):
                    action ToggleField(persistent, "sj_reika")
                    text_size 18
                    text_color INK
                    text_hover_color PEN_RED
                textbutton "検証リスト":
                    action Show("chk_list")
                    text_size 18
                    text_color INK
                    text_hover_color PEN_RED
                textbutton "ヒロイン場面":
                    action Start("hs_start")
                    text_size 18
                    text_color INK
                    text_hover_color PEN_RED
                textbutton "タイトルへ":
                    action Return(None)
                    text_size 18
                    text_color INK
                    text_hover_color PEN_RED
            viewport:
                ysize 520
                mousewheel True
                draggable True
                scrollbars "vertical"
                vbox:
                    spacing 4
                    for _j, _e in enumerate(_rows):
                        if renpy.has_label(_e[0]):
                            button:
                                style "roster_card"
                                xsize 880
                                action Return((_ti, _j))
                                hover_background "#ffffffcc"
                                vbox:
                                    spacing 0
                                    text (_e[1] or _e[0]) size 18 color INK
                                    text "%s　%s　%s" % (_e[3] or "―", _e[4], _e[0]) size 13 color INK_SOFT

label sj_start:
    $ quick_menu = True
    $ persistent.save_guide_seen = True
    if persistent.choice_hints is None:
        $ persistent.choice_hints = True
label sj_loop:
    scene black
    window hide
    $ music_stop(0.5)
    $ amb_stop()
    $ sj_testing = False
    $ hs_testing = False
    $ _sj = renpy.call_screen("sj_list")
    if _sj is None:
        $ renpy.full_restart()
    $ _sj_ti, _sj_j = _sj
    $ _sj_state = SJ_TABS[_sj_ti][1]
    $ _sj_ent = SJ_TABS[_sj_ti][2][_sj_j]
    call expression ("cs_state" + _sj_state)
    $ sj_prepare(_sj_state, _sj_ent)
    call expression _sj_ent[0]
    window hide
    jump sj_loop


## ---------------------------------------------------------------------------
## 作者メニュー（遊んでいる途中に、クイックメニューの「作者」から）
## ---------------------------------------------------------------------------
init python:
    def author_bump(kind, key, sub=None, d=10):
        if kind == "stat":
            store.stats[key] = max(0, min(100, store.stats.get(key, 0) + d))
        elif kind == "hidden":
            store.hidden[key] = max(0, min(100, store.hidden.get(key, 0) + d))
        elif kind == "heart":
            store.heart.setdefault(key, {"ときめき": 0, "信頼": 0, "さみしさ": 0})
            store.heart[key][sub] = max(0, min(100, store.heart[key].get(sub, 0) + d))
        renpy.restart_interaction()

screen author_menu():
    modal True
    zorder 200
    add "#000000aa"
    frame:
        xalign 0.5
        yalign 0.5
        xsize 980
        padding (30, 24)
        background "#f6f0e1"
        vbox:
            spacing 10
            hbox:
                spacing 20
                text "作者メニュー" size 28 color PEN_RED
                text "[cal_date]　[cal_time]" size 18 color INK_SOFT yalign 0.5
            text "能力" size 20 color INK
            hbox:
                spacing 14
                for _k in ("技術", "フィジカル", "戦術眼", "メンタル"):
                    hbox:
                        spacing 4
                        text "%s %d" % (_k, stats.get(_k, 0)) size 18 color INK min_width 120
                        textbutton "−" action Function(author_bump, "stat", _k, None, -10) text_size 20
                        textbutton "＋" action Function(author_bump, "stat", _k, None, 10) text_size 20
            hbox:
                spacing 14
                for _k in ("無理ゲージ", "注目度"):
                    hbox:
                        spacing 4
                        text "%s %d" % (_k, hidden.get(_k, 0)) size 18 color INK min_width 140
                        textbutton "−" action Function(author_bump, "hidden", _k, None, -10) text_size 20
                        textbutton "＋" action Function(author_bump, "hidden", _k, None, 10) text_size 20
            text "ヒロインの気持ち（ときめき・信頼）" size 20 color INK
            for _h in [h for h in ("ひなた", "千夏", "紗希", "あげは", "麗華") if h in heart]:
                hbox:
                    spacing 10
                    text _h size 18 color INK min_width 70
                    for _s in ("ときめき", "信頼"):
                        hbox:
                            spacing 4
                            text "%s %d" % (_s, heart[_h].get(_s, 0)) size 17 color INK_SOFT min_width 110
                            textbutton "−" action Function(author_bump, "heart", _h, _s, -10) text_size 20
                            textbutton "＋" action Function(author_bump, "heart", _h, _s, 10) text_size 20
            null height 6
            hbox:
                spacing 24
                textbutton ("■ 未読もスキップ" if _preferences.skip_unseen else "□ 未読もスキップ"):
                    action ToggleField(_preferences, "skip_unseen")
                    text_size 19
                textbutton "検証リスト" action [Hide("author_menu"), Show("chk_list")] text_size 19
                textbutton "次の選択肢まで飛ばす" action [Hide("author_menu"), Skip(fast=True)] text_size 19
                textbutton "場面ジャンプへ" action [Hide("author_menu"), Start("sj_start")] text_size 19
                textbutton "閉じる" action Hide("author_menu") text_size 19
