## chapter4b_night.rpy ―― 第4章（ルートB）の夜のトーク（v0.34.0・Claude の第1稿）
##   ルートAの第4章（chapter4a_night.rpy）と同じ形。自分から送れるのは月の最後の自由行動の夜だけ（★つき・最大3人）。
##   ほかの夜は、2晩に1晩、まだ話していないことがある人から先に届く。夜のトークで上がる気持ち・絆は2倍（NIGHT_BOOST）
##   相手：紗希（連絡先を交換してから）・あげは・ひなた・本田・母さん・大門・坂口（既読だけ）・鷹野（既読がつかない）
##   千夏とは、ほぼ縁がない（11/5 作者の決定：ルートBの蓮は、港北のみんなを裏切ったことになる）
##   麗華は雑談をしない人なので、ここには入れない（7/17 の夜に一度だけ届く。chapter4b_reika.rpy）
##   神城とはトークしない（同じ部屋なので、そのかわりに場面がある）
##   話：1回目 b4nc_<id>_<月>、2回目 b4nc_<id>_<月>_2（あれば）、それからは b4nc_<id>_more1, 2…

default b4_night_sent = {}
default b4_night_seen = []
default b4_night_more_seen = []
default b4_night_quiet = 0

init 1 python:
    NIGHT_INCOMING_OPEN.update({"本田": "早瀬、起きてる？", "母": "蓮、ちゃんと食べてる？"})

init python:
    B4_NIGHT_IDS = {"紗希": "saki", "あげは": "ageha", "ひなた": "hinata", "本田": "honda",
                    "母": "mother", "大門": "daimon", "坂口": "sakaguchi", "鷹野": "takano"}
    B4_NIGHT_ORDER = ("紗希", "あげは", "ひなた", "本田", "母", "大門", "坂口", "鷹野")
    ## 話を聞いていないと届かないトーク（ラベル → 必要な印のどれか）
    B4_NIGHT_NEED = {
        "b4nc_honda_b4jul": ("b4_本田_居残り",),
    }

    def b4_night_ok(lab):
        if not renpy.has_label(lab):
            return False
        need = B4_NIGHT_NEED.get(lab)
        return not need or any(store.flags.get(k) for k in need)

    B4_NIGHT_HEROINES = ("麗華", "紗希", "あげは", "ひなた")

    def b4_night_can(who):
        if who == "紗希":
            return store.b4_saki_contact
        if who in ("あげは", "本田"):
            return who in store.met
        return who in B4_NIGHT_IDS

    def b4_night_has_new(who, month):
        nid = B4_NIGHT_IDS[who]
        n = store.b4_night_sent.get((who, month), 0)
        first = "b4nc_%s_%s" % (nid, month)
        seen = store.b4_night_seen
        return ((n == 0 and b4_night_ok(first) and first not in seen)
                or (n <= 1 and b4_night_ok(first + "_2") and (first + "_2") not in seen))

    def b4_night_label(who, month):
        nid = B4_NIGHT_IDS[who]
        n = store.b4_night_sent.get((who, month), 0)
        first = "b4nc_%s_%s" % (nid, month)
        if n == 0 and b4_night_ok(first) and first not in store.b4_night_seen:
            store.b4_night_seen.append(first)
            return first
        if n <= 1 and b4_night_ok(first + "_2") and (first + "_2") not in store.b4_night_seen:
            store.b4_night_seen.append(first + "_2")
            return first + "_2"
        k = 1
        spare = ""
        while renpy.has_label("b4nc_%s_more%d" % (nid, k)):
            lab = "b4nc_%s_more%d" % (nid, k)
            if b4_night_ok(lab):
                if lab not in store.b4_night_more_seen:
                    store.b4_night_more_seen.append(lab)
                    return lab
                spare = spare or lab
            k += 1
        return spare or first

    def b4_night_list(month):
        ok = [w for w in B4_NIGHT_ORDER if b4_night_can(w) and b4_night_has_new(w, month)]
        her = [w for w in ok if w in B4_NIGHT_HEROINES]
        mates = sorted([w for w in ok if w not in B4_NIGHT_HEROINES],
                       key=lambda w: (store.night_last.get(w, 0), B4_NIGHT_ORDER.index(w)))
        return (her + mates)[:3]

    def b4_night_incoming(month):
        ## 鷹野は既読がつかないので、向こうからは届かない
        ok = [w for w in B4_NIGHT_ORDER if w not in ("鷹野", "坂口") and w in NIGHT_INCOMING_OPEN and b4_night_can(w) and b4_night_has_new(w, month)]
        if not ok:
            return ""
        ok.sort(key=lambda w: (store.night_last.get(w, 0), B4_NIGHT_ORDER.index(w)))
        return ok[0]

label b4_night_send(date, month):
    $ _b4_send = (B4_FREE[month][0][-1] == date)
    scene black
    with dissolve
    $ set_cal(date, "夜")
    scene bg ouryo_dorm_night
    with dissolve
    $ bgm("静かな夜の曲")
    if not _b4_send:
        $ b4_night_quiet += 1
        $ _b4n = b4_night_incoming(month) if b4_night_quiet % 2 == 0 else ""
        if not _b4n:
            $ _ns_close = ("消灯のチャイムが鳴って、そのまま眠った。", "上の段に上がったとたん、意識が落ちた。", "下の段の寝息を聞きながら、目を閉じた。")[b4_night_quiet // 2 % 3]
            "[_ns_close]"
            return
        $ se("トークアプリの通知音")
        $ _ns_in_name = {"母": "母さん"}.get(_b4n, _b4n)
        "スマホが鳴った。[_ns_in_name]からだった。"
        $ night_incoming = _b4n
        jump b4_night_open
    $ _b4_who = b4_night_list(month)
    if not _b4_who:
        return
    "消灯の前に、スマホを手に取った。下の段は、もう暗かった。"
    "……誰かに、送ってみようか。"
    menu:
        "★ [saki_call]に送る" (nochosen=True) if "紗希" in _b4_who:
            $ _b4n = "紗希"
        "★ あげはに送る" (nochosen=True) if "あげは" in _b4_who:
            $ _b4n = "あげは"
        "★ ひなたに送る" (nochosen=True) if "ひなた" in _b4_who:
            $ _b4n = "ひなた"
        "★ 本田に送る" (nochosen=True) if "本田" in _b4_who:
            $ _b4n = "本田"
        "★ 母さんに送る" (nochosen=True) if "母" in _b4_who:
            $ _b4n = "母"
        "★ 大門に送る" (nochosen=True) if "大門" in _b4_who:
            $ _b4n = "大門"
        "★ 坂口に送る" (nochosen=True) if "坂口" in _b4_who:
            $ _b4n = "坂口"
        "★ 鷹野に送る" (nochosen=True) if "鷹野" in _b4_who:
            $ _b4n = "鷹野"
        "今日は、やめておく" (nochosen=True):
            $ _b4n = ""
    if not _b4n:
        "スマホを伏せて、目を閉じた。"
        return
label b4_night_open:
    $ _b4lab = b4_night_label(_b4n, month)
    $ b4_night_sent[(_b4n, month)] = b4_night_sent.get((_b4n, month), 0) + 1
    $ night_count += 1
    $ night_last[_b4n] = night_count
    window auto hide
    $ night_boost = True
    call expression _b4lab
    $ night_boost = False
    $ night_incoming = ""
    window auto hide
    $ talk_end()
    return


## ===========================================================================
## 紗希
## ===========================================================================
label b4nc_saki_b4apr:
    $ talk_start("紗希", "22:04")
    $ talk_me("連絡、夜ならいいって言ってた")
    $ talk_wait(9)
    $ talk("紗希", "言った")
    $ talk("紗希", "でも、ほんとに来るとは思ってなかった")
    $ talk_me("8小節のとこ、今日、最後までつながってたな")
    $ talk_wait(4)
    $ talk("紗希", "……聞いてたの")
    $ talk("紗希", "廊下で聞くの、やめて。下手なとこまで聞こえるから")
    $ talk("紗希", "おやすみ")
    $ heart_up("紗希", "信頼", 2)
    return

label b4nc_saki_b4may:
    $ talk_start("紗希", "22:31")
    $ talk_me("ビブス、変わった")
    $ talk_wait(3)
    $ talk("紗希", "知ってる。窓から見えた")
    $ talk("紗希", "色が変わっても、走り方、変わってない")
    $ talk("紗希", "右足、着くとき、ちょっとだけ遅い")
    $ talk_me("……見てないって言ってた")
    $ talk_wait(6)
    $ talk("紗希", "見えるだけ")
    $ talk("紗希", "寝る")
    $ heart_up("紗希", "ときめき", 2)
    return

label b4nc_saki_b4jul:
    $ talk_start("紗希", "23:10")
    if b4_honda == "tell":
        $ talk("紗希", "本田くん、今日、壁のとこ、一人だった")
        $ talk("紗希", "あの人に、何か言わされた？")
        $ talk_wait(5)
        $ talk_me("……言った")
        $ talk_wait(12)
        $ talk("紗希", "そう")
        $ talk("紗希", "あの人の家の子は、みんな、最初はそうなる")
        $ heart_up("紗希", "さみしさ", 3)
    else:
        $ talk("紗希", "毎晩、壁のとこで、うるさい")
        $ talk("紗希", "音楽室まで聞こえる。ボールの音と、「前！」って声")
        $ talk_me("ごめん")
        $ talk_wait(4)
        $ talk("紗希", "……謝らなくていい")
        $ talk("紗希", "あの音、きらいじゃない")
        $ heart_up("紗希", "ときめき", 2)
        $ heart_up("紗希", "信頼", 2)
    return

label b4nc_saki_more1:
    $ talk_start("紗希", "22:50")
    $ talk("紗希", "……起きてる？")
    $ talk_me("起きてる")
    $ talk("紗希", "別に。用はない")
    $ talk_wait(3)
    $ talk("紗希", "今日、鍵盤のふた、閉めるの忘れた")
    $ talk("紗希", "それだけ")
    $ heart_up("紗希", "信頼", 1)
    return


## ===========================================================================
## あげは
## ===========================================================================
label b4nc_ageha_b4apr:
    $ talk_start("あげは", "22:15")
    $ talk("あげは", "パイセン！！今日の推しの記録")
    $ talk("あげは", "壁当て：めっちゃ地味　5軍の部室：めっちゃ狭い　ビブス：灰色")
    $ talk("あげは", "推せる要素、ゼロ。ウケる")
    $ talk_me("じゃあ、なんで撮ってるんだ")
    $ talk_wait(2)
    $ talk("あげは", "ゼロから上がるとこ撮るのが、いちばんエモいから")
    $ talk("あげは", "あと、ゼロの日の動画は、あとで100倍の価値になるやつ")
    $ heart_up("あげは", "信頼", 2)
    return

label b4nc_ageha_b4may:
    $ talk_start("あげは", "21:58")
    $ talk("あげは", "選手の名前、今日で60人")
    $ talk("あげは", "本田パイセンは、最初に覚えた。パイセンの隣にいつもいるから")
    $ talk_me("あと52人だな")
    $ talk("あげは", "数えないで！！プレッシャー！！")
    $ talk_wait(1)
    $ talk("あげは", "……でも、数えてくれてるの、ちょっとうれしい")
    $ heart_up("あげは", "ときめき", 2)
    return

label b4nc_ageha_b4jul:
    $ talk_start("あげは", "22:40")
    $ talk("あげは", "パイセン、Aのテスト、真壁パイセンいるよ")
    $ talk("あげは", "去年の動画、全部見た。あの人、右側から体ぶつけてくる")
    $ talk("あげは", "パイセンの、右ひざのほう")
    $ talk_wait(1)
    $ talk("あげは", "……気をつけて。マジで")
    $ talk_me("ありがとう")
    $ talk("あげは", "マネだから。……推しだから、じゃなくて")
    $ heart_up("あげは", "信頼", 2)
    $ up("戦術眼", 1)
    return

label b4nc_ageha_more1:
    $ talk_start("あげは", "23:05")
    $ talk("あげは", "パイセン起きてる？？")
    $ talk("あげは", "寮って何時消灯？")
    $ talk_me("10時半")
    $ talk("あげは", "もう過ぎてんじゃん！！寝て！！")
    $ talk("あげは", "推しの睡眠不足は、ファンの責任")
    $ heart_up("あげは", "信頼", 1)
    return


## ===========================================================================
## ひなた
## ===========================================================================
label b4nc_hinata_b4apr:
    $ talk_start("ひなた", "22:20")
    $ talk_me("元気か")
    $ talk_wait(40)
    $ talk("ひなた", "元気じゃない")
    $ talk("ひなた", "蓮のいない朝練、静か。……静かすぎて、やだ")
    if b4_tell == "hug":
        $ talk_wait(2)
        $ talk("ひなた", "テーピング、写真送って")
        $ talk_me("（写真）")
        $ talk_wait(2)
        $ talk("ひなた", "下手。三周目、ひっぱりすぎ。むくむよ")
        $ talk("ひなた", "……怒ってるけど、それとこれとは、べつ")
        $ heart_up("ひなた", "信頼", 2)
    else:
        $ talk("ひなた", "それだけ")
        $ heart_up("ひなた", "さみしさ", 2)
    return

label b4nc_hinata_b4jul:
    $ talk_start("ひなた", "21:47")
    $ talk("ひなた", "準決勝、来てたね")
    if b4_ih_seat == "kohoku":
        $ talk("ひなた", "白いシャツで、こっちまで来た")
        $ talk("ひなた", "みんな、何も言わなかったけど")
        $ talk("ひなた", "鷹野くん、試合のあと、蓮の席だったとこ、ずっと見てた")
        $ heart_up("ひなた", "信頼", 2)
    else:
        $ talk("ひなた", "桜嶺の席の、太鼓の横")
        $ talk("ひなた", "試合中は、眉毛、見えなかった。遠すぎて")
        $ heart_up("ひなた", "さみしさ", 2)
    $ talk_wait(1)
    $ talk("ひなた", "神城くん、左足、変じゃなかった？")
    $ talk_me("……ひなたも、気づいたのか")
    $ talk("ひなた", "マネだもん")
    return

label b4nc_hinata_more1:
    $ talk_start("ひなた", "22:35")
    $ talk("ひなた", "千鶴さんのお店で、生姜焼き食べた")
    $ talk("ひなた", "蓮のいつもの席、空いてた")
    $ talk("ひなた", "座らなかったけど")
    return


## ===========================================================================
## 本田
## ===========================================================================
label b4nc_honda_b4apr:
    $ talk_start("本田", "22:45")
    $ talk("本田", "早瀬、起きてる？")
    $ talk("本田", "壁ごしに、ベッドのきしむ音、聞こえるんだけど")
    $ talk_me("上の段、狭いんだ")
    $ talk("本田", "神城と同じ部屋とか、俺なら寝れない")
    $ talk("本田", "あいつ、夜中に、何か巻いてる音するだろ")
    $ talk_wait(2)
    $ talk("本田", "……なんでもない。おやすみ")
    $ bond_up("本田", 2)
    return

label b4nc_honda_b4may:
    $ talk_start("本田", "22:10")
    $ talk("本田", "右足の壁当て、今日、10回中4回、跡に当たった")
    $ talk_me("増えたな")
    $ talk("本田", "左は10回中10回だけどな")
    $ talk("本田", "……一年、左しか蹴ってなかったんだなって、思った")
    $ bond_up("本田", 2)
    return

label b4nc_honda_b4jul:
    $ talk_start("本田", "22:58")
    $ talk("本田", "居残り、今日もありがとな")
    $ talk("本田", "なんで俺なんだって、まだ思ってるけど")
    $ talk_me("隣の部屋だから")
    $ talk("本田", "それ、理由になってないから")
    $ talk_wait(1)
    $ talk("本田", "……でも、助かってる。マジで")
    $ bond_up("本田", 3)
    return


## ===========================================================================
## 母さん
## ===========================================================================
label b4nc_mother_b4apr:
    $ talk_start("母", "21:10")
    $ talk("母", "寮の洗濯、ちゃんとしてる？")
    $ talk("母", "白いシャツは、ほかのと一緒に洗っちゃだめよ")
    $ talk_me("もう、ピンクになった")
    $ talk_wait(2)
    $ talk("母", "……やっぱり")
    $ talk("母", "次に帰ってきたら、持ってきなさい。戻るかもしれないから")
    $ up("メンタル", 1)
    return

label b4nc_mother_b4may:
    $ talk_start("母", "21:40")
    $ talk("母", "ゆずが、リフティング7回できたって")
    $ talk("母", "お兄ちゃんに言ってって、うるさいから")
    $ talk_me("すごいな、って言っといて")
    $ talk("母", "自分で言いなさい。今度帰ってきたとき")
    $ talk_wait(1)
    $ talk("母", "ひざ、冷やしてる？")
    $ up("無理ゲージ", -1)
    return


## ===========================================================================
## 港北の仲間（大門・坂口・鷹野）
## ===========================================================================
label b4nc_daimon_b4may:
    $ talk_start("大門", "22:00")
    $ talk_me("元気か")
    $ talk_wait(25)
    $ talk("大門", "元気です")
    $ talk("大門", "みんなの前では、返事しないことにしてます。……すみません")
    $ talk("大門", "倉田という1年が、キーパーに入りました。僕の練習に、毎日ついてきます")
    $ talk("大門", "……試合で会ったら、止めます。早瀬くんのシュートも")
    $ bond_up("大門", 2)
    return

label b4nc_daimon_b4jul:
    $ talk_start("大門", "21:30")
    $ talk("大門", "準決勝、3点、取られました")
    $ talk("大門", "2点目は、神城くんが、右だけで鷹野くんを外したやつです")
    $ talk_wait(1)
    $ talk("大門", "あれ、左を使わなかったのは、わざとですか。それとも")
    $ talk_me("……分からない")
    $ talk("大門", "そうですか。……次は、止めます")
    $ bond_up("大門", 2)
    return

label b4nc_sakaguchi_b4apr:
    $ talk_start("坂口", "23:12")
    $ talk_me("坂口、元気か")
    $ talk_wait(30)
    window auto hide
    "既読は、ついた。返事は、来なかった。"
    return

label b4nc_sakaguchi_b4jul:
    $ talk_start("坂口", "22:20")
    $ talk_me("準決勝、見てた")
    $ talk_wait(50)
    $ talk("坂口", "知ってる。白いシャツの列にいたろ")
    $ talk("坂口", "蓮がこっちにいたらとか、思ってねえから")
    $ talk_wait(3)
    $ talk("坂口", "……森が泣いてた。それだけ")
    $ bond_up("坂口", 1)
    return

label b4nc_takano_b4apr:
    $ talk_start("鷹野 迅", "23:00")
    $ talk_me("小早川ってやつ、どうだ")
    window auto hide
    "既読は、つかなかった。"
    return

label b4nc_takano_b4may:
    $ talk_start("鷹野 迅", "23:00")
    $ talk_me(b4_rank_name() + "に上がった")
    window auto hide
    "既読は、つかなかった。"
    return

label b4nc_takano_b4jul:
    $ talk_start("鷹野 迅", "23:00")
    $ talk_me("準決勝、いい当たりだった")
    $ talk_wait(30)
    $ talk("鷹野", "……ああ")
    window auto hide
    "返事が来たのは、四か月で、初めてだった。"
    $ bond_up("鷹野", 2)
    return
