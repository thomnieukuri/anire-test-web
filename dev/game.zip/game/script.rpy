## script.rpy ―― ゲームの入口と共通の小道具

## 「はじめから」でここに来る
label start:
    $ quick_menu = True
    $ music_stop(1.5)       # タイトル画面の曲を消す
    $ mark_update_seen()    # はじめから遊ぶ人には、この版の「更新しました」は出さない
    ## 選択肢のヒント（v0.29.13）：まだ決めていない人は、プロローグのあいだだけ「何が上がるか」を見せて、
    ##   プロローグが終わったところ（第1章のはじめ）で、このあともどうするかを聞く（hint_demo・choice_hint_ask）
    $ hint_demo = persistent.choice_hints is None
    if hint_demo:
        call hint_demo_intro
    jump prologue

## はじめから遊ぶとき、プロローグの前に一度だけ
label hint_demo_intro:
    scene black
    window auto hide
    tuto "このゲームでは、選んだことで能力やヒロインの気持ちが変わり、物語の行き先も変わります。"
    tuto "プロローグのあいだは、選択肢の下に「何が上がるか」の小さなヒントを出しています。プロローグが終わったら、このあとも出すかどうかを選べます。"
    return

## プロローグが終わったところ（第1章のはじめ）で聞く。章えらびから始めた人は、そのときに聞く
##   v0.29.13：「何が上がるか」と「試合の判定」を分けた。試合の判定は最初から出す（設定で消せる）。
##   「何が上がるか」は、どちらにも良さがあるので、おすすめは付けない（作者の判断）
label choice_hint_ask(hint_from_prologue=False):
    $ hint_demo = False
    scene black
    window auto hide
    show screen hint_sample
    tuto "試合の大事な場面では、選択肢の下に「判定に使う能力」と「必要な数値」が出ます。"
    tuto "これは、このあともずっと出します（設定の「ヒント」タブで切りかえられます）。"
    hide screen hint_sample
    if hint_from_prologue:
        tuto "プロローグでは、選択肢の下に「何が上がるか」（能力・仲間との絆・ヒロインの気持ち）を出していました。"
    else:
        tuto "選択肢の下に「何が上がるか」（能力・仲間との絆・ヒロインの気持ち）を出すこともできます。"
    menu:
        tuto "これから先、「何が上がるか」を出しますか？"
        "出さない\n{size=-6}蓮になったつもりで選べる。選んだことの重みが、あとで分かる{/size}":
            $ persistent.choice_hints = False
        "出す\n{size=-6}迷わず選べる。1回で、ねらった結末に向かいやすい{/size}":
            $ persistent.choice_hints = True
    tuto "あとから、設定の「ヒント」タブで、いつでも切りかえられます。"
    return

## 試合の判定の見本（聞くときに見せる。選択肢と同じ見た目）
screen hint_sample():
    zorder 50
    vbox:
        xalign 0.5
        ypos 120
        spacing 14
        text "見本" style "hint_sample_label" xalign 0.5
        frame:
            style "hint_sample_frame"
            vbox:
                xalign 0.5
                yalign 0.5
                text "鷹野に預けて、裏へ走る" style "choice_button_text" xalign 0.5
                text "判定：鷹野の絆 高い30・最高45（いま 38）" style "choice_hint_text" xalign 0.5
        frame:
            style "hint_sample_frame"
            vbox:
                xalign 0.5
                yalign 0.5
                text "自分で持ちこむ" style "choice_button_text" xalign 0.5
                text "判定：技術 53以上（いま 52）" style "choice_hint_text" xalign 0.5

style hint_sample_label:
    color "#ffffff"
    size 22
style hint_sample_frame:
    background Frame("gui/choice_idle.png", 80, 0)
    xsize 928
    ysize 94
    xalign 0.5

## 古い版のセーブを読んだとき、続きの場所（台本の行）が見つからなかったら、ここに来る。
##   何もしないと、Ren'Py は「戻る先がない」としてタイトル画面に戻してしまうので、
##   いちばん新しく来た章のはじめから続ける（選択や気持ちの数値は、そのまま残る）。
##   ※ 版をまたいでセーブを使えるように、.rpyc ファイルは消さずに残しておくこと（README の「セーブの互換」）
init python:
    config.return_not_found_label = "save_lost"
    config.load_failed_label = "save_lost"

label save_lost:
    python:
        _lost_to = "start"
        for _n in ("chapter6a", "chapter5a", "chapter4a", "chapter3", "chapter2", "chapter1", "prologue"):
            if _n in play_marks:
                _lost_to = _n
                break
    $ quick_menu = True
    window auto hide
    tuto "古い版のセーブデータだったため、続きの場所が見つかりませんでした。今の章のはじめから続けます（ここまでの選択や気持ちの数値は、そのまま残っています）。"
    $ renpy.jump(_lost_to)

## 章タイトルを出す。例：call show_title("プロローグ", "止まった冬")
label show_title(main, sub=""):
    window auto hide
    $ quick_menu = False
    $ cal_quiet = True      # 章タイトルの間は日付を隠す（日付そのものは残す）
    $ music_stop(1.5)       # 章の区切りは、いったん静かにする
    ## v0.44.6：章の始まりは「スタジアムの光」、終わりは「CHAPTER 1 CLEAR」（chapter_title.rpy）。体験版の終わり・結末はノートのまま
    $ _ti = ttl_info(main, sub)
    if _ti and _ti["kind"] == "open":
        show screen ttl_open(_ti)
        $ se("笛の音")
        pause 4.3
        hide screen ttl_open
        with Dissolve(0.6)
    elif _ti and _ti["kind"] == "clear":
        show screen ttl_clear(_ti)
        $ ttl_cleared = True
        $ se("鈍い衝突音")
        pause 2.6
        show screen ttl_wipe
        pause 0.26
        hide screen ttl_clear
        pause 0.3
    else:
        show screen title_card(main, sub)
        with Dissolve(0.8)
        pause 2.5
        hide screen title_card
        with Dissolve(0.8)
    $ quick_menu = True
    return

## 最初の選択肢の前に出す、セーブとロードの案内（1回目のプレイだけ）
label save_guide:
    if persistent.save_guide_seen:
        return
    window auto hide
    tuto "ここは、この先の話が大きく分かれる選択肢です。選んだ答えで、このあとの話やヒロインとの関係が変わっていきます。"
    tuto "「1つ戻る」で読み返すことはできますが、選んだ答えは変えられません。別の答えを試したいときは、選ぶ前に「セーブ」しておきましょう。"
    tuto "セーブは、画面の右上のメニューボタン（≡）を押して「セーブ」から。右クリックで開くメニューからもできます（スマホは、右上のメニューボタンから）。"
    tuto "続きから遊ぶときは、タイトル画面の「つづきから」か、右上のメニューボタンの「ロード」から、セーブした場所を選びます。"
    call screen save_prompt
    $ persistent.save_guide_seen = True
    return

## 体験版の終わり
label trial_end:
    window auto hide
    scene black
    with Dissolve(1.0)
    $ persistent.trial_cleared = True
    ## v0.30.0：製品版の続きを買っていれば、そのまま続きの章へ（store_unlock.rpy）
    if full_unlocked() and route_ready(ch3_route):
        if iap_testable():
            ## 作者の確認用と開発中だけ：体験版の終わりの画面も見られるように
            menu:
                "続きの章へ進む":
                    jump to_paid_part
                "体験版の終わりを見る":
                    pass
        else:
            jump to_paid_part
    call show_title("無料で遊べるのはここまで", "遊んでくれてありがとう！　第4章からの続きは、製品版で。")
    ## 製品版の予告（続きの量と中身。テスターの声：何章あるかで値段の印象が変わる）
    call screen product_preview with Dissolve(0.6)
    ## アプリ版（ストアで買える端末）と、テスト用の確認：購入画面を出す。買えたら続きへ
    if (store_available() or iap_testable()) and route_ready(ch3_route):
        call ask_unlock
        if _return:
            jump to_paid_part
        return
    ## テストページ（Web）と PC：遊んだ時間と、アンケートの案内（testplay.rpy）
    call screen trial_result with Dissolve(0.6)
    return


## 製品版の予告（体験版の最後に出す）
##   v0.29.7：買いたくなる画面に作り直した。2つの道を「扉」として並べ、選んだ道を大きく、もう一つの道も遊べることを見せる。
##   ボリュームは「続きのプレイ時間 8時間以上（予定）」だけを数字で出す（作者の決定。章の数・結末の数・値段はまだ出さない）。
##   この先の中身（ルート名、運命の選択の中身や回数、恋愛の結末の種類）は書かない（ネタバレになるため）。
screen pp_door(route, name, line, img, accent):
    $ _chosen = (ch3_route == route)
    $ _other = bool(ch3_route) and not _chosen
    fixed:
        xysize (560, 236)
        if _other:
            add Transform(img, crop=(0, 90, 1280, 540), size=(560, 236), matrixcolor=SaturationMatrix(0.35) * BrightnessMatrix(-0.18))
        else:
            add Transform(img, crop=(0, 90, 1280, 540), size=(560, 236))
        add Solid("#0b0f1680" if _chosen else "#0b0f16b8") xysize (560, 236)
        add Solid(accent) xysize (560, 6) yalign 1.0
        vbox:
            xpos 26
            yalign 0.5
            spacing 6
            if _chosen:
                text "あなたが選んだ道" style "pp_badge" color accent
            elif _other:
                text "もう一つの道も、遊べる" style "pp_badge" color "#c9d2de"
            text name style "pp_door_name"
            text line style "pp_door_line"

screen product_preview():
    modal True
    zorder 100
    add Solid("#0f141c")
    vbox:
        xalign 0.5
        yalign 0.5
        xsize 1180
        spacing 18
        vbox:
            xalign 0.5
            spacing 2
            text "製品版でつづく物語" xalign 0.5 style "pp_kicker"
            text "物語は、ここから二つに分かれる。" xalign 0.5 style "pp_title"
        hbox:
            xalign 0.5
            spacing 24
            use pp_door("stay", "港北に残る", "弱いまま、上を目指す。この仲間と。", "images/bg/kohoku_ground_eve.webp", "#4f8fe0")
            use pp_door("move", "桜嶺へ移る", "いちばん強い場所で、いちばん上を目指す。", "images/bg/ouryo_ground_rain.webp", "#d7a73c")
        hbox:
            xalign 0.5
            spacing 48
            vbox:
                yalign 0.5
                spacing 0
                text "8時間以上" style "pp_big"
                text "続きのプレイ時間（予定）" style "pp_small" xalign 0.5
            vbox:
                yalign 0.5
                spacing 6
                text "・体験版で選んだ答えは、すべて続きに引き継がれる" style "pp_point"
                text "・「残るか、移るか」のような、取り消せない大きな選択が、この先にも待っている" style "pp_point"
                text "・結末は、サッカーと恋愛の両方が、選んだ答えで変わる" style "pp_point"
                text "・1回の購入で、2つの道と、すべての結末が遊べる" style "pp_point"
        vbox:
            xalign 0.5
            spacing 2
            text "「春になったら、全部話す」――神城は、約束を守るのか。" xalign 0.5 style "pp_hook"
            text "港北は、残るのか。右ひざは、最後までもつのか。" xalign 0.5 style "pp_hook"
        hbox:
            xalign 0.5
            spacing 30
            text "※開発中のため、内容は変わることがあります" yalign 0.5 size 16 color "#7d8794"
            textbutton "つぎへ" action Return() yalign 0.5 text_size 28 text_color "#ff8a7a" text_hover_color "#ffffff" text_font FONT_JP_B

style pp_kicker:
    font FONT_JP_B
    size 20
    color "#9fb0c4"
    kerning 2

style pp_title:
    font FONT_JP_B
    size 36
    color "#ffffff"

style pp_badge:
    font FONT_JP_B
    size 17
    kerning 1

style pp_door_name:
    font FONT_JP_B
    size 38
    color "#ffffff"
    outlines [(2, "#0b0f16aa", 0, 0)]

style pp_door_line:
    size 20
    color "#e7ecf2"
    outlines [(2, "#0b0f16aa", 0, 0)]

style pp_big:
    font FONT_JP_B
    size 52
    color "#ffd27a"

style pp_small:
    size 16
    color "#c9d2de"

style pp_point:
    size 19
    color "#e7ecf2"

style pp_hook:
    size 21
    color "#8fd3cf"
    font FONT_JP_B
