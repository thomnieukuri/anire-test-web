################################################################################
## 試合中の作戦ボード（中継カメラのピッチ）の動き・飾り・カットイン・選ぶあいだ
##   v0.44.4（試合中のボードの確認帳 第5〜7回で決めたもの）
##   ・出方：ピッチが起き上がって、光る白線が走り、選手が奥から順に降りてくる（はじめて出たときだけ）
##   ・選手の動き：少し行きすぎて戻る、はずむ動き。走るあいだ小さく揺れて、通った道にチームの色の跡が残る
##   ・ボール：サッカーボールの絵。パスは影から浮いて弧を描く。矢印は点線が順に出てから、流れつづける
##   ・飾り：ボールを持っている人の足もとに、ゆっくり広がる輪
##   ・相手の丸：スコアボードの相手の色。背番号は丸の中に
##   ・1対1（比べ札が出る場面）：カメラが2人に寄って、比べ札が光って入る（軽め）。
##     名前のあるライバル（神城・真壁）との最初の1対1だけ、カットイン「目の帯」（作者「カットインが早い。選手画像も滞在時間が短い」→ ゆっくり）。
##     同じ相手の2回目は短く、3回目からは出さない。タップで飛ばせる
##   ・選ぶあいだ（tactics_choose）：ボードは消さずに、ボールのまわりだけ照らす。選択肢は照らした場所の反対側に
##   使い方は今までどおり tactics(...)。1対1は vs=("西海 10番", "B", "キープ A", "10")（4つ目はボードの上の相手の名前）
################################################################################

default tb_cut_seen = {}      # 1対1のカットインを、相手ごとに何回見たか
default tb_cam = None         # カメラが寄る場所 (x, y, 何秒後に寄るか)。None なら寄らない
default tb_choosing = False   # 時間で選ぶあいだ
default tb_spot = (640, 330)  # 照らす場所（画面の座標）
default tb_vs_key = ""        # いま出ている比べ札（同じ比べ札で、カットインを二度出さない）
default tb_vs_anim = (0.0, "slide")   # 比べ札の出方（何秒後に・slide／slam）
default tb_cut_req = None     # これから出すカットイン (相手, 長さ, 何秒後に, 相手の色)
default tb_last = None        # いま出ているボードの (dots, home, vs)
default tb_aside_list = None  # ボードのあいだ消している立ち絵（v0.44.8）
default tb_rec = []           # v0.44.11 リプレイ用：いまのボードに出した動き（ボードが新しく出るたびに空にする）
default tb_replay_ring = None # v0.44.11 リプレイの最後に出す赤い輪 (x, y)
default tb_replay_why = ""    # v0.44.11 赤い輪の横の理由の札

init 1 python:
    import math as _tbm
    import time as _tbt

    ## 時間は「いつ起きるか」（時計の時刻）で持つ。ボードが文ごとに出し直されても、比べ札やカメラの待ち時間が最初からにならないように
    def tb_left(at):
        return max(0.0, at - _tbt.time())

    ## カットインを出す、名前のあるライバル（目の帯の絵がある相手）
    TB_RIVAL_CUT = {"神城": ("gui/tactics/cut_kamishiro.jpg", "神城 凌"), "真壁": ("gui/tactics/cut_makabe.jpg", "真壁")}
    TB_CUT_FULL = (0.35, 1.6, 0.3)     # 入る・見せる・出ていく（秒）。作者「カットインが早い」で、ゆっくりにした
    TB_CUT_SHORT = (0.25, 0.7, 0.25)   # 同じ相手の2回目

    ## 相手の丸の色づけは、最初の1回だけ絵を作って使い回す（v0.44.5：毎フレームの色づけをやめた。スマホでカクつくため）
    _tb_disc_cache = {}
    def tb_disc_img(col):
        d = _tb_disc_cache.get(col)
        if d is None:
            try:
                r, g, b = Color(col).rgb
            except Exception:
                r, g, b = (1.0, 1.0, 1.0)
            d = im.MatrixColor("gui/tactics/mag_disc.png", im.matrix.tint(r, g, b))
            _tb_disc_cache[col] = d
        return d

    def tb_text_on(col):
        """チームの色の上に置く字の色"""
        try:
            c = Color(col)
            r, g, b = c.rgb
            return "#1a1a1a" if (0.299 * r + 0.587 * g + 0.114 * b) > 0.62 else "#ffffff"
        except Exception:
            return "#ffffff"

    ## v0.44.8：作者「選手表示はなるべく◯じゃなくて、画像ある人は画像を出して」「真壁はなるべく画像を入れた方が覚えられる」
    ##   ・名前のない港北の丸は、その時期の並び（第2章は CH2_442、第3章は ch3_442）でいちばん近い場所の人にする（15メートルまで）
    ##   ・桜嶺の14番（真壁）は、顔のマグネットにする
    TB_FACE_AWAY = {"真壁": "makabe"}

    def tb_auto_lineup():
        try:
            y = store.cal_year
            m = _month_of(store.cal_date)
        except Exception:
            return None
        if y != 2026 or not m or m < 6:
            return None
        if store.sb_home_name != "港北":
            return None
        try:
            return ch3_442() if m >= 9 else CH2_442
        except Exception:
            return None

    def tb_name_dots(dots):
        lu = tb_auto_lineup()
        used = set(d[1] for d in dots if len(d) > 1 and d[1])
        out = []
        for d in dots:
            d = list(d)
            if d[0] == "a" and d[1] == "14" and store.sb_away_name == "桜嶺":     # 桜嶺B（第1章）のときは、まだ名前を知らない
                d[1] = "真壁"
            if lu and d[0] == "h" and not d[1]:
                p = d[2]
                best, bd = None, 15.0
                for o in lu:
                    if o[1] in used or o[0] not in ("h",):
                        continue
                    dd = _tbm.hypot(o[2][0] - p[0], o[2][1] - p[1])
                    if dd < bd:
                        best, bd = o[1], dd
                if best:
                    d[1] = best
                    used.add(best)
            out.append(tuple(d))
        return out

    def tb_build(dots, home="navy", vs=None):
        """ボードに出すもの（選手・ボール・走った跡）と、ボールを持つ人・1対1の2人の位置"""
        away = store.sb_away_color
        dots = tb_name_dots(dots)
        ball_end = None
        for d in dots:
            if d[0] == "ball":
                ball_end = d[3] if len(d) > 3 and d[3] is not None else d[2]
        toks = []
        for d in dots:
            kind, label, p0 = d[0], d[1], d[2]
            p1 = d[3] if len(d) > 3 and d[3] is not None else p0
            delay = d[4] if len(d) > 4 else 0.0
            dur = max(0.01, d[5] if len(d) > 5 else 0.6)
            t = {"kind": kind, "label": label, "m0": p0, "m1": p1, "d": delay, "t": dur,
                 "p0": tb_xy_d(p0), "p1": tb_xy_d(p1), "z0": tb_zoom_d(p0), "z1": tb_zoom_d(p1),
                 "img": None, "disc": None, "ring": None, "plate": None, "hold": False, "moving": p0 != p1}
            face = TB_FACE.get(label) if kind in ("h", "ren", "kami") else TB_FACE_AWAY.get(label) if kind == "a" else None
            ## v0.44.8：合宿の紅白戦（相手も港北の仲間）は、白のチームも顔
            if kind == "a" and not face and store.sb_away_name == "白":
                face = TB_FACE.get(label)
            if kind == "ball":
                t["img"] = "gui/tactics/ball_s.png"
            elif face and renpy.loadable("gui/tactics/face_%s.png" % face):
                t["img"] = "gui/tactics/face_%s.png" % face
            elif kind in ("a", "kami"):
                t["disc"] = away
            else:
                t["img"] = "gui/tactics/mag_%s.png" % home
            if kind == "ren":
                t["ring"] = "gui/tactics/ring_ren.png"
            elif kind == "kami":
                t["ring"] = "gui/tactics/ring_kami.png"
            if label and kind != "ball":
                if t["disc"] is not None and len(label) <= 2:
                    pass                    # 背番号は丸の中
                else:
                    t["plate"] = "ren" if label == "蓮" else ("a" if kind in ("a", "kami") else "h")
            toks.append(t)
        ## ボールを持つ人：ボールの行き先にいちばん近い人（4メートルまで）
        if ball_end is not None:
            best, bd = None, 4.0
            for t in toks:
                if t["kind"] == "ball":
                    continue
                dd = _tbm.hypot(t["m1"][0] - ball_end[0], t["m1"][1] - ball_end[1])
                if dd < bd:
                    best, bd = t, dd
            if best:
                best["hold"] = True
        ## 降りてくる順（奥から）と、重ねる順（奥が下）
        for i, t in enumerate(sorted([t for t in toks if t["kind"] != "ball"], key=lambda o: o["p0"][1])):
            t["i"] = i
        toks.sort(key=lambda o: (o["kind"] == "ball", o["p1"][1]))
        ## 走った跡（動いた選手だけ）。v0.44.7：点を1つずつ出すのをやめ、点の並んだ1本の絵を伸ばす（スマホのカクつき対策）
        ##   (色, まん中x, まん中y, 長さ, 角度, 何秒後に, 伸びる秒)
        trails = []
        for t in toks:
            if t["kind"] == "ball" or not t["moving"]:
                continue
            col = "w" if t["kind"] in ("a", "kami") else ("y" if t["kind"] == "ren" else "h")
            (x0, y0), (x1, y1) = t["p0"], t["p1"]
            L = _tbm.hypot(x1 - x0, y1 - y0)
            if L < 12:
                continue
            ang = _tbm.degrees(_tbm.atan2(y1 - y0, x1 - x0))
            trails.append((col, int((x0 + x1) / 2), int((y0 + y1) / 2) + 14, int(L), ang, t["d"], t["t"]))
        ## 1対1の2人
        duel = None
        if vs:
            op = vs[3] if len(vs) > 3 else None
            if op == "14" and any(t["label"] == "真壁" for t in toks):
                op = "真壁"
            ren = [t for t in toks if t["kind"] == "ren"]
            opp = [t for t in toks if t["kind"] in ("a", "kami") and t["label"] and (t["label"] == op or (op is None and t["label"] in vs[0]))]
            if ren and opp:
                duel = ((ren[0]["p1"][0] + opp[0]["p1"][0]) // 2, (ren[0]["p1"][1] + opp[0]["p1"][1]) // 2)
        bxy = tb_xy_d(ball_end) if ball_end is not None else None
        end = max([t["d"] + t["t"] for t in toks if t["moving"]] or [0.0])
        return toks, trails, duel, bxy, end

    def tb_rival_of(vs):
        if not vs:
            return None
        for k in TB_RIVAL_CUT:
            if k in vs[0]:
                return k
        return None

    ## v0.44.8：作者「戦術ボードを出しているときに、うしろに立ち絵があることがある。左右に出すか消すかして」
    ##   → ボードを出すとき、立ち絵をいったん消して、ボードを消したら同じ場所にもどす（そのあいだに場面が変わっていたら、もどさない）
    TB_NOT_SPRITE = ("bg", "cg", "black", "white", "map")

    def tb_aside():
        if store.tb_aside_list:
            return
        tags = [t for t in renpy.get_showing_tags("master", sort=True) if t not in TB_NOT_SPRITE]
        keep = []
        for t in tags:
            try:
                b = renpy.get_image_bounds(t, layer="master")
                at = renpy.get_attributes(t, layer="master") or ()
            except Exception:
                continue
            keep.append((t, tuple(at), b))
        if not keep:
            return
        base = tuple((t, tuple(renpy.get_attributes(t, layer="master") or ())) for t in renpy.get_showing_tags("master", sort=True) if t in TB_NOT_SPRITE)
        store.tb_aside_list = (keep, base)
        for t, at, b in keep:
            renpy.hide(t, layer="master")

    def tb_back():
        a = store.tb_aside_list
        store.tb_aside_list = None
        if not a:
            return
        keep, base = a
        now = tuple((t, tuple(renpy.get_attributes(t, layer="master") or ())) for t in renpy.get_showing_tags("master", sort=True) if t in TB_NOT_SPRITE)
        if now != base:
            return
        showing = set(renpy.get_showing_tags("master"))
        for t, at, b in keep:
            if t in showing:
                continue
            try:
                x, y, w, h = b
                renpy.show(" ".join((t,) + at), at_list=[Transform(pos=(int(x), int(y)), anchor=(0, 0))], layer="master")
            except Exception:
                pass

    def tactics(dots=(), arrows=(), caption="", home="navy", style=None, vs=None, surface=None):
        """作戦ボードを出す（出ていれば、中身を入れかえる）。vs は比べ札（1対1の場面だけ）、surface は "dirt"／"grass"（ふつうは自動）"""
        style = style or tb_style_of(caption)
        if not renpy.get_screen("tactics_pitch") and not renpy.get_screen("tactics_board"):
            tb_aside()
        if style != "pitch":
            if renpy.get_screen("tactics_pitch"):
                tactics_off()
            renpy.show_screen("tactics_board", dots=list(dots), arrows=list(arrows), caption=caption, home=home)
            return
        if renpy.get_screen("tactics_board"):
            renpy.hide_screen("tactics_board")
        intro = not renpy.get_screen("tactics_pitch")
        if intro:
            ## 新しいボード：前のボードの「寄る・照らす・比べ札」を持ちこさない
            store.tb_cam = None
            store.tb_choosing = False
            store.tb_vs_key = ""
            store.tb_cut_req = None
        dots = list(dots)
        if vs:
            key = "%s|%s" % (vs[0], caption)
            if key != store.tb_vs_key:
                store.tb_vs_key = key
                toks, trails, duel, bxy, end = tb_build(dots, home, vs)
                now = _tbt.time()
                t0 = now + (1.2 if intro else 0.2) + end
                rv = tb_rival_of(vs)
                n = store.tb_cut_seen.get(rv, 0) if rv else 9
                if rv and n < 2:
                    tm = TB_CUT_FULL if n == 0 else TB_CUT_SHORT
                    store.tb_cut_seen = dict(store.tb_cut_seen)
                    store.tb_cut_seen[rv] = n + 1
                    store.tb_cut_req = (rv, tm, t0, store.sb_away_color)
                    t1 = t0 + sum(tm)
                    store.tb_vs_anim = (t1, "slam")
                else:
                    t1 = t0
                    store.tb_vs_anim = (t1, "slide")
                if duel:
                    store.tb_cam = (duel[0], duel[1], t1)
        store.tb_last = (dots, home, vs)
        ## v0.44.11：点のあとのリプレイ用に、出した動きを覚えておく
        if intro:
            store.tb_rec = []
        rec = (dots, list(arrows), caption, home, surface or tb_surface_of())
        if not store.tb_rec or store.tb_rec[-1][:2] != rec[:2]:
            store.tb_rec = store.tb_rec + [rec]
        renpy.show_screen("tactics_pitch", dots=dots, arrows=list(arrows), caption=caption, home=home,
                          vs=vs, surface=surface or tb_surface_of(), intro=intro)

    def tactics_choose():
        """時間で選ぶ前に呼ぶ（tactics_off のかわり）。ボードは消さずに、ボールのまわりだけ照らす。選んだら消える"""
        if not renpy.get_screen("tactics_pitch") or not store.tb_last:
            return
        toks, trails, duel, bxy, end = tb_build(*store.tb_last)
        c = duel or bxy or (640, 330)
        store.tb_spot = (int(c[0]), int(c[1]))
        if store.tb_cam is None:
            store.tb_cam = (c[0], c[1], _tbt.time())
        store.tb_choosing = True
        renpy.restart_interaction()

    def tactics_off():
        renpy.hide_screen("tb_replay_fx")
        store.tb_replay_ring = None
        renpy.hide_screen("tactics_board")
        renpy.hide_screen("tactics_pitch")
        renpy.hide_screen("tb_cutin")
        tb_back()
        store.tb_cam = None
        store.tb_choosing = False
        store.tb_vs_key = ""
        store.tb_cut_req = None
        store.tb_last = None

    ## ---------------------------------------------------------------------------
    ## v0.44.11 点のあとのリプレイ（試合中のボードの確認帳 第6回で決めた形）
    ##   ふつうの速さで見た動きを、巻き戻して REPLAY ×0.5 でゆっくりもう一度。守る側も遅れて動く・走った跡・空いた場所に赤い輪
    ##   使い方：点が入った一枚絵のあとで  $ tactics_replay()  → 「どこが空いていたか」の文 → $ tactics_off()
    ##     hole=(x, y) … 赤い輪を出す場所（ボードの座標）。省くと、最後にボールが行った場所
    ##     att="h"／"a" … 攻めた側（守る側が遅れて動く）。省くと、最後にボールを持った人の側
    ##   ボードは、点の前に出したものを、出した順にそのまま使う（同じ動きを2回書かなくてよい）
    ## ---------------------------------------------------------------------------
    TB_REPLAY_SLOW = 2.0

    def _tb_scale(dots, k, add):
        out = []
        for d in dots:
            if len(d) > 3 and d[3] is not None and d[3] != d[2]:
                dl = d[4] if len(d) > 4 else 0.0
                du = d[5] if len(d) > 5 else 0.6
                out.append((d[0], d[1], d[2], d[3], add + dl * k, du * k))
            else:
                out.append((d[0], d[1], d[2]))
        return out

    def _tb_drift(dots, att):
        """守る側：止まっている人を、ボードの最後のボールの場所へ少しだけ、遅れて寄せる"""
        ball = None
        for d in dots:
            if d[0] == "ball":
                ball = d
        if not ball:
            return dots
        be = ball[3] if len(ball) > 3 and ball[3] is not None else ball[2]
        bd = (ball[4] if len(ball) > 4 else 0.0) + 0.35
        bt = max(0.5, (ball[5] if len(ball) > 5 else 0.6) * 1.2)
        defend = ("a", "kami") if att == "h" else ("h", "ren")
        out = []
        for d in dots:
            moving = len(d) > 3 and d[3] is not None and d[3] != d[2]
            if d[0] in defend and not moving:
                dx, dy = be[0] - d[2][0], be[1] - d[2][1]
                L = _tbm.hypot(dx, dy)
                if 3.0 < L < 22.0:
                    m = min(L * 0.35, 5.0)
                    p1 = (round(d[2][0] + dx / L * m, 1), round(d[2][1] + dy / L * m, 1))
                    out.append((d[0], d[1], d[2], p1, bd, bt))
                    continue
            out.append(d)
        return out

    def tactics_replay(hole=None, att=None, why="ここが空いた"):
        rec = [r for r in (store.tb_rec or [])]
        if not rec:
            return
        ## 動きのない段（はじめの止まった絵など）は、はじめの1つだけ残す
        stages = []
        for i, r in enumerate(rec):
            moving = any(len(d) > 3 and d[3] is not None and d[3] != d[2] for d in r[0])
            if moving or r[1] or i == 0:
                stages.append(r)
        if len(stages) > 1 and not any(len(d) > 3 and d[3] is not None and d[3] != d[2] for d in stages[0][0]) and not stages[0][1]:
            stages = stages[1:]
        last = stages[-1]
        toks, trails, duel, bxy, end = tb_build(last[0], last[3])
        if att is None:
            hold = [t for t in toks if t["hold"]]
            att = "a" if hold and hold[0]["kind"] in ("a", "kami") else "h"
        ring = tb_xy_d(hole) if hole else bxy
        renpy.hide_screen("tb_cutin")
        if not renpy.get_screen("tactics_pitch"):
            tb_aside()
        store.tb_cam = None
        store.tb_choosing = False
        store.tb_vs_key = ""
        store.tb_cut_req = None
        store.tb_replay_ring = None
        ## 巻き戻し：最後の段の動きを、さかさまに速く
        back = []
        for d in last[0]:
            if len(d) > 3 and d[3] is not None and d[3] != d[2]:
                back.append((d[0], d[1], d[3], d[2], 0.05, 0.4))
            else:
                back.append((d[0], d[1], d[2]))
        renpy.show_screen("tb_replay_fx", mode="rewind")
        renpy.show_screen("tactics_pitch", dots=back, arrows=[], caption="", home=last[3], vs=None, surface=last[4], intro=False)
        renpy.pause(0.65, hard=True)
        renpy.show_screen("tb_replay_fx", mode="play")
        for i, (dots, arrows, cap, home, surf) in enumerate(stages):
            if i == len(stages) - 1:
                dots = _tb_drift(dots, att)
            sd = _tb_scale(dots, TB_REPLAY_SLOW, 0.2)
            sa = [(a[0], a[1], 0.2 + (a[2] if len(a) > 2 else 0.0) * TB_REPLAY_SLOW) + tuple(a[3:]) for a in arrows]
            renpy.show_screen("tactics_pitch", dots=sd, arrows=sa, caption=cap, home=home, vs=None, surface=surf, intro=False)
            t = tb_build(sd, home)[4]
            renpy.pause(max(0.9, t + 0.5))
        store.tb_replay_ring = (ring[0], ring[1], _tbt.time())
        store.tb_replay_why = why
        store.tb_last = (stages[-1][0], stages[-1][3], None)
        renpy.restart_interaction()

    def tb_arrow_lines(arrows, xy):
        """v0.44.7：矢印を、点線の1本の絵（伸びる）＋矢じりにする。前は点線のかけらを1つずつ出していた（スマホでカクつくため）
        (色, まん中x, まん中y, 長さ, 角度, 何秒後に, 伸びる秒, 矢じりx, 矢じりy)"""
        out = []
        for a in arrows:
            p0, p1 = xy(a[0]), xy(a[1])
            delay = a[2] if len(a) > 2 else 0.0
            col = a[3] if len(a) > 3 else "w"
            dx, dy = p1[0] - p0[0], p1[1] - p0[1]
            L = _tbm.hypot(dx, dy)
            if L < 40:
                continue
            ux, uy = dx / L, dy / L
            ang = _tbm.degrees(_tbm.atan2(dy, dx))
            st, en = 16.0, L - 18.0
            draw = 0.35 + L / 900.0
            out.append((col, int(p0[0] + ux * (st + en) / 2), int(p0[1] + uy * (st + en) / 2), int(en - st), ang, delay, draw,
                        int(p0[0] + ux * (L - 11)), int(p0[1] + uy * (L - 11))))
        return out

    TB_PRELOAD = ["pitch_tv_dirt", "pitch_tv_grass", "pitch_glow", "shadow_d", "ring_pulse", "ring_ren", "ring_kami", "mag_disc",
                  "mag_rim_w", "mag_rim_g", "mag_navy", "mag_sky", "mag_white", "plate_h", "plate_a", "plate_ren", "ball_s",
                  "dashline_w", "dashline_r", "dashline_y", "head_w", "head_r", "head_y", "trailline_h", "trailline_y", "trailline_w",
                  "cap_shine", "spot", "spot_ring", "rankbox_y", "rankbox_w"]

    def tb_preload():
        """v0.44.7：試合が始まったら、ボードの絵を先に読みこんでおく（はじめてボードが出たときに止まらないように）"""
        try:
            fs = ["gui/tactics/%s.png" % n for n in TB_PRELOAD]
            fs += ["gui/tactics/face_%s.png" % f for f in TB_FACE.values()]
            renpy.start_predict(*[f for f in fs if renpy.loadable(f)])
        except Exception:
            pass

    TB_CHOICE_W = 470
    def tb_choice_x():
        """選択肢の左はし：照らした場所の反対側（照らした輪にかからないように）"""
        sx = store.tb_spot[0]
        if sx < 640:
            return min(1280 - 20 - TB_CHOICE_W, sx + 200)
        return max(20, sx - 200 - TB_CHOICE_W)

    def tb_cam_tf(c):
        if not c:
            return tb_cam_off
        if _tbt.time() - c[2] > 0.6:
            return tb_zoom_static(int(c[0]), int(c[1]))      # もう寄り終わっている（文が進んでも、寄り直さない）
        return tb_zoom_to(int(c[0]), int(c[1]), tb_left(c[2]))

    def tb_vs_tf(a):
        at, kind = a
        if _tbt.time() - at > 0.5:
            return tb_vs_slam_static if kind == "slam" else tb_none
        d = tb_left(at)
        return tb_vs_slam(d) if kind == "slam" else tb_vs_slide(d)

    def tb_vs_flash_tf(a):
        if _tbt.time() - a[0] > 0.6:
            return tb_hidden
        return tb_vs_flash(tb_left(a[0]))

    def tb_cap_w(caption):
        return 60 + 21 * len(caption or "")

screen tactics_pitch(dots=[], arrows=[], caption="", home="navy", vs=None, surface="dirt", intro=False):
    zorder 40
    if tb_cut_req:
        timer max(0.01, tb_left(tb_cut_req[2])) action [Show("tb_cutin", rv=tb_cut_req[0], tm=tb_cut_req[1], away=tb_cut_req[3]), SetVariable("tb_cut_req", None)]
    $ _tk, _tr, _duel, _bxy, _end = tb_build(dots, home, vs)
    fixed at tb_in_full:
        xysize (1280, 720)
        ## うしろの絵を少し暗くして、ボードを浮かせる（試合の黒帯の内側だけ）
        add Solid("#00000052") pos (0, 64) xysize (1280, 592)
        ## カメラ（1対1・選ぶあいだは、2人に寄る）
        fixed at tb_cam_tf(tb_cam):
            xysize (1280, 720)
            add ("gui/tactics/pitch_tv_%s.png" % surface) at (tb_rise if intro else tb_pitch_at)
            if intro:
                add "gui/tactics/pitch_glow.png" at tb_glow_draw
            for _col, _x, _y, _len, _ang, _d, _t in _tr:
                fixed at tb_trail_line(_x, _y, _ang, _d, _t):
                    xysize (_len, 12)
                    add ("gui/tactics/trailline_%s.png" % _col) at tb_line_grow(_len, 12, _d, _t)
            use tb_arrow_set(arrows)
            for _t in _tk:
                fixed at (tb_move_d if _t["kind"] == "ball" else tb_move_a)(_t["p0"], _t["p1"], _t["z0"], _t["z1"], _t["d"], _t["t"]):
                    xysize (48, 48)
                    if _t["kind"] == "ball":
                        add "gui/tactics/shadow_d.png" xalign 0.5 ypos 26 zoom 0.36
                        add _t["img"] at tb_ball_arc(_t["d"], _t["t"], (min(30, int(abs(_t["p1"][0] - _t["p0"][0]) * 0.12 + abs(_t["p1"][1] - _t["p0"][1]) * 0.12)) if _t["moving"] else 0))
                    else:
                        fixed at (tb_drop(0.45 + _t["i"] * 0.028) if intro else tb_none):
                            xysize (48, 48)
                            add "gui/tactics/shadow_d.png" xalign 0.5 ypos 34 zoom 0.7
                            if _t["hold"]:
                                add "gui/tactics/ring_pulse.png" xalign 0.5 ypos 30 at tb_pulse
                            fixed at (tb_bob(_t["d"], _t["t"]) if _t["moving"] else tb_none):
                                xysize (48, 48)
                                if _t["disc"] is not None:
                                    add tb_disc_img(_t["disc"]) align (0.5, 0.5)
                                    add ("gui/tactics/mag_rim_g.png" if tb_text_on(_t["disc"]) == "#1a1a1a" else "gui/tactics/mag_rim_w.png") align (0.5, 0.5)
                                    if _t["label"] and not _t["plate"]:
                                        text _t["label"] style "tb_disc_num" color tb_text_on(_t["disc"])
                                else:
                                    add _t["img"] align (0.5, 0.5)
                                if _t["ring"]:
                                    add _t["ring"] align (0.5, 0.5)
                                if _t["plate"]:
                                    frame:
                                        style "tb_plate"
                                        background Frame("gui/tactics/plate_%s.png" % _t["plate"], 10, 10)
                                        text _t["label"] style "tb_label_d"

        ## 選ぶあいだ：ボールのまわりだけ照らす
        if tb_choosing:
            add "gui/tactics/spot.png" pos (tb_spot[0] - 1280, tb_spot[1] - 720) zoom 4.0 at tb_fade_in(0.35)      # 小さい絵を4倍に（v0.44.5：メモリを減らした）
            add "gui/tactics/spot_ring.png" pos (tb_spot[0] - 170, tb_spot[1] - 100) at tb_ring_in

        ## 見出し（中継の札。左右の色は、スコアボードの両チームの色）。はじめて出たとき、一度だけ光が走る
        if caption:
            fixed:
                pos (70, 80)
                xysize (tb_cap_w(caption) + 18, 42)
                hbox:
                    add Solid(sb_home_color) xysize (9, 42)
                    frame:
                        style "tb_caption_d_frame"
                        text caption style "tb_caption_d"
                    add Solid(sb_away_color) xysize (9, 42)
                if intro:
                    add "gui/tactics/cap_shine.png" at tb_cap_shine(tb_cap_w(caption))

        ## 比べ札（1対1の場面だけ）
        if vs:
            $ _vr = tb_vs_rows(vs)
            fixed at tb_vs_tf(tb_vs_anim):
                pos (396, 76)
                xysize (488, 64)
                add Solid("#0b1424ee")
                add Solid("#ffd23f") xysize (214, 5)
                add Solid(sb_away_color) xpos 274 xysize (214, 5)
                text _vr[0][0] style "tb_vs_name" xpos 18 ypos 9 color "#ffd23f"
                text _vr[0][2] style "tb_vs_sub" xpos 18 ypos 38
                fixed:
                    pos (158, 9) xysize (54, 46)
                    add Frame("gui/tactics/rankbox_y.png", 10, 10)
                    text _vr[0][1] style "tb_vs_rank" color "#ffd23f" align (0.5, 0.5)
                add Solid("#c62828") pos (221, 9) xysize (46, 46)
                text "VS" style "tb_vs_rank" size 19 pos (244, 32) anchor (0.5, 0.5)
                fixed:
                    pos (276, 9) xysize (54, 46)
                    add Frame("gui/tactics/rankbox_w.png", 10, 10)
                    text _vr[1][1] style "tb_vs_rank" align (0.5, 0.5)
                text _vr[1][0] style "tb_vs_name" xanchor 1.0 xpos 470 ypos 9
                text _vr[1][2] style "tb_vs_sub" xanchor 1.0 xpos 470 ypos 38
                add Solid("#ffffff") xysize (488, 64) at tb_vs_flash_tf(tb_vs_anim)

## カットイン「目の帯」（名前のあるライバルとの1対1だけ）。タップで飛ばせる
screen tb_cutin(rv, tm=(0.35, 1.6, 0.3), away="#f2f2ee"):
    zorder 45
    modal True
    $ _img, _nm = TB_RIVAL_CUT[rv]
    $ _tin, _hold, _tout = tm
    timer _tin + _hold + _tout + 0.05 action Hide("tb_cutin")
    key "dismiss" action Hide("tb_cutin")
    fixed:
        xysize (1280, 720)
        button:
            xysize (1280, 720)
            background None
            action Hide("tb_cutin")
        add Solid("#ffffff") xysize (1280, 720) at tb_cut_flash
        ## 上の帯：蓮
        fixed at tb_band(True, _tin, _hold, _tout):
            pos (-200, 118)
            xysize (1680, 190)
            add Solid("#10204a") xysize (1680, 190)
            add Transform("gui/tactics/cut_ren.jpg", crop=(0, 30, 1280, 190)) xpos 200
            add "gui/tactics/band_spd.png" at tb_spd(90)
            text "早瀬 蓮" style "tb_cut_name" xpos 260 yalign 0.92
        add Solid("#ffd23f") xysize (1680, 5) pos (-200, 114) at tb_band(True, _tin, _hold, _tout)
        ## 下の帯：相手
        fixed at tb_band(False, _tin, _hold, _tout):
            pos (-200, 372)
            xysize (1680, 190)
            add Solid(away if away != "#f2f2ee" else "#2a2a2a") xysize (1680, 190)
            add Transform(_img, crop=(0, 30, 1280, 190)) xpos 200
            add "gui/tactics/band_spd.png" at tb_spd(-90)
            text _nm style "tb_cut_name" xanchor 1.0 xpos 1420 yalign 0.92
        add Solid("#ffd23f") xysize (1680, 5) pos (-200, 562) at tb_band(False, _tin, _hold, _tout)

## 矢印（点線の1本の絵が伸びて、矢じりが出る。そのあと3回だけ明るさが揺れる）。試合前の紹介でも使う
screen tb_arrow_set(arrows):
    for _col, _x, _y, _len, _ang, _d, _dr, _hx, _hy in tb_arrow_lines(arrows, tb_xy_d):
        fixed at tb_line_at(_x, _y, _ang, _d + _dr):
            xysize (_len, 6)
            add ("gui/tactics/dashline_%s.png" % _col) at tb_line_grow(_len, 6, _d, _dr)
        add ("gui/tactics/head_%s.png" % _col) at tb_head_pop(_hx, _hy, _ang, _d + _dr)

transform tb_line_at(x, y, ang, d=0.0):
    subpixel True
    anchor (0.5, 0.5) pos (x, y)
    rotate ang
    alpha 1.0
    pause (d + 0.35)
    block:
        linear 0.3 alpha 0.4
        linear 0.3 alpha 1.0
        repeat 3

transform tb_line_grow(w, h, d=0.0, t=0.4):
    crop (0, 0, 1, h)
    pause d
    linear t crop (0, 0, w, h)

transform tb_trail_line(x, y, ang, d=0.0, t=0.6):
    subpixel True
    anchor (0.5, 0.5) pos (x, y)
    rotate ang
    alpha 0.5
    pause (d + t + 0.9)
    linear 0.8 alpha 0.0

transform tb_none:
    alpha 1.0 yoffset 0

transform tb_cam_off:
    pos (0, 0) zoom 1.0

transform tb_in_full:
    on show:
        alpha 0.0
        easein 0.22 alpha 1.0
    on hide:
        easeout 0.22 alpha 0.0 yoffset 12

## ピッチが起き上がる（はじめて出たとき）
transform tb_pitch_at:
    anchor (0, 0) pos TB_D_IMG_POS yzoom 1.0 alpha 1.0

transform tb_rise:
    xpos TB_D_IMG_POS[0] ypos (TB_D_IMG_POS[1] + 444)
    yanchor 1.0
    yzoom 0.12 alpha 0.0
    easeout 0.55 yzoom 1.0 alpha 1.0

## 光る白線が、左から右へ走って描かれる
transform tb_glow_draw:
    xpos 0 ypos 130
    crop (0, 0, 1, 444)
    alpha 1.0
    pause 0.25
    linear 0.45 crop (0, 0, 1280, 444)
    linear 0.5 alpha 0.0

## 選手が奥から順に降りてくる
transform tb_drop(d=0.0):
    alpha 0.0 yoffset -46
    pause d
    easeout 0.26 alpha 1.0 yoffset 4
    ease 0.1 yoffset 0

## はずむ動き（少し行きすぎて戻る）。ボールは素直に
transform tb_move_a(p0, p1, z0=1.0, z1=1.0, d=0.0, t=0.6):
    subpixel True
    anchor (0.5, 0.5)
    pos p0
    zoom z0
    pause d
    easeout_back t pos p1 zoom z1

## 走っているあいだ、小さく上下に揺れる
transform tb_bob(d=0.0, t=0.6):
    pause d
    block:
        linear 0.08 yoffset -4
        linear 0.08 yoffset 0
        repeat max(1, int(t / 0.16))

## ボールは影から浮いて、弧を描く
transform tb_ball_arc(d=0.0, t=0.6, lift=0):
    align (0.5, 0.5)
    zoom 0.62
    pause d
    easeout (t / 2.0) yoffset (-lift) zoom (0.62 + lift * 0.006)
    easein (t / 2.0) yoffset 0 zoom 0.62

## 走った跡の点
transform tb_trail_dot(x, y, d=0.0):
    anchor (0.5, 0.5)
    pos (x, y)
    alpha 0.0
    pause d
    linear 0.05 alpha 0.5
    pause 0.9
    linear 0.8 alpha 0.0

## 矢印：点線が順に出てから、流れつづける
transform tb_dash_flow(x, y, ang, d=0.0, ph=0.0):
    subpixel True
    anchor (0.5, 0.5)
    pos (x, y)
    rotate ang
    alpha 0.0
    pause d
    linear 0.06 alpha 1.0
    pause (0.35 + ph)
    block:
        linear 0.3 alpha 0.35
        linear 0.3 alpha 1.0
        repeat 3        # v0.44.5：流れつづけると画面が描き直されつづけるので、3回で止める

transform tb_head_pop(x, y, ang, d=0.0):
    subpixel True
    anchor (0.5, 0.5)
    pos (x, y)
    rotate ang
    alpha 0.0 zoom 0.2
    pause d
    easeout 0.16 alpha 1.0 zoom 1.0

## ボールを持つ人の足もとの輪
transform tb_pulse:
    alpha 0.9 zoom 0.6
    linear 1.3 alpha 0.0 zoom 1.5
    repeat 3        # v0.44.7：ずっとくり返すと、ボードが出ているあいだ画面が描き直されつづける（スマホのカクつき）

## カメラが寄る（その点を動かさずに 1.3倍）
transform tb_zoom_to(x, y, d=0.0):
    pos (0, 0) zoom 1.0
    pause d
    ease 0.5 zoom 1.3 xpos int(x - x * 1.3) ypos int(y - y * 1.3)

transform tb_zoom_static(x, y):
    zoom 1.3 xpos int(x - x * 1.3) ypos int(y - y * 1.3)

transform tb_vs_slam_static:
    alpha 1.0 zoom 1.0 xanchor 0.5 yanchor 0.5 xpos 640 ypos 108

transform tb_hidden:
    alpha 0.0

transform tb_fade_in(t=0.3):
    alpha 0.0
    linear t alpha 1.0

transform tb_ring_in:
    alpha 0.0 zoom 1.25
    easeout 0.42 alpha 1.0 zoom 1.0

transform tb_cap_shine(w=300):
    ypos 0 xpos -70 alpha 1.0
    pause 0.5
    ease 0.7 xpos w
    alpha 0.0

## 比べ札：上から光って入る（軽め）／カットインのあとは、たたきつける
transform tb_vs_slide(d=0.2):
    alpha 0.0 yoffset -40
    pause d
    easeout_back 0.3 alpha 1.0 yoffset 0

transform tb_vs_slam(d=0.2):
    alpha 0.0 zoom 1.7
    xanchor 0.5 yanchor 0.5 xpos 640 ypos 108
    pause d
    easeout 0.18 alpha 1.0 zoom 0.94
    ease 0.12 zoom 1.0

transform tb_vs_flash(d=0.2):
    alpha 0.0
    pause (d + 0.15)
    alpha 0.9
    linear 0.35 alpha 0.0

## カットイン
transform tb_cut_flash:
    alpha 0.0
    linear 0.1 alpha 0.85
    linear 0.25 alpha 0.0

transform tb_band(from_left=True, tin=0.35, hold=1.6, tout=0.3):
    rotate -6
    rotate_pad False
    xoffset (-1700 if from_left else 1700)
    easeout tin xoffset 0
    pause hold
    easein tout xoffset (1700 if from_left else -1700)

transform tb_spd(dx=90):
    xoffset 0
    linear 0.3 xoffset dx
    xoffset 0
    repeat

init 1:
    style tb_disc_num:
        align (0.5, 0.5)
        font FONT_JP_B
        size 16
        outlines []

    style tb_cut_name:
        font FONT_JP_B
        size 30
        color "#ffffff"
        outlines [(3, "#000000", 0, 2)]


## v0.44.11 リプレイの飾り：巻き戻しの線と「REPLAY ×0.5」の札、最後に赤い輪
transform tb_rw_lines:
    alpha 0.0
    linear 0.12 alpha 1.0
    pause 0.38
    linear 0.15 alpha 0.0

transform tb_rw_scroll(y0):
    ypos y0
    linear 0.65 ypos (y0 - 220)

transform tb_rp_tag:
    alpha 0.0 xoffset 24
    easeout 0.3 alpha 1.0 xoffset 0

transform tb_rp_blink:
    alpha 1.0
    pause 0.5
    alpha 0.15
    pause 0.5
    repeat 6

transform tb_ring_red_in:
    alpha 0.0 zoom 1.8
    easeout 0.45 alpha 1.0 zoom 1.0

screen tb_replay_fx(mode="play"):
    zorder 41
    if mode == "rewind":
        fixed at tb_rw_lines:
            xysize (1280, 720)
            add Solid("#ffffff10") pos (0, 64) xysize (1280, 592)
            for _i in range(9):
                add "gui/tactics/rw_line.png" at tb_rw_scroll(160 + _i * 60)
            fixed:
                xysize (300, 64) xalign 0.5 ypos 290
                add Solid("#0b1424dd")
                add Solid("#e53935") xysize (6, 64)
                text "◀◀  REWIND" font FONT_JP_B size 30 color "#ffffff" align (0.5, 0.5)
    else:
        fixed at tb_rp_tag:
            pos (1280 - 70 - 236, 80)
            xysize (236, 42)
            add Solid("#0b1424ee")
            add Solid("#e53935") xysize (6, 42)
            add Solid("#e53935") pos (22, 15) xysize (12, 12) at tb_rp_blink
            text "REPLAY" font FONT_JP_B size 22 color "#ffffff" pos (44, 7)
            text "×0.5" font FONT_JP_B size 22 color "#ffd23f" pos (150, 7)
        if tb_replay_ring:
            $ _rp_new = (tb_left(tb_replay_ring[2] + 1.0) > 0)      # 文が進んでも、輪の動きを最初からにしない
            add "gui/tactics/ring_red.png" anchor (0.5, 0.5) pos (int(tb_replay_ring[0]), int(tb_replay_ring[1]) + 6) at (tb_ring_red_in if _rp_new else tb_none)
            if tb_replay_why:
                frame at (tb_fade_in(0.4) if _rp_new else tb_none):
                    background Solid("#e53935")
                    padding (10, 3, 10, 4)
                    xanchor (1.0 if tb_replay_ring[0] > 900 else 0.0)
                    pos (int(tb_replay_ring[0]) + (-50 if tb_replay_ring[0] > 900 else 50), int(tb_replay_ring[1]) - 52)
                    text tb_replay_why font FONT_JP_B size 18 color "#ffffff"
