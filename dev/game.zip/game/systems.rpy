## systems.rpy ―― ゲームの仕組み（能力値・絆・恋愛パラメータ・カレンダー・トーク画面・行動マップ・ステータス）

################################################################################
## 「1つ戻る」：読み返しはできるが、選んだ答えは変えられない
##   新しい場面が始まるたびに、それまでの場面を「固定」にする（Ren'Py の fixed rollback）。
##   選択肢の場面まで戻ると、選んだ答えだけが押せる。行動マップ・トークの返事も、前と同じ答えで進む。
##   別の答えを試したいときは、セーブ／ロードを使う。
################################################################################
define config.fix_rollback_without_choice = False     # 戻ったとき、選んだ答えだけは押せる（ほかは押せない）

init python:
    def _fix_past_choices():
        ## renpy.fix_rollback() と同じだが、毎回チェックポイントを増やさない
        ## （増やすと、「1つ戻る」が画面の切り替えのたびに止まってしまう）
        for rb in renpy.game.log.log:
            rb.fixed = True
    config.start_interact_callbacks.append(_fix_past_choices)

################################################################################
## パラメータ
################################################################################

define STAT_KEYS = ["技術", "フィジカル", "戦術眼", "メンタル"]
define HIDDEN_KEYS = ["無理ゲージ"]   # 隠しパラメータ。v0.29.13 からステータス画面では数字を出さず、ひざの調子を言葉で出す（knee_state）。「注目度」は有料パートで使い始めるまで出さない
define BOND_KEYS = ["鷹野", "大門", "三好", "坂口", "神城"]   # 坂口は「坂口たち」（ゲーセンの5人組）
define HEROINES = ["ひなた", "千夏", "紗希", "あげは"]   # あげはは第4章（製品版）から。v0.30.0
define HEART_KEYS = ["ときめき", "信頼", "さみしさ"]
define HINATA_TRUST_RATE = 0.7     # ひなたの信頼の上がり幅（heart_up で掛ける）
## v0.32.6：体験版（プロローグ〜第3章。大晦日の選択の前）のあいだの気持ちの上限。有料部分で育てる余地を残す（作者の決定 11/4）
define TRIAL_HEART_CAP = {"ときめき": 60, "信頼": 70}
## v0.32.6：揺れる場面（ハーレムにしない。作者の決定 11/4）。ときめきの上の2人がどちらも SWAY_MIN 以上で、差が SWAY_GAP 以内のときに起こす
define SWAY_MIN = 40
define SWAY_GAP = 10
define SWAY_PICK = 8          # 選んだ人のときめき
define SWAY_LEFT = -6         # 選ばなかった人のときめき（さみしさ +SWAY_LONELY）
define SWAY_LONELY = 8
define SWAY_NONE = -3         # どちらも選ばなかったとき、2人とも
define HEART_CLOSE = -20      # 付き合ったあとに、別の人の告白を断ったとき（そのあと、その人のときめきは上がらない）
define BELIEF_KEYS = ["仲間型", "野心型", "求道型"]

## 能力値（0〜100）
default stats = {"技術": 35, "フィジカル": 25, "戦術眼": 40, "メンタル": 30}

## 隠しパラメータ（0〜100）
default hidden = {"無理ゲージ": 15, "注目度": 5}

## 仲間・ライバルとの絆（0〜100）
default bond = {"鷹野": 0, "大門": 0, "三好": 0, "坂口": 0, "神城": 10}

## ヒロインごとの気持ち（ときめき→恋人ルート／信頼→親友ルート／さみしさ→会わないと溜まる）
default heart = {
    "ひなた": {"ときめき": 10, "信頼": 30, "さみしさ": 0},
    "千夏": {"ときめき": 0, "信頼": 0, "さみしさ": 0},
    "紗希": {"ときめき": 0, "信頼": 0, "さみしさ": 0},
    "あげは": {"ときめき": 0, "信頼": 0, "さみしさ": 0},   # 第4章（製品版）から。v0.30.0
}
## 告白を断ったヒロイン（そのあと、ときめきが上がらない。v0.32.6）
default heart_closed = set()

init python:
    ## あとから足したヒロイン（あげは）を、古いセーブの heart にも足す（v0.30.0）
    def heart_fill():
        for _h in HEROINES:
            store.heart.setdefault(_h, {"ときめき": 0, "信頼": 0, "さみしさ": 0})
    config.after_load_callbacks.append(heart_fill)

## 信念タイプ（選択の傾向。エンディング判定に使う）
##   数字は見せない。ステータス画面に「いまの蓮」として、いちばん強いタイプを言葉で出す（belief_now）
default belief = {"仲間型": 0, "野心型": 0, "求道型": 0}

define BELIEF_WORDS = {
    "仲間型": "仲間を信じて、頼るタイプ。一人で抱えず、みんなで勝とうとする。",
    "野心型": "上だけを見るタイプ。強い相手と高い場所を、自分から取りに行く。",
    "求道型": "自分の道を、黙って突きつめるタイプ。やるべきことを、一人でやりきる。",
}

init python:
    def belief_now():
        """いちばん強い信念タイプの名前と説明。同じくらいなら「まだ決まっていない」"""
        b = store.belief
        top = max(b.values()) if b else 0
        tops = [k for k in BELIEF_KEYS if b.get(k, 0) == top]
        if top <= 0 or len(tops) > 1:
            return "まだ、どのタイプとも言えない", "どの道を選ぶかで、蓮の考え方が少しずつ形になっていく。"
        return tops[0], BELIEF_WORDS[tops[0]]

## 物語のフラグ（例：flags["鷹野_わざと負け"] = True）
default flags = {}

init python:

    def _clamp(v):
        return max(0, min(100, v))

    def _signed(d):
        return ("＋" if d >= 0 else "−") + str(abs(d))

    def up(key, d):
        """能力値か隠しパラメータを増減する。例：$ up("メンタル", 5)"""
        if key in store.stats:
            store.stats[key] = _clamp(store.stats[key] + d)
        elif key in store.hidden:
            store.hidden[key] = _clamp(store.hidden[key] + d)
        else:
            raise Exception("知らないパラメータです: " + key)
        param_toast(key + " " + _signed(d))

    def bond_up(who, d):
        """仲間・ライバルとの絆を増減する。例：$ bond_up("鷹野", 5)"""
        ## 古いセーブには、あとから足した人（坂口）がいないので 0 から数える
        if store.night_boost:
            d *= NIGHT_BOOST      # 夜のトークは回数を減らしたぶん、1回の上がり方を大きく（nightcontact.rpy）
        store.bond[who] = _clamp(store.bond.get(who, 0) + d)
        param_toast(("坂口たち" if who == "坂口" else who) + "の絆 " + _signed(d))

    def heart_up(who, kind, d):
        """ヒロインの気持ちを増減する。例：$ heart_up("ひなた", "信頼", 5)"""
        ## ひなたは幼なじみで、信頼が最初から高く、体験版のうちに上限（100）に届いてしまうので、
        ## 信頼の上がり幅だけ 7割にする（v0.27.0。第3章の終わりで 80 前後になるように）
        if store.night_boost:
            d *= NIGHT_BOOST      # 夜のトークは回数を減らしたぶん、1回の上がり方を大きく（nightcontact.rpy）
        if who == "ひなた" and kind == "信頼" and d > 0:
            d = max(1, int(round(d * HINATA_TRUST_RATE)))
        ## 告白を断った人のときめきは、もう上がらない（v0.32.6）
        if kind == "ときめき" and d > 0 and who in store.heart_closed:
            return
        heart_fill()
        old = store.heart[who][kind]
        new = _clamp(old + d)
        ## 体験版のあいだは上限で止める（上限より上にいるときは下がるだけ）
        cap = TRIAL_HEART_CAP.get(kind) if not getattr(store, "ch3_route", "") else None
        if cap is not None and d > 0:
            new = min(new, max(old, cap))
        d = new - old
        store.heart[who][kind] = new
        if d != 0:
            param_toast(who + "の" + kind + " " + _signed(d))
        ## はじめて「ときめき」か「信頼」が上がったとき、一度だけ意味を説明する（テスターの声：信頼の意味が分からなかった）
        ##   ときめき＝ドキドキする気持ち、信頼＝本音を話せる気持ち。恋人とは、どちらも欠かせない関係
        if d > 0 and kind in ("ときめき", "信頼") and not persistent.heart_guide_seen:
            persistent.heart_guide_seen = True
            renpy.show_screen("heart_guide")

    def sway_pair(names):
        """揺れる場面を起こすか（v0.32.6）。names の中で、ときめきの上の2人がどちらも SWAY_MIN 以上・差が SWAY_GAP 以内なら (上, 下) を返す。起こさないときは None。
        告白を断った人は入れない。例：$ _sw = sway_pair(["ひなた", "千夏", "あげは"])"""
        c = [n for n in names if n in store.heart and n not in store.heart_closed]
        c.sort(key=lambda n: -store.heart[n]["ときめき"])
        if len(c) < 2:
            return None
        a, b = c[0], c[1]
        ta, tb = store.heart[a]["ときめき"], store.heart[b]["ときめき"]
        if tb >= SWAY_MIN and ta - tb <= SWAY_GAP:
            return (a, b)
        return None

    def sway_pick(chosen, left):
        """揺れる場面で選んだ人（chosen）と、選ばなかった人（left）"""
        heart_up(chosen, "ときめき", SWAY_PICK)
        heart_up(left, "ときめき", SWAY_LEFT)
        heart_up(left, "さみしさ", SWAY_LONELY)

    def sway_none(a, b):
        """揺れる場面で、どちらも選ばなかったとき"""
        heart_up(a, "ときめき", SWAY_NONE)
        heart_up(b, "ときめき", SWAY_NONE)

    def heart_close(who):
        """付き合ったあとに、別の人の告白を断ったとき。ときめき −20、そのあとは上がらない（信頼はそのまま）"""
        heart_up(who, "ときめき", HEART_CLOSE)
        store.heart_closed.add(who)

    def lean(kind, d=1):
        """信念タイプの傾向を加算する。例：$ lean("仲間型")"""
        store.belief[kind] += d
        ## v0.29.3：「○○型の傾向 +1」の通知は出さない（数字だけでは意味が分からない、という作者の声）。
        ##   ステータス画面の「いまの蓮」に、いちばん強いタイプを言葉で出す

    def set_flag(name, value=True):
        store.flags[name] = value

    def check_bond(who, need):
        """仲間との絆の判定。右上に「鷹野の絆 22／必要 20　成功」と出す"""
        v = store.bond.get(who, 0)
        ok = v >= need
        toast("%sの絆 %d／必要 %d　%s" % ("坂口たち" if who == "坂口" else who, v, need, "成功" if ok else "失敗"))
        telop_sound()
        return ok

    def bond_level(who, hi, top):
        """仲間との絆の3段階（v0.29.13・テスターT7の声）。運は入れない（絆の数字だけで決まる）。
        top 以上＝2（最高）／hi 以上＝1（高い）／それより下＝0（ふつう）。
        右上に「鷹野の絆 38／高い 30・最高 45　高い」と出す。例：$ _lv = bond_level("鷹野", 30, 45)"""
        v = store.bond.get(who, 0)
        lv = 2 if v >= top else (1 if v >= hi else 0)
        toast("%sの絆 %d／高い %d・最高 %d　%s" % ("坂口たち" if who == "坂口" else who, v, hi, top, ("ふつう", "高い", "最高")[lv]))
        telop_sound()
        return lv

    def check(key, need):
        """能力の判定。能力値が need 以上なら成功（True）。右上に「技術 47／必要 45　成功」と出す。
        例：if check("戦術眼", 50): …"""
        v = store.stats.get(key, store.hidden.get(key, 0))
        ok = v >= need
        toast("%s %d／必要 %d　%s" % (key, v, need, "成功" if ok else "失敗"))
        telop_sound()
        return ok


################################################################################
## 画面右上の小さな通知（能力値の変化・仮の演出メモ）
################################################################################

default toast_list = []

init python:

    def toast(msg):
        lst = list(store.toast_list) + [msg]
        store.toast_list = lst[-6:]
        ## 一度消してから出し直して、表示時間のカウントをやり直す
        renpy.hide_screen("toasts")
        renpy.show_screen("toasts")

    def clear_toasts():
        store.toast_list = []

    def param_toast(msg):
        if persistent.show_param_notify:
            toast(msg)
            telop_sound()

    ## BGM と効果音の bgm() / se() は audio.rpy にある

screen toasts():
    zorder 150
    vbox:
        xalign 1.0
        xoffset -12
        ypos 100    # 右上のメニューボタンの下に出す
        spacing 0
        for t in toast_list:
            frame:
                style "toast_frame"
                text t style "toast_text"
    timer 3.2 action [Function(clear_toasts), Hide("toasts")]

## 選択肢のヒント（設定でオンにしたときだけ）：選択肢の下に「何が上がるか」と「判定に使う能力」を出す。
##   表は tools/make_branch_map.py が作る game/choice_hints.rpy の CHOICE_HINTS。上がるものは↑↓だけ。
##   判定は、必要な数値といまの数値を出す（v0.29.13・テスターの「どれくらい要るか知りたい」）
default persistent.choice_hints = None      # 何が上がるか：None＝まだ聞いていない（出さない）／False／True
default persistent.judge_hints = True       # 試合の判定（必要な能力と数値）：最初から出す。設定で消せる（v0.29.13）
default hint_demo = False                   # プロローグのあいだだけ「何が上がるか」を見せる（まだ決めていない人。script.rpy）

init python:
    import re as _hre, os as _hos

    def _hint_norm(s):
        ## 練習の重点の選択肢（practice.rpy）は「★」と、小さい字の数値の部分を除いて引く
        s = s.split("{size=-6}")[0].replace("★ ", "")
        s = _hre.sub(r"\{rb\}(.*?)\{/rb\}\{rt\}.*?\{/rt\}", r"\1", s)
        s = _hre.sub(r"\{[^}]*\}", "", s)
        return _hre.sub(r"[\s\u3000]", "", s)

    def choice_hint(caption):
        """選択肢の文から、ヒントの一行を返す（オフのときや、何も変わらない選択肢は空）
        v0.29.13：「何が上がるか」（persistent.choice_hints。プロローグの見本 hint_demo のあいだも出す）と、
        「試合の判定」（persistent.judge_hints）を別々に切りかえる"""
        show_ups = bool(persistent.choice_hints) or (persistent.choice_hints is None and store.hint_demo)
        show_chk = bool(persistent.judge_hints)
        if not (show_ups or show_chk):
            return ""
        lst = CHOICE_HINTS.get(_hint_norm(caption))
        if not lst:
            return ""
        try:
            fn, ln = renpy.get_filename_line()
            fn = _hos.path.basename(fn)
        except Exception:
            fn, ln = "", 0
        best = min(lst, key=lambda e: (e[0] != fn, abs(e[1] - ln)))
        return "　".join(x for x in (best[2] if show_ups else "", _hint_checks(best[3]) if show_chk else "") if x)

    def _hint_need(expr):
        ## 判定の数値は、式のこともある（例：54 if ch3_knee_plan == "half" else 57）。その場で計算する
        try:
            return int(renpy.python.py_eval(expr))
        except Exception:
            return None

    def _hint_checks(chks):
        """判定の一行（v0.29.13・テスターT4・T7の声）。必要な数値と、いまの数値を出す。
        例：判定：技術 57以上（いま 52）／判定：鷹野の絆 高い30・最高45（いま 38）"""
        if not chks:
            return ""
        if isinstance(chks, str):
            return chks
        parts = []
        for disp, kind, key, need, top in chks:
            cur = store.stats.get(key, 0) if kind == "stat" else store.bond.get(key, 0)
            n = _hint_need(need)
            t = _hint_need(top) if top else None
            if n is None:
                parts.append(disp)
            elif t is not None:
                parts.append("%s 高い%d・最高%d（いま %d）" % (disp, n, t, cur))
            else:
                parts.append("%s %d以上（いま %d）" % (disp, n, cur))
        return "判定：" + "・".join(parts)

## はじめて気持ちが動いたときの説明（一度だけ。タップか、しばらくたつと消える）
default persistent.heart_guide_seen = False

screen heart_guide():
    zorder 151
    button:
        style "heart_guide_frame"
        action Hide("heart_guide")
        vbox:
            spacing 6
            text "ヒロインの気持ちが動きました" style "heart_guide_title"
            text "{color=#e0708a}ときめき{/color}　ドキドキする気持ち" style "heart_guide_text"
            text "{color=#2f6f76}信頼{/color}　　　本音を話せる気持ち" style "heart_guide_text"
            text "恋人とは、ときめきも信頼も、どちらも欠かせない関係です。\nふたつをどう育てるかで、結末が変わります。\n今の気持ちは、メニューの「相関図」で確かめられます。" style "heart_guide_small"
    timer 12.0 action Hide("heart_guide")

style heart_guide_frame:
    background Frame("gui/note_small.png", 14, 14)
    padding (30, 20, 34, 26)
    xalign 0.5
    ypos 70
    xmaximum 760

style heart_guide_title:
    size 22
    color INK
    font FONT_JP_B

style heart_guide_text:
    size 21
    color INK

style heart_guide_small:
    size 17
    color INK
    line_spacing 4

style heart_guide_title:
    variant "small"
    size 28
style heart_guide_text:
    variant "small"
    size 27
style heart_guide_small:
    variant "small"
    size 22

## 小さな付箋
style toast_frame:
    background Frame("gui/note_small.png", 14, 14)
    padding (22, 12, 26, 18)
    xalign 1.0

style toast_text:
    size 17
    color INK


################################################################################
## カレンダー表示（画面左上）
################################################################################

default cal_date = ""
default cal_time = ""
## 西暦（プロローグの中3の冬が2025年。章の始まりで決め直す。年をまたぐと set_cal が1つ進める）
default cal_year = 2025
define CHAPTER_YEAR = {"prologue": 2025, "chapter1": 2026, "chapter2": 2026, "chapter3": 2026, "chapter4a": 2027}

init python:
    def _cal_year_by_chapter(name, abnormal):
        if name in CHAPTER_YEAR:
            store.cal_year = CHAPTER_YEAR[name]
    config.label_callbacks.append(_cal_year_by_chapter)

init python:

    def set_cal(date, time="", quiet=False):
        """日付の表示を変える。例：$ set_cal("4月14日（火）", "放課後")
          ・日付が変わったときは、画面のまん中に大きく出してから、左上に小さく残す
          ・同じ日のうちに時間だけ変わったときは、左上の小さい表示だけ変える
          ・quiet=True のときは何も出さない（真面目な場面・大事な場面は雰囲気を優先）"""
        changed = bool(date) and date != store.cal_date
        old_date = store.cal_date
        ## v0.30.0：ふりがなは「日が変わるたびに」最初の1回だけ出す（前は章ごとに1回。配信で読み方が分からなくなっていたため）
        if changed:
            store.ruby_seen = set()
        ## 年をまたいだら（12月→1月など）、西暦を1つ進める
        _mo, _mn = _month_of(old_date), _month_of(date)
        if _mo and _mn and _mo - _mn >= 6:
            store.cal_year += 1
        store.cal_date = date
        store.cal_time = time
        _m = _month_of(date)
        if _m:
            store.outfit = "summer" if 6 <= _m <= 9 else "winter"
        store.cal_quiet = quiet
        delta = _days_between(old_date, date) if changed else None
        if changed and not quiet and delta is not None and delta > 0:
            ## 日付が進むときは、何日でも月のカレンダー表で見せる（過ぎた日に赤ペンの×、新しい日に○）
            ##   予定は「知った日」から先に書いてあり、知らなかった出来事は、その日が来てから書きこまれる（cal_event）
            _window_hide(None, auto=True)
            renpy.scene()
            renpy.show("black")
            renpy.with_statement(Dissolve(0.4))
            store.cal_card = True
            segs = _cal_segments(old_date, date, delta)
            for i, seg in enumerate(segs):
                last = (i == len(segs) - 1)
                renpy.show_screen("cal_month", seg, (date + "　" + time) if last else "")
                renpy.with_statement(Dissolve(0.25))
                renpy.sound.play("audio/se/telop.ogg", channel="ui")
                renpy.pause(seg["dur"] + (1.2 if last else 0.35), hard=False)
                renpy.hide_screen("cal_month")
                renpy.with_statement(Dissolve(0.25))
            store.cal_card = False
            return
        if changed and not quiet:
            ## 前の日付がない（ゲームの最初）・日付が戻るときだけ、まん中に大きな付箋で日付を出す
            _window_hide(None, auto=True)      # 「window auto hide」と同じ（自動でセリフ枠を出す設定は残す）
            renpy.scene()
            renpy.show("black")
            renpy.with_statement(Dissolve(0.4))
            store.cal_card = True
            renpy.show_screen("date_card", date, time)
            telop_sound()
            renpy.pause(2.0, hard=False)
            renpy.hide_screen("date_card")
            store.cal_card = False

default cal_quiet = False
default cal_card = False

init -1 python:
    import re as _cal_re
    _CAL_DATE_RE = _cal_re.compile(r"(\d+)月(\d+)日")
    _CAL_MDAYS = [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31]
    _CAL_WD = "月火水木金土日"

    def coat_on():
        """12〜2月の外の場面で、コート・マフラーの立ち絵にする（次の set_cal で元にもどる）"""
        if store.outfit == "winter":
            store.outfit = "coat"

    def _month_of(date):
        m = _CAL_DATE_RE.search(date or "")
        return int(m.group(1)) if m else None

    def _doy(date):
        m = _CAL_DATE_RE.search(date or "")
        if not m:
            return None
        return sum(_CAL_MDAYS[:int(m.group(1)) - 1]) + int(m.group(2))

    def _days_between(a, b):
        """a から b まで何日たったか（12月→1月のように年をまたぐときも数える）"""
        x, y = _doy(a), _doy(b)
        if x is None or y is None:
            return None
        d = y - x
        if d < -180:
            d += 365
        return d

    def _gap_words(delta):
        if delta >= 46:
            return "―― ふた月後"
        if delta >= 28:
            return "―― ひと月後"
        if delta >= 14:
            return "―― %d週間後" % (delta // 7)
        return ""

    def _md_of_doy(n):
        n = (n - 1) % 365 + 1
        for i, md in enumerate(_CAL_MDAYS):
            if n <= md:
                return i + 1, n
            n -= md
        return 12, 31

    def _flip_pages(old, new):
        """日めくりの紙（月, 日, 曜日）を、古い日から新しい日まで最大6枚"""
        y = _doy(new)
        wd_new = _CAL_WD.find(new[new.find("（") + 1]) if "（" in new else -1
        d = _days_between(old, new) or 0
        steps = sorted(set([0] + [int(d * k / 5) for k in range(1, 5)] + [d]))
        pages = []
        for st in steps:
            mo, da = _md_of_doy(y - d + st)
            wd = _CAL_WD[(wd_new - (d - st)) % 7] if wd_new >= 0 else ""
            pages.append((mo, da, wd))
        return pages

    def _wd_of(date):
        """「6月1日（月）」の曜日を、月=0〜日=6 の数で返す（書いていなければ None）"""
        if "（" in (date or ""):
            i = _CAL_WD.find(date[date.find("（") + 1])
            return i if i >= 0 else None
        return None

    def _cal_segments(old, new, delta):
        """月のカレンダー（1か月ぶん）を、古い月から新しい月まで並べる。
          pre：最初から×がついている日（それより前の日）、a〜b：順番に×をつける日、circle：○をつける日"""
        mo0, d0 = _md_of_doy(_doy(old))
        mo1, d1 = _md_of_doy(_doy(new))
        wd1 = _wd_of(new)
        if wd1 is None:
            wd1 = 0
        ## 新しい日の曜日から、古い日の曜日を逆算する
        wd0 = (wd1 - delta) % 7
        segs = []
        ## 新しい日の年から、古い月の年を逆算する（12月→1月をまたぐときは古い月が1年前）
        yr = store.cal_year - (1 if mo1 < mo0 else 0)
        mo, fw = mo0, (wd0 - (d0 - 1)) % 7
        while True:
            nd = _CAL_MDAYS[mo - 1]
            first = (mo == mo0 and not segs)
            lastm = (mo == mo1) and (not first or delta < 40)
            seg = {"mo": mo, "fw": fw, "nd": nd, "pre": 0, "a": 1, "b": nd, "circle": None, "year": yr}
            if first:
                seg["pre"] = d0 - 1
                seg["a"] = d0
            if lastm:
                seg["b"] = d1 - 1
                seg["circle"] = d1
            n = max(0, seg["b"] - seg["a"] + 1)
            seg["step"] = min(0.09, 0.9 / max(n, 1))
            seg["dur"] = n * seg["step"] + (0.45 if seg["circle"] else 0.1)
            segs.append(seg)
            if lastm or len(segs) >= 4:
                break
            fw = (fw + nd) % 7
            if mo == 12:
                yr += 1
            mo = mo % 12 + 1
        return segs

    ## 予定（月のカレンダー表で、その日のマスに大きく書く。日付は小さく。試合は赤、そのほかは青緑）
    ##   (年, 月, 日): (書く言葉, 試合か, 知る日)
    ##   知る日：True ＝ はじめから知っている（行事・休みなど）
    ##           (年, 月, 日) ＝ その日から先は書いてある（本文で蓮が予定を知った日）
    ##           None ＝ 前もって知らない出来事。その日が来てから書きこまれる
    CAL_SCHEDULE = {
        (2025, 12, 14): ("県大会決勝", True, True),
        (2026, 3, 19): ("合格発表", False, True),
        (2026, 4, 8): ("入学式", False, True),
        (2026, 5, 20): ("登録締切", False, (2026, 4, 10)),      # 4/9 生徒会室で千夏から
        (2026, 5, 31): ("練習試合", True, (2026, 5, 21)),       # 5/20 黒田の発表（見せ場の前に見えないよう、次の日から）
        (2026, 6, 27): ("インハイ", True, (2026, 6, 2)),        # 6/1 黒田「1回戦は27日の土曜だ」
        (2026, 7, 4): ("2回戦", True, (2026, 6, 28)),          # 1回戦に勝った次の日から
        (2026, 7, 27): ("夏合宿", False, (2026, 7, 5)),         # 7/4 黒田「27日から、泊まりこみで3日」
        (2026, 7, 28): ("夏合宿", False, (2026, 7, 5)),
        (2026, 7, 29): ("夏合宿", False, (2026, 7, 5)),
        (2026, 8, 15): ("花火大会", False, (2026, 8, 5)),       # 8月の自由行動の説明で知る
        (2026, 9, 7): ("組合せ発表", False, (2026, 9, 3)),      # 9/2 神城「7日に組み合わせが出るな」
        (2026, 9, 19): ("練習試合", True, None),               # 前もって知らされない
        (2026, 9, 28): ("登録締切", False, (2026, 9, 25)),      # 9/24 生徒会室で千夏から
        (2026, 10, 10): ("選手権", True, (2026, 9, 8)),        # 9/7 組み合わせ表
        (2026, 10, 11): ("2回戦", True, (2026, 10, 11)),
        (2026, 10, 17): ("3回戦", True, (2026, 10, 12)),
        (2026, 10, 31): ("準々決勝", True, (2026, 10, 18)),
        (2026, 11, 14): ("準決勝", True, (2026, 11, 1)),
        (2026, 12, 21): ("終業式", False, True),
        (2026, 12, 24): ("クリスマス", False, True),
        (2026, 12, 31): ("大晦日", False, True),
        ## 第4章（ルートA・2027年）。v0.29.9：第4章にもカレンダーの予定を入れた
        (2027, 1, 1): ("元日", False, True),
        (2027, 2, 13): ("送別旅行", False, (2027, 2, 12)),      # 2/12 坂口たちの計画（三好先輩の送別旅行・1泊2日）
        (2027, 2, 14): ("送別旅行", False, (2027, 2, 12)),
        (2027, 3, 1): ("卒業式", False, True),
        (2027, 4, 7): ("入学式", False, True),
        (2027, 4, 15): ("入部締切", False, (2027, 4, 8)),        # 4/7 黒田「入部届の締め切りは、15日だ」
        (2027, 4, 19): ("県の会議", False, True),               # 第3章の12月に千夏から（統合が決まる会議）
        (2027, 5, 20): ("登録締切", False, (2027, 4, 8)),        # 4/7 黒田「登録の締め切りは、5月20日だ」（v0.31.1：第1章と同じ日にそろえた）
        (2027, 6, 12): ("練習試合", True, None),
        (2027, 6, 26): ("インハイ", True, (2027, 4, 8)),         # 4/7 黒田「1回戦は、6月26日だ」
        (2027, 7, 3): ("2回戦", True, (2027, 6, 27)),          # 1回戦に勝った次の日から
        (2027, 7, 4): ("3回戦", True, (2027, 6, 27)),
        (2027, 7, 10): ("準々決勝", True, (2027, 7, 5)),
        (2027, 7, 11): ("準決勝", True, (2027, 7, 11)),
        (2027, 7, 19): ("海の日", False, True),
        (2027, 7, 20): ("終業式", False, True),
        (2027, 8, 2): ("夏合宿", False, (2027, 7, 12)),
        (2027, 8, 3): ("夏合宿", False, (2027, 7, 12)),
        (2027, 8, 4): ("夏合宿", False, (2027, 7, 12)),
        (2027, 8, 15): ("夏祭り", False, True),
        (2027, 8, 30): ("検診", False, (2027, 8, 1)),
    }

    def _cal_ord(y, m, d):
        return y * 400 + sum(_CAL_MDAYS[:m - 1]) + d

    def cal_now_ord():
        m = _CAL_DATE_RE.search(store.cal_date or "")
        if not m:
            return 0
        return _cal_ord(store.cal_year, int(m.group(1)), int(m.group(2)))

    def cal_event(y, mo, d):
        """その日のマスに書く予定。まだ知らない予定は None"""
        ev = CAL_SCHEDULE.get((y, mo, d))
        if not ev:
            return None
        label, match, known = ev
        now = cal_now_ord()
        if known is True:
            return (label, match)
        if known is None:
            return (label, match) if _cal_ord(y, mo, d) <= now else None
        return (label, match) if now >= _cal_ord(*known) else None

    ## 大会までの残り日数（日付の横に出す）。カレンダーの予定と同じく、まだ知らない予定は出さない
    CAL_EVENTS = [
        ((2026, 5, 31), "桜嶺Bとの練習試合"),
        ((2026, 6, 27), "インターハイ予選"),
        ((2026, 10, 10), "選手権予選"),
        ((2026, 10, 31), "準々決勝"),
        ((2026, 11, 14), "桜嶺戦"),
        ((2027, 4, 15), "入部届の締め切り"),
        ((2027, 6, 26), "インターハイ予選"),
        ((2027, 7, 11), "準決勝"),
    ]

    def cal_countdown():
        now = cal_now_ord()
        if not now:
            return ""
        best = None
        for (y, m, d), name in CAL_EVENTS:
            if not cal_event(y, m, d):
                continue
            n = _cal_ord(y, m, d) - now
            if 1 <= n <= 14 and (best is None or n < best[0]):
                best = (n, name)
        if best:
            return "%sまで　あと%d日" % (best[1], best[0])
        return ""

## 日がとんだとき：「―― 3週間後」
screen time_gap(words):
    zorder 56
    text words at time_gap_in:
        xalign 0.5
        yalign 0.45
        font FONT_JP_B
        size 52
        color "#f2ead8"

transform time_gap_in:
    on show:
        alpha 0.0 xoffset -30
        easeout 0.5 alpha 1.0 xoffset 0
    on hide:
        easein 0.3 alpha 0.0

## 日めくりカレンダー：古い日から順にめくれて、新しい日で止まる
screen cal_flip(pages, time=""):
    zorder 55
    fixed at date_card_in:
        xysize (380, 470)
        xalign 0.5
        yalign 0.44
        ## いちばん下：新しい日
        use cal_page(pages[-1])
        ## その上に、古い日ほど上に重ねて、順番に飛ばす
        for i in range(len(pages) - 2, -1, -1):
            fixed at cal_tear(0.5 + 0.16 * i):
                use cal_page(pages[i])
    if time:
        text time:
            xalign 0.5
            ypos 610
            font FONT_JP_B
            size 30
            color "#f2ead8"

## 日が大きくとんだとき：月のカレンダー表。過ぎた日に赤ペンの×、新しい日に○
screen cal_month(seg, time=""):
    zorder 55
    fixed at date_card_in:
        xysize (740, 560)
        xalign 0.5
        yalign 0.42
        add Solid("#00000040") xysize (740, 560) xoffset 8 yoffset 10
        add Solid("#fbf6ea") xysize (740, 560)
        add Solid(PEN_RED) xysize (740, 80)
        text "%d月" % seg["mo"] xalign 0.5 ypos 10 font FONT_JP_B size 46 color "#fff6ee"
        text "%d年" % seg["year"] xpos 28 ypos 28 font FONT_JP_B size 24 color "#fff6ee"
        ## 上のとじ目
        for x in (120, 290, 450, 620):
            add Solid("#3c2d23") xysize (10, 22) xpos x - 5 ypos -10
        for i in range(7):
            text _CAL_WD[i]:
                xpos 30 + i * 98 + 49
                xanchor 0.5
                ypos 92
                font FONT_JP_B
                size 22
                color (PEN_RED if i == 6 else INK_SOFT)
        for d in range(1, seg["nd"] + 1):
            $ _c = seg["fw"] + d - 1
            $ _cx = 30 + (_c % 7) * 98 + 49
            $ _cy = 128 + (_c // 7) * 70
            $ _ev = cal_event(seg["year"], seg["mo"], d)
            if _ev:
                ## 予定のある日：予定を大きく、日付は左上に小さく（試合は赤、そのほかは青緑のマーカー）
                add Solid("#cd464633" if _ev[1] else "#2f6f7633") xysize (94, 66) xpos _cx - 47 ypos _cy
                text str(d):
                    xpos _cx - 43
                    ypos _cy + 1
                    font FONT_JP_B
                    size 15
                    color (PEN_RED if _c % 7 == 6 else INK_SOFT)
                text _ev[0]:
                    xpos _cx
                    xanchor 0.5
                    ypos _cy + 22
                    font FONT_JP_B
                    size (18 if len(_ev[0]) >= 5 else (21 if len(_ev[0]) == 4 else 24))
                    color (PEN_RED if _ev[1] else PEN_TEAL)
                    outlines [(2, "#fbf6ea", 0, 0)]
            else:
                text str(d):
                    xpos _cx
                    xanchor 0.5
                    ypos _cy + 10
                    font FONT_JP_B
                    size 30
                    color (PEN_RED if _c % 7 == 6 else INK)
            ## 予定のある日の×は、予定の文字が読めるように、うすく小さくする
            if d <= seg["pre"]:
                add "gui/cal_x.png" xpos _cx ypos _cy + 32 xanchor 0.5 yanchor 0.5 zoom 0.8 alpha (0.25 if _ev else 0.5)
            elif seg["a"] <= d <= seg["b"]:
                add "gui/cal_x.png" at cal_mark(seg["step"] * (d - seg["a"]), (0.45 if _ev else 1.0), (0.75 if _ev else 1.0)) xpos _cx ypos _cy + 32 xanchor 0.5 yanchor 0.5
            if seg["circle"] == d:
                add "gui/cal_o.png" at cal_circle(seg["dur"] - 0.3) xpos _cx ypos _cy + 30 xanchor 0.5 yanchor 0.5
    if seg["circle"]:
        timer max(0.05, seg["dur"] - 0.3) action Function(renpy.sound.play, "audio/se/advance.ogg", channel="ui_text")
    if time:
        text time:
            xalign 0.5
            ypos 655
            font FONT_JP_B
            size 30
            color "#f2ead8"

transform cal_mark(d=0.0, a=1.0, z=1.0):
    alpha 0.0 zoom 1.6 * z
    pause d
    easein 0.1 alpha a zoom z

transform cal_circle(d=0.0):
    alpha 0.0 zoom 1.35
    pause d
    easein 0.2 alpha 1.0 zoom 1.0

screen cal_page(pg):
    fixed:
        xysize (380, 470)
        add Solid("#00000040") xysize (380, 470) xoffset 8 yoffset 10
        add Solid("#fbf6ea") xysize (380, 470)
        add Solid(PEN_RED) xysize (380, 92)
        text "%d月" % pg[0] xalign 0.5 ypos 14 font FONT_JP_B size 50 color "#fff6ee"
        text "%d" % pg[1] xalign 0.5 ypos 104 font FONT_JP_B size 210 color (PEN_RED if pg[2] in ("日",) else INK)
        if pg[2]:
            text "%s曜日" % pg[2] xalign 0.5 ypos 384 font FONT_JP_B size 34 color INK_SOFT
        ## 上のとじ目
        for x in (60, 150, 230, 320):
            add Solid("#3c2d23") xysize (10, 22) xpos x - 5 ypos -10

transform cal_tear(d=0.5):
    pause d
    easein 0.28 yoffset -320 xoffset 170 rotate 22 alpha 0.0

## 日付が変わったとき：まん中に大きな付箋を貼って、少ししたらはがす
screen date_card(date, time=""):
    zorder 55
    fixed at date_card_in:
        xysize (560, 270)
        xalign 0.5
        yalign 0.42
        add "gui/note_calendar.png" zoom 2.06
        text "%d年" % cal_year style "card_year"
        text date style "card_date"
        if time:
            text time style "card_time"

transform date_card_in:
    on show:
        alpha 0.0 rotate -6 zoom 1.08
        easeout 0.35 alpha 1.0 rotate -3 zoom 1.0
    on hide:
        easein 0.4 alpha 0.0 zoom 0.96

style card_date:
    xalign 0.5
    xoffset -6
    ypos 78
    font FONT_JP_B
    size 54
    color INK

style card_year:
    xalign 0.5
    xoffset -6
    ypos 44
    font FONT_JP_B
    size 24
    color "#8c735f"

style card_time:
    xalign 0.5
    xoffset -6
    ypos 164
    size 30
    color "#6e5a3c"

## ふだんは、画面の左上に小さく、うすく出しておく
screen calendar_hud():
    zorder 50
    ## 試合中（スコアボードが出ているとき）は、スコアボードと重ならないように出さない
    if cal_date and not cal_quiet and not cal_card and not renpy.get_screen("scoreboard"):
        frame at hud_fade:
            style "hud_tape"
            hbox:
                spacing 12
                text "%d年" % cal_year style "hud_year"
                text cal_date style "hud_date"
                if cal_time:
                    text cal_time style "hud_time"
                $ _cd = cal_countdown()
                if _cd:
                    text _cd style "hud_count"

style hud_tape is frame:
    xpos 14
    ypos 12
    background Frame("gui/banner_tape.png", 20, 10)
    padding (18, 4, 20, 7)

transform hud_fade:
    alpha 0.82

style hud_date:
    font FONT_JP_B
    size 19
    color INK
    yalign 0.5

style hud_year:
    size 15
    color "#6e5a3c"
    yalign 0.5
    xalign 0.0

style hud_time:
    size 17
    color "#6e5a3c"
    yalign 0.5

style hud_count:
    font FONT_JP_B
    size 16
    color PEN_RED
    yalign 0.5


################################################################################
## 章タイトル（ノートの1ページに書く）
################################################################################

screen title_card(main, sub=""):
    zorder 60
    add "gui/page.png"
    vbox:
        xalign 0.5
        yalign 0.46
        spacing 22
        text main font FONT_JP_B size 54 xalign 0.5 color INK
        if sub:
            text sub size 32 xalign 0.5 color PEN_RED

define flash = Fade(0.08, 0.0, 0.6, color="#ffffff")


################################################################################
## トークアプリ（LINE風）
##   アプリ名は架空。製品版ではロゴ・色もオリジナルにする。
################################################################################

define TALK_APP_NAME = "TALQ"

## アイコン（gui/talk/avatar/ の画像名）。立ち絵がない人は、汎用のアイコンにする
define TALK_AVATAR = {
    "ひなた": "hinata", "千夏": "chika_sky", "紗希": "saki", "三好": "miyoshi", "大門": "daimon",
    "鷹野": "takano", "坂口": "sakaguchi", "黒田": "kuroda", "母": "mother", "神城": "kamishiro",
    "森": "mori", "小池": "koike", "江藤": "eto", "野口": "noguchi",
    "桐生": "kiryu", "宮下": "miyashita",
    "あげは": "ageha",
}

default talk_title = ""
default talk_log = []
default talk_group = False
default talk_avatar = "gui/talk/avatar/flower.png"
default talk_date = ""
default talk_minutes = 0
default talk_now = -1
default talk_last = ("", 0)      # 最後に閉じたトークの (日付, 時刻の分)

init python:

    def talk_icon(name):
        """名前からアイコンの画像を決める（「神城 凌」のような書き方でも見つける）。"""
        for k, v in TALK_AVATAR.items():
            if name.startswith(k):
                return "gui/talk/avatar/%s.png" % v
        return "gui/talk/avatar/flower.png"

    def _talk_clock():
        m = store.talk_minutes
        return "%d:%02d" % ((m // 60) % 24, m % 60)

    def _talk_unlift():
        """トークの文や選択肢に戻るとき：地の文の枠を消して、スマホを元の高さに戻す"""
        if store.talk_lift:
            store.talk_lift = False
        try:
            _window_hide(None, auto=True)
        except Exception:
            pass

    def _talk_say_cb(event, interact=True, **kwargs):
        ## トーク画面が出ているあいだに地の文やセリフが出たら、スマホを上へずらす
        if event == "begin" and renpy.get_screen("talk_view") and not store.talk_lift:
            store.talk_lift = True

    config.all_character_callbacks.append(_talk_say_cb)

    def talk_wait(minutes):
        """トークの時計を進める（既読がついてから何分、など）。"""
        store.talk_minutes += int(minutes)

    def _talk_add(entry):
        _talk_unlift()
        log = store.talk_log
        prev = log[-1] if log else None
        ## 同じ人が続けて送ったときは、アイコンと名前を省く
        entry["cont"] = bool(prev and prev["kind"] == entry["kind"] and prev.get("who") == entry.get("who"))
        entry["time"] = _talk_clock()
        store.talk_minutes += 1 if len(log) % 2 else 0
        store.talk_log = log + [entry]
        ## ログ（バックログ）にも残す。トークの文は「トーク」の印を付ける
        if entry["kind"] in ("them", "me"):
            try:
                narrator.add_history("adv", ("蓮" if entry["kind"] == "me" else entry["who"]) + "（トーク）", entry["text"])
            except Exception:
                pass
        _talk_refresh()

    def _talk_refresh():
        ## 一度消してから出し直すことで、いちばん下の新しいメッセージまでスクロールさせる
        renpy.hide_screen("talk_view")
        renpy.show_screen("talk_view")

    def talk_start(title, clock="21:00"):
        """トーク画面を開く。例：$ talk_start("港北サッカー部（12）", "20:41")
        「（人数）」が付いている名前はグループのトークとして、名前を出す。"""
        store.talk_lift = False
        store.talk_title = title
        store.talk_log = []
        store.talk_group = "（" in title
        store.talk_avatar = "gui/talk/avatar/group.png" if store.talk_group else talk_icon(title)
        store.talk_date = store.cal_date
        h, m = clock.split(":")
        store.talk_minutes = int(h) * 60 + int(m)
        ## 同じ夜に前のトークがあれば、それより前の時刻にならないように少しあとへずらす（時刻が戻って見えないように）
        if store.talk_last[0] == store.cal_date and store.talk_minutes <= store.talk_last[1]:
            store.talk_minutes = store.talk_last[1] + 3
        store.talk_now = -1
        _talk_refresh()
        renpy.with_statement(dissolve)
        ## 相手から届く夜（nightcontact.rpy）：いつもの話の前に、相手の一言を先に出す
        if store.night_incoming and not store.talk_group and (title.startswith(store.night_incoming) or (store.night_incoming == "紗希" and title == store.saki_call)):
            _who = store.night_incoming
            store.night_incoming = ""
            talk(_who, NIGHT_INCOMING_OPEN.get(_who, "起きてる？"))
        ## 千夏との最初のトーク（6/1の夜。蓮がメモのIDを追加し忘れていて、千夏からは連絡できなかった）は、chapter2.rpy の ch2_chika_videocall で書いている

    def _talk_mark_read():
        """まだ既読のついていない自分のメッセージに、既読をつける（v0.32.2）"""
        changed = False
        log = []
        for m in store.talk_log:
            if m["kind"] == "me" and m.get("read") == "":
                m = dict(m)
                m["read"] = "既読"
                changed = True
            log.append(m)
        if changed:
            store.talk_log = log

    def talk(who, text):
        """相手からのメッセージ（クリックで次へ）。例：$ talk("ひなた", "ひざ、大丈夫？")"""
        _talk_mark_read()
        _talk_add({"kind": "them", "who": who, "text": text})
        renpy.pause()

    def talk_me(text, read=None):
        """自分（蓮）のメッセージ。
        v0.32.2（作者の声）：自分から送ってすぐ既読がつくのは本物らしくないので、ふつうは既読をつけずに出し、
        相手が返事をしたとき（か、talk_system("既読…") のとき）に既読がつく。すぐ既読にしたいときは read="既読"。"""
        _talk_add({"kind": "me", "who": "", "text": text, "read": ("" if read is None else read)})
        renpy.pause()

    def talk_system(text):
        """画面の真ん中に出る小さな案内（既読がついた、など）。
        「既読がついてから、7分」「3分後」のように時間がたつ文や、「ビデオ通話が終了しました（5:12）」は、
        そのぶんトークの時計も進める（あとのメッセージの時刻がずれないように）。"""
        import re as _re
        m = _re.search(r"(\d+)分", text)
        if m and ("から" in text or "後" in text or "たって" in text):
            talk_wait(int(m.group(1)))
        m = _re.search(r"（(\d+):(\d\d)）", text)
        if m:
            talk_wait(int(m.group(1)) + (1 if int(m.group(2)) >= 30 else 0))
        if text.startswith("既読"):
            _talk_mark_read()
            if text == "既読":
                ## 「既読」だけの札は出さず、吹き出しの横に既読がつくのを見せる
                _talk_refresh()
                renpy.pause(0.6)
                return
        _talk_add({"kind": "system", "who": "", "text": text})
        renpy.pause()

    def talk_typing(who, times=1, show=1.1, gap=0.7):
        """相手の「入力中」の表示を出しては消す（打っては消している、を見せる。v0.31.0）。
        例：$ talk_typing("ひなた", 3)　クリックすると早送りになる"""
        _talk_mark_read()
        for _i in range(int(times)):
            store.talk_log = store.talk_log + [{"kind": "typing", "who": who, "text": "入力中…", "cont": False, "time": ""}]
            _talk_refresh()
            renpy.pause(show)
            store.talk_log = [m for m in store.talk_log if m["kind"] != "typing"]
            _talk_refresh()
            renpy.pause(gap)

    def talk_day(date, clock):
        """日付の区切りを出して、時計をその日のその時刻にする（前の日に届いていたメッセージを見せるとき）。
        例：$ talk_day("5月21日（木）", "18:12")"""
        if not store.talk_log:
            store.talk_date = ""          # いちばん上の今日の日付は出さず、区切りで見せる
            store.talk_now = store.talk_minutes   # ステータスバーは、いま（開いた時刻）のままにする
        h, mm = clock.split(":")
        store.talk_minutes = int(h) * 60 + int(mm)
        _talk_add({"kind": "system", "who": "", "text": date})

    def talk_stamp(who, stamp):
        """スタンプを送る（v0.32.2）。who が "蓮" なら自分から。stamp は gui/talk/stamp/ の画像名。
        例：$ talk_stamp("ひなた", "dog_angry")"""
        if who in ("蓮", "me", ""):
            _talk_add({"kind": "me", "who": "", "text": "", "stamp": stamp, "read": ""})
        else:
            _talk_mark_read()
            _talk_add({"kind": "them", "who": who, "text": "", "stamp": stamp})
        renpy.pause()

    def talk_old(who, text):
        """前に届いていたメッセージを、クリックを待たずに並べる（talk_day のあとで使う）。"""
        _talk_add({"kind": "them", "who": who, "text": text})

    def talk_choose(items):
        """返信を選ぶ。items は (表示する文, 返す値) のリスト。選んだ値を返す。"""
        _talk_unlift()
        return renpy.call_screen("talk_choice", items=items)

    def talk_end():
        """トーク画面を閉じる。"""
        store.talk_last = (store.cal_date, store.talk_minutes)
        store.talk_lift = False
        renpy.hide_screen("talk_view")
        renpy.with_statement(dissolve)

## スマホ本体（gui/talk/phone.png）の位置。画面部分は (PHONE_X+16, PHONE_Y+16) から TALK_W×672
##   v0.32.2：画面の幅を 408 → 312 に（縦横比が 1.65 でタブレットのように見えたので、ふつうのスマホの 2.15 に）
define TALK_W = 312
define TALK_STAMP_ZOOM = 0.5           # スタンプの絵（240×240）を 120 に
define PHONE_X = 468
define PHONE_Y = 8

default talk_lift = False

transform talk_lift_tf(up=False):
    ease 0.25 yoffset (-200 if up else 0)

screen talk_view():
    zorder 40

    ## うしろの背景を少し暗くして、スマホを目立たせる
    add Solid("#0000004d")

    ## トークの途中で地の文が出ているあいだは、スマホを上へずらして、セリフ枠と重ならないようにする
    fixed at talk_lift_tf(talk_lift):
        ## 画面の中身
        fixed:
            pos (PHONE_X + 16, PHONE_Y + 16)
            xysize (TALK_W, 672)

            add Solid("#e4eaf1")

            ## 上のステータスバー
            fixed:
                ysize 34
                add Solid("#ffffff")
                text _talk_title_clock() style "talk_status" xpos 26
                hbox:
                    xalign 1.0
                    xoffset -24
                    yalign 0.6
                    spacing 6
                    text "4G" style "talk_status"
                    add Solid("#2b3440") xysize (22, 11) yalign 0.5

            ## ヘッダー（戻る、アイコン、トークの名前）
            fixed:
                ypos 34
                ysize 56
                add Solid("#ffffff")
                add Solid("#dfe3e8") ysize 1 yalign 1.0
                text "＜" style "talk_back"
                add talk_avatar zoom 0.4 xpos 36 yalign 0.5
                text talk_title style "talk_title"

            ## メッセージ
            viewport:
                ypos 90
                xysize (TALK_W, 524)
                yinitial 1.0
                mousewheel True
                vbox:
                    xsize TALK_W
                    spacing 8
                    null height 12
                    if talk_date:
                        frame:
                            style "talk_pill"
                            text talk_date style "talk_pill_text"
                    for m in talk_log:
                        if m["kind"] == "system":
                            frame:
                                style "talk_pill"
                                text m["text"] style "talk_pill_text"
                        elif m["kind"] == "typing":
                            hbox:
                                xpos 10
                                spacing 6
                                add talk_icon(m["who"]) zoom 0.4
                                frame:
                                    style "bubble_them"
                                    text m["text"] style "bubble_text" color "#8a94a3"
                        elif m["kind"] == "me":
                            hbox:
                                xalign 1.0
                                xoffset -12
                                spacing 6
                                vbox:
                                    yalign 1.0
                                    spacing 0
                                    if m.get("read"):
                                        text m.get("read") style "talk_meta" xalign 1.0
                                    text m.get("time", "") style "talk_meta" xalign 1.0
                                if m.get("stamp"):
                                    add "gui/talk/stamp/%s.png" % m["stamp"] zoom TALK_STAMP_ZOOM
                                else:
                                    frame:
                                        style ("bubble_me_cont" if m.get("cont") else "bubble_me")
                                        text m["text"] style "bubble_text"
                        else:
                            hbox:
                                xpos 10
                                spacing 6
                                if m.get("cont"):
                                    null width 38
                                else:
                                    add talk_icon(m["who"]) zoom 0.4
                                vbox:
                                    spacing 3
                                    if talk_group and not m.get("cont"):
                                        text m["who"] style "talk_sender"
                                    hbox:
                                        spacing 6
                                        if m.get("stamp"):
                                            add "gui/talk/stamp/%s.png" % m["stamp"] zoom TALK_STAMP_ZOOM
                                        else:
                                            frame:
                                                style ("bubble_them_cont" if m.get("cont") else "bubble_them")
                                                text m["text"] style "bubble_text"
                                        text m.get("time", "") style "talk_meta" yalign 1.0
                    null height 12

            ## 下の入力欄（飾り）
            fixed:
                ypos 614
                ysize 58
                add Solid("#ffffff")
                add Solid("#dfe3e8") ysize 1
                text "＋" style "talk_plus"
                frame:
                    style "talk_field"
                    text "メッセージを入力" style "talk_field_text"
                text "▶" style "talk_send"

        ## スマホの枠（画面の角を丸く見せるため、中身の上に重ねる）
        add "gui/talk/phone.png" pos (PHONE_X - 20, PHONE_Y - 20)

init python:
    ## ステータスバーの時計（最後のメッセージの時刻）
    def _talk_title_clock():
        t = store.talk_log[-1]["time"] if store.talk_log else _talk_clock()
        ## 前の日のメッセージを見ているあいだは、いまの時刻を出す
        if store.talk_now >= 0:
            h, m = t.split(":")
            if int(h) * 60 + int(m) < store.talk_now:
                return "%d:%02d" % ((store.talk_now // 60) % 24, store.talk_now % 60)
        return t


style talk_status:
    font FONT_JP_B
    size 14
    color "#2b3440"
    yalign 0.6

style talk_back:
    font FONT_JP_B
    size 22
    color "#2b3440"
    xpos 8
    yalign 0.5

style talk_title:
    font FONT_JP_B
    size 19
    color "#1e2733"
    xpos 82
    yalign 0.5

style talk_pill is frame:
    xalign 0.5
    background Frame("gui/talk/pill.png", 13, 13)
    padding (14, 4, 14, 5)

style talk_pill_text:
    size 13
    color "#ffffff"

style talk_sender:
    size 13
    color "#5b6878"

style talk_meta:
    size 11
    color "#7b8794"

style bubble_them is frame:
    background Frame("gui/talk/bubble_them.png", 24, 18)
    padding (22, 9, 14, 10)
    xmaximum 210

## 同じ人が続けて送った2つ目からは、しっぽのない吹き出し
style bubble_them_cont is bubble_them:
    background Frame("gui/talk/bubble_them_cont.png", 24, 18)

style bubble_me is frame:
    background Frame("gui/talk/bubble_me.png", 24, 18)
    padding (14, 9, 22, 10)
    xmaximum 210

style bubble_me_cont is bubble_me:
    background Frame("gui/talk/bubble_me_cont.png", 24, 18)

style bubble_text:
    size 18
    color "#1a1f26"
    line_spacing 2

style talk_plus:
    size 26
    color "#5b6878"
    xpos 16
    yalign 0.5

style talk_field is frame:
    xpos 50
    yalign 0.5
    xsize 206
    ysize 36
    background Frame("gui/talk/field.png", 17, 17)
    padding (16, 0, 16, 0)

style talk_field_text:
    size 15
    color "#a0a9b4"
    yalign 0.5

style talk_send:
    size 22
    color "#2f8f86"
    xpos 272
    yalign 0.5

## 返信の選択肢は、スマホの右側に付箋で並べる
screen talk_choice(items):
    zorder 110
    modal True
    vbox:
        xpos 840
        yalign 0.42
        spacing 0
        text "返信を選ぶ" style "talk_choice_head"
        null height 4
        for label_text, value in items:
            $ _h = choice_hint(label_text)
            if _h:
                button:
                    style "talk_choice_button"
                    action Return(value)
                    vbox:
                        spacing 2
                        text label_text style "talk_choice_text"
                        text _h style "talk_choice_hint"
            else:
                textbutton label_text action Return(value) style "talk_choice_button" text_style "talk_choice_text"

style talk_choice_hint:
    size 15
    color "#2f6f76"

style talk_choice_hint:
    variant "small"
    size 18

style talk_choice_head:
    font FONT_JP_B
    size 20
    color "#ffffff"
    outlines [(2, "#00000088", 0, 0)]
    xpos 16

style talk_choice_button is button:
    xsize 380
    background Frame("gui/note_small.png", 14, 14)
    hover_background Frame("gui/note_calendar.png", 14, 14)
    padding (24, 14, 26, 22)

style talk_choice_text:
    size 20
    color INK
    hover_color INK
    hover_font FONT_JP_B


################################################################################
## 行動マップ（放課後の行き先を選ぶ）
##   spots は {"id", "name", "x", "y", "event", "enabled"} の辞書のリスト
################################################################################

screen action_map(spots, banner, area="town"):
    modal True
    ## area="school" のときは、学校を大きくした地図
    add ("bg map_school" if area == "school" else "bg map")

    ## 行き先は、画びょうで留めた紙のタグ。(x, y) に画びょうが刺さる
    for s in spots:
        button:
            style "map_spot"
            pos (s["x"], s["y"])
            anchor (135, 18)
            sensitive s["enabled"]
            action Return(s["id"])
            hbox:
                xalign 0.5
                yalign 0.5
                spacing 8
                ## 人に会えるイベントは、顔の丸アイコンを名前の横に出す
                if s.get("face") and s["event"]:
                    add "gui/talk/avatar/%s.png" % s["face"] zoom 0.56 yalign 0.5
                vbox:
                    yalign 0.5
                    spacing 0
                    text s["name"] style "map_spot_name"
                    if s["event"]:
                        text "！ " + s["event"] style "map_spot_event"
                    elif not s["enabled"]:
                        text "（済み）" style "map_spot_done"

    ## 下の案内はマスキングテープ
    frame:
        style "map_banner"
        text banner style "map_banner_text"

    ## 右上：ここまでの話のふり返りと、相関図
    hbox:
        xalign 1.0
        xoffset -110    # 右上のメニューボタンをよける
        ypos 12
        spacing 10
        if recap_text:
            textbutton "これまでのこと" style "map_side" text_style "map_side_text" action Show("recap_note")
        textbutton "相関図" style "map_side" text_style "map_side_text" action ShowMenu("relations")

## 自由行動の前に、ここまでの話をまとめておく（行動マップの「これまでのこと」で読める）
default recap_text = ""

screen recap_note():
    modal True
    zorder 120
    button:
        xysize (1280, 720)
        background "#00000088"
        action Hide("recap_note")
    frame:
        xalign 0.5
        yalign 0.45
        xysize (760, 470)
        background Frame("gui/note_big.png", 30, 30)
        padding (56, 50, 56, 40)
        vbox:
            spacing 14
            text "これまでのこと" font FONT_JP_B size 30 color PEN_RED
            text recap_text size 23 color INK line_spacing 6
    textbutton "閉じる" style "map_side" text_style "map_side_text" xalign 0.5 ypos 610 action Hide("recap_note")

style map_side:
    background Frame("gui/note_small.png", 14, 14)
    padding (22, 12, 24, 16)

style map_side_text:
    font FONT_JP_B
    size 21
    color INK
    hover_color PEN_RED

style map_spot:
    xysize (270, 106)
    background "gui/spot_idle.png"
    hover_background "gui/spot_hover.png"
    insensitive_background "gui/spot_insensitive.png"
    padding (12, 24, 16, 18)

style map_spot_name:
    xalign 0.5
    font FONT_JP_B
    size 24
    color INK
    insensitive_color INK_SOFT

style map_spot_event:
    xalign 0.5
    size 17
    color PEN_RED

style map_spot_done:
    xalign 0.5
    size 17
    color INK_SOFT

style map_banner:
    xalign 0.5
    ypos 640
    xysize (780, 58)
    background "gui/banner_tape.png"
    padding (0, 0, 0, 0)

style map_banner_text:
    xalign 0.5
    yalign 0.5
    yoffset -2
    font FONT_JP_B
    size 24
    color INK


################################################################################
## ステータス画面（クイックメニューの「ステータス」から開く）
##   隠しパラメータ（ひざの無理ゲージ）は数字を出さず、言葉で出す（v0.29.13）。
##   仲間との絆・ヒロインの気持ち（ときめき・信頼・さみしさ）は数字を出さない。相関図の目盛りだけ。
################################################################################

screen status():
    tag menu
    ## v0.31.1：方眼の罫線が文字のうしろに出て読みにくかったので、白いカード4枚に分けた（左上：能力値、右上：右ひざ、左下：能力の目安、右下：いまの蓮）
    use game_menu("ステータス"):
        hbox:
            spacing 24
            ## 左の列
            vbox:
                spacing 22
                use note_card("能力値", 560, "#f4bccfc8"):
                    vbox:
                        spacing 8
                        for k in STAT_KEYS:
                            use status_bar(k, stats[k])

                ## v0.29.13：能力の目安（テスターT4・T7の声：どの能力が、どれくらい要るか知りたい）
                use note_card("能力の目安", 560, "#a9d8efc8"):
                    vbox:
                        spacing 8
                        grid 2 2:
                            xspacing 8
                            yspacing 6
                            for _rng, _w, _c in STAT_TIERS:
                                frame:
                                    xsize 252
                                    padding (10, 3, 10, 5)
                                    background _c
                                    text "{b}%s{/b}　%s" % (_rng, _w) size 15 color INK
                        for k in STAT_KEYS:
                            hbox:
                                spacing 8
                                text k style "status_role_key"
                                text STAT_ROLE[k] style "status_role"
                        text "試合の大事な場面では、選択肢の下に、判定に使う能力と必要な数値が出ます（設定の「ヒント」で消せます）。" style "status_small"

            ## 右の列
            vbox:
                spacing 22
                ## v0.29.13：ひざ（無理ゲージ）は数字を出さず、言葉で3段階（テスターT7の声：何％で壊れるのか分からない）
                use note_card("右ひざ", 316, "#f7c79ac8"):
                    vbox:
                        spacing 8
                        $ _kw, _kc = knee_state()
                        text _kw style "status_knee" color _kc
                        text "練習や試合で無理をすると重くなり、休んだり、痛みを正直に話したりすると軽くなります。重いまま大事な日をむかえると、痛んで能力が下がることがあります。" style "status_small"

                use note_card("いまの蓮", 316, "#d6c8f2c8"):
                    vbox:
                        spacing 8
                        $ _bt, _bd = belief_now()
                        text _bt style "status_sub"
                        text _bd style "status_note" xmaximum 272
                        text "選んだ答えで、少しずつ変わります。製品版では、結末や、大事な場面のセリフが変わります。" style "status_small"

screen status_bar(name, value):
    hbox:
        spacing 12
        text name style "status_label"
        bar value StaticValue(value, 100) style "status_meter"
        text str(value) style "status_value"
        text stat_tier(value) style "status_tier"

## 能力の目安の4段階（範囲, 言葉, 色）
define STAT_TIERS = [
    ("〜39", "まだ通用しない", "#ece6d6"),
    ("40〜49", "県大会の序盤で通用", "#e3f1f8"),
    ("50〜59", "県の上位と戦える", "#cfe7f3"),
    ("60〜", "強豪・全国レベル", "#b6daee"),
]

## 能力が何に効くか（ステータス画面の目安）
define STAT_ROLE = {
    "技術": "シュート・ドリブル・パスの正確さ。自分で決めにいく場面",
    "フィジカル": "走り負けない・当たり負けない足と体。試合の終わりぎわ",
    "戦術眼": "まわりが見えるか。スルーパスや、相手の動きを読む場面",
    "メンタル": "PKや、大事な場面で落ち着けるか",
}

init python:
    def stat_tier(v):
        """能力値の目安の言葉（判定の数値と合わせてある：第2章 41〜50、第3章 50〜65、第4章 62〜66）"""
        if v >= 60:
            return "全国レベル"
        if v >= 50:
            return "県の上位"
        if v >= 40:
            return "県大会の序盤"
        return "まだまだ"

    def knee_state():
        """右ひざの調子を言葉で返す（数字は見せない）。練習の「右ひざが、少し重い」と同じ言い方。
        痛み出すところは、夏（第1・2章）が 40、秋から（第3章〜）が 60（chapter2/3 の KNEE_WARN、practice.rpy と同じ）"""
        m = store.hidden.get("無理ゲージ", 0)
        mo = _month_of(store.cal_date)
        warn = 40 if (store.cal_year <= 2026 and mo is not None and 4 <= mo <= 8) else 60
        if m >= warn:
            return "ずっと重い（痛みが出そう）", PEN_RED
        if m >= warn - 15:
            return "少し重い", "#c07a1e"
        return "平気", PEN_TEAL

style status_head:
    font FONT_JP_B
    size 24
    color PEN_RED

style status_sub:
    font FONT_JP_B
    size 20
    color PEN_TEAL

style status_label:
    font FONT_JP_B
    size 19
    min_width 112       # 名前の長さに関係なく、棒の始まりをそろえる
    yalign 0.5

style status_meter:
    xsize 220
    ysize 14
    yalign 0.5
    left_bar Solid("#e98e8e")
    right_bar Solid("#ece6d6")
    thumb None

style status_value:
    font FONT_JP_B
    size 19
    min_width 36
    yalign 0.5

style status_tier:
    size 15
    color PEN_TEAL
    yalign 0.5

style status_role_key:
    font FONT_JP_B
    size 15
    min_width 86
    color INK

style status_note:
    size 16
    xmaximum 420
    color INK
    line_spacing 2

style status_role:
    size 15
    color INK

style status_small:
    size 15
    color INK_SOFT
    line_spacing 3

style status_knee:
    font FONT_JP_B
    size 24


################################################################################
## ルビ（名前の読みがな）は、各章で最初の1回だけ出す（v0.30.0 から：日が変わるたびに最初の1回。set_cal で記録を空にする）
##   本文には毎回 {rb}…{/rb}{rt}…{/rt} が書いてあるが、表示するときに、
##   同じ章ですでにルビつきで出した名前のルビを外す。分岐や章えらびでも正しく動く。
##   ・say_menu_text_filter は先読み（predict）でも呼ばれるので、ここでは記録しない（外すだけ）
##   ・実際に表示したとき（キャラの callback の begin）に、ルビつきで出した名前を記録する
##   ・章の始まり（prologue / chapter1〜3）で記録を空にする
################################################################################
default ruby_seen = set()

init python:
    import re as _ruby_re
    _RUBY_PAT = _ruby_re.compile(r"\{rb\}(.+?)\{/rb\}\{rt\}(.+?)\{/rt\}")
    RUBY_CHAPTER_LABELS = ("prologue", "chapter1", "chapter2", "chapter3", "chapter4a", "chapter5a")

    def ruby_filter(s):
        seen = store.ruby_seen
        if not seen or "{rb}" not in s:
            return s
        return _RUBY_PAT.sub(lambda m: m.group(1) if m.group(1) in seen else m.group(0), s)

    def ruby_record(event, interact=True, **kwargs):
        if event != "begin":
            return
        raw = getattr(store, "_last_raw_what", "") or ""
        if "{rb}" in raw:
            for m in _RUBY_PAT.finditer(raw):
                store.ruby_seen.add(m.group(1))

    def ruby_chapter_reset(name, abnormal):
        if name in RUBY_CHAPTER_LABELS:
            store.ruby_seen = set()

    config.say_menu_text_filters.append(ruby_filter)
    config.all_character_callbacks.append(ruby_record)
    config.label_callbacks.append(ruby_chapter_reset)


################################################################################
## セリフ枠の改行を、読点・句点のところに寄せる（v0.30.0。配信で「変なところで改行される」と言われたため）
##   セリフ枠は 1行 約37文字（xsize 1060 ÷ 文字の大きさ 28）。そのまま流すと、言葉の途中で次の行に送られる。
##   1行に入りきらない文のときだけ、その行の後半（半分より先）にある「、。！？」」などの直後で改行を入れる。
##   ・入れる改行は、自然に折り返す位置より手前なので、行が枠からはみ出すことはない
##   ・{rt}…{/rt}（ふりがな）は幅に数えない。ほかのタグも幅0。[変数] は名前くらいの幅（2.5文字）で数える
##   ・もともと改行（\n）が入っている文は、そのまま
##   ・say_menu_text_filters で、セリフと地の文にだけ使う（選択肢は枠の幅がちがうので使わない）
################################################################################
init python:
    PW_CAP = 36.0      # 「」が付くセリフのぶん、1文字少なめ
    PW_BREAK_AFTER = u"、。！？」』…）"
    PW_FULL = u"「」『』（）！？、。…―・ー〜"

    def _pw_width(ch):
        return 1.0 if (ord(ch) >= 0x2E80 or ch in PW_FULL) else 0.55

    def phrase_wrap(s):
        try:
            if not s or "\n" in s or len(s) < 30:
                return s
            out = []
            width = 0.0
            bp = None          # 改行を入れられる位置（out の添字）
            bp_w = 0.0         # その位置までの、この行の幅
            i = 0
            n = len(s)
            while i < n:
                c = s[i]
                if c == "{":
                    j = s.find("}", i)
                    if j < 0:
                        out.append(s[i:])
                        break
                    tag = s[i:j + 1]
                    if tag == "{rt}":
                        k = s.find("{/rt}", j)
                        if k < 0:
                            out.append(s[i:])
                            break
                        out.append(s[i:k + 5])
                        i = k + 5
                        continue
                    if tag == "{{":
                        out.append(tag)
                        width += 1.0
                        i = j + 1
                        continue
                    out.append(tag)
                    i = j + 1
                    continue
                if c == "[":
                    j = s.find("]", i)
                    if j > i and s[i:i + 2] != "[[":
                        tok, w = s[i:j + 1], 2.5
                        i = j + 1
                    else:
                        tok, w = c, 1.0
                        i += 1
                else:
                    tok, w = c, _pw_width(c)
                    i += 1
                if width + w > PW_CAP:
                    if bp is not None and bp_w >= PW_CAP * 0.5:
                        out.insert(bp, "\n")
                        width -= bp_w
                    else:
                        width = 0.0
                    bp = None
                out.append(tok)
                width += w
                if tok in PW_BREAK_AFTER and (i >= n or s[i] not in PW_BREAK_AFTER):
                    bp = len(out)
                    bp_w = width
            return "".join(out)
        except Exception:
            return s

    def phrase_wrap_filter(s):
        """say_menu_text_filters 用。選択肢（menu）は枠の幅がちがうので、そのまま返す"""
        try:
            node = renpy.game.script.lookup(renpy.game.context().current)
            if not isinstance(node, renpy.ast.Say):
                return s
        except Exception:
            return s
        return phrase_wrap(s)

    config.say_menu_text_filters.append(phrase_wrap_filter)
