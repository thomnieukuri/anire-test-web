## ===========================================================================
## 第4章（ルートA）のドキドキする場面（v0.31.1・Claude の下書き。作者が読んで直す）
##   これまで「作者が書く」として空けていた場所を、作者の決定（11/2）で Claude が下書きした
##   ヒロインは全員高校生。ドキドキは気持ちの揺れ（照れ・距離・言いかけてやめる・二人だけの秘密）で書き、
##   体を見せる描写はしない
##
##   このファイルにあるもの
##     ・2/13 卓球の罰ゲームの答え（a4h_pong_answer）……chapter4a.rpy の罰ゲームから呼ぶ
##     ・2/14 バレンタイン（a4h_valentine）……chapter4a.rpy の雪うさぎのあとから呼ぶ
##     ・7月の終わり 告白の前ぶれ（a4_heart_special → a4_heart_hinata / chika / ageha）……a4_trust_special から呼ぶ
##   それぞれの場面の中に直接書いたもの
##     ・合宿の恋バナで、ヒロインの名前を答える（chapter4a_2.rpy の a4_camp）
##     ・夏祭りの続き（chapter4a_2.rpy の a4_fes_hinata / a4_fes_chika、chapter4a_ageha.rpy の a4_fes_ageha）
##     ・関係が冷えたときの「ほかの人」への返事（chapter4a_free.rpy の a4_jul_chika＝相良、a4_jul_hinata＝柏木）
## ===========================================================================

## 告白の前ぶれが届く「ときめき」（7月の終わり）。いちばん高い一人だけに起きる
##   体験版の終わりで、追った人のときめきは 25〜60。第4章の罰ゲーム・バレンタインで +5〜11
##   あげはは4月に会うので低め（入部で15から。プリクラ・ドリンクの出来事に行くと 20 を超える）
define A4_HEART_SPECIAL = 50
define A4_HEART_SPECIAL_AGEHA = 22
## バレンタインに渡しに来る「ときめき」（ひなたと千夏の、高いほう）
define A4_VALENTINE_MIN = 30

default a4_feb_type = ""        # 2/13 罰ゲームで答えたヒロイン（hinata / chika）
default a4_valentine = ""       # 2/14 バレンタインに渡しに来たヒロイン（hinata / chika / ""）
default a4_heart_who = ""       # 告白の前ぶれが起きたヒロイン（ひなた / 千夏 / あげは / ""）
default a4_heart_answer = ""    # 告白の前ぶれで答えたこと


## ---------------------------------------------------------------------------
## 2/13 夜：卓球の罰ゲーム「ひなたと千夏先輩、どっちがタイプ？」
##   理由を言いかけたところで、黒田が「そこまでだ」と止める（呼んだ側に、その続きがある）
## ---------------------------------------------------------------------------
label a4h_pong_answer:
    menu:
        "「……ひなた」":
            $ a4_feb_type = "hinata"
            $ heart_up("ひなた", "ときめき", 6)
            ren "……ひなた"
            "ロビーの空気が、一回はねた。ひなたのラケットが、顔の前でぴたりと止まった。"
            scene cg a4_pong at cam_push(10.0, 1.04)
            with Dissolve(0.8)
            if ch2_koibana == "hinata":
                sakaguchi "去年の合宿と同じ！　ブレねえ！"
            elif ch2_koibana == "chika":
                sakaguchi "え、去年の合宿では、千夏先輩って……"
                voice "audio/voice/chika_a4h_pong_answer_01.mp3"
                chika "……記録と、ちがいます"
                "千夏先輩は、メモに何かを書いて、二重線で消した。"
            sakaguchi "理由！　理由まで言うのがルール！"
            "続きを言おうとして、言葉を探した。"
            ren "……理由は。あいつは、俺の眉毛を見ただけで、全部――"
        "「……千夏先輩」":
            $ a4_feb_type = "chika"
            $ heart_up("千夏", "ときめき", 6)
            ren "……千夏先輩"
            "ロビーの空気が、一回はねた。千夏先輩のペンが、メモの上でぴたりと止まった。"
            scene cg a4_pong at cam_push(10.0, 1.04)
            with Dissolve(0.8)
            if ch2_koibana == "chika":
                sakaguchi "去年の合宿と同じ！　ブレねえ！"
                voice "audio/voice/chika_a4h_pong_answer_02.mp3"
                chika "……去年も、扉の前で聞きました。……あ"
                "言ってから、先輩は、メモで口もとを隠した。"
            elif ch2_koibana == "hinata":
                sakaguchi "え、去年の合宿では、ひなたって……"
                voice "audio/voice/hinata_a4h_pong_answer_01.mp3"
                hinata "……言ってた。わたし、坂口くんから聞いたもん"
            sakaguchi "理由！　理由まで言うのがルール！"
            "続きを言おうとして、言葉を探した。"
            ren "……理由は。先輩は、誰も見てないところで、いつも――"
    scene bg ryokan_lobby_night
    with dissolve
    return


## ---------------------------------------------------------------------------
## 2/14 朝：バレンタイン（雪うさぎのあと、旅館で）
##   ひなたと千夏のうち、ときめきが高いほうが、こっそり渡しに来る（同じならひなた）。どちらも低いときは何もない
## ---------------------------------------------------------------------------
label a4h_valentine:
    $ _vh = heart["ひなた"]["ときめき"]
    $ _vc = heart["千夏"]["ときめき"]
    if max(_vh, _vc) < A4_VALENTINE_MIN:
        return
    ## 揺れる場面（v0.33.2）：前の夜の0時に、もう渡されている
    if a4_val_midnight:
        jump a4h_valentine_after_midnight
    if _vh >= _vc:
        jump a4h_valentine_hinata
    jump a4h_valentine_chika

default a4_val_midnight = False   # 揺れる場面：2/13 の夜、0時に渡された（v0.33.2）

## ===========================================================================
## 揺れる場面（v0.33.2・Claude の下書き。作者の案：寝る前に2人からトーク → 日付が変わって廊下で）
##   2/13 の夜、三好先輩の話のあと（chapter4a.rpy の a4_feb_night から呼ぶ）
##   ひなたと千夏のときめきが、どちらもバレンタインの基準（30）以上で、sway_pair のとき
##   2/14 の昼のバレンタイン（a4h_valentine）は、そのかわりに、選ばなかった人の朝の一言だけになる
## ===========================================================================
label a4h_midnight:
    $ _vh = heart["ひなた"]["ときめき"]
    $ _vc = heart["千夏"]["ときめき"]
    if min(_vh, _vc) < A4_VALENTINE_MIN or not sway_pair(["ひなた", "千夏"]):
        return
    $ a4_val_midnight = True
    "みんなの寝息が、そろってきたころ。布団の中で、スマホが、ふるえた。……二回。"
    window auto hide
    $ talk_start("ひなた", "23:52")
    $ talk("ひなた", "起きてる？")
    $ talk("ひなた", "0時になったら、階段の踊り場。1分だけ")
    $ talk_end()
    $ talk_start("千夏", "23:53")
    $ talk("千夏", "起きていますか")
    $ talk("千夏", "0時に、二階の廊下の、つきあたりの窓のところにいます")
    $ talk("千夏", "……報告です")
    window auto hide
    $ talk_end()
    "階段の踊り場と、廊下のつきあたりの窓。同じ二階の、反対の端だった。"
    "0時まで、あと7分だった。"
    menu:
        "ひなたに「行く」と返す":
            $ a4_valentine = "hinata"
            $ sway_pick("ひなた", "千夏")
            jump a4h_mid_hinata
        "千夏先輩に「行きます」と返す":
            $ a4_valentine = "chika"
            $ sway_pick("千夏", "ひなた")
            jump a4h_mid_chika
        "どちらにも返さず、目をつぶる":
            $ a4_valentine = ""
            $ sway_none("ひなた", "千夏")
            "どちらにも、返せなかった。既読だけが、二つ、ついた。"
            "目をつぶっても、0時を過ぎるまで、眠れなかった。坂口のいびきだけが、ずっと聞こえていた。"
            return

## ひなた：階段の踊り場。0時ちょうどに「一番乗り」
label a4h_mid_hinata:
    "ふすまを、そっと開けた。坂口のいびきが、ちょうどいい音消しになった。"
    scene bg ryokan_lobby_night
    with dissolve
    "階段の踊り場だけ、非常口の緑の明かりがついていた。ひなたは、旅館の浴衣の上にはんてんを着て、手すりにもたれていた。"
    show hinata ryokan
    with dissolve
    voice "audio/voice/hinata_a4sw_mid_01.mp3"
    hinata "……来た。来ないと思った"
    ren "呼んだの、そっちだろ"
    voice "audio/voice/hinata_a4sw_mid_02.mp3"
    hinata "呼んだけど。……あと1分。しゃべらないで"
    "しゃべらないで、と言ったのは、ひなたのほうだった。なのに、すぐに、小さな声がした。"
    voice "audio/voice/hinata_a4sw_mid_10.mp3"
    hinata "……部屋を出るとき、千夏先輩の布団、空っぽだった。……蓮、なんか知ってる？"
    "知っていた。0時に、廊下のつきあたりの窓。"
    ren "……知らない"
    voice "audio/voice/hinata_a4sw_mid_11.mp3"
    hinata "……そっか。知らないなら、いい"
    "ひなたは、スマホの画面をこっちに向けた。23:59。二人で、だまって、数字を見ていた。"
    "数字が、0:00に変わった。"
    voice "audio/voice/hinata_a4sw_mid_03.mp3"
    hinata "……14日に、なった"
    "はんてんの袖から、小さな箱が出てきた。リボンが、少しだけ曲がっていた。ひなたの、癖のある結び方だった。"
    voice "audio/voice/hinata_a4sw_mid_04.mp3"
    hinata "一番乗り。……だれよりも先に、渡したかったの。それだけ"
    menu:
        "「……テーピングの、お礼か？」":
            $ heart_up("ひなた", "ときめき", 4)
            $ heart_up("ひなた", "信頼", 2)
            voice "audio/voice/hinata_a4sw_mid_05.mp3"
            hinata "……それも、ある。それも、あるけど"
            voice "audio/voice/hinata_a4sw_mid_06.mp3"
            hinata "「それだけ」って言ったら、うそになるから。……言わない"
        "「一番乗り、されたな」":
            $ heart_up("ひなた", "ときめき", 5)
            voice "audio/voice/hinata_a4sw_mid_07.mp3"
            hinata "されたでしょ。……来年も、する。再来年も"
    voice "audio/voice/hinata_a4sw_mid_12.mp3"
    hinata "……ねえ。一個だけ、聞いていい？"
    voice "audio/voice/hinata_a4sw_mid_13.mp3"
    hinata "蓮って、わたしのこと……幼なじみ、以外で、何だと思ってる？"
    ren "……何って"
    voice "audio/voice/hinata_a4sw_mid_14.mp3"
    hinata "あ、いい。今のなし。……0時すぎてるから、ノーカウント"
    voice "audio/voice/hinata_a4sw_mid_08.mp3"
    hinata "義理か本命かは、聞かないでね。……暗くて、よかった。今、眉毛、見えないから"
    "ひなたは、はんてんの前を両手で合わせて、先に階段をかけ上がっていった。スリッパの音が、ぱたぱたと遠ざかった。"
    hide hinata
    with dissolve
    "布団に戻っても、箱を持った手だけが、ずっと、あたたかかった。"
    return

## 千夏：廊下のつきあたりの窓。「14日になる瞬間を、記録しに」
label a4h_mid_chika:
    "ふすまを、そっと開けた。坂口のいびきが、ちょうどいい音消しになった。"
    scene bg ryokan_lobby_night
    with dissolve
    "二階の廊下のつきあたりの窓に、雪が、音もなく当たっていた。千夏先輩は、旅館の浴衣にカーディガンを羽織って、窓の外の雪を撮っていた。"
    show chika ryokan
    with dissolve
    voice "audio/voice/chika_a4sw_mid_01.mp3"
    chika "……来ましたね。記録します。23時58分"
    ren "それも、記録するんですか"
    voice "audio/voice/chika_a4sw_mid_02.mp3"
    chika "します。……今日は、14日になる瞬間を、記録しに来ました"
    voice "audio/voice/chika_a4sw_mid_09.mp3"
    chika "……わたしが部屋を出るとき、篠宮さんは、寝たふりをしていました。スマホの明かりが、布団から、もれていたので"
    if a4_chika_call == "早瀬くん":
        voice "audio/voice/chika_a4sw_mid_10_hy.mp3"
    else:
        voice "audio/voice/chika_a4sw_mid_10.mp3"
    chika "[a4_chika_call]は、何か、ご存じですか"
    "知っていた。0時に、階段の踊り場。"
    ren "……知りません"
    voice "audio/voice/chika_a4sw_mid_14.mp3"
    chika "そうですか。……知らないなら、いいです"
    "先輩は、冷たい窓ガラスに、指で小さな時計を描いた。息で、すぐにくもって、消えた。"
    "廊下の柱時計が、ひとつ、鳴った。"
    voice "audio/voice/chika_a4sw_mid_03.mp3"
    chika "……14日に、なりました"
    "先輩は、カメラを下ろした。かわりに、茶色い紙の、小さな包みを差し出した。"
    voice "audio/voice/chika_a4sw_mid_04.mp3"
    chika "昼間、売店で買いました。……「余っていたので」と言うつもりで、さっきまで、練習していました"
    menu:
        "「……練習の成果は？」":
            $ heart_up("千夏", "ときめき", 5)
            voice "audio/voice/chika_a4sw_mid_05.mp3"
            chika "失敗しました。……今、全部、言ってしまったので"
        "黙って受け取って、頭を下げる":
            $ heart_up("千夏", "ときめき", 3)
            $ heart_up("千夏", "信頼", 3)
            voice "audio/voice/chika_a4sw_mid_06.mp3"
            chika "……何も聞かないのは、助かります"
    voice "audio/voice/chika_a4sw_mid_11.mp3"
    chika "……参考までに、一つだけ、うかがってもいいですか"
    if a4_chika_call == "早瀬くん":
        voice "audio/voice/chika_a4sw_mid_12_hy.mp3"
    else:
        voice "audio/voice/chika_a4sw_mid_12.mp3"
    chika "[a4_chika_call]にとって、わたしは、記録係のほかに、何か、ありますか"
    ren "……先輩は、先輩です"
    voice "audio/voice/chika_a4sw_mid_13.mp3"
    chika "……そうですか。今の答えは、記録しないでおきます。来年、もう一度、うかがうかもしれません"
    "窓の外の雪あかりで、先輩の耳が、少し赤いのが見えた。"
    voice "audio/voice/chika_a4sw_mid_07.mp3"
    chika "この時間のことは、記録しません。……記録係が、記録される側になってしまうので"
    voice "audio/voice/chika_a4sw_mid_08.mp3"
    chika "おやすみなさい。……味の感想は、記録しておいてください。来年の、参考にします"
    "先輩は、スリッパの音をたてないように、ゆっくり廊下を帰っていった。"
    hide chika
    with dissolve
    "布団に戻ってから、包みの裏に、細いペンで一行書いてあるのに気づいた。『いつも、撮らせてくれて、ありがとう』"
    return

## 2/14 の朝：0時に渡された人がいるときは、昼のバレンタインのかわりに、選ばなかった人の一言
label a4h_valentine_after_midnight:
    if a4_valentine == "hinata":
        "玄関で、千夏先輩が、雪の朝を撮っていた。何枚撮っても、そのファインダーの中に、俺は入らなかった。"
        "最後に一枚だけ、レンズがこっちを向いた。シャッターは、押されなかった。"
    elif a4_valentine == "chika":
        "玄関で、ひなたが、全員にお徳用の大袋のチョコを配っていた。俺の手のひらにも、みんなと同じ一個が置かれた。"
        voice "audio/voice/hinata_a4sw_mid_09.mp3"
        hinata "……昨日、既読、ついてた"
        "それだけ言って、ひなたは、次の人のほうへ行った。"
    else:
        "玄関で、ひなたと千夏先輩が、それぞれ、ポケットに手を入れたまま、雪を見ていた。二人とも、こっちを見なかった。"
    return

label a4h_valentine_hinata:
    $ a4_valentine = "hinata"
    "荷物を取りに部屋へ戻ろうとしたとき、階段の下で、袖を引っぱられた。"
    show hinata trip
    with dissolve
    voice "audio/voice/hinata_a4h_valentine_01.mp3"
    hinata "……蓮。ちょっと"
    "ひなたは、階段の陰まで俺を連れていくと、コートのポケットから小さな箱を出した。"
    hide hinata
    scene cg a4_val_hinata at cam_push(10.0, 1.04)
    with Dissolve(1.0)
    ## 差し出した箱が枠に隠れないように、一度だけ枠を消して見せる
    window hide
    pause 2.0
    window auto
    voice "audio/voice/hinata_a4h_valentine_02.mp3"
    hinata "みんなの分は、さっき三好先輩に渡した。お徳用の大袋"
    voice "audio/voice/hinata_a4h_valentine_03.mp3"
    hinata "で、これは……テーピング、いつも巻かせてくれるお礼"
    ren "巻いてもらってるのは、俺のほうだろ"
    voice "audio/voice/hinata_a4h_valentine_04.mp3"
    hinata "いいの。巻かせてくれる人がいないと、練習にならないんだから"
    "箱のリボンは、少しだけ曲がっていた。ひなたの、癖のある結び方だった。"
    menu:
        "「……手作りか」":
            $ heart_up("ひなた", "ときめき", 5)
            voice "audio/voice/hinata_a4h_valentine_05.mp3"
            hinata "ちがう。……溶かして、固めただけ"
            ren "それを手作りって言うんだ"
            voice "audio/voice/hinata_a4h_valentine_06.mp3"
            hinata "言わない！"
        "「ありがとう。大事に食べる」":
            $ heart_up("ひなた", "ときめき", 4)
            $ heart_up("ひなた", "信頼", 2)
            voice "audio/voice/hinata_a4h_valentine_07.mp3"
            hinata "……大事にしなくていいよ。チョコだもん。溶けるし"
            "そう言いながら、ひなたは、うれしそうに口をとがらせた。"
    voice "audio/voice/hinata_a4h_valentine_08.mp3"
    hinata "あと、義理か本命かは、聞かないでね"
    ren "なんで"
    voice "audio/voice/hinata_a4h_valentine_09.mp3"
    hinata "……今、わたしの眉毛、見られたくないから"
    "ひなたは、前髪を両手で押さえて、先に階段をかけ上がっていった。"
    scene bg ryokan_lobby_morning
    with dissolve
    return

label a4h_valentine_chika:
    $ a4_valentine = "chika"
    ## v0.31.1：作者の声で、少し可愛げを足した（くもったメガネ・「ちがわない、かもしれません」・来年の参考）
    "荷物を取りに部屋へ戻ろうとしたとき、玄関から千夏先輩が入ってきた。外の雪から戻ったばかりで、メガネが真っ白にくもっていた。"
    show chika trip
    with dissolve
    if a4_chika_call == "早瀬くん":
        voice "audio/voice/chika_a4h_valentine_01_hy.mp3"
    else:
        voice "audio/voice/chika_a4h_valentine_01.mp3"
    chika "……[a4_chika_call]。そこに、いますね。声で分かります"
    "先輩は、くもったメガネのまま、こっちに向かって手を差し出した。茶色い紙の、小さな包みが乗っていた。"
    hide chika
    scene cg a4_val_chika at cam_push(10.0, 1.04)
    with Dissolve(1.0)
    window hide
    pause 2.0
    window auto
    voice "audio/voice/chika_a4h_valentine_02.mp3"
    chika "旅館の売店で、余っていたので"
    "包み紙には、駅前の和菓子屋の名前が印刷してあった。すみに、ペンで小さく、雪うさぎの絵が描いてあった。"
    voice "audio/voice/chika_a4h_valentine_03.mp3"
    chika "生徒会としては、校内での菓子の受け渡しは、認めていません。……ここは、校外です"
    menu:
        "「ありがとうございます。……バレンタイン、ですよね」":
            $ heart_up("千夏", "ときめき", 5)
            voice "audio/voice/chika_a4h_valentine_04.mp3"
            chika "……ちがいます"
            "メガネのくもりが、ゆっくり晴れていった。目が合った。"
            voice "audio/voice/chika_a4h_valentine_05.mp3"
            chika "…………ちがわない、かもしれません"
        "黙って受け取って、頭を下げる":
            $ heart_up("千夏", "ときめき", 3)
            $ heart_up("千夏", "信頼", 3)
            voice "audio/voice/chika_a4h_valentine_06.mp3"
            chika "……何も聞かないのは、助かります"
            "メガネのくもりが晴れると、先輩の耳が、外の寒さのせいだけではなく赤いのが分かった。"
    "包みの裏には、細いペンで一行。『いつも、撮らせてくれて、ありがとう』"
    voice "audio/voice/chika_a4h_valentine_07.mp3"
    chika "……読むのは、帰ってからにしてください。記録係が、記録される側になるのは、困ります"
    "先輩は、くるりと背中を向けて、階段のほうへ歩いていった。三段のぼったところで、止まった。"
    voice "audio/voice/chika_a4h_valentine_08.mp3"
    chika "……味の感想は、記録しておいてください。来年の、参考にします"
    scene bg ryokan_lobby_morning
    with dissolve
    return


## ---------------------------------------------------------------------------
## 7月の終わり：告白の前ぶれ（ときめきの特別イベント）
##   ときめきが A4_HEART_SPECIAL（あげはは A4_HEART_SPECIAL_AGEHA）以上の人のうち、いちばん高い一人だけ
##   （高さは目安との比べ方で決める。同じなら ひなた → 千夏 → あげは）
##   言いかけて、言わない。続きは、それぞれの「告白の日」（ひなた＝高3の選手権、千夏＝卒業式、あげは＝蓮の卒業式）
## ---------------------------------------------------------------------------
label a4_heart_special:
    python:
        _cand = []
        for _nm, _need in (("ひなた", A4_HEART_SPECIAL), ("千夏", A4_HEART_SPECIAL), ("あげは", A4_HEART_SPECIAL_AGEHA)):
            _v = heart.get(_nm, {}).get("ときめき", 0)
            if _v >= _need:
                _cand.append((float(_v) / _need, _nm))
        a4_heart_who = ""
        _best = 0.0
        for _r, _nm in _cand:
            if _r > _best:
                _best = _r
                a4_heart_who = _nm
    if a4_heart_who == "ひなた":
        call a4_heart_hinata
    elif a4_heart_who == "千夏":
        call a4_heart_chika
    elif a4_heart_who == "あげは":
        call a4_heart_ageha
    return

## ひなた：夜の防波堤。半分このアイス
label a4_heart_hinata:
    scene black
    with dissolve
    $ set_cal("7月28日（水）", "夜")
    scene bg breakwater_night
    with dissolve
    $ bgm("静かな夜の曲")
    "コンビニの帰りに、二人で防波堤まで歩いた。ひなたが、二つに割れるアイスを買っていた。"
    show hinata normal
    with dissolve
    voice "audio/voice/hinata_a4_heart_01.mp3"
    hinata "はい。半分こ。……小学生のとき、ここで、よく分けたよね"
    "割ったアイスは、いつもどおり片方だけ大きかった。ひなたは、大きいほうを俺によこした。"
    voice "audio/voice/hinata_a4_heart_02.mp3"
    hinata "8月の終わり、検診だね"
    ren "……ああ"
    voice "audio/voice/hinata_a4_heart_03.mp3"
    hinata "もし手術になっても、わたし、ノートつけるから。リハビリのも、全部"
    show hinata serious
    voice "audio/voice/hinata_a4_heart_04.mp3"
    hinata "蓮がプロになって、遠くのチームに行っても。……ノートだけは、送ってね。ひざの"
    ren "遠くに行く前提か"
    voice "audio/voice/hinata_a4_heart_05.mp3"
    hinata "行くよ。蓮は、行く人だもん"
    "ひなたは、溶けかけたアイスを、あわててかじった。"
    if a4_feb_type == "hinata":
        voice "audio/voice/hinata_a4_heart_06.mp3"
        hinata "……冬の旅行の、罰ゲーム。蓮、わたしの名前、言ったよね"
        ren "言った"
        voice "audio/voice/hinata_a4_heart_07.mp3"
        hinata "理由、まだ聞いてない"
    "波の音が、二回、三回。ひなたは、両腕でひざを抱えた。"
    voice "audio/voice/hinata_a4_heart_08.mp3"
    hinata "……ねえ、蓮"
    voice "audio/voice/hinata_a4_heart_09.mp3"
    hinata "わたしね、蓮のこと――"
    "そこで、ひなたは口をつぐんだ。"
    "続きを待った。ひなたは、海のほうを向いたまま、首を横に振った。"
    voice "audio/voice/hinata_a4_heart_10.mp3"
    hinata "……やっぱり、今は言わない"
    voice "audio/voice/hinata_a4_heart_11.mp3"
    hinata "冬の旅行で、黒田先生が言ってたでしょ。『選手権に勝ってから言え』って"
    hide hinata
    scene cg a4_heart_hinata at cam_push(10.0, 1.04)
    with Dissolve(1.0)
    "ひなたは、泣きそうな顔で笑って、小指を差し出した。"
    voice "audio/voice/hinata_a4_heart_12.mp3"
    hinata "わたしも、そうする。……蓮が勝ったら、言う"
    voice "audio/voice/hinata_a4_heart_13.mp3"
    hinata "約束。……指切り"
    menu:
        "「……待ってる」":
            $ a4_heart_answer = "wait"
            $ heart_up("ひなた", "ときめき", 8)
            ren "……待ってる"
            voice "audio/voice/hinata_a4_heart_14.mp3"
            hinata "うん。……待ってて"
            "差し出された小指に、自分の小指をからめた。小学生のとき以来の、指切りだった。"
            "ひなたの小指は、アイスのせいで、少しだけ冷たかった。"
        "「今、言えよ」":
            $ a4_heart_answer = "now"
            $ heart_up("ひなた", "ときめき", 6)
            ren "今、言えよ"
            "ひなたは、小指を出したまま、首を横に振った。"
            voice "audio/voice/hinata_a4_heart_15.mp3"
            hinata "……やだ。今言ったら、わたし、たぶん泣くもん"
            voice "audio/voice/hinata_a4_heart_16.mp3"
            hinata "泣いてる顔で言うのは、やなの。……勝った日に、笑って言いたい"
            "ひなたは、俺の肩に一回だけ、こつんとおでこをぶつけた。"
            voice "audio/voice/hinata_a4_heart_17.mp3"
            hinata "……だから、勝って"
    scene bg breakwater_night
    with dissolve
    "帰り道、ひなたは、家の前まで一言もしゃべらなかった。"
    "三軒隣の玄関の明かりが消えるまで、俺は、自分の家の前に立っていた。"
    $ set_flag("告白の前ぶれ", "ひなた")
    return

## 千夏：夜の生徒会室。『港北の記録』の最後のページ
##   v0.31.1：作者の声で、いつもの千夏とのギャップを足した（あくび・大笑い・「半分は、撮りたくて撮りました」・敬語が抜ける）
##   一枚絵（アルバムの上で手が重なる）は、あとで足す
label a4_heart_chika:
    scene black
    with dissolve
    $ set_cal("7月29日（木）", "夜")
    scene bg student_council_night
    with dissolve
    $ bgm("静かな夜の曲")
    "夏休みの校舎は、夜になると、生徒会室の明かりだけが残る。ノックをすると、中から、気の抜けた声がした。"
    voice "audio/voice/chika_a4_heart_01.mp3"
    chika "……ふぁい。……どうぞ"
    show chika normal
    with dissolve
    "先輩は、参考書の山の向こうで、あわてて背すじを伸ばした。"
    voice "audio/voice/chika_a4_heart_02.mp3"
    chika "……今のは、あくびではありません。返事です"
    ren "ふぁい、って言いました"
    voice "audio/voice/chika_a4_heart_03.mp3"
    chika "言っていません。……受験生は、夜は、少しだけ言葉がやわらかくなるんです"
    "机の上に、分厚いアルバムが一冊。表紙に、先輩の字で『港北の記録』。"
    voice "audio/voice/chika_a4_heart_04.mp3"
    chika "サッカー部のページが、できました。見てください"
    "めくると、去年の4月の校門から始まっていた。ビラを配る三好先輩。雨の5月。土手の1回戦。"
    "三好先輩が、泥の中で両手を広げて叫んでいる一枚があった。先輩は、それを見たとたん、肩をふるわせた。"
    voice "audio/voice/chika_a4_heart_05.mp3"
    chika "……ふふっ。……あははっ"
    "千夏先輩が、声を出して笑っていた。メガネを外して、目もとをぬぐうくらいに。"
    voice "audio/voice/chika_a4_heart_06.mp3"
    chika "……すみません。この写真だけは、だめなんです。撮ったときから、ずっと"
    "どの写真にも、端のほうに、俺がいた。……真ん中では、なかったけど。"
    ren "……俺、写りすぎじゃないですか"
    show chika narrow
    voice "audio/voice/chika_a4_heart_07.mp3"
    chika "記録です。部員の写真は、均等に撮っています"
    "先輩は、ページをめくる手を止めた。少しだけ黙って、メガネをかけ直した。"
    show chika soft
    voice "audio/voice/chika_a4_heart_08.mp3"
    chika "……うそです。半分は、撮りたくて撮りました"
    if a4_feb_type == "chika":
        "冬の旅行のページに、卓球台の写真が一枚あった。ラケットで顔を隠すひなたと、メモを閉じかけた手。"
        voice "audio/voice/chika_a4_heart_09.mp3"
        chika "……このページは、早く、めくってください。今すぐ"
    "最後のページだけ、何も貼られていなかった。"
    ren "ここは"
    voice "audio/voice/chika_a4_heart_10.mp3"
    chika "空けてあります。……卒業式の日に、撮りたい写真があるので"
    if a4_chika_call == "早瀬くん":
        voice "audio/voice/chika_a4_heart_11_hy.mp3"
    else:
        voice "audio/voice/chika_a4_heart_11.mp3"
    chika "その日、[a4_chika_call]に、頼みたいことがあります"
    ren "何ですか"
    voice "audio/voice/chika_a4_heart_12.mp3"
    chika "その日まで、内緒。……あ"
    "先輩は、自分の口を指でおさえた。"
    voice "audio/voice/chika_a4_heart_13.mp3"
    chika "……今のは、敬語を忘れたのではありません。わざとです"
    "先輩は、アルバムを閉じようとして、手を止めた。"
    hide chika
    scene cg a4_heart_chika at cam_push(10.0, 1.04)
    with Dissolve(1.0)
    ## 重なった手が枠に隠れないように、一度だけ枠を消して見せる
    window hide
    pause 2.5
    window auto
    "閉じかけたアルバムの上で、俺の手と先輩の手が、少しだけ重なっていた。どちらも、すぐにはどかなかった。"
    menu:
        "「その日、空けておきます」":
            $ a4_heart_answer = "wait"
            $ heart_up("千夏", "ときめき", 8)
            voice "audio/voice/chika_a4_heart_14.mp3"
            chika "……はい。予定表に、書いておいてください。消せないペンで"
            voice "audio/voice/chika_a4_heart_15.mp3"
            chika "書いたら、写真を撮って、送ってください。……確認、したいので"
        "「今、教えてください」":
            $ a4_heart_answer = "now"
            $ heart_up("千夏", "ときめき", 6)
            voice "audio/voice/chika_a4_heart_16.mp3"
            chika "……だめです。生徒会長の任期中は、言えません"
            voice "audio/voice/chika_a4_heart_17.mp3"
            chika "任期が終わっても、まだ言えません。……卒業するまでは、先輩なので"
    scene bg student_council_night
    with dissolve
    show chika soft
    with dissolve
    "先輩は、そっと手を引いて、アルバムを胸に抱えた。"
    voice "audio/voice/chika_a4_heart_18.mp3"
    chika "……今日のことも、記録にはありません。あくびも、です"
    "窓の外で、グラウンドの照明が、一つずつ消えていった。"
    hide chika
    with dissolve
    $ set_flag("告白の前ぶれ", "千夏")
    return

## あげは：夕方のグラウンド。『推し』フォルダ
label a4_heart_ageha:
    scene black
    with dissolve
    $ set_cal("7月30日（金）", "夕方")
    scene bg kohoku_ground_eve
    with dissolve
    $ bgm("あたたかいアコースティックギター")
    "練習のあと、ボールを片づけていると、ベンチであげはがスマホを抱えて固まっていた。"
    show ageha serious
    with dissolve
    voice "audio/voice/ageha_a4_heart_01.mp3"
    ageha "……ねえ。ちょっと相談。マジのやつ"
    voice "audio/voice/ageha_a4_heart_02.mp3"
    ageha "あたしのスマホの『推し』フォルダ、見て"
    "画面いっぱいに、写真が並んでいた。ほとんど、俺だった。練習。試合。水を飲んでいるところ。"
    ren "……多くないか"
    voice "audio/voice/ageha_a4_heart_03.mp3"
    ageha "多いの。問題は、そこじゃなくて"
    "あげはは、画面を下へ流した。春の写真は、どれも遠くから撮ったものだった。夏に近づくほど、近くなっていた。"
    voice "audio/voice/ageha_a4_heart_04.mp3"
    ageha "推しってさ、遠くから見るもんじゃん。ステージの下から、きゃーって"
    voice "audio/voice/ageha_a4_heart_05.mp3"
    ageha "なのに最近、近すぎて。プリクラとか、追試とか。推しの横、普通に座ってるし"
    show ageha normal
    voice "audio/voice/ageha_a4_heart_06.mp3"
    ageha "これ、ファンとして、アウトじゃない？"
    menu:
        "「アウトでいい。近くにいろ」":
            $ a4_heart_answer = "near"
            $ heart_up("あげは", "ときめき", 6)
            voice "audio/voice/ageha_a4_heart_07.mp3"
            ageha "っ……"
            hide ageha
            scene cg a4_heart_ageha at cam_push(10.0, 1.04)
            with Dissolve(0.8)
            "あげはは、スマホを顔の前に上げて、顔を隠した。スマホの上から、目だけがこっちを見ていた。"
            voice "audio/voice/ageha_a4_heart_08.mp3"
            ageha "……今の、録音しとけばよかった。いや、しなくてよかった。心臓もたない"
        "「ファンじゃなくて、マネージャーだろ」":
            $ a4_heart_answer = "manager"
            $ heart_up("あげは", "ときめき", 4)
            $ heart_up("あげは", "信頼", 3)
            voice "audio/voice/ageha_a4_heart_09.mp3"
            ageha "……そっか。マネージャーか"
            voice "audio/voice/ageha_a4_heart_10.mp3"
            ageha "マネージャーなら、近くにいても、セーフか。……セーフだよね？"
            hide ageha
            scene cg a4_heart_ageha at cam_push(10.0, 1.04)
            with Dissolve(0.8)
            "あげはは、スマホを顔の前に上げて、顔を隠した。スマホの上から、目だけがこっちを見ていた。"
    voice "audio/voice/ageha_a4_heart_11.mp3"
    ageha "……あたし、推し、やめるかも"
    ren "嫌いになったのか"
    voice "audio/voice/ageha_a4_heart_12.mp3"
    ageha "逆！　……あ"
    "あげはは、自分の口を両手でふさいだ。"
    voice "audio/voice/ageha_a4_heart_13.mp3"
    ageha "今のなし！　わかんないなら、いい！　パイセンは、そのまま、わかんないでいて！"
    scene bg kohoku_ground_eve
    with dissolve
    "あげはは、部室のほうへ走っていった。ベンチに、スマホを置いたまま。"
    "三秒後に走って戻ってきて、スマホをひったくって、また走っていった。"
    $ set_flag("告白の前ぶれ", "あげは")
    return
