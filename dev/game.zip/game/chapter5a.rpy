## chapter5a.rpy ―― 第5章「ひざ」ルートA（港北に残る）・高2の9〜10月（v0.32.0・Claude の第1稿。作者が読んで直す）
##   構成案：ルートA 第5章「ひざ」構成案（Claude Docs）。決まったことは「第5章_決定事項」
##   9/1 始業式 → 9/3 大学病院（手術するなら10/8。決めるのは10/5まで）→ 自由行動①（9月・4日）
##   → 9/25 文化祭 → 10/2 決める前の声（黒田・佐伯・あげは）→ 10/3 だれに話すか（ひなた／母／黒田／だれにも）
##   → 母が父の話をする（はやせ食堂の夜）→ 10/5 運命の選択②「手術する／しない」
##   選手権予選（10〜11月）は chapter5a_2.rpy、12〜3月は chapter5a_3.rpy、自由行動と夜のトークは chapter5a_free.rpy
##
##   ※ 製品版（有料）の部分。第4章の最後（8/31）から続く
##   ※ 恋愛の場面（クリスマス・バレンタイン・千夏の卒業式）も Claude が下書きした（作者の決定 11/2）。確認帳で1か所ずつ確かめる
##   ※ 新しい背景・一枚絵は、まだ描いていない（下の「仮の絵」。今ある絵に「準備中」の文字をのせて出す）

default a5_clinic = ""          # 9/3 大学病院の行き帰り、母さんと：talk（話した）/ quiet（黙っていた）
default a5_tell = ""            # 10/3 決める前に話した相手：hinata / mother / kuroda / alone（だれにも言わずに決める）
default a5_surgery = None       # 運命の選択②：True（手術する）/ False（しない）
default a5_fest_with = ""       # 文化祭でいっしょに回った人：hinata / chika / ageha / team
default a5_fest_pk = ""         # 文化祭のPKチャレンジで：kick（自分で蹴る）/ koba（小早川に蹴らせる）
default a5_ageha_saw = ""       # あげはが動画でひざに気づいたとき：told（話す）/ hush（「だれにも言うな」）

## 第5章の絵（v0.32.1 で仮の絵から差し替え）
image bg a5_clinic = "images/bg/a5_clinic.jpg"
image bg a5_ward = "images/bg/a5_ward.jpg"
image bg a5_fest_class = "images/bg/a5_fest_class.jpg"
image cg a5_mother_night = "images/cg/a5_mother_night.jpg"
image cg a5_fest_hinata = "images/cg/a5_fest_hinata.jpg"
image cg a5_fest_chika = "images/cg/a5_fest_chika.jpg"
image cg a5_fest_ageha = "images/cg/a5_fest_ageha.jpg"

## ---------------------------------------------------------------------------
## 第5章のカレンダーと、自由行動の表（第4章の仕組みをそのまま使う。月の名前は a5sep / a5dec）
##   init 1：第4章・practice.rpy の表ができたあとに足す
## ---------------------------------------------------------------------------
init 1 python:
    CHAPTER_YEAR["chapter5a"] = 2027
    CAL_SCHEDULE.update({
        (2027, 9, 1): ("始業式", False, True),
        (2027, 9, 3): ("大学病院", False, (2027, 8, 31)),
        (2027, 9, 25): ("文化祭", False, True),
        (2027, 10, 5): ("返事の日", False, (2027, 9, 3)),       # 9/3 医者「10月5日までに」
        (2027, 10, 8): ("手術の枠", False, (2027, 9, 3)),
        (2027, 10, 9): ("選手権予選", True, (2027, 9, 1)),       # 9/1 黒田「1回戦は、10月9日だ」
        (2027, 10, 16): ("2回戦", True, (2027, 10, 10)),
        (2027, 10, 23): ("3回戦", True, (2027, 10, 17)),
        (2027, 10, 30): ("準々決勝", True, (2027, 10, 24)),
        (2027, 11, 6): ("準決勝", True, (2027, 10, 31)),
        (2027, 11, 14): ("決勝", True, (2027, 10, 31)),
        (2027, 12, 24): ("クリスマス", False, True),
        (2028, 1, 1): ("元日", False, True),
        (2028, 2, 14): ("バレンタイン", False, True),
        (2028, 3, 1): ("卒業式", False, True),
    })
    CAL_EVENTS.extend([
        ((2027, 10, 5), "手術の返事"),
        ((2027, 10, 9), "選手権予選"),
        ((2027, 11, 6), "準決勝"),
        ((2028, 3, 1), "千夏先輩の卒業式"),
    ])
    A4_FREE["a5sep"] = (["9月6日（月）", "9月8日（水）", "9月10日（金）", "9月13日（月）"], "放課後", "9月の放課後、どこへ行く？")
    A4_FREE["a5dec"] = (["12月6日（月）", "12月8日（水）", "12月10日（金）", "12月13日（月）"], "放課後", "12月、どこへ行く？")
    A4_RECAP["a5sep"] = ("8月30日の検診で、医者に言われた。\n「このまま高3の冬まで行くなら、どこかで、もう一度切れる」\n\n"
                         "9月3日、大学病院。\n手術するなら、10月8日。選手権予選には出られない。\n返事は、10月5日まで。\n\n"
                         "佐伯さんの名刺が、机の上にある。")
    A4_RECAP["a5dec"] = ("選手権予選は、準決勝で清翔学園に負けた。\n決勝は、桜嶺が勝った。\n\n"
                         "千夏先輩は、3月1日に卒業する。\n「その日、頼みたいことがあります」")
    PRACTICE_ADVICE["a5sep"] = ("技術", "選手権の1回戦まで、1か月だ。……お前が出る時間は、俺が決める。そのかわり、出た時間で、必ず一つ仕事をしろ")
    PRACTICE_ADVICE["a5dec"] = ("", "大会は終わった。……来年の夏に、何を持っていくか決めろ")


################################################################################
## 第5章の入口（第4章の a4_end のあとから）
################################################################################
label chapter5a:
    $ quick_menu = True
    $ play_marks["chapter5a"] = renpy.get_game_runtime()   # 古いセーブで続きが見つからないとき、ここから続ける
    call show_title("第5章", "ひざ")
    call a5_sep_first_day
    call a5_clinic_day
    call a5_free_loop("a5sep")
    call a5_festival
    call a5_voices
    call a5_tell_day
    call a5_father
    call a5_fate
    jump chapter5a_2


################################################################################
## 9月1日：始業式の朝
################################################################################
label a5_sep_first_day:
    scene black
    with dissolve
    $ set_cal("9月1日（水）", "朝")
    scene bg shokudo_day
    with dissolve
    $ bgm("日常の静かな曲")
    "朝6時に、鷹野とグラウンドでボールを蹴った。家に戻って制服に着替えると、店の前の道に、まだ蝉の声が残っていた。"
    show mother normal
    with dissolve
    if a4_checkup_mother == "told":
        haha "金曜、大学病院だからね。店は昼で閉める。……もう、張り紙も書いた"
        "入口のガラスに、母さんの字で「9月3日（金）は、午後休みます」と貼ってあった。"
        haha "検診の先生が、紹介状を書いてくれた。くわしく撮って、くわしく聞いてきな"
        $ a5_clinic = "talk"
    else:
        haha "金曜、大学病院だからね。店は昼で閉める"
        ren "……なんで、知ってるんだ"
        haha "検診の先生から、電話があった。あんたは未成年だから、紹介状は、親に渡すんだってさ"
        show mother sadsmile
        haha "……あんたの口から、聞きたかったけどね"
        "母さんは、それだけ言って、味噌汁をよそった。"
        $ a5_clinic = "quiet"
    hide mother
    with dissolve
    ## 学校まで：ひなた
    scene bg slope_eve
    with dissolve
    $ bgm("あたたかいアコースティックギター")
    "坂の下で、ひなたが待っていた。カバンから、ノートの角がはみ出していた。表紙に「ひざ」。"
    show hinata normal
    with dissolve
    hinata "おはよ。……眉毛、まだ寝てるね"
    if flags.get("ひなた_うそ一覧_閉じた") or flags.get("a4_検診_誘った"):
        ## 8/30 の検診に、ひなたがいた
        hinata "ノート、2冊目になったよ。手術のことと、しないで続けた人のこと、両方書いた"
        hinata "読みたくなったら、言って。読みたくなかったら、言わなくていい"
        ren "……ありがとう"
        show hinata pout
        hinata "お礼は、いらない。マネージャーの仕事だもん"
    else:
        hinata "……ねえ。昨日の紅白戦のあと、テーピング、自分でほどいたでしょ。巻き方、変わってた"
        hinata "検診、どうだったの"
        ren "……いつもどおり"
        show hinata stare
        hinata "ふうん"
        "ひなたは、それ以上は聞かなかった。かわりに、ノートを、カバンの奥に押しこんだ。"
        $ heart_up("ひなた", "さみしさ", 2)
    hide hinata
    with dissolve
    ## 始業式のあと：部室
    $ set_cal("9月1日（水）", "放課後")
    scene bg clubroom
    with dissolve
    $ bgm("明るい部活の曲")
    "始業式のあと、部室に全員が集まった。黒田が、ホワイトボードに日付を一つだけ書いた。"
    "「10月9日」"
    show kuroda board
    with dissolve
    kuroda "選手権予選の1回戦だ。……去年は、準決勝で桜嶺に負けた。今年の夏も、準決勝で桜嶺に負けた"
    kuroda "三回目は、ない。……それだけだ"
    hide kuroda
    with dissolve
    show kobayakawa jersey
    with dissolve
    kobayakawa "……先生。今の、もう少し長く話してもらえますか。メモが取れませんでした"
    "部室が、小さく笑った。黒田は、笑わなかった。けれど、ホワイトボードの日付を、赤いペンで丸く囲んだ。"
    hide kobayakawa
    with dissolve
    "丸の中の「9」を見ながら、右ひざに手を置いた。"
    "10月9日まで、あと38日。"
    "その日付の上に、自分がピッチに立っているのかどうか、まだ分からなかった。"
    return


################################################################################
## 9月3日：大学病院
##   手術すれば半年。今やれば、高3の夏に間に合う。しなければ、選手権に出られるが、次は保証できない
##   手術の枠は 10/8。返事は 10/5 まで
################################################################################
label a5_clinic_day:
    scene black
    with dissolve
    $ set_cal("9月3日（金）", "午後・大学病院")
    scene bg a5_clinic
    with dissolve
    $ bgm("静かなピアノ")
    "大学病院の診察室は、町の病院より、白かった。壁も、机も、先生の髪も。"
    "画面に、俺の右ひざが、輪切りになって並んでいた。"
    isha "中学3年の冬に、ここの{rb}靱帯{/rb}{rt}じんたい{/rt}を、一度傷めているね"
    isha "そのときは、手術しないで治した。よくもってる。……でも、まわりが、すり減ってきてる。このまま走れば、次は、ここが切れる"
    "先生は、画面の上の白い線を、ペンの先で軽くたたいた。"
    isha "手術をするなら、今だね"
    isha "今やれば、半年。春には走れる。高3の夏の大会には、たぶん、間に合う"
    isha "冬の大会が終わってからやると、春に間に合わない。高3の夏も、出られない"
    ren "……今やったら、冬の大会は"
    isha "出られない。……外から見ることになる"
    "隣で、母さんのハンドバッグの持ち手が、きゅっと鳴った。"
    isha "しないなら、痛み止めと、サポーターと、出る時間の決まりで、冬を戦う。それも、一つのやり方だよ"
    isha "ただ、そのあとは、保証できない。……切れるのが、冬の大会の途中かもしれないし、高3の決勝かもしれない"
    isha "手術の枠は、10月8日に一つ空いてる。返事は、10月5日までに"
    isha "決めるのは、君だよ。……大人の言うことを聞いて決めると、あとで、大人のせいにしたくなるからね"
    "診察室の時計の秒針の音が、急に大きく聞こえた。"
    ## 帰り：電車の中
    $ set_cal("9月3日（金）", "夕方")
    scene bg train_eve
    with dissolve
    $ bgm("日常の静かな曲")
    "帰りの電車は、すいていた。ボックス席に、母さんと並んで座った。"
    show mother normal
    with dissolve
    if a5_clinic == "talk":
        haha "……36日か。10月9日まで"
        ren "数えてたのか"
        haha "あんたが数えてる顔してたからね"
        show mother sadsmile
        haha "どっちに決めても、あたしは米を炊く。それは、8月に言ったとおり"
        haha "でも、一個だけ。……決めたら、決めた理由を、あたしに話しな。それだけ"
        $ up("メンタル", 1)
    else:
        "母さんは、窓の外を見ていた。俺も、反対側の窓の外を見ていた。"
        "港北のひとつ前の駅で、母さんが、ぽつりと言った。"
        haha "……お父さんもね、病院の帰りは、いつも窓の外を見てた"
        "それ以上は、何も言わなかった。"
        "父さんの話を母さんがしたのは、ずいぶん久しぶりだった。"
        $ up("無理ゲージ", 1)
    hide mother
    with dissolve
    ## 夜：知らせが来る（話した相手から）
    scene black
    with dissolve
    $ set_cal("9月3日（金）", "夜", quiet=True)
    scene bg ren_room_night
    with dissolve
    $ bgm("静かな夜の曲")
    if flags.get("a4_検診_黒田に話した"):
        $ se("トークアプリの通知音")
        window auto hide
        $ talk_start("黒田", "21:12")
        $ talk("黒田", "病院、どうだった")
        $ talk_wait(3)
        $ talk_me("手術するなら、10月8日です。返事は5日まで")
        $ talk_wait(4)
        $ talk("黒田", "分かった")
        $ talk("黒田", "明日の練習、お前は40分までだ")
        window auto hide
        $ talk_end()
        "絵文字も、はげましも、なかった。"
        "それが、黒田なりの、いちばんやさしい返事だと分かるくらいには、もう一年半、あの人を見ていた。"
    else:
        "机の上に、佐伯さんの名刺と、今日の検査の紙を並べた。"
        "検査の紙のほうが、重かった。"
    return


################################################################################
## 9月25日（土）：文化祭
##   サッカー部の出し物（PKチャレンジ）・あげはの部のアカウント・千夏の最後の生徒会の仕事
##   蓮はひざのことを、まだ言えない（「大丈夫」）
################################################################################
label a5_festival:
    scene black
    with dissolve
    $ set_cal("9月25日（土）", "文化祭")
    scene bg kohoku_ground_day
    with dissolve
    $ bgm("とぼけた日常の曲")
    "港北の文化祭は、あと三回で終わる。小早川たちが3年になる年が、最後だ。"
    "サッカー部の出し物は、グラウンドの端の「PKチャレンジ」。大門から一本決めたら、商店街のコロッケ券がもらえる。"
    "坂口が商店街を回って、コロッケ券を30枚、タダでもらってきた。どうやったのかは、誰も聞かなかった。"
    show daimon jersey
    with dissolve
    daimon "……もう、四十人止めました。コロッケ券、一枚も減ってません"
    sakaguchi "大門、空気読め！　小学生には、ちょっとは入れさせろって！"
    daimon "……す、すみません。体が、勝手に……"
    hide daimon
    with dissolve
    show ageha normal
    with dissolve
    $ meet("あげは")
    ageha "パイセン、配信まわしてまーす！　『港北サッカー部・文化祭スペシャル』、同接、もう三百！"
    ageha "大門パイセンのセーブ集、切り抜いたら絶対バズる。……あ、パイセン、ちょっと映って。手、振って"
    "言われるままに、カメラに手を振った。画面の右上で、数字がぴょんと跳ねた。"
    hide ageha
    with dissolve
    "そのとき、列に並んでいた小学生が、俺を指さした。"
    kid "あ。ねえ、あの人、新聞の人でしょ。[a4_no()]番の"
    kid "お兄ちゃん、一本蹴って！　大門からゴール決めるとこ、見たい！"
    "小学生が三人、四人と、まわりに集まってきた。"
    "右ひざが、朝から、熱を持っていた。"
    menu:
        "自分で蹴る":
            $ a5_fest_pk = "kick"
            $ lean("野心型")
            $ up("無理ゲージ", 2)
            "ボールを置いて、三歩下がった。右足で踏みこむと、ひざの奥が、小さくきしんだ。"
            $ se("ボールを蹴る音")
            "ボールは、ゴールの右の角に吸いこまれた。大門は、わざと逆に飛んでいた。"
            $ se("ネットが揺れる音")
            "小学生が、跳びはねた。あげはのスマホの画面で、数字がまた跳ねた。"
            "笑って手を振りながら、右足に体重をかけないように、ゆっくり歩いて戻った。"
        "小早川に蹴らせる":
            $ a5_fest_pk = "koba"
            $ lean("仲間型")
            ren "今日は、こいつが[a4_no()]番だ。……小早川、決めろ"
            show kobayakawa jersey
            with dissolve
            kobayakawa "……え。僕、ですか"
            "小早川は、ボールを置く前に、首を二回振った。ゴールの前に、何もないのに。"
            $ se("ボールを蹴る音")
            "ボールは、大門の指先をかすめて、ネットを揺らした。"
            $ se("ネットが揺れる音")
            kobayakawa "……入りました。先輩、入りました"
            ren "見てた"
            hide kobayakawa
            with dissolve
            "小学生たちは、すぐに小早川のまわりに集まった。小早川は、困った顔で、全員と握手していた。"
            $ bond_up("大門", 1)
    ## 昼すぎ：だれと回るか
    scene bg a5_fest_class
    with dissolve
    $ bgm("のんびりした春の曲")
    "昼すぎに、黒田から「交代だ。休め」とトークが来た。休め、のところだけ、太字だった。"
    "校舎の中は、どこも、ソースと砂糖のにおいがした。"
    ## 揺れる場面（v0.33.2）：ときめきの上の2人が近いときは、2人から同時に
    $ _sw5f = sway_pair(["ひなた", "千夏", "あげは"])
    if _sw5f:
        call a5_fest_sway
        jump a5_fest_evening
    menu:
        "だれと、回る？"
        "ひなたのクラスのメイド喫茶へ":
            $ a5_fest_with = "hinata"
            call a5_fest_hinata
        "生徒会の写真館をのぞく":
            $ a5_fest_with = "chika"
            call a5_fest_chika
        "体育館のステージを見にいく（あげはの出番）":
            $ a5_fest_with = "ageha"
            call a5_fest_ageha
        "部のみんなと、焼きそばの列に並ぶ":
            $ a5_fest_with = "team"
            call a5_fest_team
    ## 夕方：片づけのグラウンド
label a5_fest_evening:
    scene bg kohoku_ground_eve
    with dissolve
    $ bgm("静かな春の曲")
    "夕方、PKチャレンジのゴールを片づけた。コロッケ券は、結局、八枚しか減らなかった。"
    "ゴールを運ぶとき、右足をかばって、半歩遅れた。"
    show takano jersey_narrow
    with dissolve
    takano "……足、大丈夫か"
    "反射的に、口が動いた。"
    ren "大丈夫"
    "鷹野は、それ以上は聞かなかった。かわりに、俺の持っていたゴールの端を、黙って持ちかえた。"
    hide takano
    with dissolve
    "大丈夫。"
    "その一言を、どこかで、何度も聞いたことがある気がした。"
    $ set_flag("a5_大丈夫")
    return

## 揺れる場面（v0.33.2・Claude の下書き）：休憩の2時に、2つの声がかかる
label a5_fest_sway:
    $ _sa, _sb = _sw5f
    "PKチャレンジのテントを出ようとしたところで、立て続けに、声がかかった。"
    call a5_fest_sway_ask(_sa)
    call a5_fest_sway_ask(_sb)
    $ _pl = {"ひなた": "三階の教室", "千夏": "生徒会室", "あげは": "体育館"}
    $ _pa, _pb = _pl[_sa], _pl[_sb]
    "どちらも、2時だった。[_pa]と、[_pb]。休憩は、一時間しかなかった。"
    $ _sa_call = {"千夏": "千夏先輩"}.get(_sa, _sa)
    $ _sb_call = {"千夏": "千夏先輩"}.get(_sb, _sb)
    menu:
        "[_sa_call]のところへ行く":
            $ a5_fest_with = {"ひなた": "hinata", "千夏": "chika", "あげは": "ageha"}[_sa]
            $ sway_pick(_sa, _sb)
            $ _fl = _sb
        "[_sb_call]のところへ行く":
            $ a5_fest_with = {"ひなた": "hinata", "千夏": "chika", "あげは": "ageha"}[_sb]
            $ sway_pick(_sb, _sa)
            $ _fl = _sa
        "どちらにも行かず、部のみんなと焼きそばの列に並ぶ":
            $ a5_fest_with = "team"
            $ sway_none(_sa, _sb)
            $ _fl = ""
    call expression "a5_fest_" + a5_fest_with
    if _fl:
        call a5_fest_sway_left(_fl)
    return

label a5_fest_sway_ask(who):
    if who == "ひなた":
        "ひなたのクラスの女子が一人、PKの列を横から抜けて、俺の前に来た。ボールには、目もくれなかった。"
        "「早瀬くん、ひなたが教室で呼んでたよ〜。2時から休憩なんだって〜」"
        "言うだけ言うと、その子は、手をひらひらさせて、走って帰っていった。……ひなたが俺を呼ぶときは、いつも、自分でトークを送ってくる。"
    elif who == "千夏":
        $ se("トークアプリの通知音")
        window auto hide
        $ talk_start("千夏", "13:48")
        $ talk("千夏", "生徒会の写真館は、2時から、受付がわたし一人になります")
        $ talk("千夏", "……予定の報告です")
        window auto hide
        $ talk_end()
    else:
        show ageha normal
        with dissolve
        voice "audio/voice/ageha_a5sw_fest_01.mp3"
        ageha "パイセン、交代？　ナイスタイミング！　2時、体育館。最前列、一個だけ空けとくから"
        voice "audio/voice/ageha_a5sw_fest_02.mp3"
        ageha "……来なかったら、配信で、名前出すからね。うそ。出さない。来て"
        hide ageha
        with dissolve
    return

label a5_fest_sway_left(who):
    if who == "ひなた":
        "帰りに、三階の廊下を通った。メイド喫茶ののれんのすきまから、ひなたと、一瞬だけ目が合った。"
        "ひなたは、すぐに、のれんの奥へ引っこんだ。"
    elif who == "千夏":
        window auto hide
        $ talk_start("千夏", "15:02")
        $ talk("千夏", "2時から3時まで、受付に座っていました")
        $ talk("千夏", "それだけの報告です")
        window auto hide
        $ talk_end()
    else:
        "あげはの部のアカウントに、パラパラの動画が上がっていた。最前列の、いちばん端の一席だけが、空いていた。"
    return

## ひなた：クラスのメイド喫茶。この日だけ、蓮がノッておちょくる（作者の声 11/3）
label a5_fest_hinata:
    "ひなたのクラスの入口に、手書きの看板が出ていた。「メイド喫茶　2年3組」。"
    "のれんをくぐると、白いエプロンにフリルのカチューシャをつけたひなたが、こっちを見て、固まった。"
    show hinata apron
    with dissolve
    voice "audio/voice/hinata_a5_fest_01.mp3"
    hinata "……なんで、来たの"
    voice "audio/voice/hinata_a5_fest_02.mp3"
    hinata "来ないでって、言わなかったっけ。……言ってなかった。言っとけばよかった"
    "ひなたの後ろで、クラスの女子が「篠宮、決まり文句！」と小声で言った。"
    "ひなたは、エプロンのすそを両手でぎゅっとつかんで、目をつぶった。"
    hide hinata
    scene cg a5_fest_hinata
    with Dissolve(1.0)
    voice "audio/voice/hinata_a5_fest_03.mp3"
    hinata "……お、おかえりなさいませ。ご、ご主人さま"
    "教室じゅうが、拍手した。ひなたの耳が、見たことがないくらい赤かった。"
    "いつもなら「おう」で終わらせるところだった。でも、今日は文化祭だった。"
    menu:
        "「……ただいま。今日のおすすめは？　メイドさん」":
            $ lean("仲間型")
            ren "……ただいま。今日のおすすめは？　メイドさん"
            "ひなたは、カチューシャごと固まった。三秒たってから、ゆっくり目を開けた。"
            voice "audio/voice/hinata_a5_fest_04.mp3"
            hinata "……の、ノるの！？　蓮が！？　いつも「おう」しか言わないのに！？"
            voice "audio/voice/hinata_a5_fest_05.mp3"
            hinata "お、おすすめは、ミックスジュースです、ご主人さま。……ひざに、いいものしか入れてないです"
            "ひなたは、注文票で顔を半分かくした。かくれていないほうの頬が、ジュースのいちごより赤かった。"
            $ heart_up("ひなた", "ときめき", 5)
            $ heart_up("ひなた", "信頼", 1)
        "「メニューの『おいしくなるおまじない』って、ひなたがやるのか」":
            $ lean("野心型")
            ren "メニューの『おいしくなるおまじない』って、ひなたがやるのか"
            voice "audio/voice/hinata_a5_fest_06.mp3"
            hinata "や、やらない！　それは、別メニュー！　別料金！"
            ren "じゃあ、払う"
            voice "audio/voice/hinata_a5_fest_07.mp3"
            hinata "……は、払うの！？"
            "クラスの女子たちが、いっせいに「おー」と言った。ひなたは、逃げ道を探すみたいに左右を見て、それから観念した。"
            "両手でハートを作ろうとして、途中で止めて、なぜか指で丸を作った。"
            voice "audio/voice/hinata_a5_fest_08.mp3"
            hinata "……お、おいしくなーれ。……今のは、サッカーボール。ハートじゃない。……ボール"
            $ heart_up("ひなた", "ときめき", 6)
    scene bg a5_fest_class
    with dissolve
    show hinata pout
    with dissolve
    "ジュースを持ってきたとき、ひなたは、伝票をテーブルにたたきつけるように置いた。"
    voice "audio/voice/hinata_a5_fest_09.mp3"
    hinata "……今日の蓮、ずるい。ノートに書いとく。「ご主人さま、調子に乗る」って"
    "伝票の裏には、小さく「午後のゴール運び、右足に体重かけないこと」と書いてあった。"
    show hinata smile
    voice "audio/voice/hinata_a5_fest_10.mp3"
    hinata "……いってらっしゃいませ。ご主人さま"
    hide hinata
    with dissolve
    return

## 千夏：生徒会の最後の出し物「男女逆転コスプレ写真館」。お互いを撮り合う（作者の声 11/3）
label a5_fest_chika:
    "生徒会室の前に、長い列ができていた。看板には「生徒会主催　男女逆転コスプレ写真館」。"
    "受付の机に、学ランを着た人が座っていた。少し大きい学生帽を、深くかぶっていた。"
    scene cg a5_fest_chika
    with Dissolve(1.0)
    voice "audio/voice/chika_a5_fest_01.mp3"
    chika "……いらっしゃいませ。いえ。……いらっしゃい。男子の言い方が、まだ分かりません"
    "千夏先輩だった。学ランの袖が、指の先まで余っていた。"
    voice "audio/voice/chika_a5_fest_02.mp3"
    chika "生徒会の、最後の出し物です。去年、企画書を出して、先生に却下されました"
    voice "audio/voice/chika_a5_fest_03.mp3"
    chika "任期は、来週で終わりです。なので、今年は、わたしを止める人がいません"
    "写真館の奥では、副会長の男子が、セーラー服でポーズを取らされていた。目が死んでいた。"
    if a4_chika_call == "早瀬くん":
        voice "audio/voice/chika_a5_fest_04_hy.mp3"
    else:
        voice "audio/voice/chika_a5_fest_04.mp3"
    chika "[a4_chika_call]の分も、あります。……サッカー部の分は、サイズをそろえてあります"
    voice "audio/voice/chika_a5_fest_05.mp3"
    chika "写真館なので、お互いを撮るのが決まりです。わたしがあなたを撮って、あなたがわたしを撮ります。……今、決めました"
    "断る前に、セーラー服とカーテンの向こうへ押しこまれた。スカートの下は、ジャージのままにさせてもらった。"
    "カーテンを開けた。"
    "千夏先輩は、カメラを構えたまま、一秒、止まった。"
    voice "audio/voice/chika_a5_fest_06.mp3"
    chika "……っ、ふ"
    voice "audio/voice/chika_a5_fest_07.mp3"
    chika "……っ、ふふ、あは、あははは……！"
    "先輩は、カメラを胸に抱えたまま、体を二つに折った。学生帽が、床に落ちた。"
    voice "audio/voice/chika_a5_fest_08.mp3"
    chika "す、すみません……っ、記録係は、笑っては……いけないのに……っ、お腹、いたい……"
    "副会長の男子が、「会長が笑ってるの、初めて見ました」と、セーラー服のまま言った。"
    "先輩は、涙をふきながら、三回シャッターを押した。三回とも、手がふるえていた。"
    voice "audio/voice/chika_a5_fest_09.mp3"
    chika "……はい、交代です。今度は、あなたが撮る番です"
    "先輩は、学生帽をかぶり直して、白い布の前に立った。まだ、肩が少しふるえていた。"
    menu:
        "「先輩、男子っぽく腕を組んでください」":
            $ lean("仲間型")
            "先輩は、腕を組もうとして、袖が余って、うまく組めなかった。組めないまま、むっとした顔で、カメラをにらんだ。"
            "その顔のまま、シャッターを押した。"
            voice "audio/voice/chika_a5_fest_10.mp3"
            chika "……今の、ずるいです。準備ができていません"
            $ heart_up("千夏", "ときめき", 5)
            $ heart_up("千夏", "信頼", 1)
        "「先輩、さっきみたいに笑ってください」":
            $ lean("求道型")
            voice "audio/voice/chika_a5_fest_11.mp3"
            chika "……さっきのは、事故です。注文して出せるものでは、ありません"
            "そう言いながら、先輩は、ファインダーの中で、こっちを見た。セーラー服の俺を、もう一回見た。"
            "また、ふき出した。シャッターを押した。"
            voice "audio/voice/chika_a5_fest_12.mp3"
            chika "……今のは、記録には入れません。わたしの手帳に、はさみます"
            $ heart_up("千夏", "ときめき", 6)
    scene bg a5_fest_class
    with dissolve
    show chika normal
    with dissolve
    "帰りぎわ、先輩は学生帽を取って、いつもの声で言った。"
    if a4_chika_call == "早瀬くん":
        voice "audio/voice/chika_a5_fest_13_hy.mp3"
    else:
        voice "audio/voice/chika_a5_fest_13.mp3"
    chika "[a4_chika_call]。今日、右足で、一度も踏み切っていません。……写真は、うそをつきません"
    "答えられないでいると、先輩は、学生帽をもう一度かぶって、受付に戻っていった。"
    hide chika
    with dissolve
    return

## あげは：1年有志のパラパラ。蓮が配信係（作者の声 11/3）
label a5_fest_ageha:
    scene bg gym_day
    with dissolve
    $ bgm("明るい部活の曲")
    "体育館のステージのプログラムに、手書きで一行足してあった。「1年有志　パラパラ（桃井ほか）」。"
    show ageha normal
    with dissolve
    voice "audio/voice/ageha_a5_fest_01.mp3"
    ageha "パイセン！　ちょうどいいとこに。今日の配信係に、任命しまーす"
    "あげはは、自分のスマホを、俺の両手に押しつけた。画面には、もう配信の準備ができていた。"
    voice "audio/voice/ageha_a5_fest_02.mp3"
    ageha "あたし、今から踊るから。正面から、全部撮って。手ブレしたら、推し失格ね"
    ren "推しに失格があるのか"
    voice "audio/voice/ageha_a5_fest_03.mp3"
    ageha "ある。今つくった"
    hide ageha
    with dissolve
    "ステージの照明が、ぱっとついた。古いユーロビートが、体育館の窓をびりびり鳴らした。"
    scene cg a5_fest_ageha
    with Dissolve(1.0)
    "五人の1年女子が、同じ動きで腕を回した。真ん中のあげはだけ、ほんの半拍、速かった。"
    "画面の中で、コメントが滝みたいに流れた。「センターの子だれ」「港北やば」。"
    "曲の最後の決めのポーズで、あげはは、客席じゃなく、カメラを――俺を、まっすぐ指さした。"
    scene bg gym_day
    with dissolve
    show ageha normal
    with dissolve
    "ステージを降りると、あげはは、息を切らしたまま走ってきた。"
    voice "audio/voice/ageha_a5_fest_04.mp3"
    ageha "どうだった！？　撮れた！？　最後の、撮れた！？"
    menu:
        "「最後のやつ、ちゃんと撮れた」":
            $ lean("仲間型")
            voice "audio/voice/ageha_a5_fest_05.mp3"
            ageha "……っしゃ。あれ、カメラ指したんじゃないから。……レンズの向こう、指したんだから"
            "あげはは、言ってから、自分で言ったことに気づいたみたいに、スマホをひったくった。"
            $ heart_up("あげは", "ときめき", 5)
            $ heart_up("あげは", "信頼", 1)
        "「半拍、速かった」":
            $ lean("求道型")
            voice "audio/voice/ageha_a5_fest_06.mp3"
            ageha "……は？　見てたの、そこ？　推しの粗探しは、あたしの仕事なんですけど"
            voice "audio/voice/ageha_a5_fest_07.mp3"
            ageha "でも、そこ見てたってことは、ずっとあたしだけ見てたってことじゃん。……ウケる。うれしい"
            $ heart_up("あげは", "ときめき", 4)
            $ heart_up("あげは", "信頼", 2)
    show ageha serious
    voice "audio/voice/ageha_a5_fest_08.mp3"
    ageha "……あとさ。配信、切る前に一個だけ"
    voice "audio/voice/ageha_a5_fest_09.mp3"
    ageha "パイセン、撮ってるあいだ、ずっと左足に体重のせてた。右足、なんか、かばってるっぽかった"
    voice "audio/voice/ageha_a5_fest_10.mp3"
    ageha "あたし、推しの変化には、うるさいからさ。……変なこと言ってたら、ごめん"
    "あげはは、返事を待たなかった。スマホを持って、ステージの仲間のほうへ走っていった。"
    hide ageha
    with dissolve
    return

## 部のみんな：焼きそばの列
label a5_fest_team:
    "焼きそばの列に、坂口たちと、1年たちと、大門と、鷹野が並んでいた。並んでいるだけで、列が二倍になった。"
    akasaka "早瀬先輩、知ってます？　来年、1年が入ってこないから、俺たち、ずっと「いちばん下」なんすよ"
    akasaka "最後の後輩っす。……かっこよくないすか"
    sakaguchi "かっこよくねーよ。お前ら、ずっとボール運び係だぞ"
    kurata "……運びます。いいです。運ぶの、好きなんで"
    "焼きそばは、[a4_members]人分には足りなかった。三パックを、みんなで分けた。"
    "鷹野が、自分の分を、黙って小早川のパックに入れていた。"
    $ bond_up("坂口", 2)
    $ bond_up("鷹野", 1)
    $ up("メンタル", 1)
    return


################################################################################
## 10月2日（土）：決める前の声（黒田・佐伯・あげは）
##   だれも、答えを押しつけない
################################################################################
label a5_voices:
    scene black
    with dissolve
    $ set_cal("10月2日（土）", "練習のあと")
    scene bg kohoku_ground_eve
    with dissolve
    $ bgm("静かな春の曲")
    "返事の日まで、あと3日だった。"
    "練習のあと、黒田は、いつものベンチで缶コーヒーを開けた。今日は、二本あった。一本を、黙って俺の前に置いた。"
    show kuroda normal
    with dissolve
    if flags.get("a4_検診_黒田に話した"):
        kuroda "……決めたか"
        ren "まだです"
        kuroda "そうか"
    else:
        kuroda "……お前の母親から、電話があった。店に来いと言われて、定食を食わされて、全部聞いた"
        kuroda "10月5日。……大学病院の返事の日だろう"
        "黒田は、からあげ定食がうまかったとは、言わなかった。"
        ren "……黙ってて、すみません"
        kuroda "謝るところじゃない。……言えなかったんだろう。俺も、言えなかった"
        $ set_flag("a5_黒田_母から聞いた")
    kuroda "手術しろとは、言わん。するなとも、言わん"
    kuroda "しないなら、お前が試合に出る時間は、俺が決める。最初から最後まで、一分も譲らん"
    kuroda "するなら、お前のいない十一人で、勝つ方法を考える。……俺の仕事は、それだけだ"
    "黒田は、缶コーヒーを一口だけ飲んで、グラウンドの向こうを見た。"
    kuroda "……一つだけ。止まれなかったやつを、俺は知ってる"
    kuroda "そいつは、止まれなかったんじゃない。止まり方を、誰にも聞かなかっただけだ"
    "誰の話かは、聞かなかった。聞いても、たぶん、今は答えないと思った。"
    hide kuroda
    with dissolve
    ## 佐伯
    "フェンスの外に、青いジャンパーが見えた。"
    show saeki normal
    with dissolve
    saeki "……[a4_no()]番"
    saeki "大学病院のリハビリには、うちの選手も世話になってる。……お前のことは、誰からも聞いちゃいない。聞かなくても、走り方で分かる"
    saeki "だから、俺の言えることだけ言う"
    saeki "クラブは、高2の冬の一試合で、選手を決めない。高3の夏の一試合でも、決めない"
    saeki "決めるのは、そいつが、これから十年、走れるかどうかだ"
    saeki "……名刺は、捨てるなよ。どっちにしてもな"
    "佐伯さんは、それだけ言って、帰っていった。手帳は、今日も持っていなかった。"
    hide saeki
    with dissolve
    ## あげは
    scene bg clubroom
    with dissolve
    $ bgm("日常の静かな曲")
    "部室に戻ると、あげはが、スマホを両手で持ったまま待っていた。"
    show ageha serious
    with dissolve
    ageha "……パイセン。これ、見て"
    "画面の中で、俺が走っていた。あげはの指が、動画を、ゆっくりにした。"
    "右足が地面につく瞬間。ほんの少しだけ、体が左に逃げていた。何十回見ても、同じだった。"
    if a5_fest_with == "ageha":
        ageha "8月から、毎日。……文化祭のとき、言ったじゃん。右足、かばってるっぽいって"
    else:
        ageha "8月から、毎日。……着地のとき、右足、いっつも後からついてる"
    ageha "これ、ひなたパイセンは、知ってるの。クロセンは。……みんな、知ってるの"
    menu:
        "「……全部、話す」":
            $ a5_ageha_saw = "told"
            $ lean("仲間型")
            "あげはに、大学病院で聞いたことを、そのまま話した。手術のこと。10月8日のこと。冬の大会のこと。"
            "あげはは、一度も動画を止めなかった。俺が話し終わるまで、画面の中の俺は、ずっと、ゆっくり走っていた。"
            ageha "……そっか"
            show ageha normal
            ageha "じゃあ、あたしは、どっちになっても撮る。手術したら、戻ってくるまで、毎日撮る。しないなら、試合を、全部撮る"
            ageha "推しの記録係は、あたしだから。……会長には、負けないから"
            $ heart_up("あげは", "信頼", 4)
        "「……だれにも、言うな」":
            $ a5_ageha_saw = "hush"
            $ lean("野心型")
            ren "……だれにも、言うな。動画にも、上げるな"
            show ageha normal
            ageha "上げないよ！　上げるわけないじゃん"
            "あげはは、スマホを胸に抱えた。"
            ageha "……でも、あたし、推しの秘密を守るのは、得意じゃないかも。顔に出るタイプだから"
            ageha "だから、早く、パイセンの口から、みんなに言って。……あたしの顔に出る前に"
            $ heart_up("あげは", "さみしさ", 3)
            $ up("無理ゲージ", 1)
    hide ageha
    with dissolve
    return


################################################################################
## 10月3日（日）：決める前に、だれに話すか
##   ひなた／母さん／黒田／だれにも言わずに決める（「だれにも」は、父と同じ道。信念タイプと結末にひびく）
################################################################################
label a5_tell_day:
    scene black
    with dissolve
    $ set_cal("10月3日（日）", "朝")
    scene bg ren_room_morning
    with dissolve
    $ bgm("静かなピアノ")
    if flags.get("ひなた_うそ一覧_閉じた") or flags.get("a4_検診_誘った"):
        "日曜の朝。机の上に、名刺と、検査の紙と、ひなたが貸してくれた「ひざ」のノートの2冊目。"
    else:
        "日曜の朝。机の上に、名刺と、検査の紙。返事の日まで、あと2日。"
    "一人で決めて、あとで言えばいい。……でも。"
    menu:
        "決める前に、だれに話す？"
        "ひなたに":
            $ a5_tell = "hinata"
            $ lean("仲間型")
            call a5_tell_hinata
        "母さんに":
            $ a5_tell = "mother"
            $ lean("仲間型")
        "黒田に":
            $ a5_tell = "kuroda"
            $ lean("求道型")
            call a5_tell_kuroda
        "だれにも言わずに、一人で決める":
            $ a5_tell = "alone"
            $ lean("求道型", 2)
            call a5_tell_alone
    return

## ひなた：港への坂道。本音で話す（作者の声 11/3「もっと本音で」）
label a5_tell_hinata:
    scene bg slope_eve
    with dissolve
    $ bgm("あたたかいアコースティックギター")
    "坂の途中のベンチに、ひなたは先に座っていた。トークを送ってから、十分もたっていなかった。"
    show hinata serious
    with dissolve
    voice "audio/voice/hinata_a5_tell_01.mp3"
    hinata "……眉毛。もう、ずっと上がりっぱなしだよ。夏から"
    "大学病院の先生に言われたことを、全部話した。ひなたは、ノートを開かなかった。俺の顔だけを見ていた。"
    "話し終わっても、ひなたは、しばらく何も言わなかった。それから、ノートを、ベンチの上に伏せた。"
    voice "audio/voice/hinata_a5_tell_02.mp3"
    hinata "……今日は、マネージャーとして話すの、やめていい？"
    voice "audio/voice/hinata_a5_tell_03.mp3"
    hinata "マネージャーなら、「決めるのは蓮だよ」って言う。わたし、ずっとそう言ってきた"
    show hinata teary
    voice "audio/voice/hinata_a5_tell_04.mp3"
    hinata "でも、ほんとは、手術してほしい。冬の大会なんか、どうでもいい"
    voice "audio/voice/hinata_a5_tell_05.mp3"
    hinata "蓮が、大人になっても、おじさんになっても、ふつうに走れるほうがいい。……わたし、蓮が走ってるとこ、ずっと見てたいの"
    voice "audio/voice/hinata_a5_tell_06.mp3"
    hinata "……わがままでしょ。蓮のひざなのに。わたしの気持ちの話、してる"
    "ひなたは、手の甲で目をこすった。こすっても、すぐにまた、にじんだ。"
    voice "audio/voice/hinata_a5_tell_07.mp3"
    hinata "……ねえ。蓮の本音は？　まだ、一回も聞いてない"
    menu:
        "「……こわい。どっちを選んでも」":
            $ lean("仲間型")
            ren "……こわい。手術しても、しなくても。どっちを選んでも、何か、なくなる"
            "言ってしまうと、声が、少しかすれた。"
            show hinata serious
            voice "audio/voice/hinata_a5_tell_08.mp3"
            hinata "……うん。それ、聞きたかった"
            voice "audio/voice/hinata_a5_tell_09.mp3"
            hinata "こわいって言える人は、一人で決めない。……わたし、それだけで、ちょっと安心した"
            $ heart_up("ひなた", "信頼", 5)
            $ up("無理ゲージ", -3)
        "「冬に、出たい。本当は」":
            $ lean("野心型")
            ren "冬に、出たい。……本当は。来年があるって分かってても、この冬を、捨てたくない"
            show hinata serious
            voice "audio/voice/hinata_a5_tell_10.mp3"
            hinata "……うん。知ってた。眉毛に書いてあった"
            voice "audio/voice/hinata_a5_tell_11.mp3"
            hinata "わたしの本音と、蓮の本音、反対だね。……でも、両方、ほんとのことだから"
            $ heart_up("ひなた", "信頼", 4)
            $ heart_up("ひなた", "ときめき", 2)
    voice "audio/voice/hinata_a5_tell_12.mp3"
    hinata "決めるのは、蓮。……これは、マネージャーじゃなくて、わたしとして言うね。どっちになっても、いちばん近くにいる"
    if flags.get("ひなた_トレーナー"):
        voice "audio/voice/hinata_a5_tell_13.mp3"
        hinata "手術するなら、リハビリは、わたしが見る。……まだ学生にもなってないけど、蓮が、わたしの最初の患者"
    if flags.get("ひなた_タオル"):
        voice "audio/voice/hinata_a5_tell_14.mp3"
        hinata "しないなら、タオル。……あの約束、今度は、本当に使うかもしれないから"
    hide hinata
    with dissolve
    return

## 黒田：職員室。「全部言え。誰かに」
label a5_tell_kuroda:
    scene bg staffroom
    with dissolve
    $ bgm("静かな春の曲")
    "日曜の職員室には、黒田しかいなかった。いつもどおり、ソファで寝ていた。"
    show kuroda peek
    with dissolve
    kuroda "……日曜だぞ"
    ren "相談があって来ました"
    "黒田は、片目だけ開けて、しばらく俺を見ていた。それから、起き上がって、ちゃんと座った。"
    show kuroda normal
    kuroda "……言え。全部だ"
    "大学病院のこと。佐伯さんのこと。あげはの動画のこと。どっちを選んでも、何かがなくなること。"
    "黒田は、最後まで一言もはさまなかった。"
    kuroda "俺は、28で、誰にも言わずに決めた。……決めたあとで、全部なくした"
    kuroda "お前は、言った。それだけで、俺より、もう一歩先にいる"
    kuroda "あとは、家で、もう一回言え。……俺に言ったことを、母親に"
    hide kuroda
    with dissolve
    $ up("メンタル", 2)
    return

## だれにも：港の防波堤で一人。ひなたへの「大丈夫」
label a5_tell_alone:
    scene bg harbor_sunset
    with dissolve
    $ bgm("静かなピアノ")
    "防波堤の先まで、一人で歩いた。"
    "手術する。しない。紙に二本、線を引いて、それぞれの下に、いいことと悪いことを書いた。"
    "どっちの線の下にも、同じくらいの数が並んだ。"
    $ se("トークアプリの通知音")
    window auto hide
    $ talk_start("ひなた", "16:40")
    $ talk("ひなた", "いま、どこ？")
    $ talk("ひなた", "眉毛、見せて")
    $ talk_wait(5)
    $ talk_me("大丈夫")
    $ talk_wait(2)
    $ talk("ひなた", "……大丈夫って、聞いてない")
    window auto hide
    $ talk_end()
    "既読のまま、スマホをポケットにしまった。"
    "夕日が、港の向こうの山に、半分だけ沈んでいた。"
    $ heart_up("ひなた", "さみしさ", 4)
    $ up("無理ゲージ", 2)
    $ set_flag("a5_一人で決めた")
    return


################################################################################
## 母さんが、父さんの話をする（はやせ食堂の夜）
##   父は、心臓の不調を誰にも言わず（市民病院の紹介状を、封も開けずに前掛けのポケットに入れたまま）、店と蓮のために「大丈夫」と言い続けて、心筋梗塞で亡くなった（作者の声 11/3：母が病名も亡くなり方も知っている形に）
##   「あの人は一人で決めて、一人で抱えて、いなくなった。あんたには、そうしてほしくない」
##   母さんに話すと決めた人は 10/3 の夜。ほかは 10/4（月）の夜
################################################################################
label a5_father:
    scene black
    with dissolve
    if a5_tell == "mother":
        $ set_cal("10月3日（日）", "夜")
    else:
        $ set_cal("10月4日（月）", "夜")
    scene bg shokudo_night
    with dissolve
    $ bgm("（なし）")
    "店ののれんは、もう中にしまってあった。カウンターの明かりだけが、ついていた。"
    show mother normal
    with dissolve
    if a5_tell == "mother":
        "母さんは、俺の顔を見るなり、湯のみを二つ出した。"
        haha "……座りな。話があるんでしょ"
        "大学病院のこと。返事の日のこと。どっちに決めても、何かがなくなること。全部、話した。"
        "母さんは、黙って聞いていた。聞き終わってから、湯のみのお茶を、ゆっくり一口飲んだ。"
    elif a5_tell == "alone":
        "店に入ると、母さんは、カウンターの奥で帳簿をつけていた。顔を上げて、俺を見て、ペンを置いた。"
        show mother serious
        haha "……あんた、今、お父さんと同じ顔してる"
        "心臓が、一回、変な音を立てた。"
    else:
        "母さんは、俺の顔を見て、湯のみを二つ出した。"
        if a5_tell == "kuroda":
            haha "黒田先生から、電話があったよ。「本人から話があると思います」って。……あの先生、電話だと、敬語なんだね"
        else:
            haha "ひなたちゃんがね、夕方、店の前を三回通った。何も言わないで。……あの子は、うそが下手だ"
    $ bgm("静かなピアノの旋律")
    show mother down
    "母さんは、カウンターの下の引き出しから、白い封筒を一枚出して、俺の前に置いた。"
    "四つに折りたたまれて、角がすり切れていた。封は、開いていなかった。表に、「大学病院　循環器科　御中」。"
    haha "お父さんの、紹介状"
    hide mother
    scene cg a5_mother_night
    with Dissolve(1.2)
    haha "お葬式のあとにね、前掛けのポケットから出てきたの"
    haha "胸が苦しいって、一人で町の病院に行ってた。くわしく調べなさいって、これをもらって。……それから半年、ポケットに入れたまま、毎日、ここに立ってた"
    haha "あたしが「どっか痛いの」って聞くと、「大丈夫」。毎回、笑って"
    haha "あんたが「とうちゃん、どうしたの」って聞いても、「大丈夫」"
    "覚えていなかった。"
    "でも、その声だけは、知っていた。文化祭の日、鷹野に向かって、自分の口から出たのと、同じ声だった。"
    haha "ある朝、仕込みの途中で、ここで倒れた。心臓だった"
    haha "救急車が来たときには、もう、何も言わなかった。……最後に聞いたのは、前の晩の「大丈夫」"
    "母さんは、カウンターの、ちょうど俺の手の横を、指でとんとんとたたいた。ここ、という意味だった。"
    haha "あの人は、一人で決めて、一人で抱えて、いなくなった"
    scene bg shokudo_night
    with dissolve
    show mother serious
    with dissolve
    haha "9月にあんたの紹介状を受け取ったとき、手がふるえたよ。……同じ封筒だったから"
    haha "蓮。あんたには、そうしてほしくない"
    haha "手術するか、しないか。それは、あんたが決めな。あんたのひざだから"
    haha "でも、一人で決めるのは、やめな。……誰かといっしょに決めた答えなら、どっちでも、あたしは、文句言わない"
    show mother sadsmile
    if ch3_nye == "mother":
        haha "前にも言ったでしょ。一人で抱えるのは、やめな、って。……あれ、半分は、お父さんへの文句だったんだよ"
    else:
        haha "一人で抱えるのは、やめな。……それ、ずっと、お父さんに言いたかった言葉なんだよ"
    menu:
        "「……手術のこと、いっしょに考えてくれ」":
            $ lean("仲間型")
            ren "……母さん。いっしょに、考えてくれ"
            "母さんは、目を見開いた。それから、封筒を引き出しに戻して、かわりに、店のメモ帳とボールペンを出した。"
            haha "よし。じゃあ、書き出そう。いいことと、悪いこと。……あたし、店の仕入れで、こういうの得意なんだから"
            "その夜、カウンターで、母さんと二人で、メモ帳を三枚使った。"
            "書き終わっても、答えは出なかった。でも、一人で考えていたときより、紙が、軽かった。"
            $ up("メンタル", 3)
            $ up("無理ゲージ", -3)
            $ set_flag("a5_母と決めた")
        "「父さんの写真、もっと近くで見てもいいか」":
            $ lean("求道型")
            ren "……父さんの写真、もっと近くで、見てもいいか"
            haha "どうぞ。……あんた、そこの写真、ちゃんと見たことなかったでしょ"
            "柱の前に立った。泥だらけのユニフォームの父さんは、いつもと同じ顔で笑っていた。"
            "右ひざに、白いテーピングが巻いてあった。何年も毎日見ていたのに、一度も気づかなかった。"
            haha "その日もね。ひざが痛いのに「大丈夫」って言って、最後まで試合に出たの。……昔から、そういう人"
            "写真の父さんに向かって、心の中で一回だけ言った。"
            "――俺は、言うよ。"
            $ up("メンタル", 2)
            $ set_flag("a5_父の写真")
    hide mother
    with dissolve
    $ set_flag("a5_父の話")
    return


################################################################################
## 10月5日（火）：運命の選択②「手術する／しない」
##   手術する：高2の選手権はスタンドから。無理ゲージを大きく下げ、高3の夏に戻る。仲間の絆が上がる
##   しない：痛み止めで出る。無理ゲージが大きく上がり、高3で再発の危険（第6章で鬼塚の「もう一度試す」につながる）
################################################################################
label a5_fate:
    scene black
    with dissolve
    $ set_cal("10月5日（火）", "放課後")
    scene bg kohoku_ground_eve
    with dissolve
    $ bgm("張りつめた静かな曲")
    "返事の日の放課後。練習が始まる前のグラウンドに、一人で立った。"
    "ゴールの前。去年の春、一人でボールを蹴っていた場所。"
    if a5_tell == "hinata":
        "――決めるのは蓮。わたしは、決めたほうの、いちばん近くにいる。"
    elif a5_tell == "kuroda":
        "――あとは、家で、もう一回言え。"
    elif a5_tell == "mother":
        "――誰かといっしょに決めた答えなら、どっちでも、あたしは、文句言わない。"
    else:
        "――あんた、今、お父さんと同じ顔してる。"
    "ベンチで、ひなたが、テーピングの箱を開けずに、ひざの上に置いて座っていた。"
    "部室の窓から、あげはがスマホを構えて、構えたまま、下ろした。"
    ## 運命の選択の前の案内とセーブ
    window auto hide
    tuto "ここは「運命の選択」です。選んだあと、物語の中では取り消せません。"
    tuto "高2の冬の大会と、高3の夏が、この選択で変わります。迷ったら、選ぶ前にセーブしておきましょう。"
    call screen save_prompt
    menu:
        "手術する（冬の大会は、外から見る）":
            $ a5_surgery = True
            $ lean("仲間型", 2)
        "手術しない（痛み止めで、冬の大会に出る）":
            $ a5_surgery = False
            $ lean("野心型", 2)
    $ set_flag("a5_手術", a5_surgery)
    scene black
    with Dissolve(1.5)
    if a5_surgery:
        mono "手術する。"
        mono "高2の冬を、手放す。"
        mono "そのかわり、高3の夏に、走れる足で帰ってくる。"
        call a5_fate_surgery
    else:
        mono "手術しない。"
        mono "高2の冬を、取りにいく。"
        mono "そのかわり、この先のどこかで、切れるかもしれない足で。"
        call a5_fate_no
    return

## 手術する：ベンチのひなた → 部室で、みんなに言う
label a5_fate_surgery:
    scene bg kohoku_ground_eve
    with dissolve
    $ bgm("静かな春の曲")
    "ベンチのひなたの隣に、座った。"
    show hinata serious
    with dissolve
    ren "……手術する。10月8日"
    "ひなたは、テーピングの箱を、ぎゅっと握った。"
    show hinata teary
    hinata "……うん"
    hinata "うん。……うん"
    "三回目の「うん」で、ひなたは、やっと箱を開けた。中に入っていたのは、テープじゃなかった。新しいノートだった。表紙に「リハビリ」。"
    show hinata smile
    hinata "どっちになってもいいように、両方、用意してたの。……こっちを、使う"
    hide hinata
    with dissolve
    ## 部室
    scene bg clubroom
    with dissolve
    "練習の前に、部室で、全員に言った。"
    "部員全員と、マネージャーの二人。誰も、すぐには何も言わなかった。"
    show daimon uniform_worried
    with dissolve
    daimon "……冬の大会、早瀬くん、いないんですか"
    daimon "……いや、あの、いいんです、いなくても……ち、違います、そういう意味じゃなくて"
    "大門は、言いかけては、首を振った。"
    show daimon uniform
    daimon "……僕が、止めます。早瀬くんがいないぶん、全部。……それで、いいですよね"
    hide daimon
    with dissolve
    show takano jersey
    with dissolve
    takano "……[a4_no()]番の位置、誰がやる"
    show kobayakawa jersey
    with dissolve
    kobayakawa "……僕が、やります"
    "小早川は、首を一回だけ振ってから、そう言った。"
    kobayakawa "春から、ずっと、先輩の後ろから、先輩の見ているところを見てきました。……全部じゃないけど、少しは、見えます"
    takano "……少しで、いい。足りねえ分は、俺が走る"
    hide kobayakawa
    hide takano
    with dissolve
    "黒田は、部室の入口に立ったまま、最後まで何も言わなかった。"
    "最後に、一言だけ言った。"
    show kuroda normal
    with dissolve
    kuroda "……練習を始める。早瀬。お前は今日から、ベンチで、俺の隣だ。全部見て、全部言え"
    hide kuroda
    with dissolve
    $ up("無理ゲージ", -25)
    $ up("技術", -2)
    $ up("フィジカル", -4)
    $ up("戦術眼", 3)
    $ up("注目度", -5)
    $ bond_up("大門", 5)
    $ bond_up("鷹野", 5)
    $ bond_up("坂口", 3)
    return

## 手術しない：黒田に言う → 黒田の「時間」
label a5_fate_no:
    scene bg kohoku_ground_eve
    with dissolve
    $ bgm("張りつめた静かな曲")
    "練習のあと、黒田のいるベンチまで歩いた。"
    show kuroda normal
    with dissolve
    ren "……手術は、しません。冬の大会に出ます"
    "黒田は、驚かなかった。缶コーヒーのプルタブを、指で何度か起こしては、戻した。"
    kuroda "そうか"
    kuroda "なら、決まりを言う。……1回戦から準々決勝までは、後半の20分だけだ。準決勝は、60分。それ以上は、一秒もない"
    kuroda "痛み止めは、医者の言った量だけ。篠宮のテーピングは、一周も減らすな"
    kuroda "それと、痛いときは――"
    ren "言います"
    "黒田は、片方の眉を上げた。それから、缶を開けた。"
    kuroda "……ならいい"
    hide kuroda
    with dissolve
    "ベンチの端で、ひなたが、テーピングの箱を開けた。中には、いつもの白いテープと、もう一つ、新しいノートが入っていた。表紙に「冬」。"
    show hinata serious
    with dissolve
    hinata "……どっちになってもいいように、両方、用意してたの。こっちを、使う"
    if flags.get("ひなた_タオル"):
        hinata "タオル、ベンチに置いとくから。……上げさせないでね"
    hide hinata
    with dissolve
    $ up("無理ゲージ", 8)
    $ up("注目度", 5)
    if a5_ageha_saw == "hush":
        "部室の窓のところで、あげはが、スマホを胸に抱えたまま、何も撮らずに立っていた。"
    return


################################################################################
## 章えらび：第5章から（第4章の終わり＝8/31 の状態。ふつうに遊んだくらいの値）
################################################################################
label cs_chapter5a:
    $ quick_menu = True
    $ music_stop(1.5)
    call cs_state5a
    jump cs_chapter5a_menu

## 第5章Aの頭の状態（章えらびと場面ジャンプで使う。v0.35.1 で分けた）
label cs_state5a:
    call cs_state4a
    python:
        met = met + ["あげは", "小早川", "倉田", "赤坂", "佐伯", "真壁"]
        stats = {"技術": 64, "フィジカル": 56, "戦術眼": 66, "メンタル": 60}
        hidden = {"無理ゲージ": 52, "注目度": 42}
        bond = {"鷹野": 70, "大門": 60, "三好": 52, "坂口": 45, "神城": 14}
        heart = {"ひなた": {"ときめき": 48, "信頼": 75, "さみしさ": 3},
                 "千夏": {"ときめき": 42, "信頼": 52, "さみしさ": 2},
                 "紗希": {"ときめき": 22, "信頼": 30, "さみしさ": 0},
                 "あげは": {"ときめき": 28, "信頼": 24, "さみしさ": 0}}
        flags.update({"鷹野_相棒": True, "a4_3年_冬まで": True, "千夏_記録": True, "港北の記録_聞いた": True,
                      "あげは_アカウント": True, "ひなた_トレーナー": True})
        a4_members = 17
        a4_captain = "ren"
        a4_takano = "push"
        a4_kamishiro = "final"
    return

label cs_chapter5a_menu:
    scene black
    if iap_testable():
        tuto "（作者の確認用）第5章の最初の場面は、第4章の終わりに、だれに話したかで変わります。"
    menu:
        "8/30 の検診のあと、母さんには？"
        "全部、話した":
            $ a4_checkup_mother = "told"
            $ flags["a4_検診_母に話した"] = True
        "「いつもどおり」と言った":
            $ a4_checkup_mother = "hide"
    menu:
        "8/31、黒田には？"
        "全部、話した":
            $ a4_end_kuroda = "told"
            $ flags["a4_検診_黒田に話した"] = True
        "「痛くない」と言った":
            $ a4_end_kuroda = "hide"
            $ flags["a4_検診_黒田に黙った"] = True
    menu:
        "検診の待合室に、ひなたは？"
        "いた（7月に誘った）":
            $ flags["a4_検診_誘った"] = True
        "いなかった":
            pass
    menu:
        "7月の「相棒」で、ひなたとタオルの約束をした？"
        "した":
            $ flags["ひなた_タオル"] = True
        "していない":
            pass
    if persistent.choice_hints is None:
        call choice_hint_ask
    jump chapter5a
