## Web 版のビルドのときだけ tools/web_lighten.py が足すファイル（プロジェクト本体には入れない）
##   音を MP3 に作り直したので、台本の「〜.ogg」を「〜.mp3」に読みかえ、ブラウザの WebAudio で鳴らす（iPhone の Safari 対策）
init python:
    def _web_audio_name(fn):
        if fn.startswith("audio/") and fn.endswith(".ogg"):
            return fn[:-4] + ".mp3"
        return fn
    if renpy.emscripten:
        config.audio_filename_callback = _web_audio_name
        config.webaudio_required_types = ["audio/mpeg"]
