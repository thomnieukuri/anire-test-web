## screens.rpy ―― 画面まわり（デザイン：放課後ノート）
##   セリフ枠・選択肢・タイトル・メニュー・セーブ／ロード・設定・ログ・確認ダイアログ
##   画像パーツは game/gui/ にある（作り直すときは同じファイル名で上書きする）

################################################################################
## 色とフォント
################################################################################

define FONT_JP = "fonts/NotoSansCJKjp-Regular-subset.otf"
define FONT_JP_B = "fonts/NotoSansCJKjp-Bold-subset.otf"

define INK = "#3c2d23"          # 鉛筆の文字
define INK_SOFT = "#8c735f"     # 薄い文字
define PEN_RED = "#cd4646"      # 赤ペン
define PEN_TEAL = "#2f6f76"     # 青緑のペン

## 蛍光ペン（ボタンにマウスを乗せたとき）
define HL = Frame("gui/highlight.png", 16, 10)


################################################################################
## 共通スタイル
################################################################################

style default:
    font FONT_JP
    size 26
    language "japanese-normal"
    color INK
    ## ▶ や ◀ が絵文字（青い四角）にならないように、フォントにある字はフォントで出す
    prefer_emoji False

style button:
    padding (12, 4, 12, 4)
    hover_background HL
    selected_background HL

style button_text:
    color INK_SOFT
    hover_color INK
    selected_color INK
    selected_font FONT_JP_B
    insensitive_color "#c8bba8"

style label_text:
    font FONT_JP_B
    color PEN_RED
    size 24

style frame:
    background Frame("gui/note_small.png", 14, 14)
    padding (22, 14, 22, 18)

style bar:
    ysize 18
    left_bar Solid("#f08c8c")
    right_bar Solid("#e6dbc4")

style slider:
    ysize 26
    xsize 440
    left_bar Solid("#f08c8c")
    right_bar Solid("#e6dbc4")
    thumb "gui/slider_thumb.png"
    thumb_offset 6

style vscrollbar:
    xsize 8
    base_bar Solid("#e6dbc4")
    thumb Solid("#c9a98a")
    unscrollable "hide"

style hyperlink_text:
    color PEN_TEAL


################################################################################
## 文字送りの合図（赤い▼が点滅）
################################################################################

image ctc_blink:
    "gui/ctc.png"
    yoffset 4
    block:
        linear 0.45 alpha 0.25
        linear 0.45 alpha 1.0
        repeat


################################################################################
## セリフ枠（ルーズリーフ）。名前はマスキングテープ
################################################################################

screen say(who, what):
    zorder 41       # トーク画面（スマホ）を出したまま地の文を出しても、セリフ枠が上に来るように
    window:
        id "window"

        ## 坂口の仲間（森・小池・江藤・野口）と2年の桐生・宮下が話すときは、セリフ枠の左上に顔の写真を貼る
        ##   4人が一言ずつ続けて話す場面が多いので、立ち絵を出し入れせずに、だれが話しているか分かるようにする（v0.28.0）
        ##   v0.30.0：その人の立ち絵が画面に出ているときは、顔の写真は出さない（二重にならないように）
        $ _sf = side_face_on(who)
        if _sf:
            add side_face(who) at side_photo

        if who is not None:
            window:
                id "namebox"
                style "namebox"
                if _sf:
                    xpos 168
                text who id "who"

        text what id "what"

        if quick_menu:
            use quick_buttons

style window:
    xalign 0.5
    yalign 1.0
    yoffset 6
    xsize 1224
    ysize 200
    background "gui/textbox.png"
    padding (0, 0, 0, 0)

style say_window is window

## 顔の写真（名前 → 画像）。写真は images/chara/face/ に、白いふちと影をつけて少し傾けて作ってある
define SIDE_FACE = {
    "森": "images/chara/face/mori.png",
    "小池": "images/chara/face/koike.png",
    "江藤": "images/chara/face/eto.png",
    "野口": "images/chara/face/noguchi.png",
    "桐生": "images/chara/face/kiryu.png",
    "宮下": "images/chara/face/miyashita.png",
    ## 第4章の人（v0.30.0）
    "小早川": "images/chara/face/kobayakawa.png",
    "倉田": "images/chara/face/kurata.png",
    "赤坂": "images/chara/face/akasaka.png",
    "真壁": "images/chara/face/makabe.png",
    "佐伯": "images/chara/face/saeki.png",
}

## 顔の写真の人の、立ち絵のタグ（その立ち絵が出ているときは、顔の写真を出さない）
define SIDE_TAG = {"森": "mori", "小池": "koike", "江藤": "eto", "野口": "noguchi", "桐生": "kiryu", "宮下": "miyashita",
                   "小早川": "kobayakawa", "倉田": "kurata", "赤坂": "akasaka", "真壁": "makabe", "佐伯": "saeki"}

init python:
    def side_face_on(who):
        if who not in SIDE_FACE:
            return False
        tag = SIDE_TAG.get(who)
        return not (tag and renpy.showing(tag))

init python:
    def side_face(who):
        """セリフ枠の顔の写真。送別旅行のあいだ（trip_outfit）は、私服・浴衣の写真があればそれを出す"""
        base = SIDE_FACE[who]
        o = getattr(store, "trip_outfit", "")
        if o:
            alt = base.replace(".png", "_%s.png" % o)
            if renpy.loadable(alt):
                return alt
        return base

transform side_photo:
    xpos 6
    ypos -148

style namebox:
    xpos 100
    ypos -20
    xysize (262, 62)
    background "gui/namebox.png"
    padding (0, 0, 0, 0)

style say_label:
    font FONT_JP_B
    size 28
    color INK
    outlines [(3, "#fffaf2", 0, 0)]     # 名前を読みやすく（テープの上でも文字がにじまないように）
    xalign 0.5
    yalign 0.5
    yoffset -2

style say_dialogue:
    xpos 120
    ypos 50                 # line_leading の分だけ上げて、罫線の位置は前と同じにしている
    xsize 1060
    size 28
    line_leading 8          # ふりがな（ルビ）を書くすき間
    line_spacing -6         # 行の間隔は前と同じ（42.5px）
    ruby_style style.ruby_text

## ふりがな（ルビ）。台本では {rb}神城{/rb}{rt}かみしろ{/rt} のように書く
style ruby_text:
    size 13
    yoffset -29
    color None


################################################################################
## クイックメニュー（セリフ枠の右下に、鉛筆の文字で）
##   雰囲気をこわさないように、ふだん見えるのは「戻る・ログ・オート・スキップ」だけ。
##   セーブ・ロード・ステータス・相関図・設定などは、画面右上のメニューボタン（mobile.rpy の menu_tab）から開く。
##   右クリック／Esc でもメニューが開く。
################################################################################

default quick_menu = True

screen quick_buttons():
    hbox:
        style_prefix "quick"
        xalign 1.0
        xoffset -44
        ypos 160
        spacing 2

        ## v0.29.12：「戻る」を出して、あまり使わない「次の選択肢へ」は右上のメニューの中だけに
        textbutton "戻る" action Rollback()
        textbutton "ログ" action ShowMenu("history")
        textbutton "オート" action Preference("auto-forward", "toggle")
        textbutton "スキップ" action Skip() alternate Skip(fast=True, confirm=True)

style quick_button:
    padding (6, 0, 6, 2)

style quick_button_text:
    size 15
    color INK_SOFT
    hover_color INK
    selected_color PEN_RED

init python:
    config.overlay_screens.append("calendar_hud")

    ## タイトル画面・セーブ／ロード・設定の画面を Ren'Py の流れにつなぐ
    ## （公式テンプレートでは gui.init() の中で行われている処理）
    layout.defaults()


################################################################################
## 名前入力（使わないが、Ren'Py が必要とする場合に備えて用意）
################################################################################

screen input(prompt):
    style_prefix "input"
    window:
        vbox:
            xpos 120
            ypos 40
            spacing 12
            text prompt
            input id "input"


################################################################################
## 選択肢（ノートの切れ端。マウスを乗せると蛍光ペン）
################################################################################

screen choice(items):
    style_prefix "choice"
    ## 「1つ戻る」のあとで先へ進んだときなどに、古い「先送りの記録」が残っていると、
    ## まだ選んでいない選択肢まで全部押せなくなる。この選択肢の記録がなければ、古い記録を捨てる
    python:
        if renpy.in_fixed_rollback() and renpy.roll_forward_info() is None:
            del renpy.game.log.forward[:]
    ## GOALの帯が残っていたら、選択肢と重ならないように消す
    on "show" action Hide("goal_banner")
    if len(items) > 6:
        ## 答えが多いとき（夜にトークを送る相手など）は、2列に並べる
        $ _half = (len(items) + 1) // 2
        hbox:
            xalign 0.5
            yalign 0.45
            spacing 12
            for _col in (items[:_half], items[_half:]):
                vbox:
                    spacing 0
                    for i in _col:
                        use choice_item(i, 600, 86)
    else:
        vbox:
            for i in items:
                use choice_item(i)

## 選択肢の1つぶん
##   menu の答えに (nochosen=True) を付けると「済」の印を付けない（毎晩使い回す、夜のトークの相手選びなど）
screen choice_item(i, w=928, h=94):
    style_prefix "choice"
    ## 選択肢のヒント（設定でオンのときだけ。systems.rpy の choice_hint）
    $ _h = choice_hint(i.caption)
    ## 前のプレイで選んだことがある答えは、文字を薄くして「済」の印を付ける
    if i.chosen and not (getattr(i, "kwargs", None) or {}).get("nochosen"):
        button:
            xsize w
            yminimum h
            action i.action
            vbox:
                xalign 0.5
                yalign 0.5
                spacing 0
                hbox:
                    xalign 0.5
                    spacing 10
                    text "済" style "choice_chosen_mark"
                    text i.caption style "choice_chosen_text"
                if _h:
                    text _h style "choice_hint_text"
    elif _h:
        button:
            xsize w
            yminimum h
            action i.action
            vbox:
                xalign 0.5
                yalign 0.5
                spacing 0
                text i.caption style "choice_button_text"
                text _h style "choice_hint_text"
    else:
        textbutton i.caption action i.action xsize w yminimum h

style choice_hint_text:
    xalign 0.5
    text_align 0.5
    size 17
    color PEN_TEAL
    hover_color PEN_TEAL

style choice_hint_text:
    variant "small"
    size 20

style choice_chosen_mark:
    yalign 0.5
    size 18
    font FONT_JP_B
    color "#ffffff"
    outlines [(6, INK_SOFT, 0, 0)]

style choice_chosen_text:
    yalign 0.5
    text_align 0.5
    size 26
    color INK_SOFT
    insensitive_color "#8f846e"

style choice_vbox:
    xalign 0.5
    yalign 0.4
    spacing 0

style choice_button:
    xsize 928
    ## v0.30.0：長い選択肢やヒントで文字が枠からはみ出さないように、高さは文字に合わせてのばす（最低 94）
    yminimum 94
    background Frame("gui/choice_idle.png", 80, 30)
    hover_background Frame("gui/choice_hover.png", 80, 30)
    ## 「1つ戻る」で選択肢まで戻ったとき：選んだ答えは目立たせ、ほかの答えは薄くする（押せない）
    selected_background Frame("gui/choice_hover.png", 80, 30)
    insensitive_background Frame(Transform("gui/choice_idle.png", alpha=0.55), 80, 30)
    padding (80, 14, 80, 22)

style choice_button_text:
    xalign 0.5
    yalign 0.5
    text_align 0.5
    size 26
    color INK
    hover_color INK
    hover_font FONT_JP_B
    selected_font FONT_JP_B
    insensitive_color "#8f846e"


################################################################################
## タイトル画面
################################################################################

## 放課後のノートと付箋の作り（v0.31.0：一度スポーツ中継風にしたが、ゲーム中の画面と合わせてノート・付箋にそろえた）
##   メニューは、マスキングテープで貼った紙片。マウスを乗せると蛍光ペンが引かれる。右下に黄色い付箋で版と更新情報
##   部品は tools/make_note_ui.py で gui/note/ に作る

## メニューの紙片が、上から順に貼られていく
transform mm_slide(i):
    alpha 0.0 yoffset -12
    pause 0.05 * i
    easein 0.22 alpha 1.0 yoffset 0

screen main_menu():
    tag menu

    add "gui/title_bg.png"
    add "gui/title_logo.png" xpos 34 ypos 62 zoom 0.70

    ## Web 版で、オートセーブがあるときは「前回のつづき」を出す（ボタンが増えるぶん、少し上から並べる）
    $ _auto = last_autosave() if renpy.emscripten else None
    $ _items = []
    if _auto:
        $ _items.append(("前回のつづき", Function(renpy.load, _auto)))
    $ _items.append(("はじめから", Start()))
    $ _items.append(("つづきから", ShowMenu("load")))
    if persistent.trial_cleared or AUTHOR_BUILD:
        $ _items.append(("章えらび", ShowMenu("chapter_select")))
    $ _items.append(("回想", ShowMenu("gallery")))
    $ _items.append(("設定", ShowMenu("preferences")))
    ## Web 版（テストページ）では「終了」が使えないので、かわりに「アンケート」を出す
    if survey_available():
        $ _items.append(("アンケート", Function(survey_open, False)))
    else:
        $ _items.append(("終了", Quit(confirm=False)))

    ## いちばん上の紙片だけ、マスキングテープで留める
    add "gui/note/tape.png" xpos 72 ypos (232 if _auto else 254) rotate -8

    vbox:
        style_prefix "mm"
        xpos 70
        ypos (240 if _auto else 262)
        spacing (2 if _auto else 6)
        for _i, (_label, _act) in enumerate(_items):
            textbutton _label action _act:
                ## いちばん上の項目を最初から選んだ状態にする（キーボード・パッドでもすぐ決定できる）
                default_focus (_i == 0)
                xoffset (0 if _i % 2 == 0 else 12)
                at mm_slide(_i), Transform(rotate=(-1.0 if _i % 2 == 0 else 0.8), rotate_pad=False)

    ## 右下：黄色い付箋に、版と「更新情報」
    button:
        style "mm_sticky"
        action ShowMenu("updates")
        at Transform(rotate=2.5, rotate_pad=False)
        vbox:
            xalign 0.5
            yalign 0.5
            spacing 0
            text "ver.[config.version]" style "mm_sticky_ver"
            text "更新情報を見る ▶" style "mm_sticky_text"

    ## 新しい版を初めて開いたときだけ、お知らせを出す（updates.rpy）
    on "show" action If(update_notice_due(), Show("update_notice"))

style mm_button:
    xysize (312, 68)
    background "gui/note/strip.png"
    hover_background "gui/note/strip_hover.png"
    padding (34, 0, 0, 8)

style mm_button_text:
    yalign 0.5
    font FONT_JP_B
    size 26
    color INK
    hover_color INK

style mm_sticky:
    xysize (240, 74)
    xalign 1.0
    yalign 1.0
    xoffset -26
    yoffset -18
    background "gui/note/sticky_yellow.png"
    hover_background "gui/note/sticky_yellow_hover.png"
    padding (0, 10, 10, 10)

style mm_sticky_ver:
    xalign 0.5
    size 16
    color INK_SOFT

style mm_sticky_text:
    xalign 0.5
    font FONT_JP_B
    size 20
    color INK
    hover_color PEN_RED

style mm_version:
    xalign 1.0
    yalign 1.0
    xoffset -20
    yoffset -14
    size 18
    color "#ffffff"
    outlines [(2, "#00000088", 0, 0)]


################################################################################
## ゲームメニュー共通の枠（机の上のノート。左にインデックスタブ）
################################################################################

screen navigation():
    ## いちばん使う「ゲームに戻る（タイトルでは「戻る」）」を、いちばん上に赤い付箋で大きく出す。
    ## ほかは「遊ぶ（セーブ・ロード・ログ）」「見る（ステータス・相関図）」「設定」のまとまりに分けて、すき間をあける。
    ## 「タイトルへ」はうっかり押さないように、いちばん下に小さく。クレジット・終了はタイトル画面からだけ。
    vbox:
        style_prefix "navigation"
        xpos 36
        ypos 40
        spacing 0

        if main_menu:
            textbutton "戻る" action Return() style "navigation_back_button" text_style "navigation_back_text"
            null height 18
            use nav_tab("はじめから", Start(), "orange")
            use nav_tab("ロード", ShowMenu("load"), "sky")
            use nav_tab("回想", ShowMenu("gallery"), "pink")
            null height 12
            use nav_tab("設定", ShowMenu("preferences"), "lav")
            use nav_tab("クレジット", ShowMenu("credits"), "green")
        else:
            textbutton "ゲームに戻る" action Return() style "navigation_back_button" text_style "navigation_back_text"
            null height 18
            use nav_tab("セーブ", ShowMenu("save"), "yellow")
            null height 10    # セーブとロードの押しまちがいを防ぐすき間
            use nav_tab("ロード", ShowMenu("load"), "sky")
            use nav_tab("ログ", ShowMenu("history"), "green")
            null height 12
            use nav_tab("ステータス", ShowMenu("status"), "pink")
            use nav_tab("相関図", ShowMenu("relations"), "pink")
            null height 12
            use nav_tab("設定", ShowMenu("preferences"), "lav")

    ## いちばん下の小さなリンク
    hbox:
        xpos 52
        yanchor 1.0
        ypos 700
        spacing 24
        if main_menu:
            if not renpy.variant("mobile") and not renpy.variant("web"):
                textbutton "終了" action Quit(confirm=False) style "navigation_small_button" text_style "navigation_small_text"
        else:
            textbutton "タイトルへ" action MainMenu() style "navigation_small_button" text_style "navigation_small_text"

style navigation_back_button:
    xysize (216, 66)
    background "gui/tab_back.png"
    hover_background "gui/tab_back_hover.png"
    padding (0, 0, 16, 6)

style navigation_back_text:
    xalign 0.5
    yalign 0.5
    font FONT_JP_B
    size 23
    color "#ffffff"
    hover_color "#ffffff"
    outlines [(2, "#8a2a2a", 0, 0)]

style navigation_small_button:
    padding (6, 4, 6, 4)
    background None

style navigation_small_text:
    font FONT_JP_B
    size 20
    color "#f3e6c8"
    hover_color "#ffffff"
    underline True

## 色つきの付箋のタブ（v0.31.0。部品は tools/make_note_ui.py で作る）
##   左の色の帯で、何の画面かを見分ける：セーブ＝黄、ロード＝水色、ログ・クレジット＝緑、ステータス・相関図・回想＝ピンク、設定＝紫、はじめから＝オレンジ
screen nav_tab(label, act, color):
    textbutton label action act style "navigation_button" text_style "navigation_button_text":
        background "gui/note/tab_%s.png" % color
        hover_background "gui/note/tab_%s_hover.png" % color
        selected_background "gui/note/tab_%s_sel.png" % color

style navigation_button:
    xysize (224, 66)
    padding (30, 0, 16, 8)
    selected_xoffset 14

style navigation_button_text:
    yalign 0.5
    font FONT_JP_B
    size 22
    color INK
    hover_color PEN_RED
    selected_color INK

screen game_menu(title, scroll=None, yinitial=0.0):
    style_prefix "game_menu"

    add "gui/menu_bg.png"

    use navigation

    text title style "game_menu_title"

    frame:
        style "game_menu_content"

        if scroll == "viewport":
            viewport:
                yinitial yinitial
                scrollbars "vertical"
                mousewheel True
                draggable True
                vbox:
                    spacing 12
                    transclude
        else:
            transclude

style game_menu_title:
    xpos 352
    ypos 44
    font FONT_JP_B
    size 34
    color PEN_RED

style game_menu_content:
    ## ノートの赤い線（x=330あたり）に文字が重ならないように、線の右から始める（v0.31.0）
    xpos 348
    ypos 104
    xsize 884
    ysize 580
    background None
    padding (0, 4, 0, 4)


################################################################################
## セーブ・ロード（ポラロイド写真）
################################################################################

screen save():
    tag menu
    use file_slots("セーブ")

screen load():
    tag menu
    use file_slots("ロード")

## セーブとロードを見まちがえないように、見出しの横に「何をする画面か」を色を変えて出す
##   セーブ＝赤ペン、ロード＝青緑のペン（スマホの画面も同じ）
init python:
    def file_hint(title):
        verb = "タップ" if renpy.variant("touch") else "クリック"
        if title == "セーブ":
            return ("%sした枠に、いまの場面を保存します" % verb, PEN_RED)
        return ("%sした枠の場面から、続きを遊びます" % verb, PEN_TEAL)

    ## セーブ枠に、物語の中の日付を書いておく（例：2026年 5月12日（火））
    def _save_name_by_date(d):
        if store.cal_date:
            d["_save_name"] = "%d年 %s" % (store.cal_year, store.cal_date)
    config.save_json_callbacks.append(_save_name_by_date)

    ## セーブのメモ（v0.31.0）：周回するときに「ここは千夏ルートの分かれ道」などと書いておける。
    ##   セーブ画面で枠を押すとメモを書く小さな紙が出て、「保存する」でメモといっしょに保存する
    save_memo_pending = ""
    def _save_memo(d):
        if store.save_memo_pending:
            d["memo"] = store.save_memo_pending
    config.save_json_callbacks.append(_save_memo)

    def slot_action(title, slot):
        """セーブ画面ではメモの紙を出す。ロード画面ではそのまま読む"""
        if title == "セーブ":
            return Show("save_memo", slot=slot, memo=(FileJson(slot, "memo", missing="") or ""))
        return FileAction(slot)

## セーブのメモを書く紙（20文字まで。空のままでも保存できる）
screen save_memo(slot, memo=""):
    modal True
    zorder 200
    default memo_value = ScreenVariableInputValue("memo", default=True, returnable=False)
    add Solid("#00000077")
    frame:
        xysize (620, 330)
        xalign 0.5
        yalign 0.5
        background "gui/note_big.png"
        padding (50, 40, 50, 30)
        vbox:
            spacing 14
            text ("この枠に上書きします。メモをつけますか？" if FileLoadable(slot) else "メモをつけて保存しますか？") style "memo_title"
            text "（例：千夏ルートの分かれ道　空のままでも保存できます）" size 17 color INK_SOFT
            frame:
                xsize 500
                ysize 52
                background Frame("gui/highlight.png", 16, 10)
                padding (14, 8, 14, 8)
                input value memo_value length 20 size 24 color INK
            hbox:
                xalign 0.5
                spacing 60
                textbutton "保存する" action [SetVariable("save_memo_pending", memo), FileSave(slot, confirm=False), SetVariable("save_memo_pending", ""), Hide("save_memo")] text_size 26 text_color PEN_RED
                textbutton "やめる" action Hide("save_memo") text_size 26
    key "game_menu" action Hide("save_memo")

style memo_title:
    font FONT_JP_B
    size 23
    color INK

screen file_slots(title):
    $ _hint, _hcol = file_hint(title)
    use game_menu(title):
        vbox:
            spacing 6

            hbox:
                spacing 2
                style_prefix "page"
                textbutton "オート" action FilePage("auto")
                textbutton "クイック" action FilePage("quick")
                ## セーブは3ページ（18枠）まで（v0.31.0：9ページは多すぎて、ページの数字が並びすぎるため）
                for page in range(1, 4):
                    textbutton "[page]" action FilePage(page)

            grid 3 2:
                xspacing -4
                yspacing 16
                for i in range(6):
                    $ slot = i + 1
                    ## ノートに貼った写真のように、少しずつ傾けて、上をマスキングテープで留める（v0.31.0）
                    button:
                        style "slot_button"
                        action slot_action(title, slot)
                        at Transform(rotate=(-1.4 if i % 2 == 0 else 1.1), rotate_pad=False)
                        fixed:
                            key "save_delete" action FileDelete(slot)
                            add FileScreenshot(slot) pos (22, 22)
                            $ _memo = FileJson(slot, "memo", missing="") or ""
                            if _memo:
                                ## メモがあるときは、メモを赤ペンで大きく、日付は小さく
                                text _memo style "slot_memo"
                                text FileTime(slot, format="%Y/%m/%d %H:%M", empty="") + "　" + FileSaveName(slot) style "slot_name"
                            else:
                                text FileTime(slot, format="%Y/%m/%d %H:%M", empty="― 空き ―") style "slot_time"
                                text FileSaveName(slot) style "slot_name"
                            add "gui/note/tape.png" xalign 0.5 ypos -6

            if not renpy.variant("touch"):
                text "※スロットにマウスを合わせて Delete キーで削除できます" size 16 color INK_SOFT

    text _hint style "file_hint" color _hcol

style file_hint:
    xpos 490
    ypos 54
    font FONT_JP_B
    size 20

style page_button:
    padding (10, 2, 10, 4)

style page_button_text:
    size 22

style slot_button:
    xysize (300, 240)
    background "gui/slot_idle.png"
    hover_background "gui/slot_hover.png"
    selected_background "gui/slot_idle.png"
    padding (0, 0, 0, 0)

style slot_time:
    xpos 150
    xanchor 0.5
    ypos 176
    size 18
    color INK

style slot_memo:
    xpos 150
    xanchor 0.5
    ypos 174
    font FONT_JP_B
    size 19
    color PEN_RED

style slot_name:
    xpos 150
    xanchor 0.5
    ypos 200
    size 15
    color INK_SOFT


################################################################################
## 設定
################################################################################

## ノートの枠（game_menu）の中に、付箋のタブ「画面と文字／音／ヒント」と、2列の項目を並べる（スクロールしない。v0.31.0）
##   2択は、選んだほうに赤ペンの丸がつく。音量や速さは、蛍光ペンを引いた定規とボールのつまみ
default persistent.pref_tab = "display"

define PREF_TABS = [("display", "画面と文字"), ("sound", "音"), ("hint", "ヒント")]

init python:
    def pref_items(tab):
        """そのタブの項目：(見出し, 種類, 中身)。種類は bar（定規）・choice（2択）・button（1つだけのボタン）"""
        P = persistent
        if tab == "sound":
            return [
                ("BGMの音量", "bar", Preference("music volume")),
                ("効果音の音量", "bar", Preference("sound volume")),
                ("ボイスの音量", "bar", Preference("voice volume")),
                ("次の文に進んだときのボイス", "choice", [("止める", Preference("voice sustain", "disable")), ("止めない", Preference("voice sustain", "enable"))]),
            ]
        if tab == "hint":
            return [
                ("何が上がるか（選択肢）", "choice", [("出さない", SetField(P, "choice_hints", False), not P.choice_hints), ("出す", SetField(P, "choice_hints", True), bool(P.choice_hints))]),
                ("試合の判定", "choice", [("出さない", SetField(P, "judge_hints", False), not P.judge_hints), ("出す", SetField(P, "judge_hints", True), bool(P.judge_hints))]),
                ("能力値・絆の変化を出す（テスト用）", "choice", [("出さない", SetField(P, "show_param_notify", False), not P.show_param_notify), ("出す", SetField(P, "show_param_notify", True), bool(P.show_param_notify))]),
                ## セーブの案内は1回目のプレイだけ出る。もう一度見たいときに押す
                ("セーブの案内", "button", ("最初の選択肢の前に、もう一度出す", [SetField(P, "save_guide_seen", False), Notify("次に最初の選択肢まで進むと、セーブの案内が出ます")], bool(P.save_guide_seen))),
            ]
        items = []
        ## ウィンドウ／全画面の切り替えは PC だけ（スマホでは出さない）
        if not renpy.variant("mobile"):
            items.append(("画面", "choice", [("ウィンドウ", Preference("display", "window")), ("全画面", Preference("display", "fullscreen"))]))
        items += [
            ("スキップ", "choice", [("既読のみ", Preference("skip", "seen")), ("未読も含む", Preference("skip", "all"))]),
            ("文字の速さ", "bar", Preference("text speed")),
            ("オートの速さ", "bar", Preference("auto-forward time")),
        ]
        return items

screen preferences():
    tag menu
    use game_menu("設定"):
        vbox:
            spacing 18
            hbox:
                spacing 8
                for _k, _l in PREF_TABS:
                    textbutton _l style "rel_tab" text_style "rel_tab_text" action SetField(persistent, "pref_tab", _k) selected (persistent.pref_tab == _k)

            ## 2列に並べる（左の列・右の列の順に、上から）
            $ _items = pref_items(persistent.pref_tab)
            hbox:
                spacing 40
                for _col in (_items[0::2], _items[1::2]):
                    vbox:
                        spacing 26
                        for _label, _kind, _arg in _col:
                            use pref_item(_label):
                                if _kind == "bar":
                                    bar value _arg style "pref_ruler"
                                elif _kind == "choice":
                                    use pref_choice(_arg)
                                else:
                                    textbutton _arg[0] action _arg[1] sensitive _arg[2] style "prefc_button" text_style "prefc_button_text"

            if persistent.pref_tab == "hint":
                text "何が上がるか：能力・仲間との絆・ヒロインの気持ちのどれが上がるか（↑↓だけ）。出さないと、蓮になったつもりで選べます。出すと、ねらった結末に向かいやすくなります\n試合の判定：試合の大事な場面で、判定に使う能力と、必要な数値・いまの数値" size 17 color INK_SOFT xsize 860

## 項目1つ（赤ペンの見出し＋中身）
screen pref_item(label):
    vbox:
        xsize 420
        spacing 10
        text label style "pref_label"
        transclude

## 2択（□ と、選んだほうに赤ペンの丸）。items: (名前, action) か (名前, action, 選ばれているか)
screen pref_choice(items):
    hbox:
        spacing 18
        for _it in items:
            if len(_it) > 2:
                textbutton _it[0] action _it[1] selected _it[2] style "prefc_button" text_style "prefc_button_text"
            else:
                textbutton _it[0] action _it[1] style "prefc_button" text_style "prefc_button_text"

style pref_label:
    font FONT_JP_B
    size 22
    color PEN_RED

style prefc_button:
    padding (18, 6, 18, 8)
    xminimum 104
    background None
    hover_background Frame("gui/highlight.png", 16, 10)
    selected_background Frame("gui/note/circle.png", 30, 14)
    selected_hover_background Frame("gui/note/circle.png", 30, 14)

style prefc_button_text:
    xalign 0.5
    size 21
    color INK_SOFT
    hover_color INK
    selected_color INK
    selected_font FONT_JP_B
    insensitive_color "#c8bba8"

style pref_ruler:
    xsize 380
    ysize 36
    left_bar Frame("gui/note/ruler_hl.png", 4, 4)
    right_bar Frame("gui/note/ruler.png", 4, 4)
    thumb "gui/note/ball_thumb.png"
    thumb_offset 18


################################################################################
## ログ（バックログ）
################################################################################

define config.history_length = 250

screen history():
    tag menu
    predict False

    use game_menu("ログ", scroll="viewport", yinitial=1.0):
        style_prefix "history"

        for h in _history_list:
            vbox:
                spacing 0
                if h.who:
                    text h.who style "history_name"
                text h.what substitute False style "history_text"

        if not _history_list:
            text "ログはまだありません。"

style history_name:
    font FONT_JP_B
    size 19
    color PEN_RED

## ふりがな（ログ画面用）。使うスタイルより先に作っておく
style ruby_history:
    size 11
    yoffset -20
    color None

style history_text:
    size 22
    xsize 860
    ruby_line_leading 10
    ruby_style style.ruby_history


################################################################################
## 確認ダイアログ（大きな付箋）
################################################################################

screen confirm(message, yes_action, no_action):
    modal True
    zorder 200

    add Solid("#00000077")

    fixed:
        xysize (580, 300)
        xalign 0.5
        yalign 0.5
        add "gui/note_big.png"
        vbox:
            xalign 0.5
            yalign 0.5
            yoffset -6
            xsize 480
            spacing 30
            text message xalign 0.5 text_align 0.5 size 24
            hbox:
                xalign 0.5
                spacing 80
                textbutton "はい" action yes_action text_size 28
                textbutton "いいえ" action no_action text_size 28

    key "game_menu" action no_action

################################################################################
## セーブの案内（最初の選択肢の前に1回だけ出す。大きな付箋）
################################################################################

screen save_prompt():
    modal True
    zorder 200

    add Solid("#00000077")

    fixed:
        xysize (580, 300)
        xalign 0.5
        yalign 0.5
        add "gui/note_big.png"
        vbox:
            xalign 0.5
            yalign 0.5
            yoffset -6
            xsize 480
            spacing 26
            text "ここでセーブしておこう" xalign 0.5 font FONT_JP_B size 30 color INK
            text "あとで、ここから別の答えを試せます" xalign 0.5 size 20 color INK_SOFT
            hbox:
                xalign 0.5
                spacing 60
                textbutton "セーブする" action ShowMenu("save") text_size 28 text_color PEN_RED text_hover_color INK
                textbutton "つづける" action Return() text_size 28

    key "game_menu" action ShowMenu("save")

init python:
    layout.ARE_YOU_SURE = "よろしいですか？"
    layout.DELETE_SAVE = "このセーブデータを削除しますか？"
    layout.OVERWRITE_SAVE = "上書きしますか？"
    layout.LOADING = "ロードすると、保存していない進み具合は失われます。よろしいですか？"
    layout.QUIT = "ゲームを終了しますか？"
    layout.MAIN_MENU = "タイトル画面に戻りますか？保存していない進み具合は失われます。"
    layout.END_REPLAY = "回想を終了しますか？"
    layout.SLOW_SKIP = "スキップを始めますか？"
    layout.FAST_SKIP_SEEN = "次の選択肢まで既読をスキップしますか？"
    layout.FAST_SKIP_UNSEEN = "次の選択肢までスキップしますか？"


################################################################################
## 通知・スキップ中の表示（小さな付箋）
################################################################################

screen notify(message):
    zorder 150
    frame at fade_in_out:
        xalign 0.5
        ypos 12
        text "[message!tq]" size 20
    timer 3.0 action Hide("notify")

screen skip_indicator():
    zorder 100
    frame:
        xpos 14
        yalign 0.66
        text "スキップ中 ▶▶" size 20 color PEN_RED

transform fade_in_out:
    on show:
        alpha 0.0
        linear 0.25 alpha 1.0
    on hide:
        linear 0.4 alpha 0.0
