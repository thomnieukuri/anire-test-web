## screens.rpy ―― 画面まわり（デザイン：放課後ノート）
##   セリフ枠・選択肢・タイトル・メニュー・セーブ／ロード・設定・ログ・確認ダイアログ
##   画像パーツは game/gui/ にある（作り直すときは同じファイル名で上書きする）

################################################################################
## 色とフォント
################################################################################

define FONT_JP = "fonts/NotoSansCJKjp-Regular-subset.otf"
define FONT_JP_B = "fonts/NotoSansCJKjp-Bold-subset.otf"

define INK = "#3c2d23"          # 鉛筆の文字
define INK_SOFT = "#8c735f"     # 薄い文字
define PEN_RED = "#cd4646"      # 赤ペン
define PEN_TEAL = "#2f6f76"     # 青緑のペン

## 蛍光ペン（ボタンにマウスを乗せたとき）
define HL = Frame("gui/highlight.png", 16, 10)


################################################################################
## 共通スタイル
################################################################################

style default:
    font FONT_JP
    size 26
    language "japanese-normal"
    color INK
    ## ▶ や ◀ が絵文字（青い四角）にならないように、フォントにある字はフォントで出す
    prefer_emoji False

style button:
    padding (12, 4, 12, 4)
    hover_background HL
    selected_background HL

style button_text:
    color INK_SOFT
    hover_color INK
    selected_color INK
    selected_font FONT_JP_B
    insensitive_color "#c8bba8"

style label_text:
    font FONT_JP_B
    color PEN_RED
    size 24

style frame:
    background Frame("gui/note_small.png", 14, 14)
    padding (22, 14, 22, 18)

style bar:
    ysize 18
    left_bar Solid("#f08c8c")
    right_bar Solid("#e6dbc4")

style slider:
    ysize 26
    xsize 440
    left_bar Solid("#f08c8c")
    right_bar Solid("#e6dbc4")
    thumb "gui/slider_thumb.png"
    thumb_offset 6

style vscrollbar:
    xsize 8
    base_bar Solid("#e6dbc4")
    thumb Solid("#c9a98a")
    unscrollable "hide"

style hyperlink_text:
    color PEN_TEAL


################################################################################
## 文字送りの合図（赤い▼が点滅）
################################################################################

image ctc_blink:
    "gui/ctc.png"
    yoffset 4
    block:
        linear 0.45 alpha 0.25
        linear 0.45 alpha 1.0
        repeat


################################################################################
## セリフ枠（ルーズリーフ）。名前はマスキングテープ
################################################################################

screen say(who, what):
    zorder 41       # トーク画面（スマホ）を出したまま地の文を出しても、セリフ枠が上に来るように
    window:
        id "window"

        ## 坂口の仲間（森・小池・江藤・野口）と2年の桐生・宮下が話すときは、セリフ枠の左上に顔の写真を貼る
        ##   4人が一言ずつ続けて話す場面が多いので、立ち絵を出し入れせずに、だれが話しているか分かるようにする（v0.28.0）
        ##   v0.30.0：その人の立ち絵が画面に出ているときは、顔の写真は出さない（二重にならないように）
        $ _sf = side_face_on(who)
        if _sf:
            add side_face(who) at side_photo

        if who is not None:
            window:
                id "namebox"
                style "namebox"
                if _sf:
                    xpos 168
                text who id "who"

        text what id "what"

        if quick_menu:
            use quick_buttons

style window:
    xalign 0.5
    yalign 1.0
    yoffset 6
    xsize 1224
    ysize 200
    background "gui/textbox.png"
    padding (0, 0, 0, 0)

style say_window is window

## 顔の写真（名前 → 画像）。写真は images/chara/face/ に、白いふちと影をつけて少し傾けて作ってある
define SIDE_FACE = {
    "森": "images/chara/face/mori.png",
    "小池": "images/chara/face/koike.png",
    "江藤": "images/chara/face/eto.png",
    "野口": "images/chara/face/noguchi.png",
    "桐生": "images/chara/face/kiryu.png",
    "宮下": "images/chara/face/miyashita.png",
    ## 第4章の人（v0.30.0）
    "小早川": "images/chara/face/kobayakawa.png",
    "倉田": "images/chara/face/kurata.png",
    "赤坂": "images/chara/face/akasaka.png",
    "真壁": "images/chara/face/makabe.png",
    "佐伯": "images/chara/face/saeki.png",
}

## 顔の写真の人の、立ち絵のタグ（その立ち絵が出ているときは、顔の写真を出さない）
define SIDE_TAG = {"森": "mori", "小池": "koike", "江藤": "eto", "野口": "noguchi", "桐生": "kiryu", "宮下": "miyashita",
                   "小早川": "kobayakawa", "倉田": "kurata", "赤坂": "akasaka", "真壁": "makabe", "佐伯": "saeki"}

init python:
    def side_face_on(who):
        if who not in SIDE_FACE:
            return False
        tag = SIDE_TAG.get(who)
        return not (tag and renpy.showing(tag))

init python:
    def side_face(who):
        """セリフ枠の顔の写真。送別旅行のあいだ（trip_outfit）は、私服・浴衣の写真があればそれを出す"""
        base = SIDE_FACE[who]
        o = getattr(store, "trip_outfit", "")
        if o:
            alt = base.replace(".png", "_%s.png" % o)
            if renpy.loadable(alt):
                return alt
        return base

transform side_photo:
    xpos 6
    ypos -148

style namebox:
    xpos 100
    ypos -20
    xysize (262, 62)
    background "gui/namebox.png"
    padding (0, 0, 0, 0)

style say_label:
    font FONT_JP_B
    size 28
    color INK
    outlines [(3, "#fffaf2", 0, 0)]     # 名前を読みやすく（テープの上でも文字がにじまないように）
    xalign 0.5
    yalign 0.5
    yoffset -2

style say_dialogue:
    xpos 120
    ypos 50                 # line_leading の分だけ上げて、罫線の位置は前と同じにしている
    xsize 1060
    size 28
    line_leading 8          # ふりがな（ルビ）を書くすき間
    line_spacing -6         # 行の間隔は前と同じ（42.5px）
    ruby_style style.ruby_text

## ふりがな（ルビ）。台本では {rb}神城{/rb}{rt}かみしろ{/rt} のように書く
style ruby_text:
    size 13
    yoffset -29
    color None


################################################################################
## クイックメニュー（セリフ枠の右下に、鉛筆の文字で）
##   雰囲気をこわさないように、ふだん見えるのは「戻る・ログ・オート・スキップ」だけ。
##   セーブ・ロード・ステータス・相関図・設定などは、画面右上のメニューボタン（mobile.rpy の menu_tab）から開く。
##   右クリック／Esc でもメニューが開く。
################################################################################

default quick_menu = True

screen quick_buttons():
    hbox:
        style_prefix "quick"
        xalign 1.0
        xoffset -44
        ypos 160
        spacing 2

        ## v0.29.12：「戻る」を出して、あまり使わない「次の選択肢へ」は右上のメニューの中だけに
        textbutton "戻る" action Rollback()
        textbutton "ログ" action ShowMenu("history")
        textbutton "オート" action Preference("auto-forward", "toggle")
        textbutton "スキップ" action Skip() alternate Skip(fast=True, confirm=True)

style quick_button:
    padding (6, 0, 6, 2)

style quick_button_text:
    size 15
    color INK_SOFT
    hover_color INK
    selected_color PEN_RED

init python:
    config.overlay_screens.append("calendar_hud")

    ## タイトル画面・セーブ／ロード・設定の画面を Ren'Py の流れにつなぐ
    ## （公式テンプレートでは gui.init() の中で行われている処理）
    layout.defaults()


################################################################################
## 名前入力（使わないが、Ren'Py が必要とする場合に備えて用意）
################################################################################

screen input(prompt):
    style_prefix "input"
    window:
        vbox:
            xpos 120
            ypos 40
            spacing 12
            text prompt
            input id "input"


################################################################################
## 選択肢（ノートの切れ端。マウスを乗せると蛍光ペン）
################################################################################

screen choice(items):
    style_prefix "choice"
    ## 「1つ戻る」のあとで先へ進んだときなどに、古い「先送りの記録」が残っていると、
    ## まだ選んでいない選択肢まで全部押せなくなる。この選択肢の記録がなければ、古い記録を捨てる
    python:
        if renpy.in_fixed_rollback() and renpy.roll_forward_info() is None:
            del renpy.game.log.forward[:]
    ## GOALの帯が残っていたら、選択肢と重ならないように消す
    on "show" action Hide("goal_banner")
    if len(items) > 6:
        ## 答えが多いとき（夜にトークを送る相手など）は、2列に並べる
        $ _half = (len(items) + 1) // 2
        hbox:
            xalign 0.5
            yalign 0.45
            spacing 12
            for _col in (items[:_half], items[_half:]):
                vbox:
                    spacing 0
                    for i in _col:
                        use choice_item(i, 600, 86)
    else:
        vbox:
            for i in items:
                use choice_item(i)

## 選択肢の1つぶん
##   menu の答えに (nochosen=True) を付けると「済」の印を付けない（毎晩使い回す、夜のトークの相手選びなど）
screen choice_item(i, w=928, h=94):
    style_prefix "choice"
    ## 選択肢のヒント（設定でオンのときだけ。systems.rpy の choice_hint）
    $ _h = choice_hint(i.caption)
    ## 前のプレイで選んだことがある答えは、文字を薄くして「済」の印を付ける
    if i.chosen and not (getattr(i, "kwargs", None) or {}).get("nochosen"):
        button:
            xsize w
            yminimum h
            action i.action
            vbox:
                xalign 0.5
                yalign 0.5
                spacing 0
                hbox:
                    xalign 0.5
                    spacing 10
                    text "済" style "choice_chosen_mark"
                    text i.caption style "choice_chosen_text"
                if _h:
                    text _h style "choice_hint_text"
    elif _h:
        button:
            xsize w
            yminimum h
            action i.action
            vbox:
                xalign 0.5
                yalign 0.5
                spacing 0
                text i.caption style "choice_button_text"
                text _h style "choice_hint_text"
    else:
        textbutton i.caption action i.action xsize w yminimum h

style choice_hint_text:
    xalign 0.5
    text_align 0.5
    size 17
    color PEN_TEAL
    hover_color PEN_TEAL

style choice_hint_text:
    variant "small"
    size 20

style choice_chosen_mark:
    yalign 0.5
    size 18
    font FONT_JP_B
    color "#ffffff"
    outlines [(6, INK_SOFT, 0, 0)]

style choice_chosen_text:
    yalign 0.5
    text_align 0.5
    size 26
    color INK_SOFT
    insensitive_color "#8f846e"

style choice_vbox:
    xalign 0.5
    yalign 0.4
    spacing 0

style choice_button:
    xsize 928
    ## v0.30.0：長い選択肢やヒントで文字が枠からはみ出さないように、高さは文字に合わせてのばす（最低 94）
    yminimum 94
    background Frame("gui/choice_idle.png", 80, 30)
    hover_background Frame("gui/choice_hover.png", 80, 30)
    ## 「1つ戻る」で選択肢まで戻ったとき：選んだ答えは目立たせ、ほかの答えは薄くする（押せない）
    selected_background Frame("gui/choice_hover.png", 80, 30)
    insensitive_background Frame(Transform("gui/choice_idle.png", alpha=0.55), 80, 30)
    padding (80, 14, 80, 22)

style choice_button_text:
    xalign 0.5
    yalign 0.5
    text_align 0.5
    size 26
    color INK
    hover_color INK
    hover_font FONT_JP_B
    selected_font FONT_JP_B
    insensitive_color "#8f846e"


################################################################################
## タイトル画面
################################################################################

## スポーツ中継の画面のような作り（紺の斜めの帯・赤の差し色・下に流れるニュース帯）。部品は tools/make_sp_ui.py で作る
define SP_NAVY = "#10204a"
define SP_RED = "#e03a2f"
define SP_SKY = "#8aa0d8"
define SP_PALE = "#c5d0ee"

## ニュース帯に流す文（いまの版の更新情報をつなげる）
init python:
    def mm_ticker_text():
        n = update_notes_for(config.version)
        if not n:
            return "ver.%s" % config.version
        return "ver.%s　　" % config.version + "　／　".join(n[1])

transform mm_ticker_scroll(w):
    xoffset 760
    linear (w + 760) / 70.0 xoffset -w
    repeat

## メニューの帯が、左から順にすべりこむ
transform mm_slide(i):
    alpha 0.0 xoffset -60
    pause 0.05 * i
    easein 0.25 alpha 1.0 xoffset 0

screen main_menu():
    tag menu

    add "gui/title_bg.png"
    ## 左側を少し暗くして、メニューの帯を読みやすくする
    add "gui/sp/title_shade.png"
    add "gui/title_logo.png" xpos 34 ypos 62 zoom 0.70

    ## Web 版で、オートセーブがあるときは「前回のつづき」を出す（ボタンが増えるぶん、少し上から並べる）
    $ _auto = last_autosave() if renpy.emscripten else None
    $ _items = []
    if _auto:
        $ _items.append(("前回のつづき", "RESUME", Function(renpy.load, _auto)))
    $ _items.append(("はじめから", "KICK OFF", Start()))
    $ _items.append(("つづきから", "LOAD", ShowMenu("load")))
    if persistent.trial_cleared or AUTHOR_BUILD:
        $ _items.append(("章えらび", "CHAPTER", ShowMenu("chapter_select")))
    $ _items.append(("回想", "REPLAY", ShowMenu("gallery")))
    $ _items.append(("設定", "CONFIG", ShowMenu("preferences")))
    ## Web 版（テストページ）では「終了」が使えないので、かわりに「アンケート」を出す
    if survey_available():
        $ _items.append(("アンケート", "SURVEY", Function(survey_open, False)))
    else:
        $ _items.append(("終了", "EXIT", Quit(confirm=False)))

    vbox:
        style_prefix "mm"
        xpos 0
        ypos (238 if _auto else 262)
        spacing (6 if _auto else 10)
        for _i, (_jp, _en, _act) in enumerate(_items):
            button:
                action _act
                ## いちばん上の項目を最初から選んだ状態にする（キーボード・パッドでもすぐ決定できる）
                default_focus (_i == 0)
                at mm_slide(_i)
                text _jp style "mm_button_text"
                text _en style "mm_sub_text"

    ## 下：ニュース帯（いまの版の更新情報が流れる）と「更新情報」
    frame:
        style "mm_ticker"
        add Solid(SP_RED) xysize (1280, 3)
        add "gui/sp/news.png" xpos 20 yalign 0.5
        text "NEWS" style "mm_news_text" xpos 68 xanchor 0.5 yalign 0.5
        viewport:
            xpos 130
            xsize 760
            ysize 42
            $ _t = mm_ticker_text()
            text _t style "mm_ticker_text" yalign 0.5 at mm_ticker_scroll(len(_t) * 17)
        hbox:
            xalign 1.0
            xoffset -20
            yalign 0.5
            spacing 16
            text "ver.[config.version]" style "mm_version_inline" yalign 0.5
            textbutton "更新情報 ▶" style "mm_link_button" text_style "mm_link_button_text" action ShowMenu("updates")

    ## 新しい版を初めて開いたときだけ、お知らせを出す（updates.rpy）
    on "show" action If(update_notice_due(), Show("update_notice"))

style mm_button:
    xysize (460, 54)
    background "gui/sp/mm_idle.png"
    hover_background "gui/sp/mm_hover.png"

style mm_button_text:
    xpos 64
    yalign 0.5
    font FONT_JP_B
    size 26
    color "#ffffff"
    hover_color SP_NAVY

style mm_sub_text:
    xpos 340
    xanchor 1.0
    yalign 0.5
    font FONT_JP
    size 14
    kerning 2
    color SP_SKY
    hover_color SP_RED
    hover_xpos 400

style mm_ticker:
    xfill True
    ysize 42
    yalign 1.0
    background Solid(SP_NAVY)
    padding (0, 0, 0, 0)

style mm_news_text:
    font FONT_JP_B
    size 15
    kerning 2
    color "#ffffff"

style mm_ticker_text:
    size 17
    layout "nobreak"
    color "#ffffff"

style mm_version_inline:
    size 17
    color SP_PALE

style mm_version:
    xalign 1.0
    yalign 1.0
    xoffset -20
    yoffset -14
    size 18
    color "#ffffff"
    outlines [(2, "#00000088", 0, 0)]


################################################################################
## ゲームメニュー共通の枠（机の上のノート。左にインデックスタブ）
################################################################################

screen navigation():
    ## いちばん使う「ゲームに戻る（タイトルでは「戻る」）」を、いちばん上に赤い付箋で大きく出す。
    ## ほかは「遊ぶ（セーブ・ロード・ログ）」「見る（ステータス・相関図）」「設定」のまとまりに分けて、すき間をあける。
    ## 「タイトルへ」はうっかり押さないように、いちばん下に小さく。クレジット・終了はタイトル画面からだけ。
    vbox:
        style_prefix "navigation"
        xpos 36
        ypos 40
        spacing 0

        if main_menu:
            textbutton "戻る" action Return() style "navigation_back_button" text_style "navigation_back_text"
            null height 18
            textbutton "はじめから" action Start()
            textbutton "ロード" action ShowMenu("load")
            textbutton "回想" action ShowMenu("gallery")
            null height 12
            textbutton "設定" action ShowMenu("preferences")
            textbutton "クレジット" action ShowMenu("credits")
        else:
            textbutton "ゲームに戻る" action Return() style "navigation_back_button" text_style "navigation_back_text"
            null height 18
            textbutton "セーブ" action ShowMenu("save")
            null height 10    # セーブとロードの押しまちがいを防ぐすき間
            textbutton "ロード" action ShowMenu("load")
            textbutton "ログ" action ShowMenu("history")
            null height 12
            textbutton "ステータス" action ShowMenu("status")
            textbutton "相関図" action ShowMenu("relations")
            null height 12
            textbutton "設定" action ShowMenu("preferences")

    ## いちばん下の小さなリンク
    hbox:
        xpos 52
        yanchor 1.0
        ypos 700
        spacing 24
        if main_menu:
            if not renpy.variant("mobile") and not renpy.variant("web"):
                textbutton "終了" action Quit(confirm=False) style "navigation_small_button" text_style "navigation_small_text"
        else:
            textbutton "タイトルへ" action MainMenu() style "navigation_small_button" text_style "navigation_small_text"

style navigation_back_button:
    xysize (216, 66)
    background "gui/tab_back.png"
    hover_background "gui/tab_back_hover.png"
    padding (0, 0, 16, 6)

style navigation_back_text:
    xalign 0.5
    yalign 0.5
    font FONT_JP_B
    size 23
    color "#ffffff"
    hover_color "#ffffff"
    outlines [(2, "#8a2a2a", 0, 0)]

style navigation_small_button:
    padding (6, 4, 6, 4)
    background None

style navigation_small_text:
    font FONT_JP_B
    size 20
    color "#f3e6c8"
    hover_color "#ffffff"
    underline True

style navigation_button:
    xysize (216, 66)
    background "gui/tab_idle.png"
    hover_background "gui/tab_hover.png"
    selected_background "gui/tab_selected.png"
    padding (0, 0, 16, 6)

style navigation_button_text:
    xalign 0.5
    yalign 0.5
    font FONT_JP_B
    size 22
    color INK
    hover_color INK
    selected_color INK

screen game_menu(title, scroll=None, yinitial=0.0):
    style_prefix "game_menu"

    add "gui/menu_bg.png"

    use navigation

    text title style "game_menu_title"

    frame:
        style "game_menu_content"

        if scroll == "viewport":
            viewport:
                yinitial yinitial
                scrollbars "vertical"
                mousewheel True
                draggable True
                vbox:
                    spacing 12
                    transclude
        else:
            transclude

style game_menu_title:
    xpos 352
    ypos 44
    font FONT_JP_B
    size 34
    color PEN_RED

style game_menu_content:
    xpos 320
    ypos 104
    xsize 910
    ysize 580
    background None
    padding (0, 4, 0, 4)


################################################################################
## セーブ・ロード（ポラロイド写真）
################################################################################

screen save():
    tag menu
    use file_slots("セーブ")

screen load():
    tag menu
    use file_slots("ロード")

## セーブとロードを見まちがえないように、見出しの横に「何をする画面か」を色を変えて出す
##   セーブ＝赤ペン、ロード＝青緑のペン（スマホの画面も同じ）
init python:
    def file_hint(title):
        verb = "タップ" if renpy.variant("touch") else "クリック"
        if title == "セーブ":
            return ("%sした枠に、いまの場面を保存します" % verb, PEN_RED)
        return ("%sした枠の場面から、続きを遊びます" % verb, PEN_TEAL)

    ## セーブ枠に、物語の中の日付を書いておく（例：2026年 5月12日（火））
    def _save_name_by_date(d):
        if store.cal_date:
            d["_save_name"] = "%d年 %s" % (store.cal_year, store.cal_date)
    config.save_json_callbacks.append(_save_name_by_date)

screen file_slots(title):
    $ _hint, _hcol = file_hint(title)
    use game_menu(title):
        vbox:
            spacing 6

            hbox:
                spacing 2
                style_prefix "page"
                textbutton "オート" action FilePage("auto")
                textbutton "クイック" action FilePage("quick")
                for page in range(1, 10):
                    textbutton "[page]" action FilePage(page)

            grid 3 2:
                spacing 5
                for i in range(6):
                    $ slot = i + 1
                    button:
                        style "slot_button"
                        action FileAction(slot)
                        fixed:
                            key "save_delete" action FileDelete(slot)
                            add FileScreenshot(slot) pos (22, 22)
                            text FileTime(slot, format="%Y/%m/%d %H:%M", empty="― 空き ―") style "slot_time"
                            text FileSaveName(slot) style "slot_name"

            if not renpy.variant("touch"):
                text "※スロットにマウスを合わせて Delete キーで削除できます" size 16 color INK_SOFT

    text _hint style "file_hint" color _hcol

style file_hint:
    xpos 490
    ypos 54
    font FONT_JP_B
    size 20

style page_button:
    padding (10, 2, 10, 4)

style page_button_text:
    size 22

style slot_button:
    xysize (300, 240)
    background "gui/slot_idle.png"
    hover_background "gui/slot_hover.png"
    selected_background "gui/slot_idle.png"
    padding (0, 0, 0, 0)

style slot_time:
    xpos 150
    xanchor 0.5
    ypos 176
    size 18
    color INK

style slot_name:
    xpos 150
    xanchor 0.5
    ypos 200
    size 15
    color INK_SOFT


################################################################################
## 設定
################################################################################

## タイトル画面と同じスポーツ中継風。ノートの枠（game_menu）は使わず、この画面だけで完結させる
##   左のタブで「画面と文字／音／ヒント」を切り替え、右に2列のカードで並べる（スクロールしない）
default persistent.pref_tab = "display"

screen preferences():
    tag menu
    style_prefix "sp"

    add "gui/sp/pref_bg.jpg"

    ## 見出し
    add "gui/sp/head.png" xpos 0 ypos 34
    text "設定" style "sp_head_text"

    ## ゲーム中は、右上からセーブ・ロードなどにも移れるようにする
    if not main_menu:
        hbox:
            xalign 1.0
            xoffset -40
            ypos 46
            spacing 6
            textbutton "セーブ" action ShowMenu("save") style "sp_link_button" text_style "sp_link_text"
            textbutton "ロード" action ShowMenu("load") style "sp_link_button" text_style "sp_link_text"
            textbutton "ログ" action ShowMenu("history") style "sp_link_button" text_style "sp_link_text"
            textbutton "ステータス" action ShowMenu("status") style "sp_link_button" text_style "sp_link_text"
            textbutton "相関図" action ShowMenu("relations") style "sp_link_button" text_style "sp_link_text"

    ## 左のタブ
    vbox:
        xpos 60
        ypos 136
        spacing 8
        textbutton "画面と文字" action SetField(persistent, "pref_tab", "display") style "sp_tab_button" text_style "sp_tab_text"
        textbutton "音" action SetField(persistent, "pref_tab", "sound") style "sp_tab_button" text_style "sp_tab_text"
        textbutton "ヒント" action SetField(persistent, "pref_tab", "hint") style "sp_tab_button" text_style "sp_tab_text"

    textbutton ("◀ ゲームに戻る" if not main_menu else "◀ 戻る") action Return() style "sp_back_button" text_style "sp_back_text"
    if not main_menu:
        textbutton "タイトルへ" action MainMenu() style "sp_small_button" text_style "sp_small_text"

    ## 右のカード
    vbox:
        xpos 300
        ypos 136
        spacing 16
        vpgrid:
            cols 2
            xspacing 18
            yspacing 18
            if persistent.pref_tab == "sound":
                use sp_card("BGM", "BGMの音量"):
                    use sp_gauge(Preference("music volume"))
                use sp_card("SE", "効果音の音量"):
                    use sp_gauge(Preference("sound volume"))
                use sp_card("VOICE", "ボイスの音量"):
                    use sp_gauge(Preference("voice volume"))
                use sp_card("VOICE", "次の文に進んだときのボイス"):
                    use sp_pills([("止める", Preference("voice sustain", "disable")), ("止めない", Preference("voice sustain", "enable"))])
            elif persistent.pref_tab == "hint":
                use sp_card("HINT", "何が上がるか（選択肢）"):
                    use sp_pills([("出さない", SetField(persistent, "choice_hints", False), not persistent.choice_hints), ("出す", SetField(persistent, "choice_hints", True), bool(persistent.choice_hints))])
                use sp_card("JUDGE", "試合の判定"):
                    use sp_pills([("出さない", SetField(persistent, "judge_hints", False), not persistent.judge_hints), ("出す", SetField(persistent, "judge_hints", True), bool(persistent.judge_hints))])
                use sp_card("TEST", "能力値・絆の変化を画面に出す"):
                    use sp_pills([("出さない", SetField(persistent, "show_param_notify", False), not persistent.show_param_notify), ("出す", SetField(persistent, "show_param_notify", True), bool(persistent.show_param_notify))])
                use sp_card("GUIDE", "セーブの案内"):
                    ## セーブの案内は1回目のプレイだけ出る。もう一度見たいときに押す
                    frame:
                        style "sp_pill_base"
                        textbutton "最初の選択肢の前に、もう一度出す" action [SetField(persistent, "save_guide_seen", False), Notify("次に最初の選択肢まで進むと、セーブの案内が出ます")] sensitive persistent.save_guide_seen style "sp_pill_button" text_style "sp_pill_text"
            else:
                ## ウィンドウ／全画面の切り替えは PC だけ（スマホでは出さない）
                if not renpy.variant("mobile"):
                    use sp_card("DISPLAY", "画面"):
                        use sp_pills([("ウィンドウ", Preference("display", "window")), ("全画面", Preference("display", "fullscreen"))])
                use sp_card("SKIP", "スキップ"):
                    use sp_pills([("既読のみ", Preference("skip", "seen")), ("未読も含む", Preference("skip", "all"))])
                use sp_card("TEXT SPEED", "文字の速さ"):
                    use sp_gauge(Preference("text speed"))
                use sp_card("AUTO SPEED", "オートの速さ"):
                    use sp_gauge(Preference("auto-forward time"))

        if persistent.pref_tab == "hint":
            text "何が上がるか：能力・仲間との絆・ヒロインの気持ちのどれが上がるか（↑↓だけ）。出さないと、蓮になったつもりで選べます。出すと、ねらった結末に向かいやすくなります\n試合の判定：試合の大事な場面で、判定に使う能力と、必要な数値・いまの数値" style "sp_note_text"

## カード1枚（英字の小見出し・名前・中身）
screen sp_card(en, jp):
    frame:
        style "sp_card"
        vbox:
            spacing 2
            text en style "sp_card_en"
            text jp style "sp_card_jp"
            null height 12
            transclude

## ゲージ（バー）
screen sp_gauge(value):
    bar value value style "sp_gauge"

## 切り替えボタン（暗い土台の中に並べる。選ばれたほうが白くなる）
##   items: (名前, action) か (名前, action, 選ばれているか)
screen sp_pills(items):
    frame:
        style "sp_pill_base"
        hbox:
            spacing 4
            for _it in items:
                if len(_it) > 2:
                    textbutton _it[0] action _it[1] selected _it[2] style "sp_pill_button" text_style "sp_pill_text"
                else:
                    textbutton _it[0] action _it[1] style "sp_pill_button" text_style "sp_pill_text"

style sp_head_text:
    xpos 52
    ypos 40
    font FONT_JP_B
    size 32
    kerning 4
    color SP_NAVY

style sp_link_button:
    padding (14, 4, 14, 6)
    hover_background Frame("gui/sp/link_hover.png", 12, 0)

style sp_link_text:
    font FONT_JP_B
    size 18
    color SP_PALE
    hover_color "#ffffff"

style sp_tab_button:
    xysize (220, 50)
    background "gui/sp/tab_idle.png"
    hover_background "gui/sp/tab_hover.png"
    selected_background "gui/sp/tab_sel.png"
    padding (20, 0, 0, 0)

style sp_tab_text:
    yalign 0.5
    font FONT_JP_B
    size 22
    color SP_PALE
    hover_color "#ffffff"
    selected_color "#ffffff"

style sp_back_button:
    xpos 60
    yanchor 1.0
    ypos 670
    xysize (170, 46)
    background "gui/sp/back_idle.png"
    hover_background "gui/sp/back_hover.png"

style sp_back_text:
    xalign 0.5
    yalign 0.5
    font FONT_JP_B
    size 19
    color "#ffffff"
    hover_color SP_NAVY

style sp_small_button:
    xpos 70
    yanchor 1.0
    ypos 708
    padding (4, 2, 4, 2)

style sp_small_text:
    size 17
    color SP_SKY
    hover_color "#ffffff"
    underline True

style sp_card:
    xysize (456, 150)
    background Frame("gui/sp/card.png", 8, 8)
    padding (24, 18, 24, 16)

style sp_card_en:
    size 13
    kerning 3
    color SP_SKY

style sp_card_jp:
    font FONT_JP_B
    size 22
    color "#ffffff"

style sp_gauge:
    xsize 342
    ysize 16
    left_bar "gui/sp/gauge_full.png"
    right_bar "gui/sp/gauge_empty.png"
    hover_right_bar "gui/sp/gauge_empty_hover.png"
    thumb "gui/sp/gauge_thumb.png"
    hover_thumb "gui/sp/gauge_thumb_hover.png"
    thumb_offset 0

style sp_pill_base:
    background Frame("gui/sp/pill_base.png", 6, 6)
    padding (4, 4, 4, 4)

style sp_pill_button:
    padding (22, 5, 22, 7)
    hover_background Frame("gui/sp/pill_hover.png", 6, 6)
    selected_background Frame("gui/sp/pill_on.png", 6, 6)

style sp_pill_text:
    size 19
    color SP_PALE
    hover_color "#ffffff"
    selected_font FONT_JP_B
    selected_color SP_NAVY
    selected_hover_color SP_NAVY
    insensitive_color "#6a78a0"

style sp_note_text:
    xsize 930
    size 17
    color SP_PALE
    line_spacing 4


################################################################################
## ログ（バックログ）
################################################################################

define config.history_length = 250

screen history():
    tag menu
    predict False

    use game_menu("ログ", scroll="viewport", yinitial=1.0):
        style_prefix "history"

        for h in _history_list:
            vbox:
                spacing 0
                if h.who:
                    text h.who style "history_name"
                text h.what substitute False style "history_text"

        if not _history_list:
            text "ログはまだありません。"

style history_name:
    font FONT_JP_B
    size 19
    color PEN_RED

## ふりがな（ログ画面用）。使うスタイルより先に作っておく
style ruby_history:
    size 11
    yoffset -20
    color None

style history_text:
    size 22
    xsize 860
    ruby_line_leading 10
    ruby_style style.ruby_history


################################################################################
## 確認ダイアログ（大きな付箋）
################################################################################

screen confirm(message, yes_action, no_action):
    modal True
    zorder 200

    add Solid("#00000077")

    fixed:
        xysize (580, 300)
        xalign 0.5
        yalign 0.5
        add "gui/note_big.png"
        vbox:
            xalign 0.5
            yalign 0.5
            yoffset -6
            xsize 480
            spacing 30
            text message xalign 0.5 text_align 0.5 size 24
            hbox:
                xalign 0.5
                spacing 80
                textbutton "はい" action yes_action text_size 28
                textbutton "いいえ" action no_action text_size 28

    key "game_menu" action no_action

################################################################################
## セーブの案内（最初の選択肢の前に1回だけ出す。大きな付箋）
################################################################################

screen save_prompt():
    modal True
    zorder 200

    add Solid("#00000077")

    fixed:
        xysize (580, 300)
        xalign 0.5
        yalign 0.5
        add "gui/note_big.png"
        vbox:
            xalign 0.5
            yalign 0.5
            yoffset -6
            xsize 480
            spacing 26
            text "ここでセーブしておこう" xalign 0.5 font FONT_JP_B size 30 color INK
            text "あとで、ここから別の答えを試せます" xalign 0.5 size 20 color INK_SOFT
            hbox:
                xalign 0.5
                spacing 60
                textbutton "セーブする" action ShowMenu("save") text_size 28 text_color PEN_RED text_hover_color INK
                textbutton "つづける" action Return() text_size 28

    key "game_menu" action ShowMenu("save")

init python:
    layout.ARE_YOU_SURE = "よろしいですか？"
    layout.DELETE_SAVE = "このセーブデータを削除しますか？"
    layout.OVERWRITE_SAVE = "上書きしますか？"
    layout.LOADING = "ロードすると、保存していない進み具合は失われます。よろしいですか？"
    layout.QUIT = "ゲームを終了しますか？"
    layout.MAIN_MENU = "タイトル画面に戻りますか？保存していない進み具合は失われます。"
    layout.END_REPLAY = "回想を終了しますか？"
    layout.SLOW_SKIP = "スキップを始めますか？"
    layout.FAST_SKIP_SEEN = "次の選択肢まで既読をスキップしますか？"
    layout.FAST_SKIP_UNSEEN = "次の選択肢までスキップしますか？"


################################################################################
## 通知・スキップ中の表示（小さな付箋）
################################################################################

screen notify(message):
    zorder 150
    frame at fade_in_out:
        xalign 0.5
        ypos 12
        text "[message!tq]" size 20
    timer 3.0 action Hide("notify")

screen skip_indicator():
    zorder 100
    frame:
        xpos 14
        yalign 0.66
        text "スキップ中 ▶▶" size 20 color PEN_RED

transform fade_in_out:
    on show:
        alpha 0.0
        linear 0.25 alpha 1.0
    on hide:
        linear 0.4 alpha 0.0
