## chapter5a_2.rpy ―― 第5章（ルートA）の後半①：選手権予選（10〜11月）（v0.32.0・Claude の第1稿）
##   手術する：10/8 手術 → 1回戦は病室でトーク、2回戦はあげはの配信、3回戦からベンチで黒田の隣
##             → 11/6 準決勝・清翔に 0−0 から PK で負け（外から見る）
##   手術しない：痛み止めで、1回戦〜準々決勝は後半20分だけ → 11/6 準決勝・清翔に 1−2。60分の前に、ひざが止まる
##   → 11/14 決勝（清翔 対 桜嶺）をスタンドから。桜嶺が勝つ。神城の左足首は、あげはの動画の中だけ
##   → 11月の終わり：リハビリの始まり（手術した人）／痛みを隠す（しなかった人。あげはの「推しの秘密」）
##   清翔学園のコーチ・結城は、鷹野のジュニアユース時代のコーチ。理詰めで、怒鳴らない（鬼塚の逆）

default a5_semi = ""            # 準決勝のスコア（"0−0（PK 3−4）" / "1−2"）
default a5_semi_towel = ""      # 準決勝でひなたがタオルを上げたとき：go（ベンチへ行く）/ stay（走り続ける）/ ""（約束していない）
default a5_semi_word = ""       # 手術した人：準決勝のハーフタイムに黒田へ言ったこと（koba：小早川の首 / takano：鷹野の裏）
default a5_r3_word = ""        # 手術した人：3回戦でベンチから黒田に言ったこと（inside：坂口を内側へ / behind：鷹野が4番の右へ）
default a5_secret = ""          # 手術しなかった人：11月、あげはに痛み止めを見られて：tell（自分で話す）/ keep（黙っていてくれ）


## 手術した人の選手権の一枚絵（11/12 作者の声「絵も変わらない、試合の緊張感もない」で足した）
image cg a5_bench_kuroda = "images/cg/a5_bench_kuroda.jpg"    # 3回戦：松葉杖をベンチに立てかけ、身を乗り出して指さす蓮と、腕を組んだ黒田
image cg a5_koba_scan = "images/cg/a5_koba_scan.jpg"          # 準々決勝：蓮の場所で、ボールを受ける前に首を振る小早川（15番）
image cg ch5r_goal = "images/cg/ch5r_goal.jpg"    # 3回戦（手術した道）：鷹野のループ（v0.44.1）
image cg ch5r_post = "images/cg/ch5r_post.jpg"    # 3回戦（手術した道）：最後のフリーキックがポスト（v0.44.1）
image cg ch5r_ice = "images/cg/ch5r_ice.jpg"    # 3回戦（手術しなかった道）：氷と痛み止め（v0.44.1）
image cg ch5q_goal14 = "images/cg/ch5q_goal14.jpg"    # 準々決勝：前半14分、鷹野の1点目（v0.44.1）
image cg ch5q_keeper = "images/cg/ch5q_keeper.jpg"    # 準々決勝：後半28分、混戦のボールを抱える大門（v0.44.1）
image cg ch5q_left = "images/cg/ch5q_left.jpg"    # 準々決勝（手術しなかった道）：左足のアウトで赤坂へ（v0.44.1）
image cg ch5q_rightshot = "images/cg/ch5q_rightshot.jpg"    # 準々決勝（手術しなかった道）：右足で自分で撃つ（v0.44.1）
image cg ch5q_takano2 = "images/cg/ch5q_takano2.jpg"    # 準々決勝（手術しなかった道）：鷹野に預けて鷹野のゴール（v0.44.1）
image cg ch5q_dive = "images/cg/ch5q_dive.jpg"    # 準々決勝（手術した道）：後半44分、こぼれ球に飛びこむ大門（v0.44.1）
image cg a5_daimon_pk = "images/cg/a5_daimon_pk.jpg"          # 準決勝のPK：清翔の3人目を止める大門
image cg a5_koba_pk_bar = "images/cg/a5_koba_pk_bar.jpg"      # 準決勝のPK：小早川の5人目が右上の角でバーをたたいて外へ
image cg a5_crutch_koba = "images/cg/a5_crutch_koba.jpg"      # PKのあと：ひざをつく小早川へ、松葉杖で歩いていく蓮（うしろに人はいない）

label chapter5a_2:
    call a5_surgery_day
    call a5_early_rounds
    call a5_qf
    call a5_semi_eve
    call a5_semi
    call a5_final
    call a5_after_semi
    jump chapter5a_3


################################################################################
## 10月8日：手術の日（しない人は、前の夜の部室）
################################################################################
label a5_surgery_day:
    scene black
    with dissolve
    if a5_surgery:
        $ set_cal("10月8日（金）", "夕方・大学病院")
        scene bg a5_ward
        with dissolve
        $ bgm("静かなピアノ")
        "目がさめると、窓の外が、オレンジ色だった。右足が、自分のものじゃないみたいに重かった。"
        show mother casual
        with dissolve
        haha "……おはよう。もう夕方だけど"
        haha "先生、うまくいったって。……あたしは、何回も聞いた。三回目で、看護師さんに笑われた"
        show mother casual_sad
        haha "お父さんのときは、手術室の前で、待つこともできなかったから。……待てて、よかった"
        hide mother
        with dissolve
        "母さんが売店に行っているあいだに、スマホが何回も鳴っていた。"
        $ se("トークアプリの通知音（連続）")
        window auto hide
        $ talk_start("港北サッカー部（%d）" % (a4_members + 2), "17:40")
        $ talk("坂口", "蓮、生きてる？")
        $ talk("大門", "生きてるか")
        $ talk("赤坂", "生きてますか")
        $ talk("ひなた", "みんな、それしか言えないの？")
        $ talk("ひなた", "蓮、起きたら、ひざの角度だけ教えて")
        $ talk("鷹野", "明日、勝つ")
        $ talk_wait(2)
        $ talk_me("生きてる。角度は、まだ聞いてない")
        $ talk("あげは", "既読ついた！！！　推し、生存確認！！！")
        window auto hide
        $ talk_end()
        "スマホを胸の上に置いた。ひざのかわりに、胸が、少し熱かった。"
    else:
        $ set_cal("10月8日（金）", "夜・部室")
        scene bg clubroom_night_rain
        with dissolve
        $ bgm("静かな緊張感のある曲")
        $ se("雨の音")
        "1回戦の前の夜。部室で、ひなたが、俺のひざにテーピングを巻いていた。夏より、三周多かった。"
        show hinata serious
        with dissolve
        hinata "……本当なら、今ごろ、手術が終わってる時間だね"
        ren "後悔は、してない"
        hinata "うん。……わたしも、後悔しないように、全部見る"
        "ひなたは、テープを切ってから、ノート「冬」の一ページ目に、日付を書いた。"
        hide hinata
        with dissolve
        $ amb_stop()
    return


################################################################################
## 1回戦〜3回戦（10/9・10/16・10/23）。短く
################################################################################
label a5_early_rounds:
    scene black
    with dissolve
    $ set_cal("10月9日（土）", "選手権予選1回戦")
    if a5_surgery:
        scene bg a5_ward
        with dissolve
        $ bgm("静かな緊張感のある曲")
        "1回戦の日。病室のベッドで、スマホを両手で持っていた。"
        $ se("トークアプリの通知音")
        window auto hide
        $ talk_start("ひなた", "11:20")
        $ talk("ひなた", "前半、1−0。鷹野くん")
        $ talk("ひなた", "小早川くん、蓮の場所で、首3回振ってた")
        $ talk_wait(30)
        $ talk("ひなた", "おわった。3−0")
        $ talk("ひなた", "黒田先生が、ベンチの、蓮の座る場所を空けてた。誰も座らせなかった")
        window auto hide
        $ talk_end()
        "3−0。病室の天井に向かって、小さく、こぶしを上げた。"
        ## 2回戦：あげはの配信
        $ set_cal("10月16日（土）", "選手権予選2回戦")
        scene bg ren_room_morning
        with dissolve
        "2回戦は、家のベッドで、あげはの配信を見た。画面の右下に、「推し、自宅療養中。みんなで応援しよ」と書いてあった。"
        "画面の中で、大門が、PKを一本止めた。コメントが、滝みたいに流れた。2−1で勝った。"
        ## 3回戦：松葉杖でベンチへ（11/12 作者の声「手術した場合の選手権があっさり進む。絵も変わらない、緊張感もない」で、試合の場面にした）
        $ set_cal("10月23日（土）", "選手権予選3回戦")
        scene bg pref_ground_autumn
        with dissolve
        $ bgm("静かな緊張感のある曲")
        "3回戦の日、松葉杖で、ベンチに入った。手術から、ちょうど2週間だった。"
        "ベンチの端から二つ目。黒田の隣の席は、本当に空いていた。"
        show kuroda normal
        with dissolve
        voice "audio/voice/kuroda_ch5r_suwaru.mp3"
        kuroda "座れ。……全部見て、全部言え"
        hide kuroda
        with dissolve
        "相手は、港南工業。夏の大会でベスト16。体の大きい選手が多くて、前へ長いボールを蹴ってくるチームだった。"
        "円陣の声が、ベンチまで聞こえた。その輪の中に、俺はいなかった。"
        $ se("キックオフの笛")
        $ sb_set("前半", 0, 0, 0, 0, "#2a5bd7", "#d9822b", "港北", "港南工", length=45)
        scene bg pref_ground_autumn at cam_jog
        with dissolve
        show screen letterbox
        show screen scoreboard
        $ bgm("緊迫した試合の曲")
        "ピッチの外から見る試合は、思っていたより、遅かった。ボールより先に、人が動くのが見えた。"
        "見えるのに、足が動かなかった。右ひざの固定具の中で、筋肉だけが、勝手に走ろうとしていた。"
        $ sb_set(mm=18)
        $ se("鈍い衝突音")
        with hpunch
        "前半18分。港南工の長いボールを、大門が前に出てつかんだ。相手のフォワードが、大門の背中にぶつかった。"
        daimon "……っ、大丈夫です！"
        "大門の声が、ベンチまで届いた。夏より、少しだけ、低い声だった。"
        $ sb_set(mm=31)
        "前半31分。港南工の右の7番が、ハーフウェーラインの手前で、また中を向いた。……三回目だった。"
        hide screen scoreboard
        hide screen letterbox
        scene cg a5_bench_kuroda
        with Dissolve(0.8)
        "気づいたら、ベンチから身を乗り出して、指をさしていた。"
        menu:
            "「右の7番、毎回、同じところで中を向く。坂口を一歩、内に」":
                $ a5_r3_word = "inside"
                $ lean("求道型")
                ren "右の7番、毎回、ハーフウェーラインの手前で中を向きます。坂口を、一歩だけ内側に"
                kuroda "……坂口！　一歩、内だ！"
                $ up("戦術眼", 2)
            "「相手の4番、左にしか向きを変えない。鷹野を4番の右へ」":
                $ a5_r3_word = "behind"
                $ lean("野心型")
                ren "相手の4番、左足でしか向きを変えません。鷹野が4番の右に出れば、裏が空きます"
                kuroda "……鷹野！　4番の右だ！"
                $ up("戦術眼", 1)
                $ bond_up("鷹野", 1)
        "黒田は、俺のほうを見なかった。腕を組んだまま、ピッチだけを見ていた。"
        kuroda "……見えてるなら、いい。座ってろ。立つと、ひざに響く"
        scene bg pref_ground_autumn at cam_jog
        with dissolve
        show screen letterbox
        $ sb_set("後半", 45)
        show screen scoreboard
        $ se("笛の音")
        "0−0で、後半に入った。港南工は、前半よりも、もっと長いボールを蹴ってきた。"
        $ sb_set(mm=67)
        if a5_r3_word == "inside":
            "後半22分。坂口が、一歩内側で、7番の前に体を入れた。ボールが、坂口の足もとに残った。"
            "坂口は、顔を上げないまま、前へ蹴った。……鷹野は、もうそこにいた。"
        else:
            "後半22分。小早川の長いパスが、相手の4番の右に落ちた。4番が左に向き直るあいだに、鷹野は、もう裏にいた。"
        $ se("ボールを蹴る音")
        scene cg ch5r_goal
        with goal_flash
        $ goal("港北", home=1, away=0, mm=67, by="鷹野")
        with vpunch
        $ cg_look()
        "鷹野は、トラップを一回だけして、キーパーの肩の上を抜いた。"
        scene bg pref_ground_autumn at cam_jog
        with dissolve
        "ベンチの全員が立ち上がった。俺だけ、立ち上がりかけて、黒田に肩をつかまれた。"
        kuroda "座ってろと言った"
        $ sb_set(mm=88)
        "後半43分。港南工の、最後のフリーキック。ゴール前に、相手の大きい選手が全員上がってきた。"
        $ se("ボールがポストに当たる音")
        scene cg ch5r_post
        with hpunch
        $ cg_look()
        "ボールは、大門の指先をかすめて、ポストをたたいた。ベンチで、息が止まった。"
        $ se("試合終了の笛")
        pause 1.0
        hide screen scoreboard
        hide screen letterbox
        scene bg pref_ground_autumn
        with Dissolve(1.0)
        python:
            _rows = [("スコア", "1−0（勝ち）"),
                     ("前半31分", "早瀬がベンチから「右の7番」を言い、坂口を一歩内へ" if a5_r3_word == "inside" else "早瀬がベンチから「相手の4番」を言い、鷹野を4番の右へ"),
                     ("後半22分", "鷹野のゴール"),
                     ("後半43分", "港南工のフリーキックが、ポスト")]
            _memo = "ひなた：蓮、ベンチで、ずっと右足に力が入ってた。……座ってるのに"
        call screen match_report("選手権予選3回戦　港北 対 港南工業", _rows, _memo)
        $ bgm("（なし）")
        "試合のあと、鷹野が、ベンチの前を通りながら、松葉杖の先を一回だけ、軽くけった。"
        show takano match
        with dissolve
        voice "audio/voice/takano_ch5r_tsugi.mp3"
        takano "……お前の言ったとこ、空いてた。次も言え"
        hide takano
        with dissolve
        $ up("戦術眼", 1)
    else:
        scene bg pref_ground_autumn
        with dissolve
        $ bgm("明るい部活の曲")
        "1回戦。後半25分から、ピッチに入った。黒田のストップウォッチは、入る前から押されていた。"
        "20分で、一本アシストした。3−0。試合のあと、ひざを氷で冷やしながら、痛み止めを飲んだ。"
        $ set_cal("10月16日（土）", "選手権予選2回戦")
        "2回戦。後半25分から。1−1の後半40分、鷹野へのスルーパス。2−1。"
        "帰りのバスで、ひなたが、ノート「冬」に「20分。ふつう」と書いていた。"
        $ set_cal("10月23日（土）", "選手権予選3回戦")
        "3回戦。前半から、相手の右サイドが、毎回同じところで中を向いた。ベンチから黒田に言うと、黒田は、坂口を一歩だけ内側に寄せた。"
        "後半、そこで坂口がボールを奪って、俺が入ってすぐ、鷹野が決めた。1−0。"
        scene cg ch5r_ice
        with Dissolve(1.0)
        "試合のあと、右ひざが、いつもより長く熱かった。痛み止めは、医者の言った量だけ飲んだ。……言った量だけ、だと思う。"
        $ up("技術", 1)
        $ up("無理ゲージ", 4)
    return


################################################################################
## 10月30日（土）準々決勝：港北 対 鳴海（夏と同じ相手。今度は、向こうが前から来る）
################################################################################
default a5_qf_word = ""      # 準々決勝（手術した道）のハーフタイムに黒田に言ったこと：koba / eto（v0.44.1）
default a5_qf_last = ""      # 準々決勝（手術しなかった道）の後半39分：left / right / takano（v0.44.1）

label a5_qf:
    scene black
    with dissolve
    $ set_cal("10月30日（土）", "選手権予選準々決勝")
    scene bg pref_ground_autumn
    with dissolve
    $ bgm("張りつめた静かな曲")
    "準々決勝の相手は、夏と同じ鳴海高校だった。夏は後ろに9人。今度は、前から来た。"
    show kuroda board
    with dissolve
    kuroda "鳴海は、夏の負けを、俺たちのせいにしてる。……だから、前から来る"
    kuroda "前から来るチームの後ろは、空いてる。小早川、一本目は、迷わず鷹野の裏だ"
    hide kuroda
    with dissolve
    $ se("キックオフの笛")
    $ sb_set("前半", 0, 0, 0, 0, "#2a5bd7", "#1f8a5a", "港北", "鳴海", length=45)
    scene bg pref_ground_autumn at cam_jog
    with dissolve
    show screen letterbox
    show screen scoreboard
    $ bgm("緊迫した試合の曲")
    $ flow("前半", 8, "鳴海、前から来ます！　夏とは、まるでちがうチームです", panel="ch5q_p08", of=(1, 1), tag="ピンチ", shots=(0, 2), sfx="土を蹴る足音")
    if a5_surgery:
        "ベンチから見ると、小早川の首の振り方が、よく見えた。"
        $ sb_set(mm=14)
        hide screen scoreboard
        hide screen letterbox
        scene cg a5_koba_scan
        with Dissolve(0.6)
        "[a4_no()]番の場所で、小早川が、首を振った。一回。二回。……三回目で、もう蹴っていた。"
        "春に、俺が教えたやり方だった。教えた俺より、半秒、速かった。"
        scene bg pref_ground_autumn at cam_jog
        with dissolve
        show screen letterbox
        show screen scoreboard
        $ se("ボールを蹴る音")
        "前半14分。小早川の縦パスに、鷹野が裏へ抜けた。"
        scene cg ch5q_goal14
        with goal_flash
        $ goal("港北", home=1, away=0, mm=14, by="鷹野")
        with vpunch
        $ cg_look()
        scene bg pref_ground_autumn at cam_jog
        with dissolve
        "黒田の隣で、松葉杖を持ったまま立ち上がっていた。黒田は、座ったままだった。でも、ストップウォッチを握った手が、白くなっていた。"
        $ sb_set(mm=38)
        "前半38分。鳴海の10番が、小早川の背中に、わざと体を当ててきた。小早川が、芝に転がった。"
        "ベンチの俺を、小早川が、ちらっと見た。……首は、振らなかった。すぐに立って、走って戻った。"
        ## v0.44.1：ハーフタイムに、ベンチから見えたことを黒田に言う（作者の声で、試合のまとめの「右サイドの癖を言った」と中身をそろえた）
        $ sb_set(mm=45)
        $ se("前半終了の笛")
        "ハーフタイム。ベンチに戻ってきた黒田が、俺の前で、立ち止まった。"
        show kuroda normal
        with dissolve
        voice "audio/voice/kuroda_ch5q_mieta.mp3"
        kuroda "……何が見えた。言え"
        menu:
            "「10番は、小早川の右からしか当たってきません。小早川を、半歩だけ左に」":
                $ a5_qf_word = "koba"
                $ lean("仲間型")
                $ up("戦術眼", 1)
                kuroda "……小早川。半歩、左だ"
                hide kuroda
                with dissolve
                "後半、10番の体当たりは、小早川の右肩の、半歩うしろで空を切った。小早川は、もう転ばなかった。"
            "「鳴海の右のサイドバックが、上がったまま戻りません。江藤の裏が空きます」":
                $ a5_qf_word = "eto"
                $ lean("野心型")
                $ up("戦術眼", 1)
                kuroda "……江藤。裏だ"
                hide kuroda
                with dissolve
                "後半、江藤が、何度も右サイドバックの裏へ走った。鳴海は、少しずつ、前から来られなくなった。"
    else:
        "ベンチで、ストップウォッチの数字を見ていた。後半25分まで、あと70分。"
        $ sb_set(mm=14)
        $ se("ボールを蹴る音")
        "前半14分。小早川の縦パスに、鷹野が裏へ抜けた。"
        scene cg ch5q_goal14
        with goal_flash
        $ goal("港北", home=1, away=0, mm=14, by="鷹野")
        with vpunch
        $ cg_look()
        scene bg pref_ground_autumn at cam_jog
        with dissolve
    $ sb_set("後半", 45)
    $ flow("後半", 73, "鳴海のコーナーキック！　ゴール前は混戦、こぼれたボールは――", panel="ch5q_p73", of=(1, 1), tag="ピンチ", shots=(4, 9), sfx="鈍い衝突音")
    "後半28分。鳴海のコーナーキック。ゴール前の混戦から、ボールが大門の正面にこぼれた。"
    voice "audio/voice/daimon_ch4q_keeper.mp3"
    daimon "キーパー！！"
    scene cg ch5q_keeper
    with vpunch
    $ cg_look()
    if a4_qf_daimon_lv == 2:
        "大門の声が、全員を止めた。夏と同じ声だった。"
    else:
        "大門の声が、全員を止めた。夏より、ずっと大きな声だった。"
    scene bg pref_ground_autumn at cam_jog
    with dissolve
    if not a5_surgery:
        "後半25分から、ピッチに入っていた。大門が投げたボールを、左足で受けた。右足に、体重をのせなかった。"
        $ sb_set(mm=84)
        "後半39分。前に、赤坂。右に、鷹野。正面には、鳴海のディフェンダーが一人だけ。"
        ## v0.44.1：時間で選ぶ（時間切れは蓮のくせ：仲間型・野心型・求道型の順に並べた3つ）。どれでも 2−0
        menu (timed=TIMED_CHOICE, habit=("仲間型", "野心型", "求道型")):
            "左足のアウトで、赤坂の前に転がす":
                $ a5_qf_last = "left"
                $ lean("仲間型")
                $ se("ボールを蹴る音")
                scene cg ch5q_left
                with hpunch
                $ cg_look()
                "左足のアウトサイドで、赤坂の前に転がした。赤坂が、ゴールの右すみに流しこんだ。"
                $ goal("港北", home=2, away=0, mm=84, by="赤坂")
                with vpunch
                scene bg pref_ground_autumn at cam_jog
                with dissolve
                akasaka "今の、左っすよね！？　先輩、左でも出せるんすか！"
                "出せるようになったのは、右が使えない日のためだった。それは、言わなかった。"
                $ up("無理ゲージ", 2)
            "右足で、自分で撃つ":
                $ a5_qf_last = "right"
                $ lean("野心型")
                $ se("ボールを蹴る音")
                scene cg ch5q_rightshot
                with goal_flash
                $ goal("港北", home=2, away=0, mm=84, by="早瀬")
                with vpunch
                $ cg_look()
                "右足で、振り抜いた。ボールがネットに届くより先に、右ひざの奥で、何かがきしんだ。"
                scene bg pref_ground_autumn at cam_jog
                with dissolve
                "入った。……ひざに手をついたまま、しばらく、顔を上げられなかった。"
                takano "……バカ。今のは、俺に出すとこだ"
                $ up("無理ゲージ", 5)
            "鷹野に預けて、ゴール前へ走る":
                $ a5_qf_last = "takano"
                $ lean("求道型")
                $ se("ボールを蹴る音")
                "右の鷹野に、左足で預けた。ゴール前へ走りこもうとして、右足が、半歩おくれた。"
                scene cg ch5q_takano2
                with goal_flash
                $ goal("港北", home=2, away=0, mm=84, by="鷹野")
                with vpunch
                $ cg_look()
                "鷹野は、俺を待たなかった。右足のアウトで、ゴールのすみに流しこんだ。"
                scene bg pref_ground_autumn at cam_jog
                with dissolve
                takano "……来なくていい。お前は、見てろ"
                $ up("無理ゲージ", 1)
        $ _qf5 = "2−0（勝ち）"
    else:
        $ sb_set(mm=89)
        "後半44分。鳴海は、キーパーまで上がってきた。11人全員が、港北のゴール前にいた。"
        $ se("鈍い衝突音")
        with hpunch
        scene cg ch5q_dive
        with hpunch
        $ cg_look()
        "大門が、こぼれ球に、頭から飛びこんだ。誰かのスパイクが、大門の肩をかすめた。"
        scene bg pref_ground_autumn at cam_jog
        with dissolve
        "ベンチで、松葉杖の先が、床を三回たたいた。俺の手が、勝手にやっていた。"
        "アディショナルタイムは、3分。黒田のストップウォッチの数字が、こんなに遅く進むのを、初めて見た。"
        $ _qf5 = "1−0（勝ち）"
    $ se("試合終了の笛")
    pause 1.0
    hide screen scoreboard
    hide screen letterbox
    scene bg pref_ground_autumn
    with Dissolve(1.0)
    python:
        _rows = [("スコア", _qf5), ("前半14分", "小早川の縦パス　→　鷹野のゴール"),
                 ("後半", ({"left": "早瀬が後半25分から。左足で、赤坂のゴールにつないだ",
                           "right": "早瀬が後半25分から。右足で、自分で決めた（ひざがきしんだ）",
                           "takano": "早瀬が後半25分から。鷹野に預けて、鷹野のゴール"}.get(a5_qf_last, "早瀬が後半25分から"))
                          if not a5_surgery else
                          ("早瀬はベンチ。ハーフタイムに「10番は小早川の右から」と言い、小早川を半歩左へ" if a5_qf_word == "koba"
                           else "早瀬はベンチ。ハーフタイムに「右のサイドバックが戻らない」と言い、江藤が裏へ")),
                 ("大門", "声を出して、コーナーキックのこぼれ球を止めた")]
        _memo = "ひなた：2年連続で、ベスト4。……次は、清翔"
    call screen match_report("選手権予選準々決勝　港北 対 鳴海", _rows, _memo)
    $ bgm("（なし）")
    mono "ベスト4。去年の冬と、今年の夏と、同じ場所まで来た。"
    mono "準決勝の相手は、桜嶺じゃなかった。清翔学園。鷹野が、行かなかったチーム。"
    $ up("メンタル", 1)
    return


################################################################################
## 11月5日（金）：準決勝の前の日（結城が、港北のグラウンドを見に来る）
################################################################################
label a5_semi_eve:
    scene black
    with dissolve
    $ set_cal("11月5日（金）", "準決勝の前の日")
    scene bg kohoku_ground_eve
    with dissolve
    $ bgm("静かな春の曲")
    "準決勝の前の日の練習のあと、フェンスの外に、背の高い男の人が立っていた。グレーのジャンパー。腕は、組んでいなかった。"
    show takano surprised
    with dissolve
    takano "……結城さん"
    hide takano
    with dissolve
    yuki "練習の邪魔をしに来たんじゃない。……明日の会場の芝が、雨で重いと聞いたから、伝えに来た"
    yuki "同じ条件で戦いたいからね。こっちだけ知っているのは、気持ちが悪い"
    "結城さんは、そう言って、鷹野のほうを見た。"
    yuki "迅。夏の電話、断ってくれてよかったよ"
    yuki "君がうちにいたら、明日の試合が、つまらなくなった"
    "それから、俺のほうを見た。目が、黒田と少し似ていた。見るところが、ひざではなく、顔だった。"
    yuki "早瀬くんだね。……8月の練習試合の映像、見た。左で踏み切るのは、いつから？"
    if a5_surgery:
        ren "……その足は、10月8日に、手術しました"
        yuki "そうか。……いい判断をしたね。君の判断だったのなら、なおいい"
        yuki "来年の夏に、また見せてくれ。右で踏み切るところを"
    else:
        ren "……夏からです"
        yuki "そうか"
        "結城さんは、それ以上は聞かなかった。かわりに、黒田のほうへ小さく頭を下げた。"
        yuki "黒田さん。……明日、うちは、彼の右側を狙います。先に言っておきます"
        show kuroda normal
        with dissolve
        kuroda "……知ってる。俺でも、そうする"
        hide kuroda
        with dissolve
    "結城さんは、帰っていった。一回も、声を大きくしなかった。"
    show takano jersey_narrow
    with dissolve
    takano "……な。言い訳、できねえだろ"
    hide takano
    with dissolve
    return


################################################################################
## 11月6日（土）準決勝：港北 対 清翔学園
##   v0.44.1：3回戦の型にした（製品版の横展開・重さA）。会場は県の陸上競技場（去年の冬と同じ。芝）。清翔は黒（銀の線）。
##   手術した道：流れのコマ2枚・ハーフタイムは作戦ボードを見てから「見えたもの」を選ぶ・PK の5人目の前は「時間で選ぶ」・一枚絵5枚・声2本
##   手術しなかった道：試合前の作戦ボード（早瀬の右に一人）・流れのコマ2枚・前半38分とタオルは「時間で選ぶ」・一枚絵7枚・声2本
################################################################################
init python:
    ## 清翔の並び（白いマグネット。右が清翔のゴール。4−4−2）
    A5S_SEISHO = [
        ("a", "", (101, 34)),
        ("a", "", (86, 12)), ("a", "", (88, 27)), ("a", "", (88, 41)), ("a", "", (86, 56)),
        ("a", "", (74, 14)), ("a", "", (76, 28)), ("a", "", (76, 40)), ("a", "", (74, 54)),
        ("a", "10", (62, 26)), ("a", "", (62, 42)),
    ]

    def a5s_board(surgery, move=None, mark=False):
        """準決勝の作戦ボード。surgery なら蓮の場所に小早川、小早川の場所に赤坂。move={名前: 行き先} で動かす。
        mark なら、清翔の一人が蓮の右（下）につく"""
        d = []
        for o in a4_board_new():
            k, name, p = o[0], o[1], o[2]
            if surgery and name == "蓮":
                k, name = "h", "小早川"
            elif surgery and name == "小早川":
                name = "赤坂"
            if move and name in move:
                d.append((k, name, p, move[name], 0.1, 0.9))
            else:
                d.append((k, name, p))
        a = list(A5S_SEISHO)
        if mark:
            a[7] = ("a", "", (76, 40), (60, 41), 0.3, 1.0)
        return d + a

image cg ch5s_daimon33 = "images/cg/ch5s_daimon33.jpg"        # 手術した道：前半33分、10番のシュートを指先でポストの外へ
image cg ch5s_koba_quick = "images/cg/ch5s_koba_quick.jpg"    # 手術した道：後半、首を一回だけ振って前へ出す小早川
image cg ch5s_saka_run = "images/cg/ch5s_saka_run.jpg"        # 手術した道：後半、右サイドを駆け上がる坂口
image cg ch5s_takano_bar = "images/cg/ch5s_takano_bar.jpg"    # 手術した道：後半41分、鷹野のシュートがバー
image cg ch5s_cramp = "images/cg/ch5s_cramp.jpg"              # 手術した道：延長前半8分、足がつっても笑う坂口
image cg ch5s_rightpass = "images/cg/ch5s_rightpass.jpg"      # 手術しなかった道：前半38分、痛い右足で鷹野の裏へ
image cg ch5s_takano_hug = "images/cg/ch5s_takano_hug.jpg"    # 手術しなかった道：抱きつく鷹野、笑いながら歯を食いしばる蓮
image cg ch5s_saka_cross = "images/cg/ch5s_saka_cross.jpg"    # 手術しなかった道：坂口のクロス、ニアの鷹野
image cg ch5s_tape = "images/cg/ch5s_tape.jpg"                # 手術しなかった道：ハーフタイム、テーピングを巻き足すひなた
image cg ch5s_towel = "images/cg/ch5s_towel.jpg"              # 手術しなかった道：後半10分、タオルを上げるひなた
image cg ch5s_knee = "images/cg/ch5s_knee.jpg"                # 手術しなかった道：後半13分、ひざが止まる
image cg ch5s_kuroda = "images/cg/ch5s_kuroda.jpg"            # 手術しなかった道：走ってきて、横にしゃがむ黒田

label a5_semi:
    scene black
    with dissolve
    $ set_cal("11月6日（土）", "選手権予選準決勝")
    scene bg stadium_gate_morning
    with dissolve
    $ bgm("静かな緊張感のある曲")
    "準決勝の会場は、去年の冬と同じスタジアムだった。入口の階段の、三段目が欠けているのも、同じだった。"
    if flags.get("千夏_記録"):
        "スタンドに、カメラを構えた千夏先輩がいた。受験まで、あと三か月だった。"
    "スタンドの最前列で、あげはが、スマホを横にして構えていた。"
    if a5_surgery:
        jump a5_semi_surgery
    jump a5_semi_no

## ── 手術した人：ベンチから。0−0、延長、PK ─────────────────────────────
label a5_semi_surgery:
    scene bg stadium_semi_eve
    with dissolve
    $ se("キックオフの笛")
    $ sb_set("前半", 0, 0, 0, 0, "#2a5bd7", "#2b2f36", "港北", "清翔", length=45)
    scene bg stadium_semi_eve at cam_jog
    with dissolve
    show screen letterbox
    show screen scoreboard
    $ bgm("緊迫した試合の曲")
    "清翔は、怒鳴らなかった。ベンチの結城さんも、ピッチの十一人も。ボールを持つたびに、全員が、次の場所へ黙って動いた。"
    $ flow("前半", 10, "清翔、三本目のパスで、必ず来ます！　声も出さずに、三人で", panel="ch5s_p10", of=(1, 1), tag="ピンチ", shots=(0, 2), sfx="芝を蹴る足音")
    "港北のボールは、三本目のパスで、必ず止められた。止める場所が、毎回ちがった。"
    $ sb_set(mm=33)
    "前半33分。清翔の10番のシュート。"
    scene cg ch5s_daimon33
    with vpunch
    $ se("ボールがポストに当たる音")
    $ cg_look()
    "大門が、指先で、ポストの外へはじいた。"
    $ se("前半終了の笛")
    hide screen scoreboard
    scene bg stadium_semi_eve
    with dissolve
    $ bgm("静かな緊張感のある曲")
    "ハーフタイム。0−0。ロッカールームの前の廊下で、黒田が、俺のほうを見ないで言った。"
    show kuroda normal
    with dissolve
    $ tactics(dots=a5s_board(True), caption="ハーフタイム　0−0")
    voice "audio/voice/kuroda_ch5s_hitotsu.mp3"
    kuroda "……見えたものを、一つだけ言え。一つだ"
    "ボードの上で、白いマグネットは、ほとんど動いていなかった。動いていないのに、港北のパスは、三本目で止まった。"
    $ tactics_off()
    menu:
        "「小早川が、首を振ってから蹴るまで、半秒長い。清翔は、そこで寄せてる」":
            $ a5_semi_word = "koba"
            $ lean("求道型")
            $ tactics(dots=a5s_board(True, {"小早川": (62, 34)}), caption="小早川　首は二回。半秒早く、前へ")
            kuroda "……小早川。首は、二回でいい。三回目は、俺が見てる。……そう伝えろ"
            "小早川に伝えると、小早川は、首を一回だけ振って、うなずいた。"
            $ up("戦術眼", 2)
        "「清翔は、鷹野の裏を消すために、右のサイドバックを上げない。坂口が、空いてる」":
            $ a5_semi_word = "takano"
            $ lean("仲間型")
            $ tactics(dots=a5s_board(True, {"坂口": (80, 60)}), caption="坂口　右があいている。駆け上がれ")
            kuroda "……坂口。後半は、お前が主役だ"
            sakaguchi "マジで！？　俺、主役とか、ゲームでしかやったことないんだけど！"
            $ bond_up("坂口", 3)
    $ tactics_off()
    hide kuroda
    with dissolve
    $ sb_set("後半", 45)
    show screen scoreboard
    scene bg stadium_semi_eve at cam_jog
    with dissolve
    $ bgm("試合の曲（終盤）")
    if a5_semi_word == "koba":
        scene cg ch5s_koba_quick
        with dissolve
        $ cg_look()
        "後半、小早川のパスが、半秒早くなった。清翔の寄せが、一歩、遅れはじめた。"
    else:
        scene cg ch5s_saka_run
        with dissolve
        $ cg_look()
        "後半、坂口が、右サイドを何度も駆け上がった。清翔のベンチで、結城さんが、初めてメモを取った。"
    scene bg stadium_semi_eve at cam_jog
    with dissolve
    $ sb_set(mm=86)
    "後半41分。鷹野の左足。"
    scene cg ch5s_takano_bar
    with hpunch
    $ se("ボールがポストに当たる音")
    $ cg_look()
    "シュートが、キーパーの手をはじいて、バーをたたいた。"
    scene bg stadium_semi_eve at cam_jog
    with dissolve
    "スタンドの全員が、頭を抱えた。ベンチで、松葉杖の先が、床を一回たたいた。俺の手が、勝手にやっていた。"
    $ se("笛の音")
    "延長。"
    $ sb_set("延長", 90)
    $ sb_set(mm=98)
    "延長前半8分。坂口が、右のふくらはぎを押さえて、うずくまった。足がつっていた。"
    scene cg ch5s_cramp
    with dissolve
    $ cg_look()
    sakaguchi "……平気、平気！　あと、22分だろ！　ゲームなら、ここからが本番なんだって！"
    scene bg stadium_semi_eve at cam_jog
    with dissolve
    "坂口は、自分で足をのばして、立ち上がった。黒田は、交代の紙を、一度出して、しまった。"
    $ flow("延長", 108, "清翔の10番！　大門の手の先を抜けて――", panel="ch5s_p108", of=(1, 1), tag="ピンチ", shots=(3, 9), sfx="ボールを蹴る音")
    $ se("ボールがポストに当たる音")
    with vpunch
    "ゴールの前を横切って、反対のポストの外へ転がった。スタンドの半分が、悲鳴を上げた。"
    "120分走った十一人を、ベンチから見ていた。誰も、足を止めなかった。俺だけが、止まっていた。"
    $ se("試合終了の笛")
    "延長も、0−0。"
    ## PK
    hide screen scoreboard
    scene bg stadium_semi_eve
    with dissolve
    $ bgm("張りつめた静かな曲")
    "PK戦。"
    "ベンチの前で、黒田が、蹴る順番の紙を、小早川に渡した。五番目に、小早川の名前があった。"
    "小早川は、紙を見て、それから、俺を見た。俺は、うなずいた。……ほかに、できることがなかった。"
    $ pk_reset("港北", "清翔")
    call pk_shot("home", "港北　1人目　鷹野", "tl", "goal")
    call pk_shot("away", "清翔　1人目", "br", "goal")
    call pk_shot("home", "港北　2人目　坂口", "bl", "goal")
    "坂口は、つった足で蹴った。決めたあと、その場に座りこんだ。"
    call pk_shot("away", "清翔　2人目", "tr", "goal")
    call pk_shot("home", "港北　3人目　赤坂", "mid_hi", "goal")
    call pk_shot("away", "清翔　3人目", "bl", "save")
    scene cg a5_daimon_pk
    with Dissolve(0.5)
    "大門が、右へ飛んだ。190センチの体が、全部、のびた。指先が、ボールの横をはじいた。"
    voice "audio/voice/daimon_ch5s_tometa.mp3"
    daimon "……と、止めました……！"
    "スタンドが、割れるような声を出した。ベンチで、黒田が、初めて腕をほどいた。"
    call pk_shot("home", "港北　4人目　江藤", "br", "post")
    "江藤のボールは、右のポストの外へ。……江藤は、頭を抱えて、しゃがみこんだ。"
    call pk_shot("away", "清翔　4人目", "tl", "goal")
    scene bg stadium_semi_eve
    with dissolve
    "3−3。港北の五人目。"
    "小早川が、ボールを置いた。"
    "小早川は、ボールの前で、首を一回振った。ゴールの前に、何もないのに。"
    "それから、ベンチの俺を見た。"
    menu (timed=TIMED_CHOICE, habit=("仲間型", "求道型")):
        "うなずく":
            $ lean("仲間型")
            "うなずいた。小早川は、うなずき返した。"
        "目をそらさない":
            $ lean("求道型")
            "目をそらさなかった。小早川も、そらさなかった。"
    call pk_shot("home", "港北　5人目　小早川", "bar", "post")
    scene cg a5_koba_pk_bar
    with Dissolve(0.4)
    $ se("ボールがポストに当たる音")
    with vpunch
    "ボールは、ゴールの右上へ。キーパーの指をこえて――バーの下をたたいて、外へはね返った。"
    call pk_shot("away", "清翔　5人目", "bl", "goal")
    $ pk_off()
    "清翔の五人目が、決めた。"
    $ se("試合終了の笛")
    $ a5_semi = "0−0（PK 3−4）"
    pause 1.0
    hide screen letterbox
    python:
        _rows = [("スコア", "0−0（延長も0−0、PK 3−4）"),
                 ("ハーフタイム", "小早川のパスを半秒早くした" if a5_semi_word == "koba" else "坂口の右サイドで攻めた"),
                 ("後半41分", "鷹野のシュートが、バー"),
                 ("PK", "大門が清翔の三人目を止めた。五人目の小早川がバー")]
        _memo = "ひなた：120分、誰も、足を止めなかった。……蓮は、ベンチでずっと、立ってた"
    call screen match_report("選手権予選準決勝　港北 対 清翔学園", _rows, _memo)
    $ bgm("（なし）")
    "小早川は、ペナルティスポットに、ひざをついたまま動かなかった。"
    scene cg a5_crutch_koba
    with Dissolve(1.0)
    "松葉杖で、ピッチの中まで歩いた。走れないぶん、時間がかかった。着くまで、誰も、小早川を立たせなかった。待っていてくれた。"
    ren "……小早川。いい場所に蹴った"
    scene bg stadium_semi_eve
    with dissolve
    show kobayakawa jersey
    with dissolve
    kobayakawa "……先輩なら、入ってました"
    ren "入ってない。俺は、あそこには蹴れない。……お前の場所だ"
    "小早川は、やっと泣いた。首を振らずに。"
    hide kobayakawa
    with dissolve
    show takano jersey
    with dissolve
    takano "……来年の夏。お前が戻ってきたら、PKまで行かせねえ"
    hide takano
    with dissolve
    "清翔のベンチの前で、結城さんが、港北の全員に、深く頭を下げていた。"
    $ bond_up("大門", 3)
    $ bond_up("鷹野", 3)
    $ bond_up("坂口", 3)
    $ up("メンタル", 3)
    $ up("戦術眼", 2)
    return

## ── 手術しなかった人：60分。1−2。ひざが止まる ───────────────────────────
label a5_semi_no:
    scene bg stadium_semi_eve
    with dissolve
    show kuroda normal
    with dissolve
    kuroda "早瀬。先発だ。……60分。鳴ったら、どこにいても下がれ"
    kuroda "痛いときは――"
    ren "言います"
    hide kuroda
    with dissolve
    $ tactics(dots=a5s_board(False), caption="清翔　4−4−2")
    "ロッカールームで、黒田は、白いマグネットを一つだけ動かした。"
    $ tactics(dots=a5s_board(False, mark=True), caption="清翔　早瀬の右に、いつも一人")
    kuroda "昨日、言われたとおりだ。お前の右側に、一人つく。右に開けないなら、左で逃げろ。……左にも、もう一人いると思え"
    $ tactics_off()
    if flags.get("ひなた_タオル"):
        "ベンチの端に、白いタオルが一枚、たたんで置いてあった。ひなたは、その上に、手を置いていた。"
    $ se("キックオフの笛")
    $ sb_set("前半", 0, 0, 0, 0, "#2a5bd7", "#2b2f36", "港北", "清翔", length=45)
    scene bg stadium_semi_eve at cam_jog
    with dissolve
    show screen letterbox
    show screen scoreboard
    $ bgm("緊迫した試合の曲")
    "清翔は、昨日、結城さんが言ったとおりにした。ボールを持つと、俺の右側に、必ず一人が立った。"
    "右に体を開けない。左足で逃げると、そこに、もう一人いた。"
    $ sb_set(mm=22)
    $ flow("前半", 22, "早瀬の右側から、清翔が足を入れる！　奪われた――", panel="ch5s_p22", of=(1, 1), tag="ピンチ", shots=(1, 4), sfx="ボールを奪われる音")
    "前半22分。俺の右側で奪われたボールが、三本のパスで、港北のゴールに届いた。"
    $ goal("清翔", home=0, away=1, mm=22)
    with vpunch
    "0−1。清翔の選手たちは、喜ぶより先に、自分の場所へ戻った。"
    $ sb_set(mm=38)
    "前半38分。右側の一人が、半歩、俺から離れた。……わざとだ、と分かった。右足で蹴らせたいんだ。"
    menu (timed=TIMED_CHOICE, habit=("野心型", "求道型")):
        "右足で、鷹野の裏へ蹴る":
            $ lean("野心型")
            $ up("無理ゲージ", 4)
            "右足で踏みこんだ。ひざの奥で、何かが、ぎしっと鳴った。"
            scene cg ch5s_rightpass
            with hpunch
            $ cg_look()
            if check("技術", 66):
                $ se("ボールを蹴る音")
                "ボールは、清翔の最終ラインの頭をこえて、鷹野の前に落ちた。"
                $ goal("港北", home=1, away=1, mm=38, by="鷹野")
                with vpunch
                scene cg ch5s_takano_hug
                with dissolve
                voice "audio/voice/takano_ch5s_ren.mp3"
                takano "……蓮！！"
                "鷹野が、走ってきた。抱きつかれると、右足に体重がかかった。笑いながら、歯を食いしばった。"
                $ _semi_goal = "早瀬が右足で鷹野の裏へ　→　鷹野のゴール"
            else:
                $ se("ボールを蹴る音")
                "ボールは、わずかに長かった。キーパーが飛び出す前に、鷹野が、体ごと押しこんだ。"
                $ goal("港北", home=1, away=1, mm=38, by="鷹野")
                with vpunch
                $ _semi_goal = "早瀬が右足で裏へ（少し長い）　→　鷹野が体で押しこむ"
        "左足で、小早川に戻す":
            $ lean("求道型")
            "右足は、使わなかった。左足で、小早川に戻した。小早川が、首を一回振って、坂口へ。"
            if check("戦術眼", 64):
                scene cg ch5s_saka_cross
                with dissolve
                $ cg_look()
                "坂口のクロスは、こっちを見ないで上がった。ニアに、鷹野が飛びこんだ。"
                $ goal("港北", home=1, away=1, mm=39, by="鷹野")
                with vpunch
                sakaguchi "見なかった！　俺、蓮のこと、一回も見なかった！"
                $ _semi_goal = "早瀬が左足で戻す　→　小早川　→　坂口のクロス　→　鷹野のヘディング"
            else:
                "坂口のクロスは、キーパーにはじかれた。こぼれ球を、赤坂が左足でたたいた。"
                $ goal("港北", home=1, away=1, mm=39, by="赤坂")
                with vpunch
                $ _semi_goal = "坂口のクロスのこぼれ球　→　赤坂のゴール"
    $ se("前半終了の笛")
    hide screen scoreboard
    scene bg stadium_semi_eve
    with dissolve
    $ bgm("静かな緊張感のある曲")
    "ハーフタイム。1−1。"
    scene cg ch5s_tape
    with Dissolve(0.8)
    $ cg_look()
    "ひなたが、テーピングを一周、上から巻き足した。何も言わなかった。言わないのが、いちばんこわかった。"
    $ sb_set("後半", 45)
    show screen scoreboard
    scene bg stadium_semi_eve at cam_jog
    with dissolve
    $ bgm("試合の曲（終盤）")
    $ sb_set(mm=55)
    "後半10分。ストップウォッチは、55分。あと5分。"
    if flags.get("ひなた_タオル"):
        "ベンチで、白いものが上がった。"
        scene cg ch5s_towel
        with Dissolve(0.8)
        $ cg_look()
        "ひなたが、タオルを、両手で、高く上げていた。"
        "――試合中、わたしがベンチでタオルを上げたら、次にボールが外に出たとき、一回だけ、こっちに来て。"
        menu (timed=TIMED_CHOICE, habit=("仲間型", "野心型")):
            "ボールが外に出たとき、ベンチへ行く":
                $ a5_semi_towel = "go"
                $ lean("仲間型")
                "ボールが、タッチラインを割った。ベンチまで、歩いた。"
                scene bg stadium_semi_eve
                with dissolve
                show hinata teary
                with dissolve
                hinata "……今、右足、地面につけるの、遅れた。三回続けて"
                hinata "あと5分。蓮が決めて。……でも、うそはつかないで"
                ren "……痛い"
                "言ってしまうと、急に、ひざが重くなった。黒田が、もう立っていた。"
                hide hinata
                with dissolve
                kuroda "赤坂。入れ"
                "55分で、ピッチを出た。ひざは、最後まで、止まらなかった。"
                $ up("無理ゲージ", -3)
                $ heart_up("ひなた", "信頼", 5)
                jump a5_semi_no_after
            "タオルを見ないふりをして、走り続ける":
                $ a5_semi_towel = "stay"
                $ lean("野心型")
                scene bg stadium_semi_eve at cam_jog
                with dissolve
                "見なかったことにした。あと5分だった。"
                $ heart_up("ひなた", "さみしさ", 5)
    $ sb_set(mm=58)
    "後半13分。清翔の縦パス。追いかけて、右足で踏み切った。"
    $ se("スパイクが芝をえぐる音")
    scene cg ch5s_knee
    with hpunch
    $ cg_look()
    "ひざが、止まった。"
    "痛い、より先に、動かない、が来た。曲げようとしても、ひざの中で、何かが引っかかっていた。"
    "芝に、片手をついた。ボールは、清翔の選手の足もとに転がっていった。"
    $ se("担架を呼ぶ笛")
    "黒田が、ストップウォッチを地面に置いて、走ってきた。走る黒田を見るのは、初めてだった。"
    scene cg ch5s_kuroda
    with dissolve
    kuroda "……動くな。担架だ"
    ren "まだ、2分――"
    voice "audio/voice/kuroda_ch5s_issho.mp3"
    kuroda "2分は、やらん。……一生のほうを、取れ"
    $ up("無理ゲージ", 10)
    $ set_flag("a5_ひざが止まった")
label a5_semi_no_after:
    scene bg stadium_semi_eve
    with dissolve
    $ bgm("試合の曲（劣勢）")
    show screen scoreboard
    $ flow("後半", 81, "清翔の10番！　ゴールの左すみへ――", panel="ch5s_p81", of=(1, 1), tag="ピンチ", shots=(5, 8), sfx="ボールを蹴る音")
    "後半36分。ベンチで、ひざに氷をのせたまま見ていた。清翔の10番が、俺がさっきいた場所から、ゴールの左すみへ。"
    $ goal("清翔", home=1, away=2, mm=81, by="10番")
    with vpunch
    "1−2。"
    "最後の10分、港北は、全員で前に出た。鷹野のシュートは、二本とも、キーパーの正面だった。"
    $ se("試合終了の笛")
    $ a5_semi = "1−2"
    pause 1.0
    hide screen scoreboard
    hide screen letterbox
    scene bg stadium_semi_eve
    with Dissolve(1.0)
    python:
        _rows = [("スコア", "1−2（負け）"), ("前半38分", _semi_goal)]
        if a5_semi_towel == "go":
            _rows.append(("後半10分", "ひなたのタオルで、ベンチへ。55分で交代"))
        else:
            _rows.append(("後半13分", "早瀬のひざが止まった。58分で担架"))
        _rows.append(("後半36分", "清翔の10番のゴール"))
        _memo = ("ひなた：タオル、見てくれた。……それだけで、今日は、いい"
                 if a5_semi_towel == "go" else
                 "ひなた：ノートに「止まった」って書いた。……書きたくなかった")
    call screen match_report("選手権予選準決勝　港北 対 清翔学園", _rows, _memo)
    $ bgm("（なし）")
    mono "1−2。"
    mono "高2の冬は、60分ももたなかった。"
    "清翔のベンチの前で、結城さんが、港北の全員に、深く頭を下げていた。顔を上げたとき、まっすぐ、俺のひざを見た。それから、顔を見た。"
    $ bond_up("鷹野", 2)
    $ bond_up("大門", 2)
    $ up("メンタル", 1)
    return


################################################################################
## 11月14日（日）決勝：清翔 対 桜嶺（スタンドから）
##   桜嶺が勝つ。神城の左足首は、あげはのスローの動画の中だけ。紗希は鬼塚の一歩うしろ（一行だけ）
################################################################################
label a5_final:
    scene black
    with dissolve
    $ set_cal("11月14日（日）", "選手権予選決勝")
    scene bg stadium_stand_day
    with dissolve
    $ bgm("静かな緊張感のある曲")
    if a5_surgery:
        "決勝は、スタンドから見た。松葉杖は、もういらなかった。サポーターをつけて、階段を一段ずつ上った。"
    else:
        if a5_semi_towel == "go":
            "決勝は、スタンドから見た。55分で下がったおかげで、ひざは、まだ持っていた。サポーターをつけて、手すりを持って、階段を上った。"
        else:
            "決勝は、スタンドから見た。ひざは、切れてはいなかった。……今回は、と医者は言った。サポーターと松葉杖で、階段を一段ずつ上った。"
    "清翔 対 桜嶺。"
    "隣に、鷹野が座った。反対側に、あげはが座って、スマホを横にした。"
    "ピッチの上の、白いユニフォーム。いちばん前で、神城が、ゆっくり首を回していた。"
    $ bgm("緊迫した試合の曲")
    "神城は、90分、止まらなかった。清翔の寄せを、毎回、半歩先でかわした。"
    "後半、神城のスルーパスから、桜嶺が2点目を取った。2−1。結城さんは、最後まで、ベンチで立ったまま、腕を組まなかった。"
    $ se("試合終了の笛")
    $ bgm("（なし）")
    "桜嶺が、全国へ行く。"
    "表彰式の前、あげはが、スマホの画面を、俺と鷹野のあいだに差し出した。"
    show ageha serious
    with dissolve
    ageha "……パイセン。これ"
    "スローの動画だった。後半の終わり、神城がパスを出した瞬間。"
    "左足が地面につく、その一瞬だけ、神城の顔がゆがんでいた。普通の速さでは、誰にも見えない一瞬だった。"
    ageha "あたし、パイセンの右足、ずっと撮ってたから、分かる。……これ、同じやつ"
    hide ageha
    with dissolve
    show takano jersey_narrow
    with dissolve
    takano "……左の足首か"
    "中学の決勝でも、神城は、左で踏み切っていた。"
    if flags.get("神城_足首"):
        "高1の冬に見た、何重にも巻かれた左の足首を思い出した。"
    hide takano
    with dissolve
    "スタンドの上のほうに、黒いロングコートの鬼塚が立っていた。表彰式も見ないで、もう出口のほうを向いていた。"
    "その一歩うしろに、色素の薄い短い髪が見えた。[saki_call]は、優勝の場面を見ていなかった。ピッチの神城の、左足だけを見ていた。"
    $ set_flag("a5_神城_左足首")
    if a5_surgery:
        mono "痛みを隠して走る神城を、走るのをやめた俺が、スタンドから見ていた。"
    else:
        mono "俺と同じ足の使い方をする神城を、俺は、スタンドから見ていた。"
    return


################################################################################
## 11月の終わり：リハビリ（手術した人）／隠す痛み（しなかった人。あげはの「推しの秘密」）
################################################################################
label a5_after_semi:
    scene black
    with dissolve
    $ set_cal("11月20日（土）", "午後")
    if a5_surgery:
        scene bg a5_clinic
        with dissolve
        $ bgm("あたたかいアコースティックギター")
        "大学病院のリハビリ室は、思ったより、にぎやかだった。おじいさんも、中学生も、みんな、同じ平行棒につかまっていた。"
        show hinata serious
        with dissolve
        "ひなたは、理学療法士さんの横で、ずっとメモを取っていた。理学療法士さんが、途中で笑った。"
        pt "……君、マネージャーさん？　うちに就職する？"
        show hinata smile
        hinata "何年か後に、お願いします"
        "冗談に聞こえなかった。たぶん、冗談じゃなかった。"
        if flags.get("ひなた_トレーナー"):
            hinata "……蓮。わたしの、最初の患者。ちゃんと戻ってきてね。戻ってこないと、わたし、自信なくすから"
        hide hinata
        with dissolve
        show ageha normal
        with dissolve
        ageha "はーい、こちら、推しのリハビリ記録、1日目でーす。……あ、顔は映さないから。足だけ。ビフォーの足"
        ageha "春に、アフター撮るから。それまで、毎週撮る。……ちゃんと、走れる足になって"
        hide ageha
        with dissolve
        $ heart_up("ひなた", "信頼", 3)
        $ heart_up("あげは", "信頼", 3)
        $ up("メンタル", 2)
    else:
        scene bg locker_room
        with dissolve
        $ bgm("張りつめた静かな曲")
        "準決勝のあと、サポーターが、一枚増えた。"
        "練習のあと、ロッカーの陰で、痛み止めを二錠、口に入れた。医者に言われたのは、一錠だった。"
        "顔を上げると、ロッカーの横に、あげはが立っていた。スマホは、持っていなかった。"
        show ageha serious
        with dissolve
        ageha "……今の、何錠"
        ren "……一錠"
        ageha "うそ。二錠。あたし、パイセンの手、動画で何百回も見てるから。指の開き方で分かる"
        if a5_ageha_saw == "hush":
            if a5_semi_towel == "go":
                ageha "10月、だれにも言うなって言われて、言わなかった。……言わなかったら、パイセン、準決勝で、タオルが上がるまで走ったじゃん"
            else:
                ageha "10月、だれにも言うなって言われて、言わなかった。……言わなかったら、パイセン、止まったじゃん。ピッチで"
            ageha "あたし、推しの秘密、守るの、もう無理"
        else:
            ageha "全部話してくれたのに。……これだけ、隠すの、なんで"
        menu:
            "「……自分で、黒田とひなたに言う」":
                $ a5_secret = "tell"
                $ lean("仲間型")
                ren "……明日、自分で、黒田とひなたに言う。あげはが言う前に"
                show ageha normal
                ageha "……うん。それが、いい"
                ageha "言うとき、あたしも、後ろにいていい？　なんにも言わないから。いるだけ"
                $ up("無理ゲージ", -4)
                $ heart_up("あげは", "信頼", 4)
                $ set_flag("a5_痛み止め_話した")
            "「……黙っていてくれ。冬の間だけ」":
                $ a5_secret = "keep"
                $ lean("野心型")
                ren "……黙っていてくれ。冬の間だけ"
                "あげはは、長いあいだ、黙っていた。"
                ageha "……冬の間だけね。春になったら、あたし、全部、ひなたパイセンに言うから"
                ageha "推しの秘密は守る。でも、推しのひざは、守れないから。あたしじゃ"
                $ up("無理ゲージ", 3)
                $ heart_up("あげは", "さみしさ", 5)
                $ set_flag("a5_痛み止め_秘密")
        hide ageha
        with dissolve
    return
