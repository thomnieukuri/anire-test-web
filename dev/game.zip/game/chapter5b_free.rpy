## chapter5b_free.rpy ―― 第5章（ルートB）の自由行動・リハビリ・練習の出来事・夜のトーク（v0.35.0・Claude の第1稿）
##   仕組みは第4章Bと同じ（b4_spots・b4_night_send をそのまま使う。表に b5sep / b5dec を足す）
##   ① 9月（b5sep）：9/6・9/7・9/9・9/11（土）。返事の日（10/5）の前
##   ② 12月（b5dec）：12/6・12/7・12/9・12/11（土）。県の決勝のあと、全国大会の前。手術をした人は、練習のかわりにリハビリ
##   最後の土曜日は港北に帰れる（はやせ食堂・港の防波堤・港北のグラウンドのフェンスの外）

init 1 python:
    B4_FREE.update({
        "b5sep": (["9月6日（月）", "9月7日（火）", "9月9日（木）", "9月11日（土）"], "放課後", "9月、どこへ行く？"),
        "b5dec": (["12月6日（月）", "12月7日（火）", "12月9日（木）", "12月11日（土）"], "放課後", "12月、どこへ行く？"),
    })
    B4_RECAP.update({
        "b5sep": ("8月30日の検診の結果は、鬼塚監督のところに届いていた。\n\n"
                  "9月3日、大学病院。\n手術するなら、10月8日。選手権予選には出られない。\n返事は、10月5日まで。\n\n"
                  "桜嶺での、初めての公式戦まで、あと少し。"),
        "b5dec": ("選手権予選が終わった。\n県の決勝で、桜嶺が清翔に勝った。港北は、準決勝で清翔に負けた。\n\n"
                  "年末から、全国大会。\nそれが終われば、一ノ瀬先輩たち3年は、引退する。"),
    })
    B4_SPOTS.update({
        "b5sep": [
            ("music", "音楽室", 330, 70, "saki", "紗希", "b5_sep_saki"),
            ("club", "部室", 640, 170, "ageha", "あげは", "b5_sep_ageha"),
            ("wall", "寮の裏の壁", 980, 420, "", "本田", "b5_sep_honda"),
            ("office", "監督室の前", 520, 330, "", "一ノ瀬", "b5_sep_ichinose"),
            ("roof", "寮の屋上", 1020, 110, "kamishiro", "神城", "b5_sep_kamishiro"),
        ],
        "b5dec": [
            ("music", "音楽室", 330, 70, "saki", "紗希", "b5_dec_saki"),
            ("club", "部室", 640, 170, "ageha", "あげは", "b5_dec_ageha"),
            ("wall", "寮の裏の壁", 980, 420, "", "本田", "b5_dec_honda"),
            ("office", "監督室の前", 520, 330, "", "一ノ瀬", "b5_dec_ichinose"),
            ("roof", "寮の屋上", 1020, 110, "kamishiro", "神城", "b5_dec_kamishiro"),
        ],
    })
    B4_HOLIDAY_SPOTS.update({
        "b5sep": [
            ("shokudo", "はやせ食堂", 850, 460, "mother", "母さん", "b5_hol_mother_sep"),
            ("pier", "港の防波堤", 330, 560, "saki", "紗希", "b5_hol_saki_sep"),
            ("fence", "港北のグラウンド", 600, 170, "", "フェンスの外", "b5_hol_fence_sep"),
        ],
        "b5dec": [
            ("shokudo", "はやせ食堂", 850, 460, "mother", "母さん", "b5_hol_mother_dec"),
            ("pier", "港の防波堤", 330, 560, "saki", "紗希", "b5_hol_saki_dec"),
        ],
    })


## 自由行動のくり返し（第4章Bの b4_free_loop と同じ形。12月に手術した人はリハビリ）
label b5_free_loop(month):
    $ b4_dates, b4_time, b4_banner = B4_FREE[month]
    $ recap_text = B4_RECAP[month]
    scene black
    with dissolve
    window auto hide
    if month == "b5sep":
        tuto "自由行動です。9月の放課後は4日。返事の日（10月5日）の前に、いろんな人と話しておけます。最後の土曜日は、港北に帰れます。"
    elif b5_surgery:
        tuto "自由行動です。12月の放課後は4日。手術をしたので、練習のかわりに、毎日リハビリをします。"
    else:
        tuto "自由行動です。12月の放課後は4日。最後の土曜日は、港北に帰れます。"
    $ b4_day = 1
    while b4_day <= len(b4_dates):
        $ amb_stop()
        $ set_cal(b4_dates[b4_day - 1], b4_time)
        $ bgm("作戦会議っぽい軽快な曲")
        window auto hide
        if month == "b5dec" and b5_surgery:
            call b5_rehab_day
        else:
            call practice_day(month)
        if b4_is_holiday(month):
            $ set_cal(b4_dates[b4_day - 1], "午後")
            $ bgm("のんびりした春の曲")
            window auto hide
            if b5_surgery and month == "b5dec":
                "午前のリハビリが終わると、電車で、港北へ帰った。"
            else:
                "午前の練習が終わると、電車で、港北へ帰った。"
            call screen action_map(b4_spots(month), "港北の町、どこへ行く？（休日）")
        else:
            $ set_cal(b4_dates[b4_day - 1], b4_time)
            $ bgm("作戦会議っぽい軽快な曲")
            window auto hide
            call screen action_map(b4_spots(month), b4_banner + "（残り" + str(len(b4_dates) + 1 - b4_day) + "日）", area="ouryo")
        $ _lab = b4_spot_label(month, _return)
        $ set_flag(_lab)
        call expression _lab
        $ amb_stop()
        call b4_night_send(b4_dates[b4_day - 1], month)
        $ b4_day += 1
    $ amb_stop()
    return


################################################################################
## 9月の行き先（返事の日の前）
################################################################################

## 音楽室：紗希。コンクールの前
label b5_sep_saki:
    scene bg ouryo_music
    with dissolve
    $ bgm("静かなピアノの旋律")
    "音楽室の戸は、半分だけ開いていた。中から、同じ八小節が、何度も聞こえた。"
    show saki normal
    with dissolve
    saki_v "……また来た"
    "[saki_call]は、弾くのをやめなかった。俺は、いつもの、窓ぎわの椅子に座った。"
    saki_v "10月の終わりに、コンクールの本選があるの。……桜嶺祭でも、一曲だけ弾く"
    saki_v "あの人は、来ない。どっちも"
    ren "……選手権の、日程とかぶるのか"
    saki_v "かぶらなくても、来ない。……去年も、その前も"
    "八小節目で、[saki_call]の指が、一回だけ止まった。"
    saki_v "あんた、右足、引きずる回数、増えてる。……ピアノの音、止めるくらいには"
    $ heart_up("紗希", "ときめき", 3)
    $ heart_up("紗希", "信頼", 2)
    $ up("メンタル", 2)
    hide saki
    with dissolve
    return

## 部室：あげは。全国大会の「上げない動画」
label b5_sep_ageha:
    scene bg ouryo_clubroom
    with dissolve
    $ bgm("明るい部活の曲")
    "部室で、あげはが、段ボール箱いっぱいのビブスを、色ごとに分けていた。"
    show ageha ouryo
    with dissolve
    ageha "パイセン！　ちょうどいい。白、何枚あるか数えて。あたし、灰色で手いっぱい"
    "白いビブスは、三十枚あった。灰色は、その倍以上あった。"
    ageha "……選手権の登録、三十人なんだって。白いのと、同じ数"
    ageha "あたし、4月に、灰色のビブス、いちばんたくさん洗ったんだよ。百枚。……その中に、パイセンのもあった"
    ageha "白いの洗う日が来たら、言ってね。いちばんきれいに洗うから"
    $ heart_up("あげは", "ときめき", 3)
    $ heart_up("あげは", "信頼", 2)
    $ up("技術", 1)
    hide ageha
    with dissolve
    return

## 寮の裏の壁：本田
label b5_sep_honda:
    scene bg ouryo_ground_eve
    with dissolve
    $ bgm("あたたかいアコースティックギター")
    "寮の裏の壁の前で、本田が、一人でボールを当てていた。左足だけで。"
    honda "早瀬。……今日は、蹴らなくていいぞ。見てるだけで"
    ren "なんで"
    honda "ひざ。引きずってるの、俺でも分かるから"
    "本田は、ボールを足の裏で止めて、壁のほうを向いたまま言った。"
    honda "俺さ、早瀬が5軍に来たとき、正直、むかついた。特待生が、なんで俺の横にいるんだって"
    honda "でも、毎日ここで、俺と同じ壁、蹴ってた。……だから、今は、むかつかない"
    honda "壊れんなよ。……壁の相手、いなくなるから"
    $ bond_up("本田", 4)
    $ up("フィジカル", 1)
    return

## 監督室の前：一ノ瀬
label b5_sep_ichinose:
    scene bg ouryo_office
    with dissolve
    $ bgm("静かな緊張感のある曲")
    "監督室の前の廊下で、一ノ瀬先輩が、窓からグラウンドを見ていた。"
    ichinose "やあ。……今日は、名簿は貼ってないよ"
    ichinose "選手権が、3年の最後の大会になる。僕は、三回目で、これが最後だ"
    ichinose "一回目は、1年の冬。痛み止めを飲んで出て、全国の二回戦で負けた。二回目は、去年。神城くんの横で、全国のベスト8"
    ichinose "君は、どっちを選んでも、来年、もう一回ある。……それだけは、うらやましいな"
    $ bond_up("一ノ瀬", 3)
    $ up("戦術眼", 2)
    return

## 寮の屋上：神城
label b5_sep_kamishiro:
    scene bg ouryo_rooftop
    with dissolve
    $ bgm("静かな夜の曲")
    "寮の屋上で、神城が、左足首を手すりにのせて、のばしていた。"
    show kamishiro normal
    with dissolve
    kamishiro "……来たのか"
    "隣に立った。神城は、足首をのばしたまま、何も言わなかった。俺も、何も言わなかった。"
    "夕方の風が、二人のあいだを、何回か通りすぎた。"
    kamishiro "……お前と、こういうふうに、黙ってられるようになるとは、思わなかった"
    kamishiro "去年の今ごろは、お前の名前を聞くだけで、胃が痛かった"
    $ bond_up("神城", 4)
    $ up("メンタル", 1)
    hide kamishiro
    with dissolve
    return

## 休日：はやせ食堂（母さん・ゆず）
label b5_hol_mother_sep:
    scene bg shokudo_day
    with dissolve
    $ bgm("あたたかいアコースティックギター")
    "土曜の午後の店は、すいていた。カウンターの端で、ゆずが、宿題を広げていた。"
    show yuzu normal
    with dissolve
    yuzu "あ、お兄ちゃん。白いジャージ、また洗ってないでしょ。くさい"
    hide yuzu
    show mother normal
    with dissolve
    haha "おかえり。……座りな。なんか食べる？"
    "母さんは、何も聞かなかった。病院のことも、手術のことも。"
    "鯖の味噌煮の定食が出てきた。去年まで、毎日食べていたやつだった。"
    haha "寮のごはん、量は多いって言ってたでしょ。……これは、量はふつうだけど、うちの味だから"
    $ up("メンタル", 2)
    $ up("無理ゲージ", -2)
    hide mother
    with dissolve
    return

## 休日：港の防波堤（紗希）
label b5_hol_saki_sep:
    scene bg harbor_sunset
    with dissolve
    $ se("波の音、カモメ")
    $ bgm("静かなピアノの旋律")
    "防波堤の先で、[saki_call]が、ひざの上に楽譜を広げていた。風で飛ばないように、缶のジュースを重しにして。"
    show saki casual
    with dissolve
    saki_v "……土曜は、ここにいるって、言ってないけど"
    ren "いつもいるだろ"
    saki_v "……いつもは、いない。いるときだけ、いる"
    "[saki_call]は、楽譜の上の缶を、少しずらした。座れ、という意味だった。"
    saki_v "楽譜、読める？"
    ren "読めない"
    saki_v "そう。……じゃあ、見てていいよ。何が書いてあるか、分からないなら"
    "知らない記号が、びっしり並んでいた。ところどころに、鉛筆で、小さく何か書いてあった。"
    "いちばん最後のページの、いちばん下に、一つだけ、知っている字があった。――湊。"
    saki_v "……そこは、見ないで"
    "[saki_call]が、最後のページを、手のひらでかくした。かくした手の指先が、楽譜の上の俺の指に、少しだけ当たった。"
    "[saki_call]は、手を引かなかった。俺も、引かなかった。重しの缶が、風で、からんと鳴った。"
    saki_v "……楽譜は読めないくせに。字だけ読むの、ずるい"
    "そう言ったきり、[saki_call]は、しばらく、手をどけなかった。"
    $ heart_up("紗希", "ときめき", 3)
    $ heart_up("紗希", "信頼", 3)
    hide saki
    with dissolve
    $ amb_stop()
    return

## 休日：港北のグラウンドのフェンスの外（小早川と、遠くの鷹野）
label b5_hol_fence_sep:
    scene bg kohoku_fence_night
    with dissolve
    $ bgm("静かな夜の曲")
    "夕方まで待って、港北のグラウンドのフェンスの外に立った。照明の下で、青いジャージが、十八人走っていた。"
    "真ん中で声を出しているのは、鷹野だった。"
    "フェンスの向こうから、ボールが一つ、転がってきた。拾いに来たのは、小早川だった。"
    show kobayakawa jersey
    with dissolve
    kobayakawa "……早瀬先輩"
    "小早川は、ボールを拾って、フェンスごしに、少しだけ、俺を見た。"
    kobayakawa "選手権、桜嶺と当たるとしたら、決勝です。……僕、それまでに、レギュラーになってます"
    kobayakawa "先輩の場所、今は、僕が走ってます。……鷹野先輩に、毎日、怒られながら"
    "グラウンドの真ん中から、鷹野の声がした。「小早川！　何やってる！」"
    "小早川は、頭を下げて、走って戻っていった。鷹野は、一度も、フェンスのほうを見なかった。"
    hide kobayakawa
    with dissolve
    $ up("メンタル", 1)
    $ bond_up("鷹野", 1)
    return


################################################################################
## 12月の行き先（県の決勝のあと、全国大会の前）
################################################################################

## 音楽室：紗希
label b5_dec_saki:
    scene bg ouryo_music
    with dissolve
    $ bgm("静かなピアノの旋律")
    "音楽室のストーブが、かちかち鳴っていた。[saki_call]は、ピアノを弾かずに、窓の外を見ていた。"
    show saki normal
    with dissolve
    if b5_surgery:
        saki_v "……今日、壁のとこで、ひざ、曲げ伸ばししてた。百回"
        saki_v "数えてた。……数えるの、得意だから"
        saki_v "あんた、練習に出てたころより、今のほうが、ちゃんと顔、上げてる"
    else:
        saki_v "県の決勝、ラジオで聞いた。……あの人のチームの試合、聞いたの、初めて"
        saki_v "アナウンサーが、あんたの名前、四回言った。……数えてた。数えるの、得意だから"
        saki_v "最後に言ったとき、『右足を気にしています』って言ってた"
    saki_v "コンクール、二位だった。……一位じゃないのに、なんか、すっきりしてる"
    saki_v "最後の八小節。止まらなかったから"
    $ heart_up("紗希", "ときめき", 4)
    $ heart_up("紗希", "信頼", 2)
    $ up("メンタル", 2)
    hide saki
    with dissolve
    return

## 部室：あげは
label b5_dec_ageha:
    scene bg ouryo_clubroom
    with dissolve
    $ bgm("明るい部活の曲")
    show ageha ouryo
    with dissolve
    if b5_surgery:
        ageha "パイセン！　リハビリの動画、今日で三十本目！"
        ageha "ひざ曲げるだけの動画、三十本。……再生したら、絶対、だれも見ない。ウケる"
        show ageha serious
        ageha "でもさ。三十本並べると、ちょっとずつ、曲がる角度、変わってるの。……あたしにしか、分かんないやつ"
        ageha "推しが本物になるところって、もっと派手だと思ってた。……地味なとこも、全部、本物なんだね"
    else:
        ageha "パイセン！　県の決勝の動画、自分のスマホの中だけで、もう五十回見た"
        ageha "あのゴール、ガチで、えぐかった。……SNSに上げられないの、人生でいちばん悔しい"
        show ageha serious
        ageha "でもさ、決勝の後半、右足、着くたびに、ちょっとだけ顔、ゆがんでた。……テレビには、映ってないやつ"
        ageha "全国、行くの、止めないよ。……止めないけど、テーピング、あたしにも巻かせて。上手くなったから"
    $ heart_up("あげは", "ときめき", 4)
    $ heart_up("あげは", "信頼", 3)
    $ up("技術", 1)
    hide ageha
    with dissolve
    return

## 寮の裏の壁：本田
label b5_dec_honda:
    scene bg ouryo_ground_eve
    with dissolve
    $ bgm("あたたかいアコースティックギター")
    "寮の裏の壁の前で、本田が、両足で、交互にボールを当てていた。"
    honda "早瀬、見てろ。……右足、だいぶ、ましになっただろ"
    "本田の右足のボールは、夏より、ずっと同じところに当たるようになっていた。"
    if flags.get("b4_本田_二人で上がった"):
        honda "白いビブス、まだ慣れねえ。……全国のメンバーには、入れなかったけど"
        honda "でも、二人で上がった。……それだけは、一生、自慢する"
        $ bond_up("本田", 5)
    elif b4_honda == "stay":
        honda "4軍に上がった。……二人で、って言ってたのに、俺だけ、遅い"
        honda "でも、遅くても、上がった。……壁のおかげだ。半分は、お前のおかげだ"
        $ bond_up("本田", 5)
    else:
        honda "……7月のことは、もう、いいんだ。監督に何か言わされたって、分かってるから"
        honda "でも、壁のとこには、来てくれよな。……それで、ちゃらにする"
        $ bond_up("本田", 3)
    $ up("フィジカル", 1)
    return

## 監督室の前：一ノ瀬（全国の前）
label b5_dec_ichinose:
    scene bg ouryo_office
    with dissolve
    $ bgm("静かな緊張感のある曲")
    "監督室の前で、一ノ瀬先輩が、全国大会の組み合わせ表を見ていた。"
    ichinose "初戦は、12月31日。……大みそかに試合をするのは、三回目だよ"
    if b5_surgery:
        ichinose "君がいたら、と思う試合が、県で二つあった。……いなかったから、僕が走った。三年で、いちばん走った"
        ichinose "来年、君が戻ってきたとき、ここに、僕はいない。……でも、僕が走った分は、残しておくよ。メモで"
    else:
        if b5_final == "silent":
            ichinose "県の決勝、君のゴールの前のパス。……あれは、僕の三年で、いちばんいいパスだった"
            ichinose "君が、走りこんでくれたからだよ。……ありがとう。たぶん、これが、最後の大会だ"
        else:
            ichinose "県の決勝、君がおとりになったとき。……あれで、真ん中が、全部空いた"
            ichinose "走れないって言えるのは、強いことだよ。僕は、三年、言えなかった。……たぶん、これが、最後の大会だ"
    $ bond_up("一ノ瀬", 4)
    $ up("戦術眼", 2)
    return

## 寮の屋上：神城（冬）
label b5_dec_kamishiro:
    scene bg rooftop_winter
    with dissolve
    $ bgm("静かな夜の曲")
    show kamishiro normal
    with dissolve
    "冬の屋上は、風が強かった。神城は、ダウンのポケットに手を入れたまま、港のほうの明かりを見ていた。"
    kamishiro "……全国、勝てると思うか"
    "神城が、自分から、勝ち負けのことを聞いてきたのは、初めてだった。"
    if b5_surgery:
        kamishiro "お前がいないのに、勝てるのかって、毎晩、考える。……考えるようになったのが、変だ"
        kamishiro "前は、誰がいなくても、勝てると思ってた。……あの人のチームは、そういうチームだから"
    else:
        kamishiro "県の決勝で、お前が倒れかけたとき、俺、ベンチを見た。……監督を、じゃなくて、トレーナーを"
        kamishiro "中1のときの俺なら、ボールを見てた。……少しは、変わったのかもな"
    $ bond_up("神城", 5)
    hide kamishiro
    with dissolve
    return

## 休日：はやせ食堂（12月）
label b5_hol_mother_dec:
    scene bg shokudo_day
    with dissolve
    $ bgm("あたたかいアコースティックギター")
    show mother normal
    with dissolve
    if b5_surgery:
        haha "階段、手すりなしで上がれるようになったね。……見てたよ、店の窓から"
        haha "ひなたちゃんがね、毎週、何か置いていくの。テーピングじゃなくて、湿布とか、ストレッチの紙とか。……名前は書かないで"
    else:
        haha "全国、テレビでやるんでしょ。常連さんが、店のテレビ、つけっぱなしにしろって"
        haha "ひなたちゃんがね、毎週、テーピングを置いていくの。……名前は書かないで。あんた宛てだって、言わないで"
    "カウンターの端に、白いテーピングの箱が、三つ、積んであった。"
    haha "……あの子、まだ怒ってるって言ってたよ。怒ってるのと、心配なのは、べつなんだってさ"
    $ up("メンタル", 2)
    $ up("無理ゲージ", -2)
    $ heart_up("ひなた", "信頼", 2)
    hide mother
    with dissolve
    return

## 休日：港の防波堤（紗希・12月）
label b5_hol_saki_dec:
    scene bg harbor_winter_eve
    with dissolve
    $ se("波の音、カモメ")
    $ bgm("静かなピアノの旋律")
    "冬の防波堤は、海の色が、夏より暗かった。[saki_call]は、マフラーを鼻の上まで上げて、座っていた。"
    show saki casual
    with dissolve
    saki_v "……寒いのに、来たんだ"
    ren "そっちこそ"
    saki_v "私は、毎年、来る。……12月11日は、兄が、家を出た日"
    "[saki_call]は、ポケットから、古いキーホルダーを出した。白いユニフォームの形の、小さなゴム。背番号は、10。"
    saki_v "出ていくとき、玄関に落としてったの。……わざとかどうかは、知らない"
    saki_v "毎年、ここで、返そうかと思う。海に。……でも、毎年、やめる"
    saki_v "今年は、あんたがいるから。……やめる理由が、一個、増えた"
    $ heart_up("紗希", "ときめき", 4)
    $ heart_up("紗希", "信頼", 3)
    $ set_flag("b5_湊のキーホルダー")
    hide saki
    with dissolve
    $ amb_stop()
    return


################################################################################
## リハビリ（12月・手術した人。練習のかわり）
################################################################################
default b5_rehab_step = 0

label b5_rehab_day:
    scene bg ouryo_ground_eve
    with dissolve
    $ bgm("静かな春の曲")
    $ b5_rehab_step += 1
    if b5_rehab_step == 1:
        "5軍のグラウンドの隅で、リハビリ。灰色のビブスの列の向こうで、ひざを伸ばして、曲げて、また伸ばす。"
        "春に、一度出ていった場所に、また戻ってきた。違うのは、ボールを蹴っていないことだけだった。"
        coach_b "……早瀬。角度、昨日より三度、出てる。記録しとくぞ"
    elif b5_rehab_step == 2:
        "ゴムチューブを、右足首にかけて、ひっぱる。三十回、三セット。"
        "灰色のビブスの1年が、横を通るたびに、ちらっと見ていった。特待生が、ボールも蹴らずに、何をしているのかと。"
        $ heart_up("あげは", "信頼", 1)
        "部室の窓から、あげはが、スマホを構えていた。今度は、下ろさなかった。"
    elif b5_rehab_step == 3:
        "初めて、ジョギングの許可が出た。グラウンドを、ゆっくり、一周だけ。"
        "一周走るのに、二分かかった。夏は、四十秒だった。"
        "ゴールの前を通るとき、白いビブスの練習の中から、神城が、こっちを一回だけ見た。"
        $ bond_up("神城", 2)
    else:
        "寮の裏の壁に、ボールを、そっと当てた。手術のあと、初めて、ボールにさわった。"
        "跳ね返ってきたボールは、思っていたより、ずっと速かった。"
        "壁の向こう側で、本田が、何も言わずに、ボールを止めて、返してくれた。"
        $ bond_up("本田", 2)
    $ up("無理ゲージ", -3)
    $ up("戦術眼", 1)
    $ up("メンタル", 1)
    call tuto_stats
    return


################################################################################
## 練習の出来事（第5章B。b5sep / b5dec）
################################################################################
define B5_MONTHS = ("b5sep", "b5dec")
init 1 python:
    PRACTICE_EVENTS_A4.extend([
        ("b5p_painkiller", "技術", B5_MONTHS),
        ("b5p_white_pass", "技術", B5_MONTHS),
        ("b5p_makabe_check", "フィジカル", B5_MONTHS),
        ("b5p_hill", "フィジカル", B5_MONTHS),
        ("b5p_board", "戦術眼", B5_MONTHS),
        ("b5p_ichinose_eyes", "戦術眼", B5_MONTHS),
        ("b5p_list", "メンタル", B5_MONTHS),
        ("b5p_ageha_tape", "メンタル", B5_MONTHS),
    ])
    PRACTICE_ADVICE.update({
        "b5sep": ("技術", "選手権は、ボールを持った瞬間に決めろ。……考えるのは、持つ前だ"),
        "b5dec": ("戦術眼", "全国の相手は、県の相手より、半歩早い。……先に見ろ"),
    })

label b5p_painkiller:
    "練習の前に、トレーナー室で、ひざにテーピングを巻いてもらった。トレーナーは、何も聞かずに、いつもより一周多く巻いた。"
    "ボールを止めるたびに、右ひざの奥で、何かがきしんだ。止め方を、変えた。右ではなく、左の足の裏で。"
    return

label b5p_white_pass:
    "白いビブスと、灰色のビブスの合同練習。ワンタッチのパス回しで、ボールは、一度も止まらなかった。"
    kamishiro "……早瀬。今の、半歩前に出せ。俺が、そこに行く"
    "言われたとおりに出した。神城は、もう、そこにいた。"
    return

label b5p_makabe_check:
    "当たりの練習で、真壁と組まされた。真壁は、最初の一回で、わざと右ひざのほうから入ってきた。"
    makabe "……へえ。倒れねえんだ。港北のやつは"
    "倒れなかった。倒れないように、体の向きを、半分だけずらした。"
    return

label b5p_hill:
    "寮の裏の坂道を、ダッシュで十本。鬼塚監督のメニューは、季節が変わっても、夏と同じ量だった。"
    "八本目で、本田が、坂の途中で座りこんだ。俺は、九本目の途中で、右ひざに手をついた。"
    "十本目は、二人で、並んで歩いて上った。コーチは、何も言わなかった。"
    return

label b5p_board:
    "監督室の前の、作戦ボード。鬼塚監督が書いたマグネットの並びを、一ノ瀬先輩が、黙ってスマホで撮っていた。"
    "11の、二つの赤いマグネット。一つは神城。もう一つの横に、小さく、「早瀬」と書いてあった。"
    return

label b5p_ichinose_eyes:
    "紅白戦。一ノ瀬先輩のパスは、俺が走り出す前に、もう、走りこむ場所に出ていた。"
    ichinose "……君が見てるところ、だいたい分かるようになってきた。三年もいると、人の目の動きばかり見るようになるんだ"
    return

label b5p_list:
    "練習のあと、ロッカーの名札を、一枚ずつ見た。春に来たときの名前のうち、三つが、もうなかった。"
    "一人は、ひざだった。一人は、足首だった。一人は、理由を、誰も知らなかった。"
    return

label b5p_ageha_tape:
    "部室で、あげはが、テーピングの練習をしていた。自分の足首で。"
    ageha "パイセン、見てて。……ほら、しわ、ゼロ"
    ageha "トレーナーさんに、教えてもらってんの。……推しのひざは、推しのマネが巻くべきっしょ"
    return


################################################################################
## 夜のトーク（第5章B。b4_night_send の仕組みで、ラベルは b4nc_<id>_b5sep / b5dec）
################################################################################

## 紗希
label b4nc_saki_b5sep:
    $ talk_start("紗希", "22:18")
    $ talk_me("今日の八小節、つながってた")
    $ talk_wait(7)
    $ talk("紗希", "廊下で聞くの、やめてって言った")
    $ talk("紗希", "でも、ありがと")
    $ talk_wait(3)
    $ talk("紗希", "あんたは？　ひざ")
    $ talk_me("まだ決めてない")
    $ talk("紗希", "そう。決めたら、教えて。あの人の口からじゃなくて")
    $ heart_up("紗希", "信頼", 2)
    return

label b4nc_saki_b5dec:
    $ talk_start("紗希", "23:02")
    if b5_surgery:
        $ talk("紗希", "防波堤、来週も行く")
        $ talk("紗希", "歩けるなら、来て。走らなくていいから")
        $ talk_me("行く。歩いて")
        $ talk_wait(4)
        $ talk("紗希", "……ゆっくりでいい")
    else:
        $ talk("紗希", "全国、テレビに出るんでしょ")
        $ talk("紗希", "見ないから")
        $ talk_wait(9)
        $ talk("紗希", "……録画は、するかも")
        $ talk_me("見ないのに？")
        $ talk("紗希", "おやすみ")
    $ heart_up("紗希", "ときめき", 2)
    return

## あげは
label b4nc_ageha_b5sep:
    $ talk_start("あげは", "21:40")
    $ talk("あげは", "パイセン、起きてる？")
    $ talk("あげは", "今日の練習の動画、自分用に編集した")
    $ talk("あげは", "BGMつけたら、エモすぎて泣いた")
    $ talk_me("何の曲")
    $ talk("あげは", "ないしょ。推しに知られたら死ぬやつ")
    $ heart_up("あげは", "ときめき", 2)
    return

label b4nc_ageha_b5dec:
    $ talk_start("あげは", "22:05")
    if b5_surgery:
        $ talk("あげは", "リハビリ動画、編集して、タイトルつけた")
        $ talk("あげは", "『推し、ひざを曲げる』")
        $ talk_me("そのまんまだな")
        $ talk("あげは", "そのまんまが、いちばんエモいの")
    else:
        $ talk("あげは", "全国のメンバー表に、パイセンの名前、あった")
        $ talk("あげは", "スクショした。待ち受けにした")
        $ talk_me("消せ")
        $ talk("あげは", "やだ")
    $ heart_up("あげは", "ときめき", 2)
    $ heart_up("あげは", "信頼", 1)
    return

## ひなた
label b4nc_hinata_b5sep:
    $ talk_start("ひなた", "22:30")
    $ talk_me("ひなた。起きてるか")
    $ talk_wait(20)
    $ talk("ひなた", "起きてる")
    $ talk("ひなた", "千鶴さんから、聞いた。病院のこと")
    $ talk("ひなた", "まだ怒ってるから、えらそうなことは言わない")
    $ talk_wait(6)
    $ talk("ひなた", "でも、眉毛、上がってないか、写真で送って")
    $ talk_me("送らない")
    $ talk("ひなた", "……ばか")
    $ heart_up("ひなた", "信頼", 2)
    return

label b4nc_hinata_b5dec:
    $ talk_start("ひなた", "23:15")
    $ talk("ひなた", "県の決勝、見てたよ")
    $ talk("ひなた", "港北が負けた相手に、桜嶺が勝った")
    $ talk_wait(8)
    $ talk("ひなた", "おめでとうは、言わない")
    if b5_surgery:
        $ talk("ひなた", "でも、ひざ、ちゃんと治して。来年の決勝で、わたしたちが勝つから")
    else:
        $ talk("ひなた", "でも、全国でひざ壊したら、許さないから")
    $ talk_me("わかった")
    $ heart_up("ひなた", "信頼", 2)
    return

## 本田
label b4nc_honda_b5sep:
    $ talk_start("本田", "22:50")
    $ talk("本田", "早瀬、起きてる？")
    $ talk("本田", "明日の壁、俺、5時半から行く")
    $ talk_me("早いな")
    $ talk("本田", "選手権の三十人、まだ諦めてないから")
    $ bond_up("本田", 2)
    return

label b4nc_honda_b5dec:
    $ talk_start("本田", "22:31")
    $ talk("本田", "全国の宿、テレビで見たら、めっちゃいいホテルだった")
    $ talk("本田", "来年は、俺も行く")
    $ talk_me("行こう")
    $ talk("本田", "早瀬が言うと、ほんとっぽいからやめろ")
    $ bond_up("本田", 2)
    return

## 母さん
label b4nc_mother_b5sep:
    $ talk_start("母", "21:12")
    $ talk("母", "寮のごはん、食べてる？")
    $ talk_me("食べてる")
    $ talk("母", "ゆずが、また障子やぶった")
    $ talk("母", "あと、手術のこと、決めたら教えなさいよ")
    $ up("メンタル", 1)
    return

label b4nc_mother_b5dec:
    $ talk_start("母", "21:30")
    $ talk("母", "お正月、帰ってこられるの？")
    if b5_surgery:
        $ talk_me("帰る。寮、年末は閉まるから")
        $ talk("母", "じゃあ、お雑煮のおもち、何個？")
        $ talk_me("三個")
    else:
        $ talk_me("全国だから、帰れない")
        $ talk("母", "そう。じゃあ、テレビの前で、お雑煮食べる")
        $ talk("母", "ひなたちゃんも、呼んどく")
    $ up("メンタル", 1)
    return

## 大門（12月だけ。港北が負けたあと）
label b4nc_daimon_b5dec:
    $ talk_start("大門", "22:44")
    $ talk_me("準決勝、見てた")
    $ talk_wait(30)
    $ talk("大門", "見てたなら、分かると思いますけど")
    $ talk("大門", "2点とも、僕の手の、少し先でした")
    $ talk_wait(5)
    $ talk("大門", "早瀬くんがいたら、とは、言いません。言ったら、僕が負けを認めることになるので")
    $ bond_up("大門", 2)
    return
