## final_b_free.rpy ―― 終章ルートBの自由行動（2月。v0.36.0・Claude の第1稿）
##   11/7 の作者の決定：終章は長め。2月に自由行動1回（4日）
##   2/5（月）・2/6（火）・2/8（木）・2/10（土）。3年は大会が終わって引退しているので、練習の日はない
##   行き先で、進路を選ぶ前に、いろんな人の「これから」を聞ける（運命の選択④のヒント）
##   寮の裏の壁（本田）は、本田をかばった人だけ（何も言わなかった人は、本田がもう寮にいない）
##   麗華は、行動マップには入れない（第4章Bからの決まり）

init 1 python:
    B4_FREE.update({
        "b7feb": (["2月5日（月）", "2月6日（火）", "2月8日（木）", "2月10日（土）"], "放課後", "返事の前に、どこへ行く？"),
    })
    B4_RECAP.update({
        "b7feb": ("全国大会が終わった。3年は、もう練習に出なくていい。\n\n"
                  "机の上に、封筒が並んでいる。\n返事の期限は、2月16日。"),
    })
    B4_SPOTS.update({
        "b7feb": [
            ("music", "音楽室", 330, 70, "saki", "紗希", "fin_b_feb_saki"),
            ("club", "部室", 640, 170, "ageha", "あげは", "fin_b_feb_ageha"),
            ("wall", "寮の裏の壁", 980, 420, "", "本田", "fin_b_feb_honda"),
            ("office", "監督室の前", 520, 330, "", "真壁", "fin_b_feb_makabe"),
            ("roof", "寮の屋上", 1020, 110, "kamishiro", "神城", "fin_b_feb_kamishiro"),
        ],
    })
    B4_HOLIDAY_SPOTS.update({
        "b7feb": [
            ("shokudo", "はやせ食堂", 850, 460, "mother", "母さん・ゆず", "fin_b_feb_mother"),
            ("pier", "港の防波堤", 330, 560, "saki", "紗希", "fin_b_feb_pier"),
            ("fence", "港北のグラウンド", 600, 170, "", "黒田", "fin_b_feb_kuroda"),
        ],
    })

init python:
    def fin_b_spots(month):
        """b4_spots と同じ。本田は、かばった人だけ"""
        return [d for d in b4_spots(month)
                if not (d["id"] == "wall" and store.b6_honda != "cover")]


label fin_b_free_loop:
    $ _month = "b7feb"
    $ b4_dates, b4_time, b4_banner = B4_FREE[_month]
    $ recap_text = B4_RECAP[_month]
    scene black
    with dissolve
    window auto hide
    tuto "自由行動です。2月の放課後は4日。進路の返事の前に、いろんな人と話しておけます。最後の土曜日は、港北に帰れます。"
    $ b4_day = 1
    while b4_day <= len(b4_dates):
        $ amb_stop()
        if b4_is_holiday(_month):
            $ set_cal(b4_dates[b4_day - 1], "午後")
            $ bgm("のんびりした春の曲")
            window auto hide
            "昼前の電車で、港北へ帰った。"
            call screen action_map(fin_b_spots(_month), "港北の町、どこへ行く？（休日）")
        else:
            $ set_cal(b4_dates[b4_day - 1], b4_time)
            $ bgm("作戦会議っぽい軽快な曲")
            window auto hide
            call screen action_map(fin_b_spots(_month), b4_banner + "（残り" + str(len(b4_dates) + 1 - b4_day) + "日）", area="ouryo")
        $ _lab = b4_spot_label(_month, _return)
        $ set_flag(_lab)
        call expression _lab
        $ amb_stop()
        $ b4_day += 1
    $ amb_stop()
    return


################################################################################
## 学校の行き先
################################################################################

## 音楽室：紗希
label fin_b_feb_saki:
    scene bg ouryo_music
    with dissolve
    $ bgm("静かなピアノの旋律")
    "音楽室では、[saki_call]が、ピアノではなく、楽譜の山を、段ボールにつめていた。"
    show saki normal
    with dissolve
    saki_v "……三年分。捨てるか、持っていくか、決めてる"
    saki_v "一冊ずつ開いて、弾けるか、弾けないか、で分けてる。……弾けないのを、持っていく"
    "[saki_call]は、一冊を、段ボールのいちばん上に置いた。表紙が、すり切れていた。"
    saki_v "これ、兄さんが、いちばん最初に買ってくれたやつ。……今も、最後のページだけ、弾けない"
    saki_v "あんたの封筒も、そうやって分けたら。……できるやつと、まだできないやつ"
    saki_v "あたしは、まだできないほうを、持っていく。……できるほうは、もう、あたしのだから"
    $ heart_up("紗希", "ときめき", 3)
    $ heart_up("紗希", "信頼", 3)
    $ up("メンタル", 1)
    hide saki
    with dissolve
    call b4_saki_late_contact
    return

## 部室：あげは
label fin_b_feb_ageha:
    scene bg ouryo_clubroom
    with dissolve
    $ bgm("明るい部活の曲")
    show ageha ouryo
    with dissolve
    if b6_ageha_oshi:
        ageha "あ、パイセン。……今、神城パイセンの、卒業記念の動画、編集してて"
        ageha "パイセンのも、作るよ。ちゃんと。……部のマネージャーだから"
        "あげはは、画面から目を離さなかった。マウスを動かす指だけが、少し速かった。"
        $ heart_up("あげは", "信頼", 2)
        hide ageha
        with dissolve
        return
    ageha "パイセン！　ちょうどいいとこに。……見て、これ"
    "あげはのパソコンの画面に、動画の編集ソフトが開いていた。タイトルは、『早瀬蓮　桜嶺の二年』。"
    ageha "卒業式の日に、部のアカウントに上げるやつ。……五軍の灰色のビブスから、国立まで"
    ageha "撮りためたの、全部で、四十時間あった。……あたし、パイセンのこと、四十時間、撮ってたんだって"
    "あげはは、自分で言って、自分で笑った。それから、急に、まじめな顔になった。"
    ageha "パイセン、どこ行くの。……あ、言わなくていい。決まったら、動画の最後の一枚に、入れるから"
    ageha "どこに行っても、最後の一枚は、パイセンが前を向いてるやつにする。……それだけ、決めてる"
    $ heart_up("あげは", "ときめき", 4)
    $ heart_up("あげは", "信頼", 3)
    $ up("注目度", 2)
    hide ageha
    with dissolve
    return

## 寮の裏の壁：本田（かばった人だけ）
label fin_b_feb_honda:
    scene bg ouryo_ground_eve
    with dissolve
    $ bgm("静かな春の曲")
    "寮の裏の壁で、本田が、ボールを、ゆっくり壁に当てていた。左足は、まだ、軽くしか振っていなかった。"
    show honda normal
    with dissolve
    honda "……早瀬。見て、これ。左で、ここまで戻った"
    honda "トレーナーさんが、春には走れるって。……大学の、一般入試、受けた。地元の"
    honda "受かったら、サッカー部、入る。灰色の、いちばん下から。……慣れてるだろ、俺"
    "本田は、笑った。また、困ったような顔になった。"
    honda "お前は？　……いや、いいや。決めたら、言ってくれれば"
    honda "名簿から消えなかったの、お前のおかげだから。……どこ行っても、俺は、お前の味方な"
    $ bond_up("本田", 4)
    $ up("メンタル", 1)
    hide honda
    with dissolve
    return

## 監督室の前：真壁
label fin_b_feb_makabe:
    scene bg ouryo_office
    with dissolve
    $ bgm("張りつめた静かな曲")
    "監督室の前の廊下に、真壁が立っていた。ドアを、ノックしようとして、手を下ろしたところだった。"
    show makabe match
    with dissolve
    "真壁は、俺に気づいて、目をそらした。それから、もう一回、こっちを見た。"
    makabe "……決勝の、後半二十分。あの合図、見てたろ"
    makabe "断れなかった。……断ったら、名簿から消えると思った。中学のときから、ずっと、そうだったから"
    makabe "鷹野とは、ジュニアユースで、二年、同じチームだった。……あいつの足を、狙った"
    "真壁は、ドアのほうを見たまま、言った。"
    makabe "俺、大学には行かない。サッカーも、たぶん、もうやらない"
    makabe "……鷹野に、言っといてくれないか。いや、いい。自分で言う。……それくらいは"
    $ lean("仲間型")
    $ up("戦術眼", 1)
    $ set_flag("fin_b_真壁")
    hide makabe
    with dissolve
    return

## 寮の屋上：神城
label fin_b_feb_kamishiro:
    scene bg ouryo_rooftop
    with dissolve
    $ bgm("静かな夜の曲")
    "屋上で、神城が、左の足首を回していた。テーピングは、もう、巻いていなかった。"
    show kamishiro normal
    with dissolve
    kamishiro "……三年前から、毎晩、巻いてた。もう、いらないって、トレーナーに言われた"
    kamishiro "巻かないで寝るの、変な感じだ。……足が、自分のじゃないみたいで"
    kamishiro "西のクラブには、一年目は、試合に出られないかもしれない。……それでいい。あの人に選ばれないで、試合に出られないのは、初めてだから"
    if b5_tell == "kamishiro" or flags.get("b6_神城が二人分走る"):
        kamishiro "早瀬。……全国で、二人分走ったとき、思った。俺、一人で走るより、だれかのぶんまで走るほうが、速い"
        kamishiro "それが分かっただけで、桜嶺の六年は、むだじゃなかった"
    $ bond_up("神城", 4)
    $ up("戦術眼", 1)
    hide kamishiro
    with dissolve
    return


################################################################################
## 休日（港北）の行き先
################################################################################

## はやせ食堂：母さん・ゆず
label fin_b_feb_mother:
    scene bg shokudo_day
    with dissolve
    $ bgm("あたたかいアコースティックギター")
    "昼のいそがしい時間が終わった店に入ると、ゆずが、カウンターで宿題を広げていた。"
    yuzu "あ、にいちゃん。……ねえ、春から、どこ行くの。ゆず、友だちに、聞かれる"
    show mother smile
    with dissolve
    haha "こら。それは、にいちゃんが決めること"
    haha "……でも、決めたら、ゆずには、いちばんに言ってあげな。あんたの、いちばんのファンだから"
    "ゆずは、宿題のノートの裏に、サッカーボールの絵を描いていた。ボールの横に、小さく、「にいちゃん」と書いてあった。"
    haha "店のことは、気にしなくていいからね。……のれんは、あたしが下ろすまで、下ろさない"
    $ up("メンタル", 2)
    $ up("無理ゲージ", -3)
    hide mother
    with dissolve
    return

## 港の防波堤：紗希
label fin_b_feb_pier:
    scene bg harbor_winter_eve
    with dissolve
    $ se("波の音、カモメ")
    $ bgm("静かなピアノの旋律")
    "防波堤のはしに、[saki_call]がいた。今日は、手紙を持っていた。去年と同じ、大人の、男の人の字の封筒。"
    show saki casual
    with dissolve
    saki_v "……兄さんから。今年の分"
    saki_v "子どもたちに教えてるチームが、市の大会で、初めて一回勝ったって。……それだけ書いてあった"
    saki_v "それから、一行だけ。……あの人が、桜嶺を辞めるなら、教えてくれ、って"
    "[saki_call]は、手紙を、ていねいに封筒に戻した。"
    saki_v "教えるかどうか、まだ、決めてない。……あんたと同じ。返事の期限、あたしにも、あるの"
    $ heart_up("紗希", "信頼", 4)
    $ heart_up("紗希", "ときめき", 2)
    hide saki
    with dissolve
    call b4_saki_late_contact
    return

## 港北のグラウンド：黒田
label fin_b_feb_kuroda:
    scene bg kohoku_ground_eve
    with dissolve
    $ bgm("静かな春の曲")
    "フェンスの外から、グラウンドを見ていると、うしろから、声がした。"
    show kuroda normal
    with dissolve
    kuroda "……見てるだけか。今日は、入ってもいいぞ"
    "黒田監督だった。ストップウォッチを、首にかけたまま。"
    kuroda "封筒、何通来た。……いい。数は聞かん"
    kuroda "一つだけ言っとく。どの封筒にも、お前のひざのことは書いてあったろう。……書いてない封筒は、選ぶな"
    if "school" in fin_offers:
        kuroda "専門学校の案内に、紙をはさんだのは、俺だ。……止まれたやつにしか、見えないものがある"
        kuroda "選べ、とは言わん。選ばなくても、紙は、捨てるな"
    else:
        kuroda "お前のひざは、まだ、走れる。……走れるうちに、走れる場所を、選べ"
    kuroda "……止まれなかったやつを、俺は、一人知ってる。昔の、俺だ"
    kuroda "お前は、止まれた。……それで、十分だ"
    $ up("戦術眼", 1)
    $ up("無理ゲージ", -2)
    hide kuroda
    with dissolve
    return
