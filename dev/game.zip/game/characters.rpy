## characters.rpy ―― 登場人物の定義
##   セリフは自動で「」で囲まれる。地の文（蓮のモノローグ）は名前なしの "……" で書く。
##   文の最後に、赤い▼（文字送りの合図）が点滅する。

## 文章を送るたびに、ごく小さな音（audio.rpy の text_cb）を鳴らす
define CTC = {"ctc": "ctc_blink", "ctc_position": "nestled", "callback": text_cb}
define QUOTE = {"what_prefix": "「", "what_suffix": "」", "ctc": "ctc_blink", "ctc_position": "nestled", "callback": text_cb}

## 地の文（名前なし）
define narrator = Character(None, **CTC)

## 名前の色は、マスキングテープの上で読みやすい濃い色にしている
define ren = Character("蓮", who_color="#2b4a7a", **QUOTE)
define hinata = Character("ひなた", who_color="#9a3a14", **QUOTE)
define hinata_s = Character("ひなた（小声）", who_color="#9a3a14", **QUOTE)
define chika = Character("千夏", who_color="#34478f", **QUOTE)
define saki = Character("紗希", who_color="#5a5a80", **QUOTE)
define saki_q = Character("？？？", who_color="#5a5a80", **QUOTE)
define miyoshi = Character("三好", who_color="#7a4508", **QUOTE)
define miyoshi_s = Character("三好（小声）", who_color="#7a4508", **QUOTE)
define kuroda = Character("黒田", who_color="#4a4a4a", **QUOTE)
define daimon = Character("大門", who_color="#356b30", **QUOTE)
define takano = Character("鷹野", who_color="#664600", **QUOTE)
define kamishiro = Character("神城", who_color="#55431a", **QUOTE)
define onizuka = Character("鬼塚", who_color="#2a2a2a", **QUOTE)
define onizuka_q = Character("黒いコートの男", who_color="#2a2a2a", **QUOTE)    # プロローグの1/10、まだ名前を知らない（v0.45.0）
define haha = Character("母", who_color="#9c3a55", **QUOTE)
define sakaguchi = Character("坂口", who_color="#6a3a8a", **QUOTE)

## ゲームの説明（チュートリアル）用。「」はつかない。青緑のペンの色
define tuto = Character("システム", who_color="#2f6f76", what_color="#2f6f76", callback=system_cb,
                        ctc="ctc_blink", ctc_position="nestled")

## 第2章から名前が出る部員（立ち絵なし）と、試合の審判
define kiryu = Character("桐生", who_color="#4a5a6a", **QUOTE)
define miyashita = Character("宮下", who_color="#4a5a6a", **QUOTE)
define mori = Character("森", who_color="#6a3a8a", **QUOTE)
define eto = Character("江藤", who_color="#6a3a8a", **QUOTE)
define koike = Character("小池", who_color="#6a3a8a", **QUOTE)
define noguchi = Character("野口", who_color="#6a3a8a", **QUOTE)
define judo_senpai = Character("柔道部の先輩", who_color="#4a4a4a", **QUOTE)
define shinpan = Character("審判", who_color="#4a4a4a", **QUOTE)

## 紗希の呼び方：第1章で名前を聞いていなければ、楽譜の端の名字「鬼塚」で呼ぶ（第2章の満員電車から）
default saki_call = "紗希"
define saki_v = Character("[saki_call]", who_color="#5a5a80", **QUOTE)

## 第3章の追加場面（chapter3_more.rpy）の人物
define jouren = Character("常連のおじさん", who_color="#5a4a3a", **QUOTE)
define kyoto = Character("教頭先生", who_color="#4a4a4a", **QUOTE)
define gendai = Character("現国の先生", who_color="#4a4a4a", **QUOTE)
define kashiwagi = Character("柏木", who_color="#4a5a6a", **QUOTE)
define sagara = Character("相良", who_color="#4a5a6a", **QUOTE)
define himuro = Character("氷室", who_color="#4a5a6a", **QUOTE)
define yuzu = Character("ゆず", who_color="#b0506e", **QUOTE)    # 蓮の妹（はやせ食堂で一言だけ話す）

## 第4章（ルートA・chapter4a.rpy）の人物
define kobayakawa = Character("小早川", who_color="#2f5d50", **QUOTE)
define kurata = Character("倉田", who_color="#2f5d50", **QUOTE)
define akasaka = Character("赤坂", who_color="#2f5d50", **QUOTE)
define saeki = Character("佐伯", who_color="#4a4a4a", **QUOTE)
## 新しいヒロイン（v0.30.0）：桃井あげは。ルートAは港北、ルートBは桜嶺の1年のマネージャー
define ageha = Character("あげは", who_color="#b04a72", **QUOTE)
define ichinen = Character("1年生", who_color="#2f5d50", **QUOTE)
define isha = Character("医者", who_color="#4a4a4a", **QUOTE)
define makabe = Character("真壁", who_color="#55431a", **QUOTE)
## ルートBの桜嶺（v0.34.0）：3年の司令塔・一ノ瀬透、2年の5軍・本田航、5軍のコーチ
define ichinose = Character("一ノ瀬", who_color="#55431a", **QUOTE)
define honda = Character("本田", who_color="#55431a", **QUOTE)
define coach_b = Character("コーチ", who_color="#4a4a4a", **QUOTE)
## ルートBだけのヒロイン（v0.34.0）：西園寺麗華（桜嶺の2年・理事長の孫・Aチームのチーフマネージャー）
define reika = Character("麗華", who_color="#6a2a44", **QUOTE)
## 第5章（ルートA・chapter5a.rpy）の人物：清翔学園のコーチ・結城（鷹野のジュニアユース時代のコーチ）
define yuki = Character("結城", who_color="#34506e", **QUOTE)
define kid = Character("小学生", who_color="#4a4a4a", **QUOTE)
define pt = Character("理学療法士", who_color="#4a4a4a", **QUOTE)
define hmom = Character("ひなたの母", who_color="#9c5a3a", **QUOTE)
