## chapter4a.rpy ―― 第4章「最後の世代」ルートA（港北に残る）・高2の1〜4月
##   構成案：ルートA 第4章 構成案（Claude Docs）。正史と神城の真相は「製品版プラン_決定事項」
##   初詣で「残る」を伝える → 鬼塚への返事 → 1〜3月（短く）→ 三好の卒業式 → 入学式と勧誘（自由行動①）
##   → 小早川が来る（部員18人）→ 統合が決まる（最後の世代）→ 港で神城「俺が決めた」（うそ）
##   5〜8月は chapter4a_2.rpy、自由行動の行き先と練習の出来事は chapter4a_free.rpy
##
##   ※ 製品版（有料）の部分。体験版（Web のテストページ）からは入れない。
##     開発中は、体験版の最後で「港北に残る」を選ぶと、開発用の選択肢から第4章に進める（script.rpy の trial_end。config.developer のときだけ）
##   ※ 恋愛の場面（ときめきの特別イベントなど）は、v0.31.1 で Claude が下書きした（chapter4a_heart.rpy ほか。作者が読んで直す）
##   ※ 新しい人物（小早川・倉田・赤坂・佐伯・真壁）の立ち絵は v0.30.0 で入れた。ふだんはセリフ枠の顔の写真、出会いの場面で立ち絵

## 第4章の人物（小早川・倉田・赤坂・佐伯など）は characters.rpy で定義している（読みこむ順番のため）

default a4_chika_call = "早瀬くん"   # 千夏が二人のときに呼ぶ名前（大晦日に千夏と話した人は「蓮くん」）
default a4_captain = "ren"         # キャプテン（三好先輩の腕章を受け取った人。ren / takano）
default a4_onizuka = ""            # 鬼塚への返事のしかた（polite / short）
default a4_miyoshi = ""            # 卒業式で三好先輩に言ったこと（zenkoku / left / thanks）
default a4_recruit = []            # 4月の勧誘で回った順（gate / gym / ground / hall / council）
default a4_members = 10            # 部員の数
default a4_merger = ""             # 統合が決まった日、千夏に言ったこと（leave / honest / zenkoku）
default a4_kamishiro = ""          # 神城のうそへの反応（grab：つかみかかる / turn：背を向ける / final：「決勝で返す」）

## 統合の会議の日（4月19日）より前に、生徒会室で千夏から日付を聞いたか
default a4_heard_meeting = False
default a4_feb_seat = ""           # 送別旅行の行きの電車で隣に座った人（daimon / takano / sakaguchi）
default a4_feb_pong = ""           # 送別旅行の卓球大会で組んだ人（miyoshi / takano / hinata）
default a4_feb_gift = ""           # 三好先輩の送別旅行のプレゼント（ball：寄せ書きのボール / words：帰りの電車でひとことずつ）

## 第4章の入口
label chapter4a:
    $ quick_menu = True
    $ play_marks["chapter4a"] = renpy.get_game_runtime()   # 古いセーブで続きが見つからないとき、ここから続ける（script.rpy の save_lost）
    $ a4_captain = ch3_armband or "ren"
    if ch3_nye == "chika":
        $ a4_chika_call = "{rb}蓮{/rb}{rt}れん{/rt}くん"
    call show_title("第4章", "最後の世代")
    call a4_hatsumode
    call a4_onizuka_call
    call a4_winter
    call a4_feb_plan
    call a4_feb_trip
    call a4_graduation
    call a4_entrance
    call a4_recruit_loop
    call a4_kobayakawa
    call a4_ageha_join
    call a4_merger_day
    call a4_kamishiro_day
    jump chapter4a_2


################################################################################
## 1月1日：「残る」を伝える（大晦日に話した人で5通り）
################################################################################
label a4_hatsumode:
    scene black
    with Dissolve(1.5)
    $ set_cal("1月1日（金）", "0時すぎ")
    call expression "a4_newyear_" + (ch3_nye or "mother")
    return

label a4_newyear_chika:
    scene bg shrine_steps_night
    $ coat_on()
    with dissolve
    $ bgm("静かな夜の曲")
    "除夜の鐘が終わって、町の神社まで歩いた。"
    "石段の下に、白いテントが一つ。生徒会の腕章をつけた人たちが、紙コップに{rb}甘酒{/rb}{rt}あまざけ{/rt}を注いでいた。"
    show chika normal
    with dissolve
    voice "audio/voice/chika_a4_newyear_01.mp3"
    chika "……どうぞ。米こうじの甘酒です。お酒は入っていません。熱いので、気をつけてください"
    "千夏先輩は、俺だと分かっても、手を止めなかった。紙コップを一つ、差し出しただけだった。"
    ren "先輩。……残ります。港北に"
    "紙コップを持つ先輩の指が、ほんの少しだけ、止まった。"
    voice "audio/voice/chika_a4_newyear_02.mp3"
    chika "……そうですか"
    show chika soft
    voice "audio/voice/chika_a4_newyear_03.mp3"
    chika "では、約束どおり、写真を撮ります。……今年の夏まで、全部"
    "テントの奥から、ほかの役員が先輩を呼んだ。"
    show chika normal
    voice "audio/voice/chika_a4_newyear_04.mp3"
    chika "……早瀬くん。生徒会の仕事中です。甘酒は、一人一杯までです"
    "人前では、名前が「早瀬くん」に戻っていた。"
    "甘酒は、少し甘すぎた。"
    hide chika
    with dissolve
    $ heart_up("千夏", "信頼", 5)
    return

label a4_newyear_hinata:
    scene bg harbor_newyear_night
    $ coat_on()
    with dissolve
    $ se("波の音、カモメ")
    $ bgm("あたたかいアコースティックギター")
    "防波堤を戻ると、街灯の下に、ひなたが立っていた。"
    show hinata stare
    with dissolve
    voice "audio/voice/hinata_a4_newyear_01.mp3"
    hinata "……ここだと思った。千鶴さんが、蓮、出てったきり帰ってこないって"
    ren "ひなた。俺――"
    voice "audio/voice/hinata_a4_newyear_02.mp3"
    hinata "待って。眉毛、見せて"
    "ひなたは、つま先立ちになって、俺の顔をのぞきこんだ。"
    ren "……残る。港北に"
    show hinata smile
    voice "audio/voice/hinata_a4_newyear_03.mp3"
    hinata "うん、うそじゃない"
    voice "audio/voice/hinata_a4_newyear_04.mp3"
    hinata "じゃあ、来年も、テーピング巻ける"
    "ひなたは、それだけ言って、くるりと背中を向けた。"
    voice "audio/voice/hinata_a4_newyear_05.mp3"
    hinata "初詣、行こ。おみくじ、蓮のぶんも引いてあげる"
    hide hinata
    with dissolve
    $ heart_up("ひなた", "信頼", 5)
    $ amb_stop()
    return

label a4_newyear_saki:
    scene bg harbor_newyear_night
    $ coat_on()
    with dissolve
    $ se("波の音、カモメ")
    $ bgm("静かなピアノの旋律")
    "防波堤の根もとまで戻ったとき、街灯の届かないところに、人影があった。"
    show saki normal
    with dissolve
    voice "audio/voice/saki_a4_newyear_01.mp3"
    saki "……決めた顔してる"
    ren "なんで、ここに"
    voice "audio/voice/saki_a4_newyear_02.mp3"
    saki "約束でしょ。決めたら教えてって"
    "[saki_call]は、マフラーに口もとをうずめたまま、こっちを見なかった。"
    ren "残る。港北に"
    voice "audio/voice/saki_a4_newyear_03.mp3"
    saki "……そう"
    voice "audio/voice/saki_a4_newyear_04.mp3"
    saki "あの人、怒るね。断られるの、慣れてないから"
    voice "audio/voice/saki_a4_newyear_05.mp3"
    saki "……いい気味"
    "少しだけ、笑ったように見えた。暗くて、よく分からなかった。"
    voice "audio/voice/saki_a4_newyear_06.mp3"
    saki "寒い。帰る"
    hide saki
    with dissolve
    $ heart_up("紗希", "信頼", 5)
    $ amb_stop()
    return

label a4_newyear_takano:
    scene bg ren_room_night
    with dissolve
    $ bgm("静かな夜の曲")
    "家に帰って、スマホを開いた。"
    window auto hide
    $ talk_start("鷹野 迅", "0:21")
    $ talk_me("残る")
    $ talk_wait(1)
    $ talk("鷹野", "知ってた")
    $ talk("鷹野", "三好先輩には、お前から言え。俺が言うと、あの人、電話してくる")
    $ talk_me("もう寝てるだろ")
    $ talk("鷹野", "寝てねえよ。あの人が大晦日に寝るわけねえ")
    $ talk_wait(1)
    $ talk("鷹野", "……全国まで、出しつづけろよ")
    window auto hide
    $ talk_end()
    "三好先輩にトークを送ると、一秒で電話が鳴った。"
    "耳から十センチ離しても、先輩の声は、全部聞こえた。"
    $ bond_up("鷹野", 3)
    $ bond_up("三好", 2)
    return

label a4_newyear_mother:
    scene bg shokudo_night
    with dissolve
    $ bgm("あたたかいアコースティックギター")
    "店に戻ると、母さんが、まだカウンターでお茶を飲んでいた。"
    show mother normal
    with dissolve
    haha "おかえり。……寒かったでしょ"
    ren "母さん。……残る。港北に"
    haha "そう"
    show mother smile
    haha "じゃあ、明日からまた、お米多めに炊かなきゃね"
    "母さんは、それ以上、何も聞かなかった。"
    "湯のみを一つ出して、お茶を注いでくれた。"
    hide mother
    with dissolve
    return


################################################################################
## 1月：鬼塚に断りの電話をかける
##   鬼塚は「試させてもらう」とだけ言う（第6章の決勝の伏線。蓮には意味が分からない）
################################################################################
label a4_onizuka_call:
    scene black
    with dissolve
    $ set_cal("1月4日（月）", "夕方")
    scene bg ren_room_night
    with dissolve
    $ bgm("張りつめた静かな曲")
    "机の上に、母さんが店で受け取った名刺が置いてあった。"
    "「桜嶺学園高等学校　サッカー部監督　{rb}鬼塚源三{/rb}{rt}おにづかげんぞう{/rt}」"
    "断るなら、自分の口で言うべきだと思った。"
    "呼び出し音が、二回鳴って、止まった。"
    onizuka "……{rb}早瀬{/rb}{rt}はやせ{/rt}か"
    "名乗る前に、名前を言われた。"
    menu:
        "「お誘いは、お断りします。港北に残ります」":
            $ a4_onizuka = "polite"
            $ lean("求道型")
            ren "お誘いは、お断りします。港北に残ります"
        "「行きません。港北で、桜嶺に勝ちます」":
            $ a4_onizuka = "short"
            $ lean("野心型")
            $ up("メンタル", 2)
            ren "行きません。港北で、桜嶺に勝ちます"
    "しばらく、何も聞こえなかった。"
    onizuka "……そうか"
    onizuka "十人の部と、一度切れたひざで、何ができる"
    onizuka "本物は、壊れない。壊れるなら、それまでだ"
    onizuka "……もう一度、試させてもらう"
    "電話は、それで切れた。こっちの返事を、待つ気もなかった。"
    "試す。何を、どうやって。"
    "スマホを置いても、最後の一言だけが、耳の奥に残っていた。"
    $ up("注目度", 3)
    return


################################################################################
## 1〜2月：10人の冬（短く）
################################################################################
label a4_winter:
    scene black
    with dissolve
    $ set_cal("1月18日（月）", "放課後")
    scene bg kohoku_ground_eve
    $ coat_on()
    with dissolve
    $ bgm("静かな春の曲")
    "三学期の練習は、10人だった。ミニゲームをすると一人足りなくて、いつも、{rb}黒田{/rb}{rt}くろだ{/rt}がそこに入った。"
    show kuroda normal
    with dissolve
    kuroda "……{rb}早瀬{/rb}{rt}はやせ{/rt}。俺に回すな。走らされる"
    ren "先生がいちばん、パスがうまいので"
    kuroda "……おだてても、走らん"
    "そう言いながら、黒田は、ワンタッチで鷹野の足もとに返した。"
    hide kuroda
    with dissolve
    if a4_captain == "ren":
        "腕には、三好先輩の腕章を巻いていた。まだ少し、ゆるかった。"
    else:
        show takano jersey
        with dissolve
        "腕章は、{rb}鷹野{/rb}{rt}たかの{/rt}の左腕にあった。"
        takano "……おい、声出せ。キャプテンだけに言わせんな"
        "そう言う鷹野の声が、いちばん小さかった。"
        hide takano
        with dissolve
    "4月に1年が入らなければ、11人にならない。誰も口にはしなかった。でも、練習が終わると、全員が一度、校門のほうを見た。"
    return


################################################################################
## 2月12日〜14日：三好先輩の送別旅行（番外編・1泊2日）（v0.29.9）
##   坂口たちが「遠征の練習試合」とうそをついて三好先輩を呼び出し、部の全員（＋ひなた・千夏・黒田）で雪の温泉町へ1泊2日
##   見せ場：みんなの私服（trip）／旅館の浴衣（ryokan）／集合写真（cg feb_group）／風呂上がりの自販機（cg feb_vending）／
##          卓球の罰ゲーム／夜のロビーで黒田とサッカーの話／消灯後の三好先輩の本音／雪の朝のパス交換
##   選択：プレゼント／電車で隣に座る人／雪合戦／自販機の牛乳／卓球のペア／黒田への答え／三好先輩への返事／雪の朝のひとこと
##   立ち絵・一枚絵は images.rpy の trip_img で、絵がまだないときは今の絵を出す（絵を置けば差し替わる）
##   trip_outfit：セリフ枠の顔の写真（森たち6人）を、私服（trip）・浴衣（ryokan）に切りかえる
################################################################################
default trip_outfit = ""
default a4_feb_milk = ""            # 風呂上がりの自販機で選んだもの（fruit：フルーツ牛乳 / coffee：コーヒー牛乳 / ichigo：いちご牛乳）
default a4_feb_kuroda = ""          # 夜のロビーで黒田に答えたこと（recruit / knee / front）

label a4_feb_plan:
    scene black
    with dissolve
    $ set_cal("2月12日（金）", "放課後")
    scene bg clubroom
    with dissolve
    $ bgm("とぼけた日常の曲")
    "練習のあと、部室のドアを閉めたとたん、坂口が声をひそめた。"
    show sakaguchi jersey
    with dissolve
    sakaguchi "てか聞いて。三好先輩、3月1日で卒業じゃん"
    sakaguchi "送別会、やろ。……部室でジュース、とかじゃなくて、ちゃんとしたやつ"
    "坂口は、スマホの画面をみんなに向けた。雪の積もった、温泉町の写真だった。"
    sakaguchi "明日から一泊。電車で2時間。足湯、タダ。ウケる、もう宿も調べた"
    hide sakaguchi
    show noguchi jersey
    with dissolve
    noguchi "……ぼく、積もってる雪、見たことない"
    hide noguchi
    with dissolve
    "江藤は、黙って財布の中身を数えはじめた。森は、なぜか正座していた。"
    show takano jersey
    with dissolve
    takano "……行かねえ。土日は走る"
    sakaguchi "鷹野も来るって。はい、決まり"
    takano "言ってねえ"
    hide takano
    with dissolve
    show hinata smile
    with dissolve
    hinata "泊まりなら、先生がいないとだめだよ。黒田先生には、わたしが言っとく"
    hinata "……たぶん、ついてくるって言うよ。先生の昔の知り合いの旅館なら、安くなるかもって"
    hinata "でも、三好先輩には、なんて言って呼ぶの？　「送別会」って言ったら、絶対その場で泣いて、明日まで持たないよ"
    hide hinata
    with dissolve
    show sakaguchi jersey
    with dissolve
    sakaguchi "そこは任せて。……「明日、遠征の練習試合です。一泊。ジャージで、朝7時に校門」"
    sakaguchi "で、俺らは全員、私服で行く。……先輩だけジャージ。ウケる"
    sakaguchi "で、蓮。……プレゼント、どうする"
    menu:
        "「ボールに、全員で寄せ書きしよう」":
            $ a4_feb_gift = "ball"
            $ lean("仲間型")
            $ bond_up("坂口", 1)
            ren "ボールに、全員で寄せ書きしよう。……先輩が、工務店でも蹴れるように"
            sakaguchi "それ。ウケる。泣くやつじゃん"
        "「物はいい。帰りの電車で、一人ずつひとこと言おう」":
            $ a4_feb_gift = "words"
            $ lean("求道型")
            $ up("メンタル", 1)
            ren "物はいい。帰りの電車で、一人ずつ、ひとこと言おう"
            sakaguchi "……え、それ、こっちが泣くやつじゃん"
    hide sakaguchi
    with dissolve
    "その夜、部のグループに、坂口からトークが一つだけ来た。「明日7時。私服。着がえ。先輩には内緒」"
    return

## 1日目（2/13・土）：校門（私服のお披露目） → 行きの電車 → 雪の温泉町（集合写真） → 旅館
label a4_feb_trip:
    scene black
    with dissolve
    $ set_cal("2月13日（土）", "朝7時")
    $ trip_outfit = "trip"
    scene bg kohoku_gate_winter
    $ coat_on()
    with dissolve
    $ bgm("明るい部活の曲")
    "朝7時。校門の前に集まった全員が、初めて見る格好をしていた。"
    show hinata trip
    with dissolve
    "ひなたは、白いニットのコートに、くすんだピンクのスカート。頭にはベレー帽、マフラーの先に、小さなポンポンが二つ。"
    hinata "……なに。じろじろ見ないでよ"
    hinata "かわいいでしょ、このポンポン。駅前の雑貨屋さんで、ずっと狙ってたの"
    hide hinata
    show chika trip
    with dissolve
    "千夏先輩は、灰色の大きなパーカーに、黒いリュック。リュックには、知らないアニメの缶バッジが七つ並んでいた。"
    sakaguchi "……千夏先輩、私服、そっちなんだ"
    chika "何か問題がありますか。動きやすさと、収納力です"
    chika "……缶バッジは、見なかったことにしてください"
    hide chika
    show kuroda trip
    with dissolve
    "黒田は、黒いダウンジャケットに、色の入った眼鏡。……完全に、休日の父親だった。"
    kuroda "……引率だ。俺は、温泉に入りに来たわけじゃない"
    "そう言う黒田のリュックから、タオルが二枚はみ出していた。"
    hide kuroda
    show daimon trip
    with dissolve
    "大門は、紺のダッフルコート。大門が着ると、なぜかサイズが一つ小さく見えた。"
    daimon "あ、あの……母に、旅行なら、ちゃんとした服を着ていきなさいって、言われたので……"
    hide daimon
    show takano trip
    with dissolve
    "鷹野は、黒いモッズコートにニット帽。一人だけ、旅慣れた大学生みたいだった。"
    takano "……見んな"
    hide takano
    show sakaguchi trip
    with dissolve
    "坂口は、背中に虎の刺しゅうのあるスタジャンだった。"
    sakaguchi "これ、ゲーセンの景品。ウケる"
    hide sakaguchi
    with dissolve
    mori "おはようございます。……旅行には、ジャケットを着ていくものだと、祖父が"
    koike "メガネ、くもる。……寒いところ、むり"
    eto "……ドリブルしやすい靴で来た"
    noguchi "雪、まだ？　ここ、まだ潮見だよね？"
    kiryu "……宮下の帽子、それ、何の動物"
    miyashita "ふふっ……ペンギン。きのう、妹に借りたの"
    "坂の下から、ボールバッグを肩にかけた人が、全力で走ってきた。"
    $ se("小走りの足音")
    show miyoshi smile
    with dissolve
    miyoshi "おはよう！！！　相手どこだ！！　桜嶺か！！　何人でも来い！！"
    miyoshi "……なんだ。なんで全員、私服なんだ。……俺だけ、ジャージじゃねえか！！"
    sakaguchi "先輩。……今日、試合、ないっす"
    sakaguchi "送別会っす。雪、見に行くっす。一泊っす"
    "三好先輩は、ボールバッグを肩にかけたまま、しばらく動かなかった。"
    miyoshi "……お前ら"
    miyoshi "……スパイク、二足持ってきたんだぞ"
    "そう言って、先輩は空を見上げた。鼻の頭が赤かったのは、寒さのせいだけではなかった。"
    hide miyoshi
    with dissolve
    call show_title("番外編", "雪と卓球と、三好先輩")
    call a4_feb_train
    call a4_feb_snow
    call a4_feb_ryokan
    call a4_feb_vending
    call a4_feb_pingpong
    call a4_feb_kuroda_talk
    call a4_feb_night
    call a4_feb_day2
    $ trip_outfit = ""
    return

## 行きの電車：誰の隣に座るか
label a4_feb_train:
    scene bg train_local_snow_day
    with dissolve
    $ se("電車の走る音")
    $ bgm("あたたかいアコースティックギター")
    "2両だけの電車は、ほとんど貸し切りだった。黒田は座ったとたんに寝て、野口は、トンネルを抜けるたびに「まだ？」と言った。"
    "三好先輩は、車両のまん中で、なぜか全員分のみかんを配っていた。ジャージのポケットから、いくらでも出てきた。"
    menu:
        "隣に座ったのは――"
        "大門":
            $ a4_feb_seat = "daimon"
            $ bond_up("大門", 3)
            show daimon trip
            with dissolve
            daimon "……早瀬くん。三好先輩、去年の春に、柔道場に3日続けて来たんです"
            daimon "僕、3日目に、やっとうなずきました。……2日目で、もう決めてたのに"
            ren "なんで3日目なんだよ"
            daimon "3日目も来てくれるのか、見たかったんです"
            daimon "来年から、後ろで声を出すのは、僕になります。……先輩みたいに、声、出せるかな"
            hide daimon
            with dissolve
        "鷹野":
            $ a4_feb_seat = "takano"
            $ bond_up("鷹野", 3)
            show takano trip
            with dissolve
            takano "……うるせえのが一人いなくなる。せいせいする"
            "鷹野は、もらったみかんを、むかないまま手の中で転がしていた。"
            takano "……で、誰が、朝6時に呼び出すんだよ"
            ren "俺が呼ぶよ"
            takano "お前の6時は、6時5分だろ"
            "否定できなかった。鷹野は、そこで初めて、みかんの皮をむいた。"
            hide takano
            with dissolve
        "坂口":
            $ a4_feb_seat = "sakaguchi"
            $ bond_up("坂口", 3)
            show sakaguchi trip
            with dissolve
            sakaguchi "三好先輩さ、ゲーセンのあの台で、俺に一回も勝ったことないんだよ"
            sakaguchi "……最後くらい、勝たせてやろうかな。わざと負けるの、むずいけど"
            ren "わざとだってばれたら、先輩、たぶん泣くぞ"
            sakaguchi "……それな。じゃあ、本気でやる。ウケる"
            hide sakaguchi
            with dissolve
    "三つ目のトンネルを抜けたとき、窓の外が、真っ白になった。"
    noguchi "……雪だ"
    "車両じゅうが、一瞬、静かになった。黒田だけが、まだ寝ていた。"
    $ amb_stop()
    return

## 雪の温泉町：雪合戦と集合写真
label a4_feb_snow:
    scene bg onsen_town_snow
    $ coat_on()
    with Dissolve(1.0)
    $ bgm("とぼけた日常の曲")
    "駅を出ると、湯気と、雪の匂いがした。最初の雪玉を投げたのが誰だったかは、あとで誰も認めなかった。"
    show miyoshi smile
    with dissolve
    miyoshi "よーし！！　卒業生チーム対、在校生チームだ！！"
    miyoshi "卒業生は、俺一人！！　かかってこい！！"
    "ひなたが、どこから出したのか、笛をくわえていた。審判らしかった。"
    menu:
        "「全員で、三好先輩をねらえ！」":
            $ lean("野心型")
            $ up("フィジカル", 1)
            ren "全員で、先輩をねらえ！"
            "10人分の雪玉が、一人に向かって飛んでいった。三好先輩は、一発もよけなかった。全部、胸で受けて、全部、笑っていた。"
            miyoshi "効かん！！　去年の0−9に比べたら、何も効かん！！"
        "「俺は、先輩のチームに入ります」":
            $ lean("仲間型")
            $ bond_up("三好", 2)
            ren "俺、先輩のチームに入ります"
            miyoshi "……蓮！！　お前ってやつは！！"
            "二人対九人になった。鷹野の雪玉だけ、異様にまっすぐ飛んできた。"
            takano "……寝返ったやつには、手加減しねえ"
    hide miyoshi
    with dissolve
    "勝負は、大門が足をすべらせて、坂口と野口を巻きこんで転んだところで、うやむやになった。雪の上に、三人分の形が残った。"
    ## 集合写真
    show chika trip
    with dissolve
    chika "……全員、そこに並んでください。港北の記録です"
    chika "セルフタイマーは10秒です。先生も、入ってください"
    hide chika
    show kuroda trip
    with dissolve
    kuroda "……俺は、いい。撮る側だ"
    "黒田が言い終わる前に、三好先輩と森が、両側から黒田の腕をつかんでいた。"
    kuroda "……おい"
    hide kuroda
    with dissolve
    "千夏先輩がボタンを押して、雪をけって走ってきた。ひなたが、はしっこで手を振って呼んだ。"
    $ se("小走りの足音")
    scene cg feb_group at cam_push(8.0, 1.04)
    with Dissolve(0.8)
    "まん中にジャージの三好先輩。その横で、腕をつかまれたままの黒田が、ほんの少しだけ笑っていた。"
    "千夏先輩は、間に合わずに、写真の左はしで半分だけ写っていた。"
    chika "……撮りなおしません。これが、いちばん港北らしいので"
    $ bond_up("三好", 1)
    return

## 旅館に着く：部屋割りと浴衣
label a4_feb_ryokan:
    scene black
    with dissolve
    $ set_cal("2月13日（土）", "夕方", quiet=True)
    scene bg ryokan_lobby_night
    with dissolve
    $ bgm("あたたかいアコースティックギター")
    "旅館は、黒田の昔の知り合いがやっている、古い木の建物だった。ロビーには、だるまストーブが燃えていた。"
    "おかみさんは、黒田を見るなり「修ちゃん、太ったねえ」と言った。全員が聞こえないふりをした。"
    $ trip_outfit = "ryokan"
    "大浴場は、11人で入るには小さかった。湯ぶねのまん中で、三好先輩が校歌を歌いはじめて、全員で止めた。"
    return

## 風呂上がりの自販機
label a4_feb_vending:
    scene bg ryokan_lobby_night
    with dissolve
    $ bgm("とぼけた日常の曲")
    "のどがかわいて、ロビーの自販機に向かった。その前に、浴衣に羽織を着た二人が並んで、ガラスに顔を近づけていた。"
    voice "audio/voice/hinata_a4_feb_vending_01.mp3"
    hinata "だから、お風呂上がりはフルーツ牛乳に決まってるじゃないですか、千夏先輩"
    voice "audio/voice/chika_a4_feb_vending_01.mp3"
    chika "いいえ。コーヒー牛乳です。これは、全国の温泉の記録に残っている事実です"
    voice "audio/voice/hinata_a4_feb_vending_02.mp3"
    hinata "そんな記録、ないですよ"
    voice "audio/voice/chika_a4_feb_vending_02.mp3"
    chika "あります。わたしが今、つけました"
    scene cg feb_vending at cam_push(8.0, 1.04)
    with Dissolve(0.8)
    voice "audio/voice/hinata_a4_feb_vending_03.mp3"
    hinata "あ、蓮。ちょうどいいとこに来た"
    voice "audio/voice/chika_a4_feb_vending_03.mp3"
    chika "決めてください。お風呂上がりに飲むのは、どちらですか"
    voice "audio/voice/hinata_a4_feb_vending_04.mp3"
    hinata "……ちなみに、負けたほうが、次のぶんをおごるから"
    menu:
        "どっちを押す？"
        "フルーツ牛乳":
            $ a4_feb_milk = "fruit"
            $ heart_up("ひなた", "信頼", 1)
            "フルーツ牛乳のボタンを押した。ひなたが、小さくガッツポーズをした。"
            voice "audio/voice/hinata_a4_feb_vending_05.mp3"
            hinata "ほらね。蓮は、小学校のときから、ずっとこれなんだから"
            voice "audio/voice/chika_a4_feb_vending_04.mp3"
            chika "……幼なじみの票は、無効にするべきです"
        "コーヒー牛乳":
            $ a4_feb_milk = "coffee"
            $ heart_up("千夏", "信頼", 1)
            "コーヒー牛乳のボタンを押した。千夏先輩が、無表情のまま、メモに何かを書いた。"
            voice "audio/voice/chika_a4_feb_vending_05.mp3"
            chika "記録しました。2対1です。……わたしと、あなたと、全国の温泉で"
            voice "audio/voice/hinata_a4_feb_vending_06.mp3"
            hinata "全国の温泉、ずるいです！"
        "どっちも押さずに、いちご牛乳":
            $ a4_feb_milk = "ichigo"
            $ lean("仲間型")
            "どちらも押さずに、いちばん下の、いちご牛乳のボタンを押した。二人が、同時に、こっちを見た。"
            voice "audio/voice/hinata_a4_feb_vending_07.mp3"
            hinata "……ずるい"
            voice "audio/voice/chika_a4_feb_vending_06.mp3"
            chika "……引き分けです。おごりは、なしです"
            "それから二人とも、同じいちご牛乳を買っていた。"
    sakaguchi "おーい！！　卓球台あった！！　全員集合！！"
    return

## 卓球大会と罰ゲーム
label a4_feb_pingpong:
    scene bg ryokan_lobby_night
    with dissolve
    $ bgm("ゲームセンターの曲")
    "ロビーのすみに、色のはげた卓球台が一台あった。浴衣のまま、全員が集まった。"
    sakaguchi "卓球大会。ダブルス。……負けたペアは、罰ゲームで、なんでも一つ質問に答える。ウケる"
    menu:
        "誰と組む？"
        "三好先輩と組む":
            $ a4_feb_pong = "miyoshi"
            $ bond_up("三好", 2)
            show miyoshi ryokan
            with dissolve
            miyoshi "よし！！　卒業生と在校生の、最強ペアだ！！"
            "先輩のスマッシュは、三回に一回しか台に入らなかった。入ると、誰も取れなかった。"
            hide miyoshi
            with dissolve
        "鷹野と組む":
            $ a4_feb_pong = "takano"
            $ bond_up("鷹野", 2)
            show takano ryokan
            with dissolve
            takano "……やるからには、勝つ"
            "鷹野は、浴衣の袖を帯にはさんで、ラリーのたびに本気で舌打ちした。"
            hide takano
            with dissolve
        "ひなたと組む":
            $ a4_feb_pong = "hinata"
            $ heart_up("ひなた", "信頼", 2)
            show hinata ryokan
            with dissolve
            hinata "いいよ。……言っとくけど、わたし、うまいよ。小学校の子ども会で、優勝したから"
            "ひなたは本当にうまかった。俺は、ほとんど球拾いだった。"
            hide hinata
            with dissolve
    show kuroda ryokan
    with dissolve
    "いつの間にか起きてきた黒田が、片手にラケット、片手に缶コーヒーを持って立っていた。ペアは、千夏先輩だった。"
    kuroda "……一回だけだ"
    "黒田は、一歩も動かなかった。缶コーヒーも、一度も置かなかった。それでも、球は全部、いちばん取りにくいところに返ってきた。"
    chika "……先生。ひざは、いいんですか"
    kuroda "卓球は、ひざを使わん"
    "11−2。千夏先輩は、一度もラケットを振らずに優勝した。"
    hide kuroda
    with dissolve
    if a4_feb_pong == "miyoshi":
        miyoshi "……先生！！　一回だけ、本気出してください！！　俺、もう卒業するんで！！"
        kuroda "……出してない"
    ## 罰ゲーム
    show sakaguchi ryokan
    with dissolve
    sakaguchi "はい、罰ゲーム。負けたペアの、蓮に質問"
    sakaguchi "……ひなたと千夏先輩、どっちがタイプ？"
    hide sakaguchi
    with dissolve
    "ロビーが、一瞬で静かになった。だるまストーブの音だけが、ぱちぱちと鳴っていた。"
    "ひなたは、ラケットで顔の半分を隠した。千夏先輩は、無表情のまま、記録用のメモを開いた。"
    "全員の目が、こっちを見ていた。三好先輩なんて、身を乗り出しすぎて、卓球台に手をついていた。"
    ## どちらを選ぶかと、言いかける理由（v0.31.1・Claude の下書き。chapter4a_heart.rpy）
    call a4h_pong_answer
    show kuroda ryokan
    with dissolve
    "ことん、と、缶コーヒーが卓球台に置かれた。"
    kuroda "……そこまでだ"
    kuroda "ここから先は、選手権に勝ってから言え"
    hide kuroda
    with dissolve
    "一瞬の間のあと、ロビーじゅうから、ブーイングが起きた。"
    miyoshi "先生！！　今、いちばんいいとこでした！！"
    sakaguchi "ウケない！！　今のはウケない！！"
    "ひなたは、ラケットで顔を隠したまま、動かなかった。千夏先輩は、開いたメモを、そっと閉じた。"
    show kuroda ryokan
    with dissolve
    kuroda "……早瀬。ちょっと来い"
    hide kuroda
    with dissolve
    return

## 夜のロビー：黒田と、サッカーの話
label a4_feb_kuroda_talk:
    scene black
    with dissolve
    scene bg ryokan_lobby_night
    with dissolve
    $ bgm("静かな夜の曲")
    "みんなが部屋に戻ったあとのロビーは、ストーブの音しかしなかった。"
    show kuroda ryokan
    with dissolve
    "黒田は、ストーブの前のソファーに座って、二本目の缶コーヒーを開けた。一本を、こっちに放ってよこした。"
    kuroda "……さっきのは、助けたわけじゃない。うるさかったからだ"
    ren "分かってます"
    kuroda "……三好がいなくなると、10人だ"
    kuroda "4月に1年が入らなければ、夏は出られん。……入っても、交代はいない"
    "黒田は、缶を両手で包んだまま、ストーブの火を見ていた。"
    kuroda "早瀬。来年、11人そろわなかったら、どうする"
    menu:
        "「そろうまで、俺が1年を誘います」":
            $ a4_feb_kuroda = "recruit"
            $ lean("仲間型")
            $ bond_up("三好", 1)
            ren "そろうまで、俺が1年を誘います。三好先輩が、俺を誘ったみたいに"
            kuroda "……三好は、3人から始めた。お前は、10人いる"
            kuroda "言いわけは、できんな"
        "「ひざを、夏まで持たせます」":
            $ a4_feb_kuroda = "knee"
            $ lean("求道型")
            $ up("無理ゲージ", -2)
            ren "……そろっても、俺のひざがだめなら、10人です。だから、夏まで持たせます"
            kuroda "……そうだ。それを、自分で言えるようになったか"
        "「そろったら、俺がもっと前で点を取ります」":
            $ a4_feb_kuroda = "front"
            $ lean("野心型")
            $ up("戦術眼", 1)
            ren "そろったら、俺がもっと前に出ます。点を取るところまで、行きます"
            kuroda "……俺も、同じことを考えていた"
    kuroda "……俺は、28で、ひざが終わった"
    kuroda "終わる前の年、無理をした。痛いのを、黙ってた。……その年が、いちばんうまかった"
    "黒田の声は、いつもと同じで、少しだけ、遠かった。"
    kuroda "うまくなる年と、壊れる年は、だいたい同じ年に来る"
    kuroda "だから、来年のお前は、いちばん危ない。……いちばん、うまくなる"
    kuroda "春から、お前を一つ前で使う。鷹野のすぐ後ろだ。考える時間は、今の半分になる"
    kuroda "そのかわり、痛いときは、俺に言え。言わなかったら、その日から、ベンチだ"
    ren "……はい"
    "黒田は、缶コーヒーを飲み干して、立ち上がった。"
    kuroda "……さっきの質問の答えは、聞かなかったことにしておく。……寝ろ"
    hide kuroda
    with dissolve
    $ up("メンタル", 2)
    return

## 消灯後：大部屋の本音
label a4_feb_night:
    scene black
    with dissolve
    scene bg ryokan_room_night
    with dissolve
    $ bgm("静かな夜の曲")
    "大部屋に、布団が11枚、すき間なく並んだ。"
    "消灯の5分後に、坂口の枕が飛んだ。10秒後には、全部の枕が飛んでいた。ふすまが開いた。黒田が立っていた。"
    kuroda "……寝ろ"
    "ふすまが閉まった。全員、布団にもぐったまま笑っていた。しばらくして、暗い天井に向かって、三好先輩の声がした。"
    miyoshi_s "……蓮。起きてるか"
    ren "起きてます"
    miyoshi_s "去年の春、何人だったか、覚えてるか"
    ren "3人です。先輩と、桐生先輩と、宮下先輩"
    miyoshi_s "今日、数えた。……11人いた。俺を入れて、ちょうど11人だ"
    miyoshi_s "4月から、一人、足りなくなるな"
    "誰かの寝息が、一つ、途中で止まった。みんな、起きていた。"
    if a4_captain == "ren":
        miyoshi_s "……腕章、きついか"
    else:
        miyoshi_s "……鷹野の横で、お前が声出すんだぞ。きついか"
    menu:
        "「きついです。でも、やります」":
            $ lean("求道型")
            $ up("メンタル", 2)
            ren "きついです。……でも、やります"
            miyoshi_s "……そうか。きついって言えるやつは、つぶれない"
            miyoshi_s "俺は、言えなかったからな。3人のとき"
        "「先輩みたいに、声、出します」":
            $ lean("仲間型")
            $ bond_up("三好", 2)
            ren "先輩みたいに、声、出します。でかいやつ"
            miyoshi_s "……俺みたいなのは、一人でいい。うるさいからな"
            miyoshi_s "お前は、お前の声で出せ"
        "「全国、連れていきます。この11人の分まで」":
            $ lean("野心型")
            $ up("注目度", 1)
            ren "全国、連れていきます。この11人の分まで"
            miyoshi_s "……でかく出たな！！"
            "暗闇のあちこちから、三好先輩に「声でかい」とツッコミが入った。"
    "それきり、先輩は何も言わなかった。いちばん奥の布団から、鼻をすする音がした。野口だった。……たぶん、野口だけではなかった。"
    $ bond_up("三好", 3)
    return

## 2日目（2/14・日）：雪の朝のパス交換 → 足湯 → 帰りの電車
label a4_feb_day2:
    scene black
    with dissolve
    $ set_cal("2月14日（日）", "朝6時")
    $ trip_outfit = "trip"
    scene bg riverbank_snow_morning
    $ coat_on()
    with dissolve
    $ bgm("あたたかいアコースティックギター")
    "朝6時。肩をゆすられて起きると、三好先輩が、ボールを抱えて枕もとにしゃがんでいた。旅館の裏の河原は、真っ白だった。"
    show miyoshi trip
    with dissolve
    "先輩は、「私服」に着がえていた。……半袖のTシャツに、半ズボンだった。"
    ren "……先輩。外、雪です"
    miyoshi "知ってる！！　俺は、小学校から冬もこれだ！！　私服はこれしか持ってない！！"
    "旅館の窓から、坂口が顔を出して叫んだ。「小学校に一人はいたやつ！！　ウケる！！」"
    "二階の窓が次々に開いて、「寒い寒い寒い」「見てるこっちが寒い」と、全員にツッコまれた。先輩は、全部に親指を立てて返した。"
    miyoshi "……やっぱり、最後に一回、蹴っとかないとな"
    "二人で、パスを交換した。ボールは雪にめりこんで、三回に一回、途中で止まった。止まるたびに、先輩は大声で笑った。俺も、笑った。"
    miyoshi "去年の4月、お前、最初のパス、俺の頭の上を越えていったんだぞ"
    miyoshi "ひざのせいだと思った。……ちがったな。お前は、俺が走るより先に、走る場所に出してた"
    miyoshi "俺の足が、遅かっただけだ"
    menu:
        "最後に、何を言う？"
        "「先輩のパスは、最初、全部ずれてました」":
            $ lean("仲間型")
            $ bond_up("三好", 2)
            ren "先輩のパスも、最初、全部ずれてました"
            miyoshi "……知ってる！！　だから、毎朝6時に来てたんだ！！"
            "先輩は、雪の上に大の字に倒れて、空に向かって笑った。"
        "「……卒業、しないでください」":
            $ lean("求道型")
            $ up("メンタル", 1)
            ren "……卒業、しないでください"
            "言ってから、自分でも驚いた。先輩は、ボールを止めたまま、しばらくこっちを見ていた。"
            miyoshi "……するよ。する。だから、お前らが、あの部室に残るんだろ"
            miyoshi "毎朝6時は、もう、お前の番だ"
        "何も言わずに、強いパスを返す":
            $ lean("野心型")
            $ up("技術", 1)
            "言葉のかわりに、いちばん強いパスを蹴った。雪をけずって、まっすぐ先輩の足もとへ。"
            "先輩は、止めた。止めて、しばらく足もとのボールを見ていた。"
            miyoshi "……いいパスだ。三年で、いちばんいいパスだった"
    hide miyoshi
    with dissolve
    ## 旅館の庭の雪うさぎ（v0.30.0。番外編のひなたと千夏の一枚絵）
    "旅館に戻ると、玄関の横の庭のすみで、ひなたと千夏先輩がしゃがみこんでいた。"
    scene cg feb_snowbunny
    with dissolve
    voice "audio/voice/hinata_a4_feb_day2_01.mp3"
    hinata "あ、蓮！　見て見て、雪うさぎ！"
    voice "audio/voice/chika_a4_feb_day2_01.mp3"
    chika "……二羽、作りました。どちらがよくできているか、決めてください"
    voice "audio/voice/hinata_a4_feb_day2_02.mp3"
    hinata "目は南天の実で、耳は笹の葉。わたしのほうが、まるくてかわいいでしょ"
    voice "audio/voice/chika_a4_feb_day2_02.mp3"
    chika "わたしのほうは、耳の角度を、本物のうさぎの写真に合わせてあります"
    "ひなたのうさぎは、まるくて、少しつぶれていた。千夏先輩のうさぎは、耳がぴんと立って、少しだけかたむいていた。"
    menu:
        "どっちの雪うさぎ？"
        "ひなたのうさぎ":
            $ heart_up("ひなた", "信頼", 2)
            voice "audio/voice/hinata_a4_feb_day2_03.mp3"
            hinata "ほらね！　まるいほうが、かわいいんです"
            voice "audio/voice/chika_a4_feb_day2_03.mp3"
            chika "……記録しました。1対0です。次は、雪だるまで勝負です"
        "千夏先輩のうさぎ":
            $ heart_up("千夏", "信頼", 2)
            voice "audio/voice/chika_a4_feb_day2_04.mp3"
            chika "……当然の結果です"
            "千夏先輩は、無表情のまま、自分のうさぎだけ写真に撮った。三枚撮った。"
            voice "audio/voice/hinata_a4_feb_day2_04.mp3"
            hinata "……先輩、うれしいの、顔に出てますよ"
        "「どっちも、ちゃんと雪うさぎだ」":
            $ heart_up("ひなた", "信頼", 1)
            $ heart_up("千夏", "信頼", 1)
            voice "audio/voice/hinata_a4_feb_day2_05.mp3"
            hinata "それ、いちばんずるい答えだよ"
            voice "audio/voice/chika_a4_feb_day2_05.mp3"
            chika "……引き分けです。二羽とも、玄関に飾ってもらいます"
    "二羽の雪うさぎは、玄関の靴箱の上に並べて置かれた。帰るころには少しだけ溶けて、寄りそっていた。"
    scene bg ryokan_lobby_morning
    with dissolve
    "玄関に入ると、坂口が「今日、何の日か知ってる？」と言い、森が「煮干しの日」と答えた。誰も、それ以上は何も言わなかった。"
    ## 2/14（バレンタイン）：ときめきが高いほうが、こっそり渡しに来る（v0.31.1・Claude の下書き。chapter4a_heart.rpy）
    call a4h_valentine
    ## 足湯
    scene bg onsen_town_snow
    $ coat_on()
    with dissolve
    $ bgm("あたたかいアコースティックギター")
    "帰りの電車の前に、町のまん中の足湯に、全員でぎゅうぎゅうに並んだ。右ひざの奥まで、じんわりとあたたかかった。"
    "千夏先輩が、足湯に並んだ全員の足を、一枚だけ撮った。「顔は、昨日たくさん撮ったので」"
    ## 帰りの電車
    scene bg train_local_snow_eve
    with Dissolve(1.0)
    $ se("電車の走る音")
    "帰りの電車は、行きよりずっと静かだった。野口と江藤は、肩をくっつけて寝ていた。大門は、寝ながらも背すじがのびていた。"
    if a4_feb_gift == "ball":
        "寄せ書きのボールを渡したのは、潮見に着く一つ前の駅だった。いちばん大きい字は、坂口の「ウケる」だった。"
        show miyoshi trip
        with dissolve
        miyoshi "……工務店の、事務所に飾る"
        miyoshi "で、昼休みに蹴る。……汚れたら、また書きに来い"
    else:
        "潮見に着く一つ前の駅で、坂口が立ち上がった。「えー、一人ずつ、ひとこと」"
        "順番に、一人ずつ言った。森は、ひとことと言われて、三分しゃべった。鷹野は「……どうも」だけだった。最後が、俺だった。"
        ren "先輩が毎日グラウンドにいたから、俺は、戻ってこられました"
        show miyoshi trip
        with dissolve
        miyoshi "……お前らなあ"
        "先輩は窓のほうを向いて、それきり、潮見に着くまでこっちを見なかった。"
    $ bond_up("三好", 3)
    hide miyoshi
    with dissolve
    "向かいの席で、黒田が、目を閉じたまま言った。"
    kuroda "……俺の先輩たちは、送別会の日に、俺を雪に埋めて帰っていった"
    kuroda "……いい部だな"
    "それが寝言だったのかどうかは、分からなかった。"
    $ amb_stop()
    mono "三好先輩の卒業式まで、あと15日。"
    return

################################################################################
## 3月1日：三好先輩の卒業式
################################################################################
label a4_graduation:
    scene black
    with dissolve
    $ set_cal("3月1日（月）", "卒業式")
    scene bg kohoku_gate_march
    with dissolve
    $ bgm("のんびりした春の曲")
    "卒業式のあと、校門の前は、花束と写真でいっぱいだった。"
    "その中で、いちばん声のでかい卒業生は、すぐに見つかった。"
    show miyoshi uniform
    with dissolve
    miyoshi "おーい！　{rb}蓮{/rb}{rt}れん{/rt}！　こっちだ、こっち！"
    "{rb}三好{/rb}{rt}みよし{/rt}先輩の胸には、造花のバラが二つついていた。誰かが、まちがえて二つつけたらしい。"
    miyoshi "見ろ、この花！　俺だけ二つだ！　卒業も二回分だ！"
    "{rb}桐生{/rb}{rt}きりゅう{/rt}先輩と{rb}宮下{/rb}{rt}みやした{/rt}先輩が、後ろで同じ顔をしていた。"
    miyashita "ふふっ……一つ、ぼくがつけたの"
    kiryu "……もう一つは、たぶん先生"
    "三好先輩は、それから急にまじめな顔になって、俺の前に立った。"
    miyoshi "……蓮"
    if a4_captain == "ren":
        miyoshi "腕章、ゆるいだろ。俺の腕、太いからな"
        miyoshi "……ゆるいうちは、まだ俺のだ。きつくなったら、お前のだ"
    else:
        miyoshi "腕章は、鷹野に渡した。……でもな、声出すのは、キャプテンだけの仕事じゃないぞ"
    if flags.get("ch3_miyoshi_left"):
        miyoshi "冬の大会、左で走らせてもらったな。……あれ、楽しかった。中学の3年間、ずっとベンチだったからな"
    miyoshi "次は、お前らの番だ"
    menu:
        "「全国、行きます。先輩の分まで」":
            $ a4_miyoshi = "zenkoku"
            $ lean("野心型")
            $ up("メンタル", 2)
            ren "全国、行きます。先輩の分まで"
            miyoshi "俺の分はいらん！　お前らの分で行け！"
            miyoshi "……行ったら、工務店のトラックで応援に行くからな"
        "「先輩の左、俺たちで走ります」" if flags.get("ch3_miyoshi_left"):
            $ a4_miyoshi = "left"
            $ lean("仲間型")
            ren "先輩の左、俺たちで走ります"
            miyoshi "……おう。誰が走っても、止まるなよ"
            "先輩は、そこで少しだけ、上を向いた。"
        "「……ありがとうございました」と頭を下げる":
            $ a4_miyoshi = "thanks"
            $ lean("求道型")
            "言葉が出てこなかった。だから、頭を下げた。"
            "去年の4月、校門でビラを配っていた人に。たった一人で、毎日グラウンドに来ていた人に。"
            miyoshi "……やめろ、そういうの。泣くだろ"
            miyoshi "――港北ーっ！"
            "先輩は、校門の前で、いきなり叫んだ。卒業生も、先生も、全員がふり返った。"
    $ bond_up("三好", 5)
    "帰りぎわ、先輩は、手に持っていた筒を、俺の胸に押しつけた。"
    miyoshi "これ、4月のビラの下書きだ。去年のやつ。……字、汚いけど、使え"
    "筒の中には、卒業証書と、くしゃくしゃの紙が一枚入っていた。"
    "「サッカー部　部員募集！　経験なくてもOK！　声がでかいやつ大歓迎！」"
    hide miyoshi
    with dissolve
    return


################################################################################
## 4月7日：入学式と勧誘（第1章の裏返し。今度は蓮が誘う側）
################################################################################
label a4_entrance:
    scene black
    with dissolve
    $ set_cal("4月7日（水）", "入学式")
    scene bg kohoku_gate_morning
    with dissolve
    $ bgm("明るい春の曲")
    "1年前、俺はこの校門を、誘われる側でくぐった。今年は、誘う側に立っている。"
    "手には、三好先輩の下書きを写したビラ。最後の一行だけ、書きかえた。「声がでかいやつ大歓迎！（小さくてもいい）」"
    show hinata smile
    with dissolve
    hinata "{rb}蓮{/rb}{rt}れん{/rt}、顔がこわい。もっと笑って"
    ren "……笑ってる"
    hinata "笑ってない。眉毛が、試合の前の顔"
    hide hinata
    with dissolve
    show sakaguchi normal
    with dissolve
    sakaguchi "てか、ビラ配りってこれでいいの？　ゲーセンのクーポンみたいに配っていい？"
    ren "……なんでもいい。1年の手に、届けば"
    sakaguchi "りょ。ウケる、俺らが勧誘する側とか"
    hide sakaguchi
    with dissolve
    "{rb}坂口{/rb}{rt}さかぐち{/rt}たち5人は、校門の両側に分かれて、新入生を呼び止めはじめた。森は、ビラを渡すたびに、律儀に頭を下げていた。"
    scene bg clubroom
    with dissolve
    $ bgm("作戦会議っぽい軽快な曲")
    show kuroda normal
    with dissolve
    kuroda "……数を言う。今、10人"
    kuroda "インターハイ予選の登録の締め切りは、5月20日だ。11人いなければ、出られん"
    kuroda "1人入れば、試合はできる。……交代はできんがな"
    kuroda "1回戦は、6月26日だ"
    "去年の冬、交代のいない11人で、桜嶺と戦った。あの準決勝の後半を、俺のひざは覚えている。"
    kuroda "勧誘の期間は、1週間。入部届の締め切りは、15日だ"
    kuroda "……誘いたいやつがいるなら、早く行け。遅れたやつは、ほかの部に取られる"
    hide kuroda
    with dissolve
    window auto hide
    tuto "第4章の最初の自由行動は「新入生の勧誘」です。4日間で、どこへ誘いに行くかを選びます。"
    tuto "行き先は5か所あります。全部は回れません。先に誘った相手ほど、早くチームになじみます。"
    return


################################################################################
## 4月15日：入部届の締め切り。小早川が来る
################################################################################
label a4_kobayakawa:
    scene black
    with dissolve
    $ set_cal("4月15日（木）", "入部届の締め切り")
    scene bg clubroom
    with dissolve
    $ bgm("明るい部活の曲")
    python:
        ## 勧誘で回らなかった相手も、締め切りの日に自分で来る（人数は少なくなる）
        if "gate" not in a4_recruit:
            a4_members += 1
        if "gym" not in a4_recruit:
            a4_members += 1
        if "ground" not in a4_recruit:
            a4_members += 1
        a4_members += 1     # 小早川
    if "gym" not in a4_recruit:
        show kurata uniform
        with dissolve
        "締め切りの日の昼休み、体の大きな1年が、部室の前を三回通りすぎてから、入部届を置いていった。{rb}倉田{/rb}{rt}くらた{/rt}、と書いてあった。"
        hide kurata
        with dissolve
        $ meet("倉田")
    if "ground" not in a4_recruit:
        show akasaka uniform
        with dissolve
        "放課後、{rb}赤坂{/rb}{rt}あかさか{/rt}という1年が、入部届を鷹野の顔の前に突きつけた。「ここのフォワード、あんたっすよね。……すぐ、抜きますんで」"
        hide akasaka
        with dissolve
        $ meet("赤坂")
    if "gate" not in a4_recruit:
        "ビラを持ってきた1年が、一人だけいた。坂口が、ゲーセンのクーポンと間違えて渡したやつだった。"
    "放課後。部室の戸を、誰かがノックした。ノックして入ってくる部員は、港北のサッカー部には、今まで一人もいなかった。"
    show kobayakawa uniform
    with dissolve
    if "hall" in a4_recruit:
        kobayakawa "失礼します。……あ、早瀬先輩。この前は、ありがとうございました"
        "昇降口で会った1年だった。あのときもう、入部届は書き終わっていた。"
    else:
        kobayakawa "失礼します。1年の、{rb}小早川陸{/rb}{rt}こばやかわりく{/rt}です。入部届を、持ってきました"
    "背は、俺より少し低い。髪は短くて、目だけが、やけにまっすぐだった。"
    kobayakawa "中学では、ボランチをやってました。……あの、去年の冬の、準決勝"
    kobayakawa "桜嶺との試合、スタンドで見てました"
    if flags.get("背番号10") == "ren":
        kobayakawa "10番の人を、見に来ました"
    else:
        kobayakawa "8番の人を、見に来ました。10番の人も、すごかったですけど"
    kobayakawa "交代のいない11人で、最後まで走ってて。……それで、港北を選びました"
    hide kobayakawa
    with dissolve
    show sakaguchi normal
    with dissolve
    sakaguchi "……え、待って。俺ら、見に来られる側？　ウケる"
    sakaguchi "てか、ウケねえ。……ちょっと、うれしい"
    hide sakaguchi
    with dissolve
    show kuroda normal
    with dissolve
    kuroda "……数を言う。[a4_members]人"
    if a4_members >= 18:
        kuroda "紅白戦が、9対9でできるな"
        "去年の5月、11人目が来るのを、校門の前で待っていた。今は、部室に入りきらない。"
    elif a4_members >= 17:
        kuroda "紅白戦は、一人足りんな。……俺は入らんぞ"
    else:
        kuroda "交代の選手がいる。それだけで、十分だ"
    hide kuroda
    with dissolve
    "その日、部室の壁の名簿に、新しい名前が書き足された。いちばん下は、小早川の字だった。ちいさくて、きれいだった。"
    $ meet("小早川")
    return


################################################################################
## 4月20日：統合が決まる（生徒会室）
##   第3章の「港北は、なくなるかもしれません」の答え。小早川たちが、港北に入る最後の新入生
################################################################################
label a4_merger_day:
    scene black
    with dissolve
    $ set_cal("4月20日（火）", "放課後")
    scene bg student_council
    with dissolve
    $ bgm("（なし）")
    "生徒会室の扉は、半分だけ開いていた。"
    "{rb}千夏{/rb}{rt}ちか{/rt}先輩は、窓の前に立って、グラウンドを見下ろしていた。"
    show chika normal
    with dissolve
    chika "……来ると思っていました"
    if a4_heard_meeting:
        chika "約束どおり、最初に、あなたに言います"
    chika "昨日の、県の会議で決まりました"
    chika "港北は、となりの学区の高校と、一つになります。名前も、校舎も、残るのは向こうです"
    chika "今年の1年生が、港北に入る、最後の1年生です。あの子たちが卒業する年に、港北は閉じます"
    "グラウンドから、1年たちの声が聞こえた。小早川が、誰かに何かを教えていた。"
    chika "あなたたちは、11人で戦える、最後の代です"
    if flags.get("千夏_署名"):
        chika "署名は、千二百人分、集まりました。……足りませんでした"
        chika "サッカー部が集めてくれた分も、ちゃんと、数えてもらいました"
    if flags.get("ch3_統廃合_秘密"):
        chika "去年の秋、三好先輩たちには言わないでほしいと、あなたは言いました"
        chika "……三好先輩は、卒業するまで、知りませんでした。それで、よかったと思います"
    "先輩は、泣いていなかった。"
    "声も、手も、ふるえていなかった。それが、いちばんつらそうに見えた。"
    menu:
        "「残せるものを、残しましょう。先輩の言ったとおりに」":
            $ a4_merger = "leave"
            $ heart_up("千夏", "信頼", 6)
            $ lean("仲間型")
            ren "残せるものを、残しましょう。……去年、先輩が言ったとおりに"
            show chika soft
            chika "……覚えていたんですか"
            chika "はい。残せるものは、あります"
            if flags.get("千夏_展示"):
                chika "写真の展示を、文化祭で始めます。「港北の記録」。……あなたが言い出したことですから、手伝ってください"
                $ set_flag("港北の記録_聞いた")
            else:
                chika "写真を、全部、残します。サッカー部の、最後の一年の"
        "「……悔しいです」":
            $ a4_merger = "honest"
            $ heart_up("千夏", "信頼", 8)
            $ lean("求道型")
            ren "……悔しいです"
            "それしか、出てこなかった。"
            "先輩は、少しだけ目を見開いて、それから、窓のほうへ顔を向けた。"
            chika "……わたしも、です"
            chika "生徒会長が、それを言ってはいけないと思っていました。……あなたが先に言ったので、言えました"
        "「最後の代で、全国に行きます」":
            $ a4_merger = "zenkoku"
            $ heart_up("千夏", "信頼", 4)
            $ lean("野心型")
            $ up("メンタル", 2)
            ren "最後の代で、全国に行きます"
            chika "……簡単に言いますね"
            chika "でも、去年の今ごろは、11人もいませんでした"
            chika "……撮りに行きます。全国まで"
    if a4_chika_call != "早瀬くん":
        "帰りぎわ、先輩は、扉の前でふり返った。"
        chika "……[a4_chika_call]。ありがとう"
        "二人のときだけ、名前が少しくずれた。"
    hide chika
    with dissolve
    $ set_flag("統合_決定")
    ## 部室：みんなに伝える
    scene bg clubroom
    with dissolve
    $ bgm("静かな春の曲")
    "その日の練習のあと、部室で、みんなに話した。"
    "誰も、何も言わなかった。最初に口を開いたのは、坂口だった。"
    show sakaguchi normal
    with dissolve
    sakaguchi "……最後の世代、ってやつ？　ウケる"
    sakaguchi "…………ウケねえ"
    hide sakaguchi
    with dissolve
    "森が、坂口の背中を、黙って二回たたいた。"
    kobayakawa "僕たちが、港北の、最後の1年生なんですね"
    "小早川は、それだけ言って、壁の名簿を見上げた。"
    kobayakawa "……じゃあ、最後の1年生が、いちばん強かったって、言われるようにします"
    show daimon jersey
    with dissolve
    daimon "ぼ、僕も……最後のキーパーが、いちばん、止めたって……"
    kurata "大門先輩の次のキーパーも、止めます！"
    daimon "えっ、あっ、はい……！　い、一緒に……"
    hide daimon
    with dissolve
    show takano jersey
    with dissolve
    takano "……しゃべってる暇あんなら、走れ"
    takano "最後なら、なおさらだ"
    hide takano
    with dissolve
    "鷹野が先に部室を出ていった。一人ずつ、そのあとに続いた。"
    "最後の世代。その言葉は、思っていたより、重くなかった。"
    "――重いのは、たぶん、これからだ。"
    $ lean("仲間型")
    return


################################################################################
## 4月29日：港で、神城との約束（「春になったら、全部話す」）
##   神城は、鬼塚に口封じされている。「あれは、言い訳だ。……俺が決めた」とうそをつく
##   遊ぶ人にだけ分かるヒント：港の黒い車／話す前に鳴るスマホ／一度も蓮の目を見ない
##   （真相は、ルートAでは明かさない。第6章の決勝と、2部作へ）
################################################################################
label a4_kamishiro_day:
    scene black
    with dissolve
    $ set_cal("4月29日（木）", "祝日・夕方")
    window auto hide
    $ talk_start("神城 凌", "10:02")
    $ talk("神城", "今日、港に行く。5時")
    $ talk("神城", "防波堤の前")
    window auto hide
    $ talk_end()
    scene bg harbor_sunset
    with dissolve
    $ se("波の音、カモメ")
    $ bgm("張りつめた静かな曲")
    "防波堤の前の駐車場に、黒い大きな車が一台、止まっていた。"
    "窓が暗くて、中は見えなかった。漁協の車にしては、きれいすぎた。"
    "{rb}神城{/rb}{rt}かみしろ{/rt}は、防波堤の根もとに、一人で立っていた。"
    show kamishiro normal
    with dissolve
    kamishiro "……来たか"
    ren "春になったら、全部話す。……そう言ったよな"
    kamishiro "ああ"
    "神城が、口を開きかけた。"
    "そのとき、神城のポケットの中で、スマホが鳴った。"
    "神城は、画面を見た。出なかった。鳴りやむまで、ずっと、画面を見ていた。"
    "波の音だけが、しばらく続いた。"
    kamishiro "……決勝のこと、だろ"
    kamishiro "去年の冬、「俺が決めたことじゃない」って言った"
    kamishiro "あれは、言い訳だ"
    "神城は、海のほうを向いていた。"
    kamishiro "……命令なんて、なかった"
    kamishiro "あのタックルは、俺が決めた"
    "頭の中で、何かが、音を立てて止まった。"
    ren "……なんで"
    kamishiro "お前が、邪魔だった。中学のときから、ずっと"
    kamishiro "推薦の枠は、一つだった。……それだけだ"
    "神城は、最後まで、一度も俺の目を見なかった。"
    "去年の冬、通路で「俺が決めたことじゃない」と言ったときは、まっすぐ俺を見ていたのに。"
    "――その違いに、俺は気づかなかった。気づける場所に、いなかった。"
    menu:
        "胸ぐらをつかむ":
            $ a4_kamishiro = "grab"
            $ lean("野心型")
            $ bond_up("神城", -15)
            $ up("無理ゲージ", 2)
            "気がついたら、神城の胸ぐらをつかんでいた。"
            hide kamishiro
            scene cg kamishiro_grab at cam_push(10.0, 1.06)
            with Dissolve(0.4)
            with hpunch
            ren "ふざけるな……！　一年……一年かけて、ここまで戻ってきたんだぞ……！"
            "神城は、抵抗しなかった。つかまれたまま、俺から目をそらしていた。"
            kamishiro "……殴れよ。そのほうが、早い"
            "殴れなかった。手を離すと、神城の襟が、くしゃくしゃのまま残った。"
            scene bg harbor_sunset
            show kamishiro normal
            with dissolve
        "黙って、背を向ける":
            $ a4_kamishiro = "turn"
            $ lean("求道型")
            $ bond_up("神城", -12)
            $ up("メンタル", 2)
            "何も言わずに、背を向けた。"
            "言葉にしたら、自分が何を言うか分からなかった。"
            "背中のほうで、神城が、小さく息を吐いた音がした。"
            kamishiro "……それでいい"
            "その声が、どうして少しだけ、ほっとしたように聞こえたのか。俺には分からなかった。"
        "「……決勝で、返す」":
            $ a4_kamishiro = "final"
            $ lean("仲間型")
            $ bond_up("神城", -10)
            $ up("メンタル", 1)
            ren "……決勝で、返す"
            ren "俺一人じゃない。港北の全員で、お前を倒す"
            "神城は、初めて、少しだけ顔を上げた。でも、こっちは見なかった。"
            kamishiro "……来いよ。決勝まで"
    hide kamishiro
    with dissolve
    "神城は、駐車場のほうへ歩いていった。"
    "黒い車のドアが開いて、閉まった。エンジンの音が、港の道を遠ざかっていった。"
    "防波堤の先で、カモメが鳴いていた。去年の夏と、同じ声だった。"
    $ set_flag("神城_うそ", a4_kamishiro)
    $ amb_stop()
    ## その夜のトーク：神城に送っても、既読がつかない
    scene bg ren_room_night
    with dissolve
    $ bgm("静かな夜の曲")
    window auto hide
    $ talk_start("神城 凌", "23:14")
    $ talk_day("12月31日（木）", "23:52")
    $ talk_old("神城", "春になったら、全部話す")
    $ talk_old("神城", "どっちを選んでも、話す。今度は、取り消さない")
    $ talk_day("4月29日（木）", "10:02")
    $ talk_old("神城", "今日、港に行く。5時")
    $ talk_old("神城", "防波堤の前")
    $ talk_wait(792)
    $ talk_me("話したな。全部", read="")
    $ talk_me("それで終わりか", read="")
    $ talk_system("30分たっても、既読はつかなかった")
    window auto hide
    $ talk_end()
    "スマホを伏せて、天井を見た。"
    "右ひざが、少しだけ、うずいた。"
    return
