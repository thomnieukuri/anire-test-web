## chapter4a.rpy ―― 第4章「最後の世代」ルートA（港北に残る）・高2の1〜4月
##   構成案：ルートA 第4章 構成案（Claude Docs）。正史と神城の真相は「製品版プラン_決定事項」
##   初詣で「残る」を伝える → 鬼塚への返事 → 1〜3月（短く）→ 三好の卒業式 → 入学式と勧誘（自由行動①）
##   → 小早川が来る（部員18人）→ 統合が決まる（最後の世代）→ 港で神城「俺が決めた」（うそ）
##   5〜8月は chapter4a_2.rpy、自由行動の行き先と練習の出来事は chapter4a_free.rpy
##
##   ※ 製品版（有料）の部分。体験版（Web のテストページ）からは入れない。
##     開発中は、体験版の最後で「港北に残る」を選ぶと、開発用の選択肢から第4章に進める（script.rpy の trial_end。config.developer のときだけ）
##   ※ 恋愛の場面（ときめきの特別イベントなど）は、作者が書く。ここでは「# 作者メモ：」の印だけ置いている
##   ※ 新しい人物（小早川・倉田・赤坂・佐伯）の立ち絵はまだない。セリフ枠の名前だけで出している

## 第4章の人物（小早川・倉田・赤坂・佐伯など）は characters.rpy で定義している（読みこむ順番のため）

default a4_chika_call = "早瀬くん"   # 千夏が二人のときに呼ぶ名前（大晦日に千夏と話した人は「蓮くん」）
default a4_captain = "ren"         # キャプテン（三好先輩の腕章を受け取った人。ren / takano）
default a4_onizuka = ""            # 鬼塚への返事のしかた（polite / short）
default a4_miyoshi = ""            # 卒業式で三好先輩に言ったこと（zenkoku / left / thanks）
default a4_recruit = []            # 4月の勧誘で回った順（gate / gym / ground / hall / council）
default a4_members = 10            # 部員の数
default a4_merger = ""             # 統合が決まった日、千夏に言ったこと（leave / honest / zenkoku）
default a4_kamishiro = ""          # 神城のうそへの反応（grab：つかみかかる / turn：背を向ける / final：「決勝で返す」）

## 統合の会議の日（4月19日）より前に、生徒会室で千夏から日付を聞いたか
default a4_heard_meeting = False

## 第4章の入口
label chapter4a:
    $ quick_menu = True
    $ play_marks["chapter4a"] = renpy.get_game_runtime()   # 古いセーブで続きが見つからないとき、ここから続ける（script.rpy の save_lost）
    $ a4_captain = ch3_armband or "ren"
    if ch3_nye == "chika":
        $ a4_chika_call = "{rb}蓮{/rb}{rt}れん{/rt}くん"
    call show_title("第4章", "最後の世代")
    call a4_hatsumode
    call a4_onizuka_call
    call a4_winter
    call a4_graduation
    call a4_entrance
    call a4_recruit_loop
    call a4_kobayakawa
    call a4_merger_day
    call a4_kamishiro_day
    jump chapter4a_2


################################################################################
## 1月1日：「残る」を伝える（大晦日に話した人で5通り）
################################################################################
label a4_hatsumode:
    scene black
    with Dissolve(1.5)
    $ set_cal("1月1日（金）", "0時すぎ")
    call expression "a4_newyear_" + (ch3_nye or "mother")
    return

label a4_newyear_chika:
    scene bg shrine_steps_night
    $ coat_on()
    with dissolve
    $ bgm("静かな夜の曲")
    "除夜の鐘が終わって、町の神社まで歩いた。"
    "石段の下に、白いテントが一つ。生徒会の腕章をつけた人たちが、紙コップに{rb}甘酒{/rb}{rt}あまざけ{/rt}を注いでいた。"
    show chika normal
    with dissolve
    chika "……どうぞ。米こうじの甘酒です。お酒は入っていません。熱いので、気をつけてください"
    "千夏先輩は、俺だと分かっても、手を止めなかった。紙コップを一つ、差し出しただけだった。"
    ren "先輩。……残ります。港北に"
    "紙コップを持つ先輩の指が、ほんの少しだけ、止まった。"
    chika "……そうですか"
    show chika soft
    chika "では、約束どおり、写真を撮ります。……来年の夏まで、全部"
    "テントの奥から、ほかの役員が先輩を呼んだ。"
    show chika normal
    chika "……早瀬くん。生徒会の仕事中です。甘酒は、一人一杯までです"
    "人前では、名前が「早瀬くん」に戻っていた。"
    "甘酒は、少し甘すぎた。"
    hide chika
    with dissolve
    $ heart_up("千夏", "信頼", 5)
    return

label a4_newyear_hinata:
    scene bg harbor_newyear_night
    $ coat_on()
    with dissolve
    $ se("波の音、カモメ")
    $ bgm("あたたかいアコースティックギター")
    "防波堤を戻ると、街灯の下に、ひなたが立っていた。"
    show hinata normal
    with dissolve
    hinata "……ここだと思った。おばさんが、蓮、出てったきり帰ってこないって"
    ren "ひなた。俺――"
    hinata "待って。眉毛、見せて"
    "ひなたは、つま先立ちになって、俺の顔をのぞきこんだ。"
    ren "……残る。港北に"
    show hinata smile
    hinata "うん。うそじゃない"
    hinata "じゃあ、来年も、テーピング巻ける"
    "ひなたは、それだけ言って、くるりと背中を向けた。"
    hinata "初詣、行こ。おみくじ、蓮のぶんも引いてあげる"
    hide hinata
    with dissolve
    $ heart_up("ひなた", "信頼", 5)
    $ amb_stop()
    return

label a4_newyear_saki:
    scene bg harbor_newyear_night
    $ coat_on()
    with dissolve
    $ se("波の音、カモメ")
    $ bgm("静かなピアノの旋律")
    "防波堤の根もとまで戻ったとき、街灯の届かないところに、人影があった。"
    show saki normal
    with dissolve
    saki "……決めた顔してる"
    ren "なんで、ここに"
    saki "約束でしょ。決めたら教えてって"
    "[saki_call]は、マフラーに口もとをうずめたまま、こっちを見なかった。"
    ren "残る。港北に"
    saki "……そう"
    saki "あの人、怒るね。断られるの、慣れてないから"
    saki "……いい気味"
    "少しだけ、笑ったように見えた。暗くて、よく分からなかった。"
    saki "寒い。帰る"
    hide saki
    with dissolve
    $ heart_up("紗希", "信頼", 5)
    $ amb_stop()
    return

label a4_newyear_takano:
    scene bg ren_room_night
    with dissolve
    $ bgm("静かな夜の曲")
    "家に帰って、スマホを開いた。"
    window auto hide
    $ talk_start("鷹野 迅", "0:21")
    $ talk_me("残る")
    $ talk_wait(1)
    $ talk("鷹野", "知ってた")
    $ talk("鷹野", "三好先輩には、お前から言え。俺が言うと、あの人、電話してくる")
    $ talk_me("もう寝てるだろ")
    $ talk("鷹野", "寝てねえよ。あの人が大晦日に寝るわけねえ")
    $ talk_wait(1)
    $ talk("鷹野", "……全国まで、出しつづけろよ")
    window auto hide
    $ talk_end()
    "三好先輩にトークを送ると、一秒で電話が鳴った。"
    "耳から十センチ離しても、先輩の声は、全部聞こえた。"
    $ bond_up("鷹野", 3)
    $ bond_up("三好", 2)
    return

label a4_newyear_mother:
    scene bg shokudo_night
    with dissolve
    $ bgm("あたたかいアコースティックギター")
    "店に戻ると、母さんが、まだカウンターでお茶を飲んでいた。"
    show mother normal
    with dissolve
    haha "おかえり。……寒かったでしょ"
    ren "母さん。……残る。港北に"
    haha "そう"
    show mother smile
    haha "じゃあ、明日からまた、お米多めに炊かなきゃね"
    "母さんは、それ以上、何も聞かなかった。"
    "湯のみを一つ出して、お茶を注いでくれた。"
    hide mother
    with dissolve
    return


################################################################################
## 1月：鬼塚に断りの電話をかける
##   鬼塚は「試させてもらう」とだけ言う（第6章の決勝の伏線。蓮には意味が分からない）
################################################################################
label a4_onizuka_call:
    scene black
    with dissolve
    $ set_cal("1月4日（月）", "夕方")
    scene bg ren_room_night
    with dissolve
    $ bgm("張りつめた静かな曲")
    "机の上に、母さんが店で受け取った名刺が置いてあった。"
    "「桜嶺学園高等学校　サッカー部監督　{rb}鬼塚源三{/rb}{rt}おにづかげんぞう{/rt}」"
    "断るなら、自分の口で言うべきだと思った。"
    "呼び出し音が、二回鳴って、止まった。"
    onizuka "……{rb}早瀬{/rb}{rt}はやせ{/rt}か"
    "名乗る前に、名前を言われた。"
    menu:
        "「お誘いは、お断りします。港北に残ります」":
            $ a4_onizuka = "polite"
            $ lean("求道型")
            ren "お誘いは、お断りします。港北に残ります"
        "「行きません。港北で、桜嶺に勝ちます」":
            $ a4_onizuka = "short"
            $ lean("野心型")
            $ up("メンタル", 2)
            ren "行きません。港北で、桜嶺に勝ちます"
    "しばらく、何も聞こえなかった。"
    onizuka "……そうか"
    onizuka "十人の部と、一度切れたひざで、何ができる"
    onizuka "本物は、壊れない。壊れるなら、それまでだ"
    onizuka "……もう一度、試させてもらう"
    "電話は、それで切れた。こっちの返事を、待つ気もなかった。"
    "試す。何を、どうやって。"
    "スマホを置いても、最後の一言だけが、耳の奥に残っていた。"
    $ up("注目度", 3)
    return


################################################################################
## 1〜2月：10人の冬（短く）
################################################################################
label a4_winter:
    scene black
    with dissolve
    $ set_cal("1月18日（月）", "放課後")
    scene bg kohoku_ground_eve
    $ coat_on()
    with dissolve
    $ bgm("静かな春の曲")
    "三学期の練習は、10人だった。"
    "ミニゲームをすると、どっちかが一人足りない。いつも、{rb}黒田{/rb}{rt}くろだ{/rt}がそこに入った。"
    show kuroda normal
    with dissolve
    kuroda "……{rb}早瀬{/rb}{rt}はやせ{/rt}。俺に回すな。走らされる"
    ren "先生がいちばん、パスがうまいので"
    kuroda "……おだてても、走らん"
    "そう言いながら、黒田は、ワンタッチで鷹野の足もとに返した。"
    hide kuroda
    with dissolve
    if a4_captain == "ren":
        "腕には、三好先輩の腕章を巻いていた。まだ少し、ゆるかった。"
    else:
        show takano jersey
        with dissolve
        "腕章は、{rb}鷹野{/rb}{rt}たかの{/rt}の左腕にあった。"
        takano "……おい、声出せ。キャプテンだけに言わせんな"
        "そう言う鷹野の声が、いちばん小さかった。"
        hide takano
        with dissolve
    "4月に1年が入らなければ、11人にならない。インターハイ予選にも、出られない。"
    "誰も口にはしなかった。でも、練習が終わると、全員が一度、校門のほうを見た。"
    return


################################################################################
## 3月1日：三好先輩の卒業式
################################################################################
label a4_graduation:
    scene black
    with dissolve
    $ set_cal("3月1日（月）", "卒業式")
    scene bg kohoku_gate_march
    with dissolve
    $ bgm("のんびりした春の曲")
    "卒業式のあと、校門の前は、花束と写真でいっぱいだった。"
    "その中で、いちばん声のでかい卒業生は、すぐに見つかった。"
    show miyoshi uniform
    with dissolve
    miyoshi "おーい！　{rb}蓮{/rb}{rt}れん{/rt}！　こっちだ、こっち！"
    "{rb}三好{/rb}{rt}みよし{/rt}先輩の胸には、造花のバラが二つついていた。誰かが、まちがえて二つつけたらしい。"
    miyoshi "見ろ、この花！　俺だけ二つだ！　卒業も二回分だ！"
    "{rb}桐生{/rb}{rt}きりゅう{/rt}先輩と{rb}宮下{/rb}{rt}みやした{/rt}先輩が、後ろで同じ顔をしていた。"
    miyashita "ふふっ……一つ、ぼくがつけたの"
    kiryu "……もう一つは、たぶん先生"
    "三好先輩は、それから急にまじめな顔になって、俺の前に立った。"
    miyoshi "……蓮"
    if a4_captain == "ren":
        miyoshi "腕章、ゆるいだろ。俺の腕、太いからな"
        miyoshi "……ゆるいうちは、まだ俺のだ。きつくなったら、お前のだ"
    else:
        miyoshi "腕章は、鷹野に渡した。……でもな、声出すのは、キャプテンだけの仕事じゃないぞ"
    if flags.get("ch3_miyoshi_left"):
        miyoshi "冬の大会、左で走らせてもらったな。……あれ、楽しかった。中学の3年間、ずっとベンチだったからな"
    miyoshi "次は、お前らの番だ"
    menu:
        "「全国、行きます。先輩の分まで」":
            $ a4_miyoshi = "zenkoku"
            $ lean("野心型")
            $ up("メンタル", 2)
            ren "全国、行きます。先輩の分まで"
            miyoshi "俺の分はいらん！　お前らの分で行け！"
            miyoshi "……行ったら、工務店のトラックで応援に行くからな"
        "「先輩の左、俺たちで走ります」" if flags.get("ch3_miyoshi_left"):
            $ a4_miyoshi = "left"
            $ lean("仲間型")
            ren "先輩の左、俺たちで走ります"
            miyoshi "……おう。誰が走っても、止まるなよ"
            "先輩は、そこで少しだけ、上を向いた。"
        "「……ありがとうございました」と頭を下げる":
            $ a4_miyoshi = "thanks"
            $ lean("求道型")
            "言葉が出てこなかった。だから、頭を下げた。"
            "去年の4月、校門でビラを配っていた人に。たった一人で、毎日グラウンドに来ていた人に。"
            miyoshi "……やめろ、そういうの。泣くだろ"
            miyoshi "――港北ーっ！"
            "先輩は、校門の前で、いきなり叫んだ。卒業生も、先生も、全員がふり返った。"
    $ bond_up("三好", 5)
    "帰りぎわ、先輩は、手に持っていた筒を、俺の胸に押しつけた。"
    miyoshi "これ、4月のビラの下書きだ。去年のやつ。……字、汚いけど、使え"
    "筒の中には、卒業証書と、くしゃくしゃの紙が一枚入っていた。"
    "「サッカー部　部員募集！　経験なくてもOK！　声がでかいやつ大歓迎！」"
    hide miyoshi
    with dissolve
    return


################################################################################
## 4月7日：入学式と勧誘（第1章の裏返し。今度は蓮が誘う側）
################################################################################
label a4_entrance:
    scene black
    with dissolve
    $ set_cal("4月7日（水）", "入学式")
    scene bg kohoku_gate_morning
    with dissolve
    $ bgm("明るい春の曲")
    "1年前、俺はこの校門を、誘われる側でくぐった。"
    "今年は、誘う側に立っている。"
    "手には、三好先輩の下書きを写したビラ。最後の一行だけ、書きかえた。"
    "「声がでかいやつ大歓迎！（小さくてもいい）」"
    show hinata smile
    with dissolve
    hinata "{rb}蓮{/rb}{rt}れん{/rt}、顔がこわい。もっと笑って"
    ren "……笑ってる"
    hinata "笑ってない。眉毛が、試合の前の顔"
    hide hinata
    with dissolve
    show sakaguchi normal
    with dissolve
    sakaguchi "てか、ビラ配りってこれでいいの？　ゲーセンのクーポンみたいに配っていい？"
    ren "……なんでもいい。1年の手に、届けば"
    sakaguchi "りょ。ウケる、俺らが勧誘する側とか"
    hide sakaguchi
    with dissolve
    "{rb}坂口{/rb}{rt}さかぐち{/rt}たち5人は、校門の両側に分かれて、新入生を一人ずつ呼び止めはじめた。"
    "森は、ビラを渡すたびに、律儀に頭を下げていた。"
    scene bg clubroom
    with dissolve
    $ bgm("作戦会議っぽい軽快な曲")
    show kuroda normal
    with dissolve
    kuroda "……数を言う。今、10人"
    kuroda "インターハイ予選の登録の締め切りは、5月の終わりだ。11人いなければ、出られん"
    kuroda "1人入れば、試合はできる。……交代はできんがな"
    "去年の冬、交代のいない11人で、桜嶺と戦った。"
    "あの準決勝の後半を、俺のひざは覚えている。"
    kuroda "勧誘の期間は、1週間。入部届の締め切りは、15日だ"
    kuroda "……誘いたいやつがいるなら、早く行け。遅れたやつは、ほかの部に取られる"
    hide kuroda
    with dissolve
    window auto hide
    tuto "第4章の最初の自由行動は「新入生の勧誘」です。4日間で、どこへ誘いに行くかを選びます。"
    tuto "行き先は5か所あります。全部は回れません。先に誘った相手ほど、早くチームになじみます。"
    return


################################################################################
## 4月15日：入部届の締め切り。小早川が来る
################################################################################
label a4_kobayakawa:
    scene black
    with dissolve
    $ set_cal("4月15日（木）", "入部届の締め切り")
    scene bg clubroom
    with dissolve
    $ bgm("明るい部活の曲")
    python:
        ## 勧誘で回らなかった相手も、締め切りの日に自分で来る（人数は少なくなる）
        if "gate" not in a4_recruit:
            a4_members += 1
        if "gym" not in a4_recruit:
            a4_members += 1
        if "ground" not in a4_recruit:
            a4_members += 1
        a4_members += 1     # 小早川
    if "gym" not in a4_recruit:
        "締め切りの日の昼休み、体の大きな1年が、部室の前を三回通りすぎてから、入部届を置いていった。{rb}倉田{/rb}{rt}くらた{/rt}、と書いてあった。"
    if "ground" not in a4_recruit:
        "放課後、{rb}赤坂{/rb}{rt}あかさか{/rt}という1年が、入部届を鷹野の顔の前に突きつけた。「……勝ち逃げは、させないんで」"
    if "gate" not in a4_recruit:
        "ビラを持ってきた1年が、一人だけいた。坂口が、ゲーセンのクーポンと間違えて渡したやつだった。"
    "放課後。部室の戸を、誰かがノックした。"
    "ノックして入ってくる部員は、港北のサッカー部には、今まで一人もいなかった。"
    if "hall" in a4_recruit:
        kobayakawa "失礼します。……あ、早瀬先輩。この前は、ありがとうございました"
        "昇降口で会った1年だった。あのときもう、入部届は書き終わっていた。"
    else:
        kobayakawa "失礼します。1年の、{rb}小早川陸{/rb}{rt}こばやかわりく{/rt}です。入部届を、持ってきました"
    "背は、俺より少し低い。髪は短くて、目だけが、やけにまっすぐだった。"
    kobayakawa "中学では、ボランチをやってました。……あの、去年の冬の、準決勝"
    kobayakawa "桜嶺との試合、スタンドで見てました"
    if flags.get("背番号10") == "ren":
        kobayakawa "10番の人を、見に来ました"
    else:
        kobayakawa "8番の人を、見に来ました。10番の人も、すごかったですけど"
    kobayakawa "交代のいない11人で、最後まで走ってて。……それで、港北を選びました"
    "部室が、一瞬、静かになった。"
    show sakaguchi normal
    with dissolve
    sakaguchi "……え、待って。俺ら、見に来られる側？　ウケる"
    sakaguchi "てか、ウケねえ。……ちょっと、うれしい"
    hide sakaguchi
    with dissolve
    show kuroda normal
    with dissolve
    kuroda "……数を言う。[a4_members]人"
    if a4_members >= 18:
        kuroda "紅白戦が、9対9でできるな"
        "去年の5月、11人目が来るのを、校門の前で待っていた。"
        "今は、部室に入りきらない。"
    elif a4_members >= 17:
        kuroda "紅白戦は、一人足りんな。……俺は入らんぞ"
    else:
        kuroda "交代の選手がいる。それだけで、十分だ"
    hide kuroda
    with dissolve
    "その日、部室の壁の名簿に、新しい名前が書き足された。"
    "いちばん下の名前を書いたのは、小早川だった。字が、ちいさくて、きれいだった。"
    $ meet("小早川")
    return


################################################################################
## 4月20日：統合が決まる（生徒会室）
##   第3章の「港北は、なくなるかもしれません」の答え。小早川たちが、港北に入る最後の新入生
################################################################################
label a4_merger_day:
    scene black
    with dissolve
    $ set_cal("4月20日（火）", "放課後")
    scene bg student_council
    with dissolve
    $ bgm("（なし）")
    "生徒会室の扉は、半分だけ開いていた。"
    "{rb}千夏{/rb}{rt}ちか{/rt}先輩は、窓の前に立って、グラウンドを見下ろしていた。"
    show chika normal
    with dissolve
    chika "……来ると思っていました"
    if a4_heard_meeting:
        chika "約束どおり、最初に、あなたに言います"
    chika "昨日の、県の会議で決まりました"
    chika "港北は、となりの学区の高校と、一つになります。名前も、校舎も、残るのは向こうです"
    chika "今年の1年生が、港北に入る、最後の1年生です。あの子たちが卒業する年に、港北は閉じます"
    "グラウンドから、1年たちの声が聞こえた。小早川が、誰かに何かを教えていた。"
    chika "あなたたちは、11人で戦える、最後の代です"
    if flags.get("千夏_署名"):
        chika "署名は、千二百人分、集まりました。……足りませんでした"
        chika "サッカー部が集めてくれた分も、ちゃんと、数えてもらいました"
    if flags.get("ch3_統廃合_秘密"):
        chika "去年の秋、三好先輩たちには言わないでほしいと、あなたは言いました"
        chika "……三好先輩は、卒業するまで、知りませんでした。それで、よかったと思います"
    "先輩は、泣いていなかった。"
    "声も、手も、ふるえていなかった。それが、いちばんつらそうに見えた。"
    menu:
        "「残せるものを、残しましょう。先輩の言ったとおりに」":
            $ a4_merger = "leave"
            $ heart_up("千夏", "信頼", 6)
            $ lean("仲間型")
            ren "残せるものを、残しましょう。……去年、先輩が言ったとおりに"
            show chika soft
            chika "……覚えていたんですか"
            chika "はい。残せるものは、あります"
            if flags.get("千夏_展示"):
                chika "写真の展示を、文化祭で始めます。「港北の記録」。……あなたが言い出したことですから、手伝ってください"
            else:
                chika "写真を、全部、残します。サッカー部の、最後の一年の"
        "「……悔しいです」":
            $ a4_merger = "honest"
            $ heart_up("千夏", "信頼", 8)
            $ lean("求道型")
            ren "……悔しいです"
            "それしか、出てこなかった。"
            "先輩は、少しだけ目を見開いて、それから、窓のほうへ顔を向けた。"
            chika "……私も、です"
            chika "生徒会長が、それを言ってはいけないと思っていました。……あなたが先に言ったので、言えました"
        "「最後の代で、全国に行きます」":
            $ a4_merger = "zenkoku"
            $ heart_up("千夏", "信頼", 4)
            $ lean("野心型")
            $ up("メンタル", 2)
            ren "最後の代で、全国に行きます"
            chika "……簡単に言いますね"
            chika "でも、去年の今ごろは、11人もいませんでした"
            chika "……撮りに行きます。全国まで"
    if a4_chika_call != "早瀬くん":
        "帰りぎわ、先輩は、扉の前でふり返った。"
        chika "……[a4_chika_call]。ありがとう"
        "二人のときだけ、名前が少しくずれた。"
    hide chika
    with dissolve
    $ set_flag("統合_決定")
    ## 部室：みんなに伝える
    scene bg clubroom
    with dissolve
    $ bgm("静かな春の曲")
    "その日の練習のあと、部室で、みんなに話した。"
    "誰も、何も言わなかった。最初に口を開いたのは、坂口だった。"
    show sakaguchi normal
    with dissolve
    sakaguchi "……最後の世代、ってやつ？　ウケる"
    sakaguchi "…………ウケねえ"
    hide sakaguchi
    with dissolve
    "森が、坂口の背中を、黙って二回たたいた。"
    kobayakawa "僕たちが、港北の、最後の1年生なんですね"
    "小早川は、それだけ言って、壁の名簿を見上げた。"
    kobayakawa "……じゃあ、最後の1年生が、いちばん強かったって、言われるようにします"
    show daimon jersey
    with dissolve
    daimon "ぼ、僕も……最後のキーパーが、いちばん、止めたって……"
    kurata "大門先輩の次のキーパーも、止めます！"
    daimon "えっ、あっ、はい……！　い、一緒に……"
    hide daimon
    with dissolve
    show takano jersey
    with dissolve
    takano "……しゃべってる暇あんなら、走れ"
    takano "最後なら、なおさらだ"
    hide takano
    with dissolve
    "鷹野が先に部室を出ていった。一人ずつ、そのあとに続いた。"
    "最後の世代。その言葉は、思っていたより、重くなかった。"
    "――重いのは、たぶん、これからだ。"
    $ lean("仲間型")
    return


################################################################################
## 4月29日：港で、神城との約束（「春になったら、全部話す」）
##   神城は、鬼塚に口封じされている。「あれは、言い訳だ。……俺が決めた」とうそをつく
##   遊ぶ人にだけ分かるヒント：港の黒い車／話す前に鳴るスマホ／一度も蓮の目を見ない
##   （真相は、ルートAでは明かさない。第6章の決勝と、2部作へ）
################################################################################
label a4_kamishiro_day:
    scene black
    with dissolve
    $ set_cal("4月29日（木）", "祝日・夕方")
    window auto hide
    $ talk_start("神城 凌", "10:02")
    $ talk("神城", "今日、港に行く。5時")
    $ talk("神城", "防波堤の前")
    window auto hide
    $ talk_end()
    scene bg harbor_sunset
    with dissolve
    $ se("波の音、カモメ")
    $ bgm("張りつめた静かな曲")
    "防波堤の前の駐車場に、黒い大きな車が一台、止まっていた。"
    "窓が暗くて、中は見えなかった。漁協の車にしては、きれいすぎた。"
    "{rb}神城{/rb}{rt}かみしろ{/rt}は、防波堤の根もとに、一人で立っていた。"
    show kamishiro normal
    with dissolve
    kamishiro "……来たか"
    ren "春になったら、全部話す。……そう言ったよな"
    kamishiro "ああ"
    "神城が、口を開きかけた。"
    "そのとき、神城のポケットの中で、スマホが鳴った。"
    "神城は、画面を見た。出なかった。鳴りやむまで、ずっと、画面を見ていた。"
    "波の音だけが、しばらく続いた。"
    kamishiro "……決勝のこと、だろ"
    kamishiro "去年の冬、「俺が決めたことじゃない」って言った"
    kamishiro "あれは、言い訳だ"
    "神城は、海のほうを向いていた。"
    kamishiro "……命令なんて、なかった"
    kamishiro "あのタックルは、俺が決めた"
    "頭の中で、何かが、音を立てて止まった。"
    ren "……なんで"
    kamishiro "お前が、邪魔だった。中学のときから、ずっと"
    kamishiro "推薦の枠は、一つだった。……それだけだ"
    "神城は、最後まで、一度も俺の目を見なかった。"
    "去年の冬、通路で「俺が決めたことじゃない」と言ったときは、まっすぐ俺を見ていたのに。"
    "――その違いに、俺は気づかなかった。気づける場所に、いなかった。"
    menu:
        "胸ぐらをつかむ":
            $ a4_kamishiro = "grab"
            $ lean("野心型")
            $ bond_up("神城", -15)
            $ up("無理ゲージ", 2)
            "気がついたら、神城の胸ぐらをつかんでいた。"
            ren "ふざけるな……！　一年……一年かけて、ここまで戻ってきたんだぞ……！"
            "神城は、抵抗しなかった。つかまれたまま、海を見ていた。"
            kamishiro "……殴れよ。そのほうが、早い"
            "殴れなかった。手を離すと、神城の襟が、くしゃくしゃのまま残った。"
        "黙って、背を向ける":
            $ a4_kamishiro = "turn"
            $ lean("求道型")
            $ bond_up("神城", -12)
            $ up("メンタル", 2)
            "何も言わずに、背を向けた。"
            "言葉にしたら、自分が何を言うか分からなかった。"
            "背中のほうで、神城が、小さく息を吐いた音がした。"
            kamishiro "……それでいい"
            "その声が、どうして少しだけ、ほっとしたように聞こえたのか。俺には分からなかった。"
        "「……決勝で、返す」":
            $ a4_kamishiro = "final"
            $ lean("仲間型")
            $ bond_up("神城", -10)
            $ up("メンタル", 1)
            ren "……決勝で、返す"
            ren "俺一人じゃない。港北の全員で、お前を倒す"
            "神城は、初めて、少しだけ顔を上げた。でも、こっちは見なかった。"
            kamishiro "……来いよ。決勝まで"
    hide kamishiro
    with dissolve
    "神城は、駐車場のほうへ歩いていった。"
    "黒い車のドアが開いて、閉まった。エンジンの音が、港の道を遠ざかっていった。"
    "防波堤の先で、カモメが鳴いていた。去年の夏と、同じ声だった。"
    $ set_flag("神城_うそ", a4_kamishiro)
    $ amb_stop()
    ## その夜のトーク：神城に送っても、既読がつかない
    scene bg ren_room_night
    with dissolve
    $ bgm("静かな夜の曲")
    window auto hide
    $ talk_start("神城 凌", "23:14")
    $ talk_day("12月31日（木）", "23:52")
    $ talk_old("神城", "春になったら、全部話す")
    $ talk_old("神城", "どっちを選んでも、話す。今度は、取り消さない")
    $ talk_day("4月29日（木）", "10:02")
    $ talk_old("神城", "今日、港に行く。5時")
    $ talk_old("神城", "防波堤の前")
    $ talk_wait(792)
    $ talk_me("話したな。全部", read="")
    $ talk_me("それで終わりか", read="")
    $ talk_system("30分たっても、既読はつかなかった")
    window auto hide
    $ talk_end()
    "スマホを伏せて、天井を見た。"
    "右ひざが、少しだけ、うずいた。"
    return
