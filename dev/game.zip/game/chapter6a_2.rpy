## chapter6a_2.rpy ―― 第6章（ルートA）の②：高3の7〜11月の準決勝まで（v0.33.0・Claude の第1稿）
##   7/22 千夏の答え（第5章で「来年の夏まで待って」と言った人だけ）→ 7/29 最後の合宿
##   → 8/5 最後の夏祭り（揺れる場面①）→ 8/31 佐伯さんと黒田 → 9/22 相棒（信頼の特別イベント）
##   → 自由行動②（10月・4日）→ 選手権予選 1回戦〜準々決勝（短く）→ 11/4 準決勝（鳴海）
##   決勝（11/12・桜嶺）は chapter6a_3.rpy

define A6_TRUST_SPECIAL = 85      # 相棒の場面が起きる信頼（いちばん高い一人だけ）
define A6_FES_SOLO = 45           # 揺れる場面にならないとき、夏祭りに誘いに来るときめき

default a6_chika_reply = ""       # 7/22 千夏に答えたこと：yes / no / end（千夏から記録をやめた）/ ""（その場面がない）
default a6_fes = ""               # 夏祭りでいっしょに歩いた人：ひなた / 千夏 / あげは / team
default a6_fes_sway = False       # 夏祭りが揺れる場面になったか
default a6_partner = ""           # 9/22 相棒の場面の人
default a6_semi = ""              # 選手権予選準決勝のスコア


label chapter6a_2:
    call a6_chika_answer
    call a6_camp
    call a6_festival
    call a6_saeki_kuroda
    call a6_partner_day
    call a6_free_loop("a6oct")
    call a6_early_rounds
    call a6_semi_day
    jump chapter6a_3


################################################################################
## 7月22日（土）：千夏の答え（第5章で「来年の夏まで待って」と言った人だけ）
################################################################################
label a6_chika_answer:
    if a5_grad_answer != "wait" or a6_lover:
        return
    scene black
    with dissolve
    $ set_cal("7月22日（土）", "夜")
    scene bg kohoku_gate_summer
    with dissolve
    $ bgm("静かなピアノ")
    "夏休みに入った夜、校門の前で、千夏先輩が待っていた。卒業式の日と、同じ場所だった。"
    show chika normal
    with dissolve
    if heart["千夏"]["ときめき"] < 42:
        voice "audio/voice/chika_a6_ans_01.mp3"
        chika "……来年の夏まで待つ、と言いました。来ました、夏"
        show chika soft
        voice "audio/voice/chika_a6_ans_02.mp3"
        chika "でも、答えは、もういいです。……聞かなくても、分かってしまったので"
        voice "audio/voice/chika_a6_ans_03.mp3"
        chika "大学で、相良さんに、写真部の記録係をやらないかと言われました。……やろうと思います"
        if a6_chika_call == "早瀬くん":
            voice "audio/voice/chika_a6_ans_04_hy.mp3"
        else:
            voice "audio/voice/chika_a6_ans_04.mp3"
        chika "[a6_chika_call]の記録は、ここまでにします。……ありがとうございました"
        "千夏先輩は、頭を下げて、駅のほうへ歩いていった。カメラは、一度も、こっちを向かなかった。"
        $ heart_close("千夏")
        $ a6_chika_reply = "end"
        hide chika
        with dissolve
        return
    voice "audio/voice/chika_a6_ans_05.mp3"
    chika "……来年の夏まで待つ、と言いました。来ました、夏"
    voice "audio/voice/chika_a6_ans_06.mp3"
    chika "四百十二枚目から、一枚も増えていません。……撮らないで待つのは、けっこう、大変でした"
    show chika soft
    voice "audio/voice/chika_a6_ans_07.mp3"
    chika "答えを、聞かせてください。どちらでも、記録します"
    menu:
        "「付き合ってください」":
            $ a6_chika_reply = "yes"
            $ a6_lover = "千夏"
            $ a6_chika_call = "蓮くん"
            ren "……付き合ってください。待たせて、すみませんでした"
            "千夏先輩は、カメラを持ち上げかけて、やめた。かわりに、両手で、顔をおおった。"
            voice "audio/voice/chika_a6_ans_08.mp3"
            chika "……撮れません。今、手が、ふるえていて"
            voice "audio/voice/chika_a6_ans_09.mp3"
            chika "四百十三枚目は、蓮くんが撮ってください。わたしを。……今日の、わたしを"
            "渡されたカメラで、千夏先輩を撮った。ファインダーの中の先輩は、敬語を忘れた顔で笑っていた。"
            $ heart_up("千夏", "ときめき", 8)
            $ heart_up("千夏", "信頼", 4)
        "「……ごめんなさい」":
            $ a6_chika_reply = "no"
            ren "……ごめんなさい"
            "千夏先輩は、少しだけ目を閉じて、それから、いつもの記録係の顔に戻った。"
            voice "audio/voice/chika_a6_ans_10.mp3"
            chika "はい。……記録しました"
            voice "audio/voice/chika_a6_ans_11.mp3"
            chika "待っている一年、楽しかったです。うそじゃありません"
            voice "audio/voice/chika_a6_ans_12.mp3"
            chika "これからは、相棒として、記録を続けさせてください。……最後のページまで"
            $ heart_close("千夏")
    hide chika
    with dissolve
    return


################################################################################
## 7月29日（土）：最後の合宿（短く）
################################################################################
label a6_camp:
    scene black
    with dissolve
    $ set_cal("7月29日（土）", "夜")
    scene bg ryokan_room_night
    with dissolve
    $ bgm("あたたかいアコースティックギター")
    "最後の合宿は、学校の合宿所で、二泊だけだった。夜、布団を並べると、17人分の布団で、床が見えなかった。"
    "電気を消したあと、2年の赤坂が、天井に向かって聞いた。"
    akasaka "……先輩たちいなくなったら、来年、布団、7枚っすね"
    "だれも、すぐには答えなかった。小早川が、ぼそっと言った。"
    kobayakawa "7枚なら、真ん中で、全員、顔が見えます"
    menu:
        "「真ん中に、俺たちの分も空けておけ」":
            $ lean("仲間型")
            ren "真ん中、一枚分、空けておけ。……OBが泊まりに来る"
            sakaguchi "毎年来るぞ、俺ら。三好先輩みたいに、作業着で"
            $ bond_up("坂口", 2)
        "「来年の話は、冬が終わってからだ」":
            $ lean("求道型")
            ren "来年の話は、冬が終わってからだ。……寝ろ"
            "小さい笑い声がいくつかして、それから、寝息に変わった。"
    "見回りに来たのは、黒田だった。千夏先輩の「見回りです」は、去年で終わっていた。"
    kuroda "……二年、見回りをしなくて済んだ。今年は、俺が回る"
    $ bond_up("鷹野", 1)
    $ bond_up("大門", 1)
    return


################################################################################
## 8月5日（土）：最後の夏祭り（揺れる場面①）
##   付き合っている人がいれば、その人と。いなければ、ときめきの上の2人が近いときは揺れる場面、
##   そうでなければ、ときめきがいちばん高い人（A6_FES_SOLO 以上）が誘いに来る。だれも来なければ、部のみんなと
################################################################################
label a6_festival:
    scene black
    with dissolve
    $ set_cal("8月5日（土）", "夕方")
    scene bg festival_night
    with dissolve
    $ bgm("夏祭りの曲")
    "潮見港の花火大会。三回目の夏祭りだった。一回目は、11人がそろうかどうかの夏だった。"
    if a6_lover:
        $ a6_fes = a6_lover
        jump a6_fes_solo
    $ _sw = sway_pair(["ひなた", "千夏", "あげは"])
    if _sw:
        $ a6_fes_sway = True
        jump a6_fes_sway_scene
    python:
        _c = [n for n in ("ひなた", "千夏", "あげは") if n not in heart_closed]
        _c.sort(key=lambda n: -heart[n]["ときめき"])
        a6_fes = _c[0] if _c and heart[_c[0]]["ときめき"] >= A6_FES_SOLO else "team"
    if a6_fes == "team":
        jump a6_fes_team
    jump a6_fes_solo

## 揺れる場面：同じ夕方に、2人から誘いが来る
label a6_fes_sway_scene:
    $ _sa, _sb = _sw
    $ se("トークアプリの通知音（連続）")
    "夕方5時、スマホが、ほとんど同時に二回鳴った。"
    window auto hide
    $ talk_start(_sa, "17:02")
    if _sa == "ひなた":
        $ talk("ひなた", "鳥居の前、6時。……浴衣、着てくから。見て、何か言って")
    elif _sa == "千夏":
        if a4_festival == "chika":
            $ talk("千夏", "帰省しています。……石段の上、6時。去年の続きの写真を、撮らせてください")
        else:
            $ talk("千夏", "帰省しています。……石段の上、6時。最後の夏の写真を、撮らせてください")
    else:
        $ talk("あげは", "パイセン！　6時、屋台の通りの入口！　最前列の場所、もう取ってある")
    $ talk_end()
    $ talk_start(_sb, "17:03")
    if _sb == "ひなた":
        $ talk("ひなた", "鳥居の前、6時。……来てくれたら、うれしい。来なくても、いい。うそ、来て")
    elif _sb == "千夏":
        $ talk("千夏", "6時に、石段の上にいます。……来なくても、記録はつけません。来たら、つけます")
    else:
        $ talk("あげは", "6時に入口ね。来なかったら、推し、変えるから。……うそ。待ってる")
    window auto hide
    $ talk_end()
    "二つの約束が、同じ6時だった。待ち合わせの場所は、花火の会場の、反対の端どうしだった。"
    $ _sa_call = {"千夏": "千夏先輩"}.get(_sa, _sa)
    $ _sb_call = {"千夏": "千夏先輩"}.get(_sb, _sb)
    menu:
        "[_sa_call]のところへ行く":
            $ a6_fes = _sa
            $ sway_pick(_sa, _sb)
            call a6_fes_left(_sb)
            jump a6_fes_solo
        "[_sb_call]のところへ行く":
            $ a6_fes = _sb
            $ sway_pick(_sb, _sa)
            call a6_fes_left(_sa)
            jump a6_fes_solo
        "どちらにも行かず、部のみんなと見る":
            $ a6_fes = "team"
            $ sway_none(_sa, _sb)
            "どちらにも、返事ができなかった。坂口から来た「河原で集合」に、「行く」とだけ返した。"
            jump a6_fes_team

## 選ばなかった人の、短い一言（その夜のトーク）
label a6_fes_left(who):
    window auto hide
    $ talk_start(who, "18:20")
    if who == "ひなた":
        $ talk("ひなた", "……そっか。うん、分かった")
        $ talk("ひなた", "花火、ちゃんと見てね。わたしの分も")
    elif who == "千夏":
        $ talk("千夏", "記録しました。……今日の欄は、空白です")
    else:
        $ talk("あげは", "既読スルーじゃないだけ、えらい。……ちゃんと楽しんで。あたしも、楽しむから")
    window auto hide
    $ talk_end()
    return

## 一人と歩く
label a6_fes_solo:
    if a6_fes == "ひなた":
        scene cg a6_fes_hinata
        with Dissolve(1.0)
        if a4_festival == "hinata":
            "鳥居の前に、白地にひまわりの浴衣のひなたが立っていた。去年と同じ浴衣だった。"
            show hinata yukata
            with dissolve
            voice "audio/voice/hinata_a6_fes_01.mp3"
            hinata "……去年と同じでしょ。新しいの、買おうか迷ったんだけど"
            voice "audio/voice/hinata_a6_fes_02.mp3"
            hinata "去年の蓮が「似合う」って言ったの、上書きしたくなくて"
            $ _opt = "「去年より、似合う」"
        else:
            "鳥居の前に、白地にひまわりの浴衣のひなたが立っていた。"
            show hinata yukata
            with dissolve
            voice "audio/voice/hinata_a6_fes_03.mp3"
            hinata "……浴衣、着てきた。去年は、みんなと歩いたから、着なかったの"
            voice "audio/voice/hinata_a6_fes_04.mp3"
            hinata "最後の夏だから。……何か、言って"
            $ _opt = "「似合う」"
        menu:
            "[_opt]":
                if a4_festival == "hinata":
                    ren "去年より、似合う"
                    show hinata teary
                    voice "audio/voice/hinata_a6_fes_05.mp3"
                    hinata "……っ。上書き、しないでって言ったのに。……したね、今"
                else:
                    ren "……似合う"
                    show hinata teary
                    voice "audio/voice/hinata_a6_fes_06.mp3"
                    hinata "……っ。言わせたの、わたしだけど。……今の、ノートに書いとく"
                $ heart_up("ひなた", "ときめき", 6)
            "「来年も、それ着ろ」":
                ren "来年も、それ着ろ"
                voice "audio/voice/hinata_a6_fes_07.mp3"
                hinata "来年、蓮、どこにいるか分かんないじゃん。……でも、着る。帰ってきたら、見て"
                $ heart_up("ひなた", "信頼", 5)
        "花火のあいだ、ひなたは、一度もスマホを出さなかった。最後の一発のあと、小さく「三回目」と言った。"
        $ up("メンタル", 1)
    elif a6_fes == "千夏":
        scene cg a6_fes_chika
        with Dissolve(1.0)
        "石段の上に、千夏先輩がいた。大学生になっても、首から、カメラを下げていた。"
        show chika yukata
        with dissolve
        if a6_lover == "千夏":
            voice "audio/voice/chika_a6_fes_01.mp3"
            chika "……蓮くん。今年は、恋人として、撮ります"
            if a4_festival == "chika":
                voice "audio/voice/chika_a6_fes_02.mp3"
                chika "去年は「覚えておくだけにします」って言いました。今年は、覚えて、撮って、それから――"
            else:
                voice "audio/voice/chika_a6_fes_03.mp3"
                chika "去年は、みんなの写真を撮るだけでした。今年は、隣で撮って、それから――"
            "千夏先輩は、カメラを下ろして、俺の浴衣の袖を、指でつまんだ。"
            voice "audio/voice/chika_a6_fes_04.mp3"
            chika "……それから、花火が終わるまで、これを、離しません"
            $ heart_up("千夏", "ときめき", 6)
        else:
            if a4_festival == "chika":
                if a6_chika_call == "早瀬くん":
                    voice "audio/voice/chika_a6_fes_05_hy.mp3"
                else:
                    voice "audio/voice/chika_a6_fes_05.mp3"
                chika "[a6_chika_call]。……去年の続きの写真です"
                voice "audio/voice/chika_a6_fes_06.mp3"
                chika "去年は、花火を撮らずに、覚えておくだけにしました。今年は、撮ります。……来年は、ここに来られないかもしれないので"
            else:
                if a6_chika_call == "早瀬くん":
                    voice "audio/voice/chika_a6_fes_07_hy.mp3"
                else:
                    voice "audio/voice/chika_a6_fes_07.mp3"
                chika "[a6_chika_call]。……今年は、二人の写真を撮らせてください"
                voice "audio/voice/chika_a6_fes_08.mp3"
                chika "去年までは、部のみんなの写真ばかりでした。……来年は、ここに来られないかもしれないので"
            menu:
                "「先輩も、写ってください」":
                    ren "先輩も、写ってください。……俺が撮ります"
                    "ファインダーの中で、千夏先輩は、花火より先に、俺のほうを見ていた。"
                    "カメラを返そうとしたとき、先輩の指が、ストラップの上で止まった。"
                    "花火が一発、上がった。先輩は、空を見なかった。"
                    "……一歩、近づいた。"
                    "花火の音が、急に遠くなった。屋台の声も、石段の下のざわめきも、全部、遠くなった。"
                    "先輩が、もう一歩。メガネの奥の目が、ゆっくり、閉じかけた。"
                    "心臓の音が、うるさかった。花火のせいだと、思うことにした。"
                    "次の花火が、なかなか上がらなかった。……一秒が、長かった。"
                    "――そこで、先輩は、ぴたりと止まった。"
                    show chika soft
                    voice "audio/voice/chika_a6_fes_09.mp3"
                    chika "……こういうのは、まだ、早いでしょうか"
                    "答える前に、先輩は、一歩下がって、カメラで顔をかくした。耳が、浴衣の帯より赤かった。"
                    voice "audio/voice/chika_a6_fes_10.mp3"
                    chika "……今のは、記録しません。手帳にも、書きません。……覚えておくだけに、します"
                    $ heart_up("千夏", "ときめき", 6)
                "「記録、ずっと続けてください」":
                    ren "記録、ずっと続けてください。……最後のページまで"
                    if a6_chika_call == "早瀬くん":
                        voice "audio/voice/chika_a6_fes_11_hy.mp3"
                    else:
                        voice "audio/voice/chika_a6_fes_11.mp3"
                    chika "……はい。最後のページは、[a6_chika_call]の冬です"
                    $ heart_up("千夏", "信頼", 5)
        $ up("戦術眼", 1)
    elif a6_fes == "あげは":
        scene cg a6_fes_ageha
        with Dissolve(1.0)
        "屋台の通りの入口で、あげはが、両手にりんご飴を持って待っていた。"
        show ageha yukata
        with dissolve
        if a4_festival == "ageha":
            voice "audio/voice/ageha_a6_fes_01.mp3"
            ageha "はい、一個はパイセン。……去年は腕組んで自撮りしたじゃん。今年は、撮らない"
        else:
            voice "audio/voice/ageha_a6_fes_02.mp3"
            ageha "はい、一個はパイセン。……去年は、みんなで撮ったじゃん。今年は、撮らない"
        voice "audio/voice/ageha_a6_fes_03.mp3"
        ageha "推しを撮らない夏祭り。……パイセンの引退前の、修行"
        menu:
            "「撮れよ。最後の夏だ」":
                ren "撮れよ。最後の夏だ"
                show ageha serious
                voice "audio/voice/ageha_a6_fes_04.mp3"
                ageha "……そういうこと言うと、撮るよ？　一生、回すよ？"
                "あげはは、スマホを出して、二人が写るように腕をのばした。シャッターの直前、花火の音にまぎれて、何かを言った。"
                voice "audio/voice/ageha_a6_fes_05.mp3"
                ageha "……ないしょ。"
                $ heart_up("あげは", "ときめき", 6)
            "「撮らないで、見ろ。花火」":
                ren "撮らないで、見ろ。花火"
                voice "audio/voice/ageha_a6_fes_06.mp3"
                ageha "……うん。見る。パイセンの横で"
                "最後の花火のあいだ、あげはは、本当にスマホを出さなかった。かわりに、袖が、ずっと触れていた。"
                $ heart_up("あげは", "信頼", 5)
        $ up("技術", 1)
    return

## 部のみんなと
label a6_fes_team:
    scene bg festival_night
    with dissolve
    "河原に、港北サッカー部の17人が並んだ。坂口が、一年の夏と同じ場所にブルーシートを敷いていた。"
    sakaguchi "三年連続、同じ場所！　縁起物だからな、ここ"
    "花火の音のあいだに、大門が、だれにも聞こえないくらいの声で、「最後ですね」と言った。……聞こえていた。"
    $ bond_up("坂口", 2)
    $ bond_up("大門", 2)
    $ bond_up("鷹野", 1)
    return


################################################################################
## 8月31日（木）：佐伯さんと黒田（蓮が、遠くから見る）
################################################################################
label a6_saeki_kuroda:
    scene black
    with dissolve
    $ set_cal("8月31日（木）", "夜")
    scene bg kohoku_ground_night
    with dissolve
    $ bgm("静かな夜の曲")
    "夏休みの最後の夜、忘れたスパイクを取りに、グラウンドに戻った。ナイター照明の下に、二人の大人がいた。"
    "黒田と、佐伯さんだった。部室の陰で、足を止めた。"
    show saeki normal at left
    show kuroda normal at right
    with dissolve
    saeki "……今年も、送ったぞ。2月に"
    kuroda "開けてない"
    saeki "知ってる。……12年、一回も開けてないな、お前は"
    saeki "開けろよ。……俺のひざは、もう、怒ってない"
    kuroda "怒ってないから、開けられないんだ"
    "佐伯さんは、少しだけ笑った。笑ったまま、照明の外に出ていった。右足を、少し引きずっていた。"
    "……初めて見た。佐伯さんは、いつも、立ったままフェンスの外にいたから。"
    hide saeki
    with dissolve
    show kuroda normal at center
    with dissolve
    kuroda "……早瀬。いるんだろ"
    menu:
        "部室の陰から出る":
            "出ていった。黒田は、振り向かないまま言った。"
            kuroda "聞いたな。……夏は終わったが、もう少し待て。決勝の前の晩に、全部話す。それまで、だれにも言うな"
            $ set_flag("a6_佐伯と黒田_聞いた")
        "そのまま帰る":
            "スパイクは、明日でいい。音を立てないように、グラウンドを出た。"
            "うしろで、黒田が、ストップウォッチを一回押す音がした。"
    hide kuroda
    with dissolve
    return


################################################################################
## 9月22日（金）：相棒（信頼の特別イベント。いちばん信頼が高い一人だけ）
################################################################################
label a6_partner_day:
    python:
        _c = [n for n in ("ひなた", "千夏", "あげは") if heart[n]["信頼"] >= A6_TRUST_SPECIAL]
        _c.sort(key=lambda n: -heart[n]["信頼"])
        a6_partner = _c[0] if _c else ""
    if not a6_partner:
        return
    scene black
    with dissolve
    $ set_cal("9月22日（金）", "夕方")
    if a6_partner == "ひなた":
        scene bg slope_eve
        with dissolve
        $ bgm("あたたかいアコースティックギター")
        show hinata serious
        with dissolve
        if a5_surgery:
            "坂道の途中で、ひなたが、ノートを全部持ってきていた。「ひざ」に「リハビリ」。片手では持てない高さだった。"
        else:
            "坂道の途中で、ひなたが、ノートを全部持ってきていた。「ひざ」に「冬」。片手では持てない高さだった。"
        voice "audio/voice/hinata_a6_pt_01.mp3"
        hinata "決勝の前に、一個だけ、本音を言わせて。マネージャーじゃなくて、幼なじみとして"
        voice "audio/voice/hinata_a6_pt_02.mp3"
        hinata "……わたし、蓮がサッカーやめたら、ほっとすると思う。ひざの心配、しなくてよくなるから"
        voice "audio/voice/hinata_a6_pt_03.mp3"
        hinata "でも、わたしのせいで蓮がやめたら、わたし、一生、後悔する。……それが、いちばんこわい"
        menu:
            "「やめない。だから、最後まで見てろ」":
                ren "やめない。だから、最後まで、見てろ"
                voice "audio/voice/hinata_a6_pt_04.mp3"
                hinata "……うん。見てる。いちばん新しいノートの最後のページ、決勝の日に書く"
            "「本音、ありがとう。俺も一個言う。……こわい」":
                ren "本音、ありがとう。……俺も一個言う。こわい"
                show hinata teary
                voice "audio/voice/hinata_a6_pt_05.mp3"
                hinata "……知ってた。でも、蓮の口から聞けたの、三年で初めてかも"
                $ up("無理ゲージ", -4)
        $ heart_up("ひなた", "信頼", 5)
    elif a6_partner == "千夏":
        scene bg student_council
        with dissolve
        $ bgm("静かなピアノ")
        show chika normal
        with dissolve
        "大学の休みに、千夏先輩が、元の生徒会室を借りていた。机の上に、『港北の記録』の、厚い束。"
        if a6_chika_call == "早瀬くん":
            voice "audio/voice/chika_a6_pt_01_hy.mp3"
        else:
            voice "audio/voice/chika_a6_pt_01.mp3"
        chika "本の最後のページを、どうするか、決められません。……[a6_chika_call]に、決めてほしくて"
        voice "audio/voice/chika_a6_pt_02.mp3"
        chika "勝っても、負けても、最後のページは、決勝の日の写真にします。その一枚に、一行だけ、何か書きたいんです"
        menu:
            "「『十一人から始まった』」":
                ren "「十一人から始まった」。……それで"
                voice "audio/voice/chika_a6_pt_03.mp3"
                chika "……はい。それ以外、ないですね"
            "「先輩が決めてください。先輩の記録だから」":
                ren "先輩が決めてください。先輩の記録だから"
                voice "audio/voice/chika_a6_pt_04.mp3"
                chika "……ずるいです。でも、うれしいです。じゃあ、決勝の日に、決めます"
        $ heart_up("千夏", "信頼", 5)
    else:
        scene bg kohoku_ground_eve
        with dissolve
        $ bgm("少しとがった曲")
        show ageha serious
        with dissolve
        "練習のあと、あげはが、スマホの画面を伏せて、ベンチに座っていた。"
        voice "audio/voice/ageha_a6_pt_01.mp3"
        ageha "パイセン。あたし、三か月でやめなかったの、これが初めてなんだよ。……一年半、続いてる"
        voice "audio/voice/ageha_a6_pt_02.mp3"
        ageha "推しのためって思ってたけど、たぶん、違う。……港北のマネージャー、好きなんだと思う"
        voice "audio/voice/ageha_a6_pt_03.mp3"
        ageha "だから、決勝、負けても、泣かない。泣かないで、最後まで撮る。それ、約束させて"
        menu:
            "「約束する。お前は撮れ。俺は走る」":
                ren "約束する。お前は撮れ。俺は、走る"
                voice "audio/voice/ageha_a6_pt_04.mp3"
                ageha "……うん。それ、一番エモい分担"
            "「泣いてもいい。泣きながら撮れ」":
                ren "泣いてもいい。泣きながら撮れ"
                voice "audio/voice/ageha_a6_pt_05.mp3"
                ageha "……むり、それ。手ぶれする。……でも、たぶん、そうなる"
        $ heart_up("あげは", "信頼", 5)
    $ set_flag("a6_相棒_" + a6_partner)
    hide hinata
    hide chika
    hide ageha
    with dissolve
    return


################################################################################
## 選手権予選 1回戦〜準々決勝（短く）
################################################################################
label a6_early_rounds:
    scene black
    with dissolve
    $ set_cal("10月9日（月）", "選手権予選1回戦")
    scene bg pref_ground_autumn
    with dissolve
    $ bgm("緊迫した試合の曲")
    "最後の選手権予選。1回戦は、3−0。2回戦は、2−0。どちらも、後半の途中で、黒田は俺を下げた。"
    kuroda "……決勝まで、お前の右ひざは、俺が預かる"
    $ set_cal("10月21日（土）", "選手権予選3回戦")
    "3回戦は、雨だった。1−1のまま、延長の前半に、坂口のクロスを、鷹野が頭で押しこんだ。"
    $ set_cal("10月28日（土）", "選手権予選準々決勝")
    "準々決勝の相手は、一年の夏に1回戦で負けた、西海学院だった。今度は、2−0で勝った。"
    "試合のあと、西海の3年の主将が、俺のところまで来た。"
    "「一年のとき、お前ら、11人ぎりぎりだったよな。……ずっと、見てた」"
    $ up("注目度", 4)
    $ up("フィジカル", 1)
    if not a5_surgery:
        $ up("無理ゲージ", 3)
    return


################################################################################
## 11月4日（土）選手権予選準決勝：港北 対 鳴海
################################################################################
label a6_semi_day:
    scene black
    with dissolve
    $ set_cal("11月4日（土）", "選手権予選準決勝")
    scene bg pref_ground_eve
    with dissolve
    $ bgm("張りつめた静かな曲")
    if a6_ih == "win":
        "準決勝の相手は、鳴海高校。夏の決勝で負けた相手に、今度は向こうが、リベンジに来た。"
    else:
        "準決勝の相手は、鳴海高校。夏の決勝で負けた相手。……今度は、こっちが、リベンジに行く番だった。"
    "もう一方の準決勝では、桜嶺が、清翔に4−0で勝っていた。神城が、2点。"
    $ se("キックオフの笛")
    $ sb_set("前半", 0, 0, 0, 0, "#2a5bd7", "#1f8a5a", "港北", "鳴海")
    scene bg pref_ground_eve at cam_jog
    with dissolve
    show screen letterbox
    show screen scoreboard
    $ bgm("緊迫した試合の曲")
    "鳴海は、ずっと前から来た。前半は、0−0のまま、港北のゴール前で終わった。大門が、四本止めた。"
    $ sb_set("後半", 45)
    $ sb_set(mm=71)
    "後半26分。小早川が、首を三回振ってから、俺を見た。……見てから、蹴らなかった。"
    menu:
        "小早川に、走って受けにいく":
            $ lean("仲間型")
            "走って、小早川の真横で受けた。二人で、壁パスを一回。鳴海の二人が、同時に置いていかれた。"
            if check("技術", 70):
                $ goal("港北", home=1, away=0, mm=72)
                with vpunch
                "ゴールの右すみ。……小早川が、俺より先に、両手を上げていた。"
                $ a6_semi = "1−0"
            else:
                "シュートは、キーパーの正面だった。"
        "小早川に「見ないで出せ」と叫ぶ":
            $ lean("求道型")
            ren "小早川！　見ないで出せ！"
            "小早川は、もう一回首を振って、それから、目を閉じたみたいな顔で、蹴った。"
            if check("戦術眼", 70):
                "ボールは、俺がまだいない場所に転がって、俺が着いたときに、そこにあった。"
                $ goal("港北", home=1, away=0, mm=72)
                with vpunch
                $ a6_semi = "1−0"
            else:
                "ボールは、一歩、先に転がった。鳴海のキーパーが、それを抱えた。"
    if not a6_semi:
        $ sb_set(mm=90)
        "そのまま、0−0で、90分が終わった。延長でも、点は入らなかった。"
        "PK戦。大門が、二本止めた。最後に蹴ったのは、江藤だった。一年の夏、PKの四人目で外した江藤だった。"
        $ se("ネットが揺れる音")
        "江藤は、決めたあと、だれよりも先に、芝に座りこんで泣いた。"
        $ a6_semi = "0−0（PK 4−2）"
        $ bond_up("坂口", 3)
        $ bond_up("大門", 3)
    $ se("試合終了の笛")
    pause 1.0
    hide screen scoreboard
    hide screen letterbox
    scene bg pref_ground_eve
    with Dissolve(1.0)
    python:
        _rows = [("スコア", a6_semi + "（勝ち）"), ("決勝", "11月12日（日）　港北 対 桜嶺学園")]
        _memo = "ひなた：決勝。……一年の春の0−9の相手と、決勝"
    call screen match_report("選手権予選準決勝　港北 対 鳴海", _rows, _memo)
    $ bgm("（なし）")
    mono "決勝。"
    mono "一年の春、0−9で負けた相手と。神城と。"
    $ up("注目度", 6)
    return
