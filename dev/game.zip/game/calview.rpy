################################################################################
## 日付が進むときの見せ方（v0.37.0 で作り直した）
##   ・ふだん（同じ月の中で、6日まで）：週の帯（cal_week）
##       絵を画面いっぱいに出して、下に1週間ぶんの日付の札が流れる。止まったら、まん中に「今日の札」が出る
##   ・月が変わる／1週間以上とぶ：卓上カレンダー（cal_desk_bg ＋ cal_desk_grid）
##       左に絵、右に月の表。過ぎた日に赤ペンの×、新しい日に○
##   ・どちらも、知っている予定があれば「◯◯まで あと◯日」を出す。動きが止まったら、タップで進む
##   ・うしろの絵は「キャラの裏側の絵」（CAL_PICS）。出せる絵がないときは、季節の背景
##   部品の絵は tools/make_cal_ui.py で作る（game/gui/cal/）
################################################################################

default cal_pic_log = []                      # さいきん出した絵（同じ絵が続かないようにする）
default persistent.cal_pics_seen = None       # 見た「裏側の絵」の名前（回想で開く）

init -1 python:
    ## カレンダーに出す「裏側の絵」（ネタバレしない、ふだんの様子）
    ##   id：絵の名前（images/cal/◯◯.jpg）　title：回想に出す題
    ##   time：合う時間帯（morning 朝／day 昼・放課後／evening 夕方／night 夜）
    ##   from・to：出してよい期間（年, 月, 日）。そのキャラに会う前や、話の流れに合わなくなったあとは出さない
    ##   months：服が合う月（書かなければ1年じゅう）
    ##   まだ第1〜3章（2026年の年末まで）だけ。第4章からあとは、話の流れを確かめてから広げる
    CAL_PICS = [
        {"id": "hinata_wake", "title": "ひなたの寝起き", "time": ("morning",),
         "from": (2025, 12, 1), "to": (2026, 12, 31)},
        {"id": "hinata_hair", "title": "髪を結ぶひなた", "time": ("morning",),
         "from": (2026, 4, 8), "to": (2026, 12, 31), "months": (10, 11, 12, 1, 2, 3, 4, 5)},     # 冬服（ブレザー）
        {"id": "chika_desk", "title": "写真を見返す千夏", "time": ("night",),
         "from": (2026, 4, 10), "to": (2026, 12, 31)},                                            # 4/9 に生徒会室で会う
        {"id": "miyoshi_run", "title": "三好の朝のランニング", "time": ("morning",),
         "from": (2026, 5, 21), "to": (2026, 12, 31)},                                            # 5/20「毎朝、河川敷を走っている」と分かったあと
        ## 11/15 に足した8枚（候補は全部「いる」。まず12枚まで描く、と決まった）
        {"id": "hinata_bibs", "title": "ビブスをたたむひなた", "time": ("day", "evening"),
         "from": (2026, 4, 14), "to": (2026, 12, 31), "months": (10, 11, 12, 1, 2, 3, 4, 5)},     # 冬服。部室・窓の外は夕日
        {"id": "hinata_noren", "title": "のれんをしまうひなた", "time": ("evening",),
         "from": (2026, 9, 1), "to": (2026, 12, 31), "months": (10, 11)},                         # 夏休みに食堂を手伝いはじめたあと。紅葉の絵
        {"id": "chika_lens", "title": "レンズをふく千夏", "time": ("day", "evening"),
         "from": (2026, 4, 14), "to": (2026, 12, 31), "months": (10, 11, 12, 1, 2, 3, 4, 5)},     # 冬服。4/13 にカメラの場面
        {"id": "saki_score", "title": "防波堤の紗希", "time": ("evening",),
         "from": (2026, 6, 1), "to": (2026, 12, 31), "months": (6, 7, 8, 9)},                     # 5/31 に港で会う。夏の私服
        {"id": "takano_park", "title": "夜の公園の鷹野", "time": ("night",),
         "from": (2026, 6, 1), "to": (2026, 12, 31)},                                             # 0−9 の試合のあと
        {"id": "kuroda_board", "title": "夜の職員室の黒田", "time": ("night",),
         "from": (2026, 6, 1), "to": (2026, 12, 31)},
        {"id": "ren_desk", "title": "蓮の机", "time": ("night",),
         "from": (2026, 4, 9), "to": (2026, 12, 31)},                                             # 入部したあと
        {"id": "daimon_wall", "title": "柔道場の大門", "time": ("day", "evening"),
         "from": (2026, 6, 1), "to": (2026, 12, 31)},
    ]
    for _p in CAL_PICS:
        renpy.image(("calpic", _p["id"]), "images/cal/%s.jpg" % _p["id"])

    ## ふつうの時間帯の言葉。これ以外（「大学病院」「選手権予選決勝」など）のときは、キャラの絵は出さない
    _CAL_PLAIN_TIMES = set(["", "朝", "早朝", "昼", "昼休み", "放課後", "午後", "土曜の午後", "夕方", "夜", "深夜", "練習のあと"])
    _CAL_EN = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"]

    def _cal_tcls(time):
        """時間帯の言葉を、朝・昼・夕方・夜の4つに分ける"""
        t = time or ""
        if "夜" in t or "0時" in t or "深夜" in t:
            return "night"
        if "夕" in t:
            return "evening"
        if "朝" in t:
            return "morning"
        return "day"

    def _cal_img(name, alt="bg ren_room_night"):
        return name if renpy.has_image(name, exact=True) else alt

    def _cal_blur_img(img):
        """卓上カレンダーのうしろに敷く、ぼかした絵（tools/make_cal_blur.py で先に作ってある）"""
        f = "images/cal/blur/%s.jpg" % (img[7:] if img.startswith("calpic ") else img.replace(" ", "_"))
        return Transform(f, xysize=(1280, 720)) if renpy.loadable(f) else Solid("#2a211b")

    def _cal_season_bg(mo, tc):
        """出せる絵がないときの、季節の背景"""
        move = store.cal_year >= 2027 and getattr(store, "ch3_route", "") == "move"
        if tc == "night":
            return _cal_img("bg ouryo_dorm_night") if move else "bg ren_room_night"
        if tc == "evening":
            if move:
                return _cal_img("bg ouryo_ground_eve")
            return _cal_img("bg harbor_winter_eve") if mo in (12, 1, 2) else _cal_img("bg harbor_sunset")
        if move:
            return _cal_img("bg ouryo_gate_spring")
        if mo == 3:
            return _cal_img("bg kohoku_gate_march")
        if mo == 4:
            return _cal_img("bg kohoku_gate_morning")
        if 5 <= mo <= 9:
            return _cal_img("bg kohoku_gate_summer")
        return _cal_img("bg kohoku_gate_autumn")

    def cal_pick_pic(date, time, loose=False, pic=None):
        """うしろに出す絵をえらぶ。
          loose=True（卓上カレンダー）のときは、時間帯が合わない絵でもよい（カレンダーの写真として出す）
          pic=False：キャラの絵は出さない　pic="hinata_wake"：その絵を出す"""
        m = _CAL_DATE_RE.search(date or "")
        mo, d = (int(m.group(1)), int(m.group(2))) if m else (4, 1)
        tc = _cal_tcls(time)
        chosen = None
        if isinstance(pic, str):
            chosen = pic
        elif pic is not False and (time or "") in _CAL_PLAIN_TIMES:
            now = _cal_ord(store.cal_year, mo, d)
            ok = [p for p in CAL_PICS
                  if _cal_ord(*p["from"]) <= now <= _cal_ord(*p["to"])
                  and (not p.get("months") or mo in p["months"])]
            pool = [p for p in ok if tc in p["time"]]
            if not pool and loose:
                pool = ok
            ## 同じ絵が続かないように、さいきんの2回に出した絵はさける（さけると何もなくなるときは、季節の背景）
            recent = store.cal_pic_log[-2:]
            pool = [p for p in pool if p["id"] not in recent]
            if pool:
                seen = persistent.cal_pics_seen or set()
                fresh = [p for p in pool if p["id"] not in seen]
                chosen = renpy.random.choice(fresh or pool)["id"]
        store.cal_pic_log.append(chosen or "")
        if len(store.cal_pic_log) > 8:
            del store.cal_pic_log[:-8]
        if chosen:
            if persistent.cal_pics_seen is None:
                persistent.cal_pics_seen = set()
            persistent.cal_pics_seen.add(chosen)
            return "calpic " + chosen
        return _cal_season_bg(mo, tc)

    def cal_next_event(limit=60):
        """次の大会・予定まで (あと何日, 名前)。まだ知らない予定は数えない。なければ None"""
        now = cal_now_ord()
        if not now:
            return None
        best = None
        _evs = CAL_EVENTS + (CAL_EVENTS_B if getattr(store, "ch3_route", "") == "move" else [])
        for (y, m, d), name in _evs:
            if not cal_event(y, m, d):
                continue
            n = _cal_ord(y, m, d) - now
            if 1 <= n <= limit and (best is None or n < best[0]):
                best = (n, name)
        return best

    def cal_today_event():
        """今日の予定の名前（大会は長い名前で）。なければ空"""
        m = _CAL_DATE_RE.search(store.cal_date or "")
        if not m:
            return ""
        y, mo, d = store.cal_year, int(m.group(1)), int(m.group(2))
        ev = cal_event(y, mo, d)
        if not ev:
            return ""
        _evs = CAL_EVENTS + (CAL_EVENTS_B if getattr(store, "ch3_route", "") == "move" else [])
        for ymd, name in _evs:
            if ymd == (y, mo, d):
                return name
        return ev[0]

    def _cal_week_info(old, date, time, delta, img):
        """週の帯に並べる札（古い日の5日前〜新しい日の5日後）"""
        y = store.cal_year
        mo1 = _month_of(date)
        wd1 = _wd_of(date)
        if wd1 is None:
            wd1 = 0
        n1 = _doy(date)
        days = []
        for k in range(-delta - 5, 6):
            n = n1 + k
            mo, d = _md_of_doy(n)
            yy = y + (1 if n > 365 else (-1 if n < 1 else 0))
            days.append({"mo": mo, "d": d, "wd": (wd1 + k) % 7, "ev": cal_event(yy, mo, d), "other": mo != mo1})
        dur = 0.7 + 0.15 * delta
        plain = (time or "") in _CAL_PLAIN_TIMES
        tape = cal_today_event() if plain else time
        cd = cal_next_event()
        return {
            "img": img, "days": days, "dur": dur, "t1": 0.45 + dur,
            "x0": 640 - (5 * 134 + 71), "x1": 640 - ((delta + 5) * 134 + 71),
            "year": y, "mo": mo1, "d": days[delta + 5]["d"], "wd": wd1,
            "sub": _CAL_WD[wd1] + "曜日" + (("・" + time) if (plain and time) else ""),
            "tape": tape, "cd": cd,
        }

    def _cal_count_d(st, at, n_final, n_marks, step):
        """卓上カレンダーの「あと◯日」の数字。×がつくたびに1つずつへる"""
        done = min(n_marks, max(0, int(st / step) + 1)) if step > 0 else n_marks
        left = n_marks - done
        return Text(str(n_final + left), font=FONT_JP_B, size=44, color=PEN_RED), (0.03 if left > 0 else None)

    def _cal_wait(anim):
        """動きが終わるまで待って、そのあとはタップを待つ（スキップ中は待たない。オート中は少し見せて進む）"""
        renpy.pause(anim, hard=False)
        if renpy.config.skipping:
            return
        if _preferences.afm_enable:
            renpy.pause(2.5, hard=False)
        else:
            renpy.pause(checkpoint=False)

    def cal_advance_show(old, date, time, delta, pic=None):
        """日付が進むときの画面を出す（set_cal から呼ぶ）"""
        big = delta >= 7 or _month_of(old) != _month_of(date)
        img = cal_pick_pic(date, time, loose=big, pic=pic)
        _window_hide(None, auto=True)
        renpy.scene()
        renpy.show("black")
        renpy.with_statement(Dissolve(0.3))
        store.cal_card = True
        if not big:
            info = _cal_week_info(old, date, time, delta, img)
            renpy.show_screen("cal_week", info)
            renpy.with_statement(Dissolve(0.4))
            renpy.sound.play("audio/se/telop.ogg", channel="ui")
            _cal_wait(info["t1"] + 0.9)
            renpy.hide_screen("cal_week")
        else:
            segs = _cal_segments(old, date, delta)
            cd = cal_next_event()
            today = cal_today_event()
            renpy.show_screen("cal_desk_bg", img)
            for i, seg in enumerate(segs):
                last = (i == len(segs) - 1)
                renpy.show_screen("cal_desk_grid", seg, last, date, time, cd, today)
                renpy.with_statement(Dissolve(0.4 if i == 0 else 0.25))
                renpy.sound.play("audio/se/telop.ogg", channel="ui")
                if last:
                    _cal_wait(seg["dur"] + 0.9)
                else:
                    renpy.pause(seg["dur"] + 0.35, hard=False)
                renpy.hide_screen("cal_desk_grid")
            renpy.hide_screen("cal_desk_bg")
        renpy.with_statement(Dissolve(0.4))
        store.cal_card = False

################################################################################
## 週の帯（ふだんの日の進み方）
################################################################################

screen cal_week(info):
    zorder 55
    add info["img"] at cal_pic_push
    add "gui/cal/botg.png" xysize (1280, 340) ypos 380
    ## 1週間ぶんの札。古い日から新しい日へ、横に流れる
    fixed at cal_strip_in:
        fixed at cal_row_move(info["x0"], info["x1"], info["dur"]):
            ypos 596
            for i, c in enumerate(info["days"]):
                $ _col = (PEN_RED if c["wd"] == 6 else (PEN_TEAL if c["wd"] == 5 else INK))
                fixed:
                    xpos i * 134
                    xysize (142, 116)
                    add "gui/cal/chip.png"
                    text (("%d月 " % c["mo"]) if c["other"] else "") + _CAL_WD[c["wd"]]:
                        xcenter 71
                        ypos 14
                        font FONT_JP_B
                        size 17
                        color (INK_SOFT if c["wd"] < 5 else _col)
                    text str(c["d"]):
                        xcenter 71
                        ypos (30 if c["ev"] else 36)
                        font FONT_JP_B
                        size 40
                        color _col
                    if c["ev"]:
                        text c["ev"][0]:
                            xcenter 71
                            ypos 82
                            font FONT_JP_B
                            size (13 if len(c["ev"][0]) >= 5 else 15)
                            color (PEN_RED if c["ev"][1] else PEN_TEAL)
    ## まん中の目じるし（流れている間だけ）
    add "gui/cal/mark.png" at cal_mark_blink(info["t1"]) xcenter 640 ycenter 654
    ## 今日の札
    fixed at cal_pop(info["t1"]):
        xcenter 640
        ycenter 624
        xysize (244, 200)
        add "gui/cal/today.png"
        text "%d年 %d月" % (info["year"], info["mo"]) xcenter 122 ypos 21 font FONT_JP_B size 21 color "#fff6ee"
        text str(info["d"]):
            xcenter 122
            ypos 52
            font FONT_JP_B
            size 84
            color (PEN_RED if info["wd"] == 6 else (PEN_TEAL if info["wd"] == 5 else INK))
        text info["sub"] xcenter 122 ypos 152 font FONT_JP_B size 19 color INK_SOFT
    ## 今日の予定（赤いテープ）
    if info["tape"]:
        frame at cal_tape_in(info["t1"] + 0.3):
            xcenter 640
            ycenter 508
            background Frame("gui/cal/tape.png", 14, 0)
            padding (26, 7, 26, 9)
            text info["tape"] font FONT_JP_B size 22 color "#fff6ee"
    ## あと◯日
    if info["cd"]:
        fixed at cal_tag_in(0.5, 3):
            xcenter 1136
            ycenter 500
            xysize (254, 128)
            use cal_tag(info["cd"][1] + "まで", info["cd"][0])
    use cal_tap_hint(info["t1"] + 0.9, 124, 566)
    timer info["t1"] action Function(renpy.sound.play, "audio/se/advance.ogg", channel="ui_text")

## 「◯◯まで あと◯日」の紙（押しピンつき）
screen cal_tag(head, n, count=None):
    add "gui/cal/tag.png"
    add "gui/cal/pin.png" xcenter 127 ypos 0
    text head xcenter 127 ypos 28 font FONT_JP_B size 17 color INK_SOFT
    hbox:
        xcenter 127
        ypos 50
        spacing 8
        text "あと" yalign 0.8 font FONT_JP_B size 22 color INK
        if count:
            add count yalign 0.5
        else:
            text str(n) yalign 0.5 font FONT_JP_B size 44 color PEN_RED
        text "日" yalign 0.8 font FONT_JP_B size 22 color INK

## 「▼ タップで進む」（動きが止まってから出る）
screen cal_tap_hint(d, cx, cy):
    fixed at cal_hint(d):
        xcenter cx
        ycenter cy
        xysize (200, 40)
        add "gui/cal/tap.png"
        text ("▼ タップで進む" if renpy.variant("touch") else "▼ クリックで進む"):
            xcenter 100
            ycenter 20
            font FONT_JP_B
            size 17
            color INK

################################################################################
## 卓上カレンダー（月が変わるとき・1週間以上とぶとき）
################################################################################

## 紙と絵（月をまたぐ間も、出したままにする）
screen cal_desk_bg(img):
    zorder 54
    add _cal_blur_img(img)
    fixed at cal_desk_in:
        xpos 53
        ypos 46
        xysize (1174, 608)
        add "gui/cal/desk.png"
        ## 左の絵（まん中を切り出す）
        add Solid("#3c2d2340") xysize (504, 520) xpos 44 ypos 44
        add Transform(img, crop=(291, 0, 698, 720), xysize=(500, 516)) xpos 46 ypos 46
        ## 上のリング
        for i in range(28):
            add "gui/cal/ring.png" xpos 50 + i * 39 ypos 2

## 月の表（月ごとに出し直す）
screen cal_desk_grid(seg, last, date, time, cd, today):
    zorder 55
    fixed:
        xpos 77
        ypos 70
        xysize (1126, 560)
        hbox:
            xpos 566
            ypos 2
            spacing 6
            text str(seg["mo"]) font FONT_JP_B size 64 color PEN_RED
            text "月" yalign 0.72 font FONT_JP_B size 26 color PEN_RED
            text "%d / %s" % (seg["year"], _CAL_EN[seg["mo"] - 1]) yalign 0.7 xoffset 14 font FONT_JP_B size 19 color INK_SOFT
        add Solid(PEN_RED) xysize (536, 3) xpos 564 ypos 84
        for i in range(7):
            text _CAL_WD[i]:
                xcenter 602 + i * 76
                ypos 93
                font FONT_JP_B
                size 18
                color (PEN_RED if i == 6 else (PEN_TEAL if i == 5 else INK_SOFT))
        for d in range(1, seg["nd"] + 1):
            $ _c = seg["fw"] + d - 1
            $ _cx = 602 + (_c % 7) * 76
            $ _cy = 126 + (_c // 7) * 70
            $ _ev = cal_event(seg["year"], seg["mo"], d)
            $ _dc = (PEN_RED if _c % 7 == 6 else (PEN_TEAL if _c % 7 == 5 else INK))
            if _ev:
                ## 予定のある日：予定を大きく、日付は左上に小さく（試合は赤、そのほかは青緑のマーカー）
                add Solid("#cd464633" if _ev[1] else "#2f6f7633") xysize (72, 62) xpos _cx - 36 ypos _cy
                text str(d) xpos _cx - 33 ypos _cy + 1 font FONT_JP_B size 14 color _dc
                text _ev[0]:
                    xcenter _cx
                    ypos _cy + 24
                    font FONT_JP_B
                    size (14 if len(_ev[0]) >= 5 else (17 if len(_ev[0]) == 4 else 20))
                    color (PEN_RED if _ev[1] else PEN_TEAL)
                    outlines [(2, "#fbf6ea", 0, 0)]
            else:
                text str(d) xcenter _cx ypos _cy + 12 font FONT_JP_B size 28 color _dc
            ## 予定のある日の×は、予定の文字が読めるように、うすく小さくする
            if d <= seg["pre"]:
                add "gui/cal_x.png" xcenter _cx ycenter _cy + 32 zoom 0.7 alpha (0.25 if _ev else 0.5)
            elif seg["a"] <= d <= seg["b"]:
                add "gui/cal_x.png" at cal_mark(seg["step"] * (d - seg["a"]), (0.45 if _ev else 1.0), (0.6 if _ev else 0.8)) xcenter _cx ycenter _cy + 32
            if seg["circle"] == d:
                add "gui/cal_o.png" at cal_circle(seg["dur"] - 0.3) xcenter _cx ycenter _cy + 30
    if seg["circle"]:
        timer max(0.05, seg["dur"] - 0.3) action Function(renpy.sound.play, "audio/se/advance.ogg", channel="ui_text")
    if last:
        ## 左下の付箋（今日の日付）
        fixed at cal_note_in(0.2):
            xcenter 190
            ycenter 606
            xysize (340, 166)
            add "gui/note_calendar.png" zoom 1.26
            text "%d年" % cal_year xcenter 166 ypos 26 font FONT_JP_B size 16 color "#8c735f"
            text date xcenter 166 ypos 46 font FONT_JP_B size 34 color INK
            if time:
                text time xcenter 166 ypos 98 size (15 if len(time) >= 14 else (18 if len(time) >= 9 else 21)) color "#6e5a3c"
        ## 右上の「あと◯日」（スマホでは右上のすみに「戻る」「メニュー」のボタンがあるので、少し左に置く）
        if today:
            fixed at cal_pop(max(0.05, seg["dur"] - 0.1), 0.8, 3):
                xcenter 972
                ycenter 66
                xysize (254, 128)
                add "gui/cal/tag.png"
                add "gui/cal/pin.png" xcenter 127 ypos 0
                text today xcenter 127 ypos 28 font FONT_JP_B size (14 if len(today) >= 10 else 17) color INK_SOFT
                text "きょう！" xcenter 127 ypos 52 font FONT_JP_B size 38 color PEN_RED
        elif cd:
            $ _nm = max(0, seg["b"] - seg["a"] + 1)
            fixed at cal_tag_in(0.2, 3):
                xcenter 972
                ycenter 66
                xysize (254, 128)
                use cal_tag(cd[1] + "まで", cd[0], DynamicDisplayable(_cal_count_d, cd[0], _nm, seg["step"]))
        use cal_tap_hint(seg["dur"] + 0.9, 1150, 684)

################################################################################
## 動き
################################################################################

transform cal_pic_push:
    subpixel True
    align (0.5, 0.5)
    zoom 1.0
    linear 14.0 zoom 1.06

transform cal_strip_in:
    alpha 0.0 yoffset 40
    easeout 0.36 alpha 1.0 yoffset 0

transform cal_row_move(x0, x1, dur):
    subpixel True
    xoffset x0
    pause 0.45
    ease dur xoffset x1

transform cal_mark_blink(t1):
    alpha 0.0
    pause 0.1
    linear 0.3 alpha 1.0
    pause max(0.0, t1 - 0.36)
    linear 0.16 alpha 0.0

transform cal_pop(d=0.0, z0=0.7, r=0):
    alpha 0.0 zoom z0 rotate r
    pause d
    easeout_back 0.3 alpha 1.0 zoom 1.0

transform cal_tape_in(d=0.0):
    alpha 0.0 yoffset 18 rotate -6
    pause d
    easeout_back 0.3 alpha 1.0 yoffset 0 rotate -2

transform cal_tag_in(d=0.0, r=3):
    alpha 0.0 yoffset -14 rotate r
    pause d
    easeout 0.3 alpha 1.0 yoffset 0

transform cal_note_in(d=0.0):
    alpha 0.0 rotate -7 zoom 1.08
    pause d
    easeout 0.35 alpha 1.0 rotate -3 zoom 1.0

transform cal_hint(d=0.0):
    alpha 0.0
    pause d
    linear 0.3 alpha 1.0
    block:
        ease 0.9 alpha 0.55
        ease 0.9 alpha 1.0
        repeat

transform cal_desk_in:
    on show:
        alpha 0.0 yoffset 16
        easeout 0.35 alpha 1.0 yoffset 0
