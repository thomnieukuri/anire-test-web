## final_common.rpy ―― 終章「どこで、だれと」（A・B共通）のしくみ（v0.36.0・Claude の第1稿）
##   構成は Claude の文書「終章（A・B共通）構成案」と、11/7 の作者の決定（ルートB_決定事項）
##   ・運命の選択④「進路」：届いたオファーから一つ選ぶ。選んだ先が、サッカーの結末になる
##   ・恋愛の結末：第6章までに決まった恋人と、蓮の卒業式（3/1）のあげはの告白で決まる
##   ・いまはルートBだけ（final_b.rpy・final_b_free.rpy）。ルートAの終章は、あとで a6_end からつなぐ
##   ・エピローグは final_ep.rpy（サッカーの結末ごとの場面＋恋愛の結末の場面）

default fin_offers = []        # 届いた進路："euro" "j1" "j2" "univ" "school" "home"（ルートAは "bm" を足す予定）
default fin_end = ""           # 選んだ進路＝サッカーの結末："hero" "euro" "king" "lone" "detour" "bench" "kickoff"
default fin_consult = ""       # 2月に進路を相談した相手：lover / mother / kamishiro / alone
default fin_ageha_end = ""     # 蓮の卒業式のあげは：lover / refused（恋人がいて断った）/ miss / partner / bye（告白なし）/ none（いない・推し変）
default persistent.fin_seen = []   # 見た結末（隠しエンド「蒼の代表」の条件に使う予定）

## サッカーの結末の名前と、行き先の名前（クラブ・学校の名前は仮）
define FIN_END = {
    "hero": ("港町の英雄", "潮見ブルーマリンズ"),
    "euro": ("海の向こうの10番", "欧州のクラブ"),
    "king": ("王者の背番号", "東都ユナイテッド"),
    "lone": ("孤高のストライカー", "ヴァルト北陸"),
    "detour": ("遠回りのエース", "明修大学"),
    "bench": ("ベンチの向こう側", "理学療法の専門学校"),
    "kickoff": ("もう一度、キックオフ", "はやせ食堂"),
}
define FIN_OFFER_END = {"bm": "hero", "euro": "euro", "j1": "king", "j2": "lone",
                        "univ": "detour", "school": "bench", "home": "kickoff"}

## あげはの告白の目安（自動プレイで決め直す）
define FIN_AGEHA_LOVE = 60      # ときめき
define FIN_AGEHA_TRUST = 45     # 恋人になるための信頼
define FIN_AGEHA_PARTNER = 55   # 相棒（信頼だけ）

init python:
    def fin_b_offers():
        """ルートBで届く進路（11/7 の構成案のたたき台。条件の数字は自動プレイで決め直す）。
        大学と母さんの店は、いつでも選べる（選ぶ場面が一択にならないように）"""
        s, h, f = store.stats, store.hidden, store.flags
        avg = (s["技術"] + s["フィジカル"] + s["戦術眼"] + s["メンタル"]) / 4.0
        best = store.b6_nat_best
        broke = store.b6_knee == "broke"
        out = []
        if not broke:
            ## 欧州：国立の準決勝のスタンドに外国人のスカウトがいた人で、能力の平均84以上・ひざが冬を越えてもっている（いちばん難しいIF）
            if f.get("b6_外国人のスカウト") and avg >= 84 and store.bond.get("神城", 0) >= 70 and h["無理ゲージ"] < 70:
                out.append("euro")
            ## J1の王者：全国で決勝まで行ったか、ベスト4でとても目立った（注目度80）
            if best in ("優勝", "準優勝") or (best == "ベスト4" and h["注目度"] >= 80):
                out.append("j1")
            ## J2：本田をかばわず、上だけを見てきた人に、一通だけ
            if store.b6_honda == "silent" and fin_belief_top() == "野心型":
                out.append("j2")
        else:
            ## ひざが止まった人：黒田の紹介で、理学療法の専門学校（ひなたの学校）
            out.append("school")
        out.append("univ")
        out.append("home")
        return out

    def fin_belief_top():
        b = store.belief
        top = max(b.values()) if b else 0
        tops = [k for k in BELIEF_KEYS if b.get(k, 0) == top]
        return tops[0] if (top > 0 and len(tops) == 1) else ""

    def fin_lover():
        """恋人（いなければ ""）"""
        if store.fin_ageha_end == "lover":
            return "あげは"
        return store.b6_lover or ""

    def fin_partner():
        """恋人がいない人の、いちばん近い人（相棒）。いなければ "" """
        if fin_lover():
            return ""
        c = []
        if store.b6_saki_end == "partner":
            c.append("紗希")
        if store.b6_reika_end == "partner":
            c.append("麗華")
        if store.fin_ageha_end == "partner":
            c.append("あげは")
        if not c:
            return ""
        return max(c, key=lambda n: store.heart.get(n, {}).get("信頼", 0))

    def fin_end_name(e=None):
        return FIN_END[e or store.fin_end][0]

    def fin_place(e=None):
        return FIN_END[e or store.fin_end][1]


################################################################################
## 蓮の卒業式のあげは（どちらのルートも。3/1）
##   11/1 の決定：あげはの恋人／相棒の中身は作者が書く。ここは作者が書くまでの仮の文章（11/7 の決定）
##   来た順に答える：恋人がいる人は、答えのいらない告白を蓮が断る（heart_close）
################################################################################
label fin_ageha_confess(school="桜嶺"):
    if "あげは" not in met or b6_ageha_oshi:
        $ fin_ageha_end = "none"
        return
    python:
        _ah = heart["あげは"]
        if "あげは" in heart_closed:
            fin_ageha_end = "partner" if _ah["信頼"] >= FIN_AGEHA_PARTNER else "bye"
        elif fin_lover():
            fin_ageha_end = "refused" if _ah["ときめき"] >= FIN_AGEHA_LOVE else ("partner" if _ah["信頼"] >= FIN_AGEHA_PARTNER else "bye")
        elif _ah["ときめき"] >= FIN_AGEHA_LOVE and _ah["信頼"] >= FIN_AGEHA_TRUST:
            fin_ageha_end = "lover"
        elif _ah["ときめき"] >= FIN_AGEHA_LOVE:
            fin_ageha_end = "miss"
        elif _ah["信頼"] >= FIN_AGEHA_PARTNER:
            fin_ageha_end = "partner"
        else:
            fin_ageha_end = "bye"
    scene bg ouryo_clubroom
    with dissolve
    $ bgm("静かな春の曲")
    "式のあと、部室に寄った。三年分のスパイクを、袋に入れるために。"
    "部室には、あげはが一人で、待っていた。スマホを、胸の前で、両手で持って。"
    show ageha ouryo
    with dissolve
    ageha "……パイセン。卒業、おめでとう、ございます"
    ageha "あたし、敬語、苦手なんだけど。今日だけ、ちゃんと言おうと思って"
    if fin_ageha_end == "bye":
        ## 告白なし：推しの卒業を、マネージャーとして見送る
        ageha "パイセンの切り抜き、三年分、まとめたんだ。部のアカウントに、最後に一本だけ上げる"
        ageha "……推しの卒業って、こういう気持ちなんだね。知らなかった"
        "あげはは、笑った。いつもの、大きい声で。"
        ageha "向こうでも、撮らせてね。……ファンとして"
        $ heart_up("あげは", "信頼", 3)
        hide ageha
        with dissolve
        return
    ## ここから告白（仮の文章。作者が書き直す）
    ageha "去年の冬、切り抜きを見て、この人推せる、って思って。入試の二週間前に、志望校、変えて"
    ageha "推しを、近くで見られたら、それでいいと思ってた。……思ってたんだけど"
    "あげはは、スマホを、ポケットにしまった。両手が、空いた。"
    ageha "推しじゃなくなっちゃった。……いつからか、分かんない"
    ageha "パイセンのこと、好きです。……ファンとして、じゃなくて"
    if fin_ageha_end == "refused":
        "答えは、もう、決まっていた。……決まっていることを、あげはも、知っていた。"
        $ _fl = fin_lover()
        ren "……ごめん。俺には、[_fl]がいる"
        ageha "知ってる。……知ってて、言った。言わないと、卒業させてあげられないから"
        ageha "パイセンの切り抜き、三年分。最後の一本は、あたしのために、取っとく"
        $ heart_close("あげは")
    elif fin_ageha_end == "lover":
        menu:
            "「……俺も、好きだ」":
                ren "……俺も、好きだ。あげは"
                "あげはは、一回だけ、目をこすった。それから、いつもの顔に戻ろうとして、戻れなかった。"
                ageha "……ずるい。名前、初めて呼んだ"
                ageha "推しが、彼氏になるの、ルール違反だと思ってた。……でも、もう、いいや"
                $ heart_up("あげは", "ときめき", 6)
                $ heart_up("あげは", "信頼", 4)
                $ set_flag("fin_あげは_恋人")
            "「……ごめん」":
                ren "……ごめん"
                ageha "うん。……知ってた。言えて、よかった"
                $ fin_ageha_end = "partner" if heart["あげは"]["信頼"] >= FIN_AGEHA_PARTNER else "bye"
                $ heart_close("あげは")
    elif fin_ageha_end == "miss":
        ## ときめきだけ：すれ違い
        "答えが、すぐに出てこなかった。……出てこないことに、あげはが、先に気づいた。"
        ageha "あ、待って。今の、なし。……返事は、いらない"
        ageha "パイセンが、まだ、こっち見てないの、知ってる。……見てないのに、言っちゃった"
        ageha "だから、あたしが、ちゃんと見てもらえるようになったら、もう一回、言う。……卒業しても"
    else:
        ## 信頼だけ：相棒（あげはが、自分から、告白を相棒の約束に変える）
        "あげはは、そこで、一回、言葉を止めた。"
        ageha "……って言うと思った？　言わない。言ったら、パイセン、困るでしょ"
        ageha "あたし、パイセンの、いちばん近いカメラでいたい。……それって、彼女より、近いときあるから"
        ageha "向こうでも、撮りに行く。勝手に。……いいよね、相棒"
        $ heart_up("あげは", "信頼", 4)
    hide ageha
    with dissolve
    return


################################################################################
## 結末の記録と、最後の画面
################################################################################
label fin_record:
    python:
        _seen = list(persistent.fin_seen or [])
        if fin_end and fin_end not in _seen:
            _seen.append(fin_end)
        persistent.fin_seen = _seen
        set_flag("結末_" + fin_end_name())
    window auto hide
    scene black
    with Dissolve(1.5)
    $ _fin_title = fin_end_name()
    call show_title("結末", _fin_title)
    tuto "ここまで遊んでくれて、ありがとうございました。"
    tuto "ほかの進路を選ぶと、別の結末が見られます。（いまの版は、作者の確認用の第1稿です）"
    return
