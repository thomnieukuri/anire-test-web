## final_b.rpy ―― 終章「どこで、だれと」ルートB（v0.36.0・Claude の第1稿）
##   1/16 封筒を開ける → 2/3 だれに相談するか → 自由行動（2/5〜2/10）→ 2/14 → 2/16 運命の選択④「進路」
##   → 2/20 神城が理事長に全部話す → 2/24 港北に進路を話しに行く → 2/27 鬼塚が自分から退くと言う
##   → 3/1 桜嶺の卒業式・あげはの告白の日 → 3/17 寮を出る日（鬼塚が桜嶺を出る。紗希が一度だけ見に来る）→ エピローグ
##   11/7 の作者の決定：鬼塚は、神城が真相を話したあと自分から退く。紗希は許さないが、退いた日に一度だけ父を見に行く
##   （ルートBは IF なので、正史＝ルートAで鬼塚の命令が明かされないまま1部が終わるのとはぶつからない）
##   ※ クラブ・学校の名前、鷹野たちの進路、紗希と麗華の春からの行き先は、仮に決めたもの（作者の確認待ち）

default fin_b_witness = ""     # 2/20 理事長室で蓮が言ったこと：knee（ひざで証明する）/ forgive（許してはいないが、辞めろとは言わない）
default fin_b_takano = ""      # 2/24 港北のグラウンドで、鷹野と：kick（一本だけ蹴る）/ talk（蹴らずに話す）

image bg ouryo_board_room = a6_tmp("images/bg/staffroom.jpg", "桜嶺の理事長室（古い木の机と、歴代の優勝旗）")
image bg ouryo_gate_spring = a6_tmp("images/bg/kohoku_gate_march.jpg", "桜嶺の正門・3月の朝")
image cg fin_b_envelopes_room = a6_tmp("images/bg/ren_room_night.jpg", "寮の部屋の床に並べた封筒と、あぐらをかいた神城")
image cg fin_b_truth = a6_tmp("images/bg/staffroom.jpg", "理事長室で、頭を下げたまま話す神城と、となりに立つ蓮")
image cg fin_b_gate = a6_tmp("images/bg/kohoku_gate_march.jpg", "正門を出ていく鬼塚の背中と、門柱のかげの紗希")


label chapter_fin_b:
    $ quick_menu = True
    $ play_marks["chapter_fin_b"] = renpy.get_game_runtime()
    call show_title("終章", "どこで、だれと")
    call fin_b_envelopes
    call fin_b_consult
    call fin_b_free_loop
    call fin_b_valentine
    call fin_b_choice
    call fin_b_truth
    call fin_b_kohoku
    call fin_b_onizuka_last
    call fin_b_graduation
    call fin_ageha_confess("桜嶺")
    call fin_b_gate
    call fin_epilogue
    call fin_record
    return


################################################################################
## 1月16日（火）夜：寮の部屋で、封筒を開ける
################################################################################
label fin_b_envelopes:
    scene black
    with dissolve
    $ set_cal("1月16日（火）", "夜")
    $ fin_offers = fin_b_offers()
    scene bg ouryo_dorm_night
    with dissolve
    $ bgm("静かな夜の曲")
    "寮の部屋の床に、封筒を並べた。二段ベッドの下の段で、神城も、自分の封筒を抱えていた。"
    show kamishiro normal
    with dissolve
    kamishiro "……お前のほうが、多いな"
    kamishiro "俺は、もう決めてる。西のクラブに行く。……あの人のいないところで、蹴る"
    kamishiro "三年前から、そう決めてた。決めてたのに、桜嶺に残った。……お前が来るって、聞いたから"
    "神城は、それ以上は言わなかった。自分の封筒を机の引き出しにしまって、床に下りてきて、俺の封筒の前に、あぐらをかいた。"
    kamishiro "開けろよ。一通ずつ。……見てるから"
    hide kamishiro
    with dissolve
    show cg fin_b_envelopes_room
    with Dissolve(1.0)
    if "euro" in fin_offers:
        "最初に、知らない国の文字の封筒を開けた。中に、日本語の手紙が一枚だけ、はさんであった。"
        "国立の準決勝を見ていた、と書いてあった。U-19のチームの練習に、一か月、来てみないか。そのあとのことは、そのときに話そう、と。"
        kamishiro "……あの人か。スタンドで、腕を組んでた"
        kamishiro "お前の左足のトラップを見たときだけ、何か言ってた。……あれ、これだったのか"
    if "j1" in fin_offers:
        "東都ユナイテッド。去年の、J1の王者。"
        "全国の決勝のビデオを、三回見た。開幕から、一緒に戦いたい。……背番号は、来てから、自分で取れ。そう書いてあった。"
        kamishiro "王者が、取れ、って言うのか。……あの人と、同じこと言うんだな"
    if "j2" in fin_offers:
        "ヴァルト北陸。J2のクラブ。……封筒は、ほかのより、ずっと薄かった。"
        "来るなら、すぐに試合に出す。点を取れ。それだけ、書いてあった。"
        kamishiro "……一行だけか。お前に、似てるな"
    if "school" in fin_offers:
        "理学療法の専門学校の、入学の案内だった。港北の、ひなたが春から行く学校。"
        "案内のあいだに、手書きの紙が一枚、はさんであった。港北の、黒田監督の字だった。"
        "――止まれたやつは、止まるやつを、見られる。来たければ、紹介状は書いておいた。"
        kamishiro "……黒田さん、か。決勝の通路で、言ってたな。止まれた、って"
    "明修大学。関東の大学リーグの名門。推薦の案内。"
    if b6_knee == "broke":
        "ひざのことは、知っている。手術とリハビリが終わったら、四年かけて、もう一度見せてほしい。そう書いてあった。"
    else:
        "四年で、プロに行ける体にする。……急がなくていい、と、手紙のいちばん最後に書いてあった。"
    hide cg
    with Dissolve(1.0)
    "封筒は、それで、全部だった。"
    "……いや。封筒に入っていない道が、もう一つあった。"
    "港北の、はやせ食堂。母さんは、一度も、継げと言ったことはない。でも、のれんの奥には、いつも、俺の分の前掛けが掛けてある。"
    show kamishiro normal
    with dissolve
    kamishiro "……どれにするかは、聞かない。お前が選べ。あの人も、そう言ったろ"
    kamishiro "そのかわり、一つだけ、頼みがある"
    kamishiro "三年前のことと、湊さんのこと。……卒業の前に、全部、表に出す。理事長に、俺の口で話す"
    kamishiro "そのとき、となりにいてくれ。……三年前、俺が潰したのは、お前のひざだから"
    $ bond_up("神城", 3)
    hide kamishiro
    with dissolve
    "返事の期限は、2月16日。……あと、一か月だった。"
    $ set_flag("fin_b_封筒")
    return


################################################################################
## 2月3日（土）：だれに相談するか（母さんの「一人で抱えるのは、やめな」の回収）
################################################################################
label fin_b_consult:
    scene black
    with dissolve
    $ set_cal("2月3日（土）", "朝")
    scene bg ouryo_dorm_night
    with dissolve
    $ bgm("静かな春の曲")
    "2月になった。封筒は、机の上に並べたまま、一通も、引き出しにしまえなかった。"
    "大会が終わって、3年は、もう練習に出なくていい。土曜の朝の寮は、静かだった。"
    "……だれかに、話したほうがいい気がした。話さないほうがいい気も、した。"
    menu:
        "だれに、相談する？"
        "[saki_call]に話す" if b6_lover == "紗希":
            $ fin_consult = "lover"
            call fin_b_consult_saki
        "麗華に話す" if b6_lover == "麗華":
            $ fin_consult = "lover"
            call fin_b_consult_reika
        "母さんに話す":
            $ fin_consult = "mother"
            call fin_b_consult_mother
        "神城に話す":
            $ fin_consult = "kamishiro"
            call fin_b_consult_kamishiro
        "一人で決める":
            $ fin_consult = "alone"
            call fin_b_consult_alone
    $ set_flag("fin_相談_" + fin_consult)
    return

## 恋人：紗希（港の防波堤）
label fin_b_consult_saki:
    $ set_cal("2月3日（土）", "午後")
    scene bg harbor_winter_eve
    with dissolve
    $ se("波の音、カモメ")
    $ bgm("静かなピアノの旋律")
    "防波堤のはしで、[saki_call]が待っていた。俺が封筒の束を出すと、少しだけ、眉を寄せた。"
    show saki casual
    with dissolve
    saki_v "……進路の話？　あたしに聞いても、サッカーのことは、分かんないよ"
    saki_v "分かんないから、一個だけ、聞く"
    "[saki_call]は、封筒を一通も手に取らずに、俺の顔だけを見た。"
    saki_v "どこなら、あんた、痛いって言える？"
    "兄さんの手紙の、一行だった。――その人は、痛いって、言える人か。"
    saki_v "あたしは、春から、街の音大。……どこに行っても、ピアノは、持っていけない。あんたは、ボール一個で、どこにでも行ける。……ずるい"
    saki_v "決めたら、最初に、あたしに言って。……二番目は、やだ"
    $ heart_up("紗希", "信頼", 4)
    $ heart_up("紗希", "ときめき", 2)
    $ lean("仲間型")
    $ up("メンタル", 2)
    hide saki
    with dissolve
    mono "一人で、抱えなかった。……それだけで、封筒が、少し軽くなった。"
    return

## 恋人：麗華（寮の坂の下）
label fin_b_consult_reika:
    $ set_cal("2月3日（土）", "午後")
    scene bg slope_eve
    with dissolve
    $ bgm("静かなピアノ")
    "寮の坂の下に、黒い車が止まった。麗華は、運転手さんに一時間、と言って、車を帰した。"
    show reika normal
    with dissolve
    reika "……私に、評価しろと言うの？"
    reika "評価表は、もう、つけないと決めたのよ。引退した日に"
    "麗華は、俺の手から封筒の束を取って、一通ずつ、俺の手に戻した。戻すたびに、俺の顔を見ていた。"
    reika "……分かったわ。どれがいいかは、言わない"
    reika "でも、どれを持ったときに、あなたが息をしていたかは、覚えておいてあげる。……あとで、答え合わせをしましょう"
    reika "私は、春から、祖父の大学には行かないの。……外で、自分の評価表を、一から、つけてみるわ"
    $ heart_up("麗華", "信頼", 4)
    $ heart_up("麗華", "ときめき", 2)
    $ lean("仲間型")
    $ up("メンタル", 2)
    hide reika
    with dissolve
    mono "一人で、抱えなかった。……それだけで、封筒が、少し軽くなった。"
    return

## 母さん（はやせ食堂）
label fin_b_consult_mother:
    $ set_cal("2月3日（土）", "夜")
    scene bg shokudo_night
    with dissolve
    $ bgm("あたたかいアコースティックギター")
    "閉店のあとの店で、カウンターに封筒を並べた。母さんは、エプロンで手をふいてから、一通ずつ、表だけを見た。"
    show mother normal
    with dissolve
    haha "……あんた、これ、一人で決めないで、持ってきたね"
    haha "それだけで、半分、合格"
    "母さんは、湯のみを二つ出した。それから、柱の写真を、ちらっと見た。"
    show mother sadsmile
    haha "お父さんがね、一回だけ、あたしに相談したことがあるの。この店を始めるとき"
    haha "あとは、全部、一人だった。……だから、店のことだけは、二人で決めた。ほかのことは、二人で決められなかった"
    haha "どれを選んでも、文句言わない。前に言ったでしょ。誰かといっしょに決めた答えなら"
    if "home" in fin_offers:
        haha "それと、のれんの奥の前掛け。……あれね、継げって意味じゃないよ"
        haha "帰ってくる場所がある、って意味。……どこに行っても"
    $ up("メンタル", 3)
    $ up("無理ゲージ", -3)
    $ lean("仲間型")
    $ set_flag("fin_母と決めた")
    hide mother
    with dissolve
    mono "一人で、抱えなかった。……父さんに、一個だけ、勝った気がした。"
    return

## 神城（寮の屋上）
label fin_b_consult_kamishiro:
    $ set_cal("2月3日（土）", "夜")
    scene bg ouryo_rooftop
    with dissolve
    $ bgm("静かな夜の曲")
    "屋上で、神城は、手すりにもたれて、町の明かりを見ていた。封筒の話をすると、少しだけ、笑った。"
    show kamishiro normal
    with dissolve
    kamishiro "俺に聞くのか。……俺は、中1からあの人に選ばれて、一回も、自分で選ばなかったやつだぞ"
    kamishiro "……だから、一つだけ、言える"
    kamishiro "選んだ場所で、壊れるな。壊れそうになったら、止まれ。……どこに行っても、それだけは、同じだ"
    kamishiro "止まったら、俺に言え。……今度は、ボールを持って担架を待ったりしない"
    $ bond_up("神城", 5)
    $ lean("仲間型")
    $ up("メンタル", 2)
    hide kamishiro
    with dissolve
    mono "一人で、抱えなかった。……三年前の、潰したやつと、潰されたやつが、同じ封筒を見ていた。"
    return

## 一人で決める（港の防波堤で、一人で）
label fin_b_consult_alone:
    $ set_cal("2月3日（土）", "午後")
    scene bg harbor_winter_eve
    with dissolve
    $ se("波の音、カモメ")
    $ bgm("静かな夜の曲")
    "電車で港北まで帰って、だれにも会わずに、防波堤のいちばん先に座った。"
    "封筒を、一通ずつ、読み直した。風で、何度も、めくれそうになった。"
    "――一人で抱えるのは、やめな。"
    "母さんの声が、波の音と一緒に、聞こえた気がした。"
    mono "分かってる。……でも、これだけは、一人で決めたかった。"
    mono "だれかに決めてもらったら、ピッチの上で、そのだれかのせいにしそうだったから。"
    $ lean("求道型", 2)
    $ up("メンタル", 2)
    $ set_flag("fin_一人で決めた")
    return


################################################################################
## 2月14日（水）
################################################################################
label fin_b_valentine:
    scene black
    with dissolve
    $ set_cal("2月14日（水）", "放課後")
    if b6_lover == "紗希":
        scene bg ouryo_music
        with dissolve
        $ bgm("静かなピアノの旋律")
        "音楽室のピアノの上に、小さな箱が置いてあった。[saki_call]は、窓のほうを向いたまま、言った。"
        show saki normal
        with dissolve
        saki_v "……去年は、義理、って書いた。今年は、書かなかった"
        saki_v "書かなかった意味は、自分で考えて"
        $ heart_up("紗希", "ときめき", 3)
        hide saki
        with dissolve
    elif b6_lover == "麗華":
        scene bg ouryo_dorm_night
        with dissolve
        $ bgm("静かなピアノ")
        "寮の郵便受けに、黒い箱が入っていた。カードが一枚、ついていた。"
        "――手作りではないわ。手作りは、評価が分かれるから。　麗華"
        "箱の底に、もう一枚、カードがあった。"
        "――来年は、作るかもしれないわ。"
        $ heart_up("麗華", "ときめき", 3)
    elif "あげは" in met and not b6_ageha_oshi and heart["あげは"]["ときめき"] >= 30:
        scene bg ouryo_clubroom
        with dissolve
        $ bgm("明るい部活の曲")
        show ageha ouryo
        with dissolve
        ageha "パイセン！　はい、これ。部員全員に配ってるやつ"
        "あげはは、同じ袋を、部室の机に三十個並べていた。俺に渡された袋だけ、リボンの色が違った。"
        ageha "……色？　たまたま。たまたまだから"
        $ heart_up("あげは", "ときめき", 3)
        hide ageha
        with dissolve
    else:
        scene bg ouryo_dorm_dining
        with dissolve
        $ bgm("日常の静かな曲")
        "寮の食堂に、寮監さんが、大きな袋のチョコを置いていった。「三年生へ」と書いた紙が、貼ってあった。"
        "神城と二人で、一個ずつ食べた。……甘かった。"
    return


################################################################################
## 2月16日（金）夜：運命の選択④「進路」
################################################################################
label fin_b_choice:
    scene black
    with dissolve
    $ set_cal("2月16日（金）", "夜")
    scene bg ouryo_dorm_night
    with dissolve
    $ bgm("張りつめた静かな曲")
    "返事の期限の夜。机の上に、封筒を、もう一度、並べた。"
    "神城は、気をつかったのか、食堂に行ったまま、戻ってこなかった。"
    if fin_consult == "lover":
        if b6_lover == "紗希":
            "――どこなら、あんた、痛いって言える？"
        else:
            "――どれを持ったときに、あなたが息をしていたかは、覚えておいてあげる。"
    elif fin_consult == "mother":
        "――帰ってくる場所がある、って意味。……どこに行っても。"
    elif fin_consult == "kamishiro":
        "――選んだ場所で、壊れるな。壊れそうになったら、止まれ。"
    else:
        "防波堤で、一人で読み直した封筒だった。一通ずつ、手に取って、手を離した。"
    if b6_knee == "broke":
        "右ひざには、まだ、手術のあとのサポーターが巻いてあった。"
    elif b6_knee == "hold":
        "右ひざは、今日も、痛み止めなしで、階段を上がれた。……今日は。"
    window auto hide
    tuto "ここは最後の「運命の選択」です。選んだ進路が、この物語の結末になります。"
    tuto "ほかの結末も見たくなったら、ここでセーブしておきましょう。"
    call screen save_prompt
    menu:
        "どこで、蹴る？"
        "海の向こう――欧州のクラブへ" if "euro" in fin_offers:
            $ fin_end = "euro"
            $ lean("求道型")
        "東都ユナイテッドへ（J1の王者）" if "j1" in fin_offers:
            $ fin_end = "king"
            $ lean("野心型")
        "ヴァルト北陸へ（J2。すぐに試合に出られる）" if "j2" in fin_offers:
            $ fin_end = "lone"
            $ lean("野心型")
        "明修大学へ（四年かけて、プロを目指す）":
            $ fin_end = "detour"
            $ lean("求道型")
        "理学療法の専門学校へ（止まるやつを、見る側に）" if "school" in fin_offers:
            $ fin_end = "bench"
            $ lean("仲間型")
        "港北に帰る（はやせ食堂。サッカーは、町のチームで）":
            $ fin_end = "kickoff"
            $ lean("仲間型")
    $ set_flag("fin_進路_" + fin_end)
    scene black
    with Dissolve(1.5)
    if fin_end == "euro":
        mono "海の向こうへ行く。"
        mono "言葉も、だれも知らない場所で、左足のトラップから、もう一回。"
    elif fin_end == "king":
        mono "王者のクラブへ行く。"
        mono "背番号は、もらわない。……取りに行く。"
    elif fin_end == "lone":
        mono "一通だけの封筒を、選ぶ。"
        mono "すぐに出る。点を取る。……それだけを、書いてくれたところへ。"
    elif fin_end == "detour":
        mono "四年、かける。"
        mono "急がなくていい、と書いてくれたところで、急がないで、強くなる。"
    elif fin_end == "bench":
        mono "ピッチの外に、出る。"
        mono "止まれたやつにしか見えないものを、見る側に。"
    else:
        mono "港北に、帰る。"
        mono "のれんの奥の前掛けを、毎朝しめる。……ボールは、町のグラウンドで、蹴る。"
    ## 次の日：監督室に返事を持っていく
    $ set_cal("2月17日（土）", "朝")
    scene bg ouryo_office
    with dissolve
    $ bgm("重く静かな曲")
    "次の朝、監督室に、返事を持っていった。鬼塚監督は、封筒の表だけを見て、机の端に置いた。"
    show onizuka normal
    with dissolve
    if fin_end == "euro":
        onizuka "……海の向こうか。俺は、見に行けんな"
        onizuka "本物かどうかは、向こうが決める。……俺の目は、もう、要らん"
    elif fin_end == "king":
        onizuka "王者か。……背番号は、取れ。もらうな"
    elif fin_end == "lone":
        onizuka "一通だけの封筒を、選んだか"
        onizuka "……点を取れ。あそこは、それしか見ない。俺と、同じだ"
    elif fin_end == "detour":
        onizuka "四年か。……急ぐな、と書いてあったろう"
        onizuka "俺は、選手に、一度も、そう言わなかった"
    elif fin_end == "bench":
        onizuka "……止まるやつを、見る側か"
        onizuka "俺には、できなかった仕事だ。……見ていたのに、見なかった"
    else:
        onizuka "……サッカーを、やめるのか"
        ren "やめません。……蹴る場所を、変えるだけです"
        onizuka "……そうか"
    hide onizuka
    with dissolve
    if fin_consult == "alone":
        $ se("トークアプリの通知音")
        window auto hide
        $ talk_start("母", "12:10")
        $ talk_me("進路、決めた。" + fin_place() + "にする")
        $ talk_wait(3)
        $ talk("母", "一人で決めたね")
        $ talk("母", "まあ、いいや。決めたあと、ちゃんと言いに来たから")
        $ talk("母", "お父さんより、ちょっとだけ、まし")
        window auto hide
        $ talk_end()
    return


################################################################################
## 2月20日（火）：神城が、理事長に全部話す
################################################################################
label fin_b_truth:
    scene black
    with dissolve
    $ set_cal("2月20日（火）", "放課後")
    scene bg ouryo_board_room
    with dissolve
    $ bgm("張りつめた静かな曲")
    if b6_reika_end in ("lover", "partner"):
        "理事長室の前の廊下に、麗華が立っていた。"
        show reika normal
        with dissolve
        reika "祖父には、私から、時間を取らせたわ。十五分"
        reika "……祖父の十五分は、高いのよ。一秒も、むだにしないで"
        hide reika
        with dissolve
    else:
        "理事長室に入れてもらえるまで、三週間かかった。神城が、事務室に、何度も頭を下げて取った、十五分だった。"
    "古い木の机の向こうに、白い髪の、小さなおじいさんが座っていた。桜嶺学園の、理事長だった。"
    "神城は、椅子をすすめられても、座らなかった。机の前で、まっすぐ立って、頭を下げた。"
    show cg fin_b_truth
    with Dissolve(1.0)
    kamishiro "三年前の、中学の県大会の決勝です。……俺は、監督に言われて、相手の10番を、後ろから潰しました"
    kamishiro "相手の10番は、ここにいる、早瀬です。……早瀬のひざは、それから、半分しか、もちません"
    kamishiro "五年前の、高校の選手権の県の決勝。鬼塚湊さんは、ひざが痛いと言えないまま使われて、倒れました。……監督は、聞きませんでした"
    kamishiro "去年の11月、選手権予選の決勝で、監督は、真壁に合図をしました。港北の9番を、止めろと"
    kamishiro "1月の全国では、けがをした本田に、退部届を書かせろと言いました。……早瀬に、持っていけと"
    kamishiro "全部、俺は、見ていました。見ていて、三年間、だれにも言いませんでした"
    kamishiro "……言わなかったのは、俺も、同じことをしたからです"
    "理事長は、一回も、話をさえぎらなかった。神城が話し終わってから、俺のほうを見た。"
    "理事長" "……君は、何か、言うことはあるかね"
    menu:
        "「全部、本当です。……俺のひざが、証拠です」":
            $ fin_b_witness = "knee"
            ren "全部、本当です。……三年前のことは、俺のひざが、証拠です"
            ren "でも、潰したのは、神城だけじゃありません。……潰せと言った人が、いました"
            $ lean("求道型")
        "「許してはいません。……でも、辞めさせてくれとは、言いません」":
            $ fin_b_witness = "forgive"
            ren "俺は、あの人を、許してはいません"
            ren "でも、辞めさせてくれとは、言いません。……それを決めるのは、俺じゃないと思うから"
            $ lean("仲間型")
    "理事長" "……そうか"
    if b6_reika_end in ("lover", "partner"):
        "理事長" "孫から、少しだけ、聞いていた。評価表の、書けなかった欄の話を"
    "理事長" "鬼塚くんには、私から話す。……君たちは、もう、何もしなくていい"
    "理事長" "三年、黙っていたのは、君たちの罪ではないよ。……黙らせていた、こちらの罪だ"
    hide cg
    with Dissolve(1.0)
    scene bg ouryo_rooftop
    with dissolve
    $ bgm("静かな夜の曲")
    "理事長室を出て、二人で、寮の屋上まで、何も言わずに上がった。"
    show kamishiro normal
    with dissolve
    kamishiro "……言えた"
    kamishiro "三年、かかった。……三分で、終わった"
    "神城は、手すりに額をつけて、しばらく、動かなかった。"
    kamishiro "早瀬。……あのとき、潰して、悪かった"
    kamishiro "三年前に言うはずだった。……遅くなった"
    $ bond_up("神城", 8)
    $ set_flag("fin_b_神城が話した")
    hide kamishiro
    with dissolve
    return


################################################################################
## 2月24日（土）：港北に、進路を話しに行く（フェンスの外 → 初めて中に入る）
##   ※ 鷹野・大門・坂口・ひなたの進路は仮に決めたもの
################################################################################
label fin_b_kohoku:
    scene black
    with dissolve
    $ set_cal("2月24日（土）", "午後")
    scene bg kohoku_ground_day
    with dissolve
    $ bgm("のんびりした春の曲")
    "港北のグラウンドの、フェンスの外に立った。一年前の1月から、何度も立った場所だった。"
    "グラウンドでは、2年の九人が、ボールを回していた。来年、ここに、十一人はいない。"
    show kobayakawa jersey
    with dissolve
    kobayakawa "……早瀬、先輩"
    "小早川は、フェンスの戸の鍵を、内側から、開けた。"
    kobayakawa "今日は、入ってください。……鷹野先輩が、呼べって"
    hide kobayakawa
    with dissolve
    "二年ぶりに、港北のグラウンドの土を踏んだ。スパイクの裏から、去年までと同じ音がした。"
    scene bg clubroom
    with dissolve
    "部室には、3年の七人が、そろっていた。ロッカーの、俺の名前のテープがあった場所は、まだ、少しだけ色が違った。"
    show sakaguchi normal
    with dissolve
    sakaguchi "……裏切り者が、何の用だよ"
    sakaguchi "って、言うつもりだったんだけどな。……全国、全部、テレビで見ちまった"
    sakaguchi "俺は、港の会社に就職。週末は、町のチームで蹴る。……それだけだ"
    hide sakaguchi
    with dissolve
    show daimon normal
    with dissolve
    daimon "僕は、県の大学に行きます。キーパーは、続けます"
    daimon "……早瀬くんは、どこに行くんですか。それを、みんな、聞きたくて"
    hide daimon
    with dissolve
    $ _fp = fin_place()
    if fin_end == "kickoff":
        ren "……港北に、帰ってくる。はやせ食堂。サッカーは、町のチームで"
        "部室が、静かになった。坂口が、最初に、吹き出した。"
        sakaguchi "……は？　じゃあ、週末、同じチームじゃねえか"
        sakaguchi "裏切り者が、帰ってくんのかよ。……ばかじゃねえの"
        "坂口は、笑いながら、壁を一回だけ、こぶしでたたいた。"
        $ bond_up("坂口", 6)
    elif fin_end == "bench":
        ren "理学療法の、専門学校に行く。……黒田監督の紹介で"
        "部室のいちばん奥で、ひなたが、顔を上げた。"
    else:
        ren "[_fp]に、行く"
        "だれも、すぐには、何も言わなかった。大門が、一回だけ、深くうなずいた。"
        daimon "……三好先輩に、電話しておきます。行ったなら、勝て、の続きを、言ってもらわないと"
    $ bond_up("大門", 3)
    ## ひなた
    show hinata normal
    with dissolve
    if fin_end == "bench":
        hinata "……同じ学校、じゃん"
        hinata "わたし、春から、そこ。……知ってて、選んだの？"
        ren "知ってた。……知ってたけど、それで選んだんじゃない"
        hinata "うん。……分かってる。蓮は、そういうので、選ばない"
        hinata "でも、巻き方は、わたしのほうが、先輩だからね。……教室では、同級生だけど"
        $ heart_up("ひなた", "信頼", 6)
    else:
        hinata "わたしは、春から、理学療法の専門学校。……前から、決めてたやつ"
        hinata "蓮のひざ、もう巻けないけど。……巻き方を、ちゃんと、勉強してくる"
        $ heart_up("ひなた", "信頼", 3)
    hide hinata
    with dissolve
    ## 鷹野：グラウンドで
    scene bg kohoku_ground_eve
    with dissolve
    $ bgm("静かな春の曲")
    "部室を出ると、鷹野が、グラウンドの真ん中で、ボールに足を乗せて立っていた。"
    show takano jersey
    with dissolve
    takano "……来たか"
    takano "俺は、ブルーマリンズだ。佐伯って人から、話が来た。……ガキのころ、俺がいたとこだ"
    takano "お前が落ちたセレクションの、クラブだよ。……今度は、俺が、あそこで、上がる"
    menu:
        "「一本だけ、蹴るか」":
            $ fin_b_takano = "kick"
            if b6_knee == "broke":
                ren "……一本だけ、蹴るか。走れないから、立ったまま"
                takano "立ったままで、十分だ。……お前の左足は、立ってても、うぜえから"
            else:
                ren "……一本だけ、蹴るか"
                takano "一本だけな。……それ以上やると、決勝の続きになる"
            "鷹野が、ボールを、ふわっと浮かせて寄こした。左足で止めて、右に流した。"
            "鷹野は、それを、振り向きもせずに、ゴールの左すみに蹴りこんだ。……港北で、何百回もやった形だった。"
            $ se("ネットが揺れる音")
            takano "……覚えてやがったか"
            $ bond_up("鷹野", 6)
            $ lean("仲間型")
        "「……ずっと、言えなかったことがある」":
            $ fin_b_takano = "talk"
            ren "……ずっと、言えなかったことがある。二年前の1月、トーク一通で、行った"
            ren "ごめん。……桜嶺に行ったことじゃなくて、顔を見て言わなかったことが"
            "鷹野は、ボールから足を下ろした。しばらく、何も言わなかった。"
            takano "……知ってる。既読だけつけたのは、俺だ"
            takano "次は、顔見て言ってから行け。……どこに行くときも"
            $ bond_up("鷹野", 5)
            $ lean("求道型")
    takano "早瀬。……どこに行っても、いつか、どこかで当たる。そのときは、全部で来い"
    hide takano
    with dissolve
    "帰りぎわ、フェンスの戸を出るとき、小早川が、うしろから言った。"
    kobayakawa "……先輩たちの、最後の部室、見せられて、よかったです"
    $ set_flag("fin_b_港北に話した")
    return


################################################################################
## 2月27日（火）：鬼塚が、自分から退くと言う
################################################################################
label fin_b_onizuka_last:
    scene black
    with dissolve
    $ set_cal("2月27日（火）", "放課後")
    scene bg ouryo_office
    with dissolve
    $ bgm("重く静かな曲")
    "監督室に呼ばれた。呼んだのは、鬼塚監督だった。神城は、呼ばれなかった。"
    "部屋の棚から、三十年分の資料のファイルが、半分、消えていた。段ボール箱が、床に、三つ並んでいた。"
    show onizuka normal
    with dissolve
    onizuka "……3月で、監督を退く"
    onizuka "理事長には、何も言い返さなかった。言い返すことが、なかった"
    onizuka "辞めろとは、言われなかった。……俺が、決めた"
    "鬼塚監督は、窓の外のグラウンドを見ていた。2年と1年が、白いビブスと、灰色のビブスに分かれて、走っていた。"
    onizuka "三十年、本物を集めてきた。本物は、壊れない。壊れたら、本物じゃなかった。……そう思って、見てきた"
    onizuka "お前は、壊れかけを、壊させないで、全国を走った。……そういうやり方があるのを、俺は、知らなかった"
    onizuka "知らなかったことを、知らないままにしたのは、俺だ"
    "それは、謝る言葉ではなかった。あの人は、最後まで、謝らなかった。……謝る言葉を、知らない人だった。"
    if b6_honda == "cover":
        "鬼塚監督は、机の引き出しから、白い紙を一枚出して、俺の前に置いた。……本田の、名前のない退部届だった。"
        onizuka "出さなかった。……お前が、持って帰れ"
        $ set_flag("fin_b_本田の紙")
    onizuka "……一つだけ、聞く"
    onizuka "紗希は、……いや。いい"
    "鬼塚監督は、それ以上、何も言わなかった。俺は、頭を下げて、監督室を出た。"
    "閉めたドアの向こうから、段ボールにファイルを入れる音が、ずっと、聞こえていた。"
    hide onizuka
    with dissolve
    $ set_flag("fin_b_鬼塚が退く")
    return


################################################################################
## 3月1日（木）：桜嶺の卒業式（このあと、あげはの告白の日。final_common.rpy）
################################################################################
label fin_b_graduation:
    scene black
    with dissolve
    $ set_cal("3月1日（木）", "卒業式")
    scene bg ouryo_hall
    with dissolve
    $ bgm("静かな春の曲")
    "桜嶺の卒業式は、講堂で、二時間かかった。三年生は、三百人いた。"
    "教職員の列のいちばん端に、鬼塚監督が座っていた。一度も、こっちを見なかった。"
    if b6_reika_end in ("lover", "partner"):
        "答辞は、麗華だった。原稿を、一度も見なかった。"
        "最後の一文だけ、麗華は、少しだけ、声の速さを変えた。――評価できないものを、大切にできる人になりたいと思います。"
    ## グラウンド：神城と
    scene bg ouryo_ground_day
    with dissolve
    $ bgm("あたたかいアコースティックギター")
    "式のあと、グラウンドに行った。三年分の白いラインが、春の雨で、少しだけ、にじんでいた。"
    show kamishiro normal
    with dissolve
    kamishiro "……二段ベッド、あと二週間か"
    if fin_end in ("euro", "king", "lone"):
        kamishiro "プロのピッチで当たったら、手加減しない。……三年前とは、違う意味で"
        kamishiro "お前を潰すのは、もう、ルールの中でだけだ"
    elif fin_end == "detour":
        kamishiro "四年後か。……先に行って、待ってる。待つのは、慣れてる"
    elif fin_end == "bench":
        kamishiro "……いつか、俺のひざを、お前が見るんだろうな"
        kamishiro "そのときは、正直に言う。痛いって。……お前にだけは"
    else:
        kamishiro "はやせ食堂、か。……開幕前に、食べに行く。からあげ定食"
        kamishiro "お前の母さんには、三年前のこと、俺の口で謝る。……それも、全部のうちだ"
    kamishiro "早瀬。……桜嶺に来てくれて、ありがとう"
    $ bond_up("神城", 4)
    hide kamishiro
    with dissolve
    ## 本田
    if b6_honda == "cover":
        "本田が、松葉杖なしで、グラウンドの端を、ゆっくり歩いてきた。"
        show honda normal
        with dissolve
        honda "……早瀬。俺、地元の大学で、もう一回、サッカーやる。灰色の、いちばん下から"
        if flags.get("fin_b_本田の紙"):
            "本田の名前のない白い紙を、本田に渡した。本田は、それを、四つに折って、制服の胸ポケットにしまった。"
            honda "……お守りにする。名前、書かなかったやつの"
        honda "一ノ瀬さんに、言っとく。……守ってもらった、って"
        $ bond_up("本田", 5)
        hide honda
        with dissolve
    else:
        "講堂の出口で、本田と、一度だけ、目が合った。本田は、部をやめたあとも、学校には来ていた。"
        "本田は、少しだけ、頭を下げた。……何も、言わなかった。俺も、何も言えなかった。"
    ## 恋人と、短く
    if b6_lover == "紗希":
        scene bg ouryo_music
        with dissolve
        $ bgm("静かなピアノの旋律")
        "音楽室の鍵を返す前に、[saki_call]が、一曲だけ、弾いた。"
        show saki normal
        with dissolve
        saki_v "……最後の授業。生徒は、あんた一人"
        saki_v "この部屋で、三年、弾いた。……一回も、止まらなかったのは、あんたが聞いてた日だけ"
        $ heart_up("紗希", "ときめき", 3)
        hide saki
        with dissolve
    elif b6_lover == "麗華":
        scene bg ouryo_gate_spring
        with dissolve
        $ bgm("静かなピアノ")
        "正門の前で、麗華が、一枚の紙を、俺に渡した。評価表の、いちばん最後のページだった。"
        show reika normal
        with dissolve
        reika "三年分の、最後の欄よ。……読んでいいわ"
        "――早瀬蓮。評価、できない。理由：隣にいるから。"
        reika "……答辞より、時間がかかったわ。この一行"
        $ heart_up("麗華", "ときめき", 3)
        hide reika
        with dissolve
    return


################################################################################
## 3月17日（土）：寮を出る日。鬼塚が、桜嶺を出ていく（紗希が、一度だけ見に来る）
################################################################################
label fin_b_gate:
    scene black
    with dissolve
    $ set_cal("3月17日（土）", "朝")
    scene bg ouryo_dorm_night
    with dissolve
    $ bgm("静かな春の曲")
    "寮を出る日の朝。部屋は、来たときより、少しだけ広く見えた。"
    "窓の下の正門に、段ボールを積んだ車が止まっていた。……鬼塚監督が、最後に、桜嶺を出ていく日だった。"
    scene bg ouryo_gate_spring
    with dissolve
    if b6_saki_end == "lover":
        "前の晩、[saki_call]から、トークが一通だけ来ていた。――明日の朝、正門。来て。"
        "正門の柱のかげに、[saki_call]が立っていた。俺の手を、何も言わずに、強くつかんだ。"
    elif b6_saki_end in ("partner", "miss", "refused"):
        "正門の柱のかげに、[saki_call]が立っていた。俺に気づいて、少しだけ、眉を寄せた。"
        saki_v "……見に来ただけ。あんたに会いに来たんじゃない"
    else:
        "正門の柱のかげに、だれかが立っていた。……灰みがかった金の髪。[saki_call]だった。"
        "声をかけられる距離では、なかった。"
    show cg fin_b_gate
    with Dissolve(1.0)
    "鬼塚監督が、最後の段ボールを抱えて、正門を出てきた。黒いロングコート。白い髪。三年前の冬、スタンドの最前列にいたのと、同じ姿だった。"
    "柱の前で、鬼塚監督は、足を止めた。[saki_call]を、見た。"
    "[saki_call]は、目をそらさなかった。"
    if b6_saki_end in ("lover", "partner", "miss", "refused"):
        saki_v "……兄さんから、年に一回、手紙が来る"
        saki_v "あんたには、来ないでしょ。……来ないまま、でいい"
        saki_v "許さない。……一生。でも、見た。今日、ちゃんと、見た"
        "鬼塚監督は、何も言わなかった。段ボールを抱えたまま、一回だけ、深く、頭を下げた。"
        "それから、車に乗って、坂を下りていった。一度も、振り返らなかった。"
    else:
        "二人とも、何も言わなかった。鬼塚監督は、一回だけ、深く、頭を下げた。それから、車に乗って、坂を下りていった。"
    hide cg
    with Dissolve(1.0)
    if b6_saki_end == "lover":
        show saki casual
        with dissolve
        "車が見えなくなってから、[saki_call]は、やっと、息を吐いた。俺の手を、まだ、離さなかった。"
        saki_v "……ついてきてくれて、ありがと。……一人だったら、来られなかった"
        saki_v "兄さんに、手紙、書く。あんたのことと、今日のこと。……今年は、二枚になる"
        $ heart_up("紗希", "信頼", 4)
        hide saki
        with dissolve
    elif b6_saki_end in ("partner", "miss", "refused"):
        show saki casual
        with dissolve
        saki_v "……あんた、今日、ここ出るんでしょ"
        saki_v "どこに行っても、痛いって、言いなよ。……あの人の選手みたいに、ならないで"
        $ heart_up("紗希", "信頼", 3)
        hide saki
        with dissolve
    else:
        "気がつくと、柱のかげには、もう、だれもいなかった。"
    "寮の玄関に戻ると、神城が、二人分の荷物を、もう、外に出していた。"
    show kamishiro normal
    with dissolve
    kamishiro "……行くか"
    "三年前、俺のひざを潰したやつと、同じ日に、同じ門を出た。"
    hide kamishiro
    with dissolve
    $ set_flag("fin_b_正門")
    return


################################################################################
## 章えらび・場面ジャンプ用：終章Bの頭の状態（作者の確認用）
################################################################################
label cs_state7b:
    call cs_state6b
    python:
        stats = {"技術": 78, "フィジカル": 72, "戦術眼": 80, "メンタル": 76}
        hidden = {"無理ゲージ": 60, "注目度": 66}
        bond.update({"神城": 68, "鷹野": 45, "大門": 42, "本田": 40, "坂口": 30})
        heart["紗希"] = {"ときめき": 55, "信頼": 62, "さみしさ": 0}
        heart["あげは"] = {"ときめき": 45, "信頼": 40, "さみしさ": 0}
        heart["麗華"] = {"ときめき": 35, "信頼": 30, "さみしさ": 0}
        for _n in ("紗希", "あげは", "麗華", "本田", "神城", "真壁", "小早川"):
            meet(_n)
        b5_surgery = False
        b6_knee = "hold"
        b6_knee_broke = False
        b6_nat_best = "ベスト4"
        b6_honda = "cover"
        b6_lover = ""
        b6_saki_end = "partner"
        b6_reika_end = ""
        b6_hinata = "tape"
        b6_ageha_oshi = False
        fin_offers = []
        fin_end = ""
        fin_consult = ""
        fin_ageha_end = ""
        fin_b_witness = ""
        fin_b_takano = ""
    return

label cs_chapter_fin_b:
    $ quick_menu = True
    $ music_stop(1.5)
    call cs_state7b
    scene black
    if iap_testable():
        tuto "（作者の確認用）終章Bは、第6章Bまでの結果で変わります。"
    menu:
        "ひざと、全国の成績は？"
        "全国で優勝・ひざはもった（欧州・J1・大学・店が届く）":
            $ b6_nat_best = "優勝"
            $ stats = {"技術": 88, "フィジカル": 82, "戦術眼": 86, "メンタル": 84}
            $ bond["神城"] = 76
            $ hidden["無理ゲージ"] = 55
            $ set_flag("b6_外国人のスカウト")
        "全国でベスト4・ひざはもった（J1・大学・店が届く）":
            $ b6_nat_best = "ベスト4"
            $ hidden["注目度"] = 82
        "全国でベスト8・ひざはもった（大学・店が届く）":
            $ b6_nat_best = "ベスト8"
            $ hidden["注目度"] = 45
        "決勝でひざが止まった（専門学校・大学・店が届く）":
            $ b6_nat_best = "ベスト8"
            $ b6_knee = "broke"
            $ b6_knee_broke = True
    menu:
        "運命の選択③（本田）は？"
        "かばった":
            $ b6_honda = "cover"
        "何も言わなかった（野心型ならJ2も届く）":
            $ b6_honda = "silent"
            $ belief = {"仲間型": 3, "野心型": 8, "求道型": 4}
    menu:
        "恋人は？"
        "紗希":
            $ b6_lover = "紗希"
            $ b6_saki_end = "lover"
            $ heart["紗希"] = {"ときめき": 72, "信頼": 70, "さみしさ": 0}
        "麗華":
            $ b6_lover = "麗華"
            $ b6_reika_end = "lover"
            $ b6_saki_end = "refused"
            $ heart["麗華"] = {"ときめき": 55, "信頼": 40, "さみしさ": 0}
        "いない（あげはの告白が来る）":
            $ heart["あげは"] = {"ときめき": 66, "信頼": 58, "さみしさ": 0}
    if persistent.choice_hints is None:
        call choice_hint_ask
    jump chapter_fin_b
