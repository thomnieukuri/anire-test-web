## chapter3.rpy ―― 第3章「冬の扉」（高1・9〜12月）
##   台本：アンイレ 体験版台本（第3章「冬の扉」のタブ）
##   選手権予選 → 準決勝で桜嶺に負ける → 神城「俺が決めたことじゃない」 → 鬼塚の誘い → 誘いの噂で仲間割れ（三好の引退の日）
##   → 防波堤の紗希「あの人の駒なの？」 → クリスマス（欲張ると鉢合わせ） → 大晦日に「残るか、移るか」
##   無料で遊べるのはここまで。大晦日の選択を選んだところで、続きは製品版（第4章〜）

## 自由行動の日付・時間帯・地図の見出し（9月・10月・11月に3日ずつ、12月に2日）
define CH3_FREE = {
    "sep": (["9月8日（火）", "9月10日（木）", "9月14日（月）"], "放課後", "9月の放課後、どこへ行く？", "9月の放課後は3日。"),
    "oct": (["10月20日（火）", "10月22日（木）", "10月26日（月）"], "放課後", "10月の放課後、どこへ行く？", "準々決勝まで、放課後は3日。"),
    "nov": (["11月4日（水）", "11月5日（木）", "11月9日（月）"], "放課後", "11月の放課後、どこへ行く？", "準決勝の桜嶺戦まで、放課後は3日。"),
    "dec": (["12月14日（月）", "12月16日（水）"], "放課後", "12月の放課後、どこへ行く？", "冬休みまで、放課後は2日。"),
}

## 自由行動の前に読める「これまでのこと」
define CH3_RECAP = {
    "sep": "夏が終わった。\n合宿で、一人ずつ、サッカーをやっている理由を話した。\n\n10月から、選手権予選が始まる。三好先輩の、最後の大会。\n組み合わせ表の、同じ山。勝ち上がれば、準決勝で――桜嶺。\n\n神城から届いたトークは、一行だけ取り消されていた。",
    "oct": "格下に0−2で負けた。坂口たちが、辞めかけた。\n黒田のロープの特訓で、守り方を三つだけ覚えた。\n\n選手権予選の1回戦と2回戦に勝った。3回戦も、ぎりぎりで勝った。\n港北が、県のベスト8に残っている。\n\n生徒会室で、千夏先輩が言った。\n「港北は、なくなるかもしれません」",
    "nov": "準々決勝に勝った。次は準決勝、相手は桜嶺。\n\nその夜、右ひざが、腫れた。",
    "dec": "準決勝は、桜嶺に負けた。\n試合のあと、神城が言いかけた。「あのタックルは、俺が決めたことじゃない」\n鬼塚監督には、「4月から桜嶺に来い」と言われた。",
}

init python:
    def ch3_recap(month):
        """自由行動の前のふり返り。12月だけは、選んだ答えで文が変わる"""
        t = CH3_RECAP[month]
        if month != "dec":
            return t
        lines = [t, ""]
        if store.ch3_rumor == "hide":
            lines.append("「なんでもない」とごまかしたことは、すぐにばれた。")
        else:
            lines.append("誘われたことは、自分から部のみんなに話した。")
        lines.append({"no": "三好先輩の引退の日、鷹野に聞かれて、「行かない」と答えた。",
                      "undecided": "三好先輩の引退の日、「まだ決められない」と答えて、鷹野とぶつかった。",
                      "maybe": "三好先輩の引退の日、「行くかもしれない」と答えて、鷹野に胸ぐらをつかまれた。",
                      }.get(store.ch3_fight, "三好先輩が、引退した。"))
        lines.append("")
        lines.append("防波堤で、紗希が言った。桜嶺の鬼塚監督は、自分の父だ、と。")
        return "\n".join(lines)

## クリスマスに誘ってくれるヒロイン（「ときめき＋信頼」がこれ以上）
##   二人以上から誘われて、両方に「行く」と返すと、鉢合わせになる
define CH3_XMAS_INVITE = 50
##   ひなただけは、最初から「ときめき＋信頼」が40あるので、もっと高くないと誘ってこない（ほうっておくと誘われない）
##   （千夏も、必ず通る場面だけで40前後になるので、50にしている）
define CH3_XMAS_INVITE_HINATA = 60

## 無理ゲージがこれ以上のまま11月の自由行動を終えると、準決勝の前にひざが痛む（能力が少し下がる）
define CH3_KNEE_WARN = 60

## 大晦日に話す相手：クリスマスを過ごしたヒロイン。いなければ、鷹野の絆がこれ以上なら鷹野。それ以外は母
define CH3_NYE_TAKANO = 35

default ch3_day = 1
default ch3_dest = ""
default ch3_dates = []
default ch3_time = ""
default ch3_banner = ""
default ch3_intro = ""
default ch3_r = ""             # 夜のトークで選んだ返事
default ch3_res = ""           # 自由行動の結果（夜のトークの中身が変わる）
default ch3_3rd = ""           # 3回戦の最後の判断（cross / takano / self）
default ch3_3rd_lv = 1         # 3回戦で鷹野に預けたときの、鷹野との絆の段階（2 最高／1 高い／0 ふつう。v0.29.13）
default ch3_semi_pair_lv = 1   # 準決勝のワンツーのときの、鷹野との絆の段階（2 最高／1 高い／0 ふつう。v0.29.13）
default ch3_knee_plan = ""     # 準決勝の出方（full：最初から全力 / half：前半は下がり目でひざを残し、後半に上がる）
## 部員はちょうど11人なので、ベンチスタートや交代はできない（ひざを守るときは「ポジションを下げる」）
default ch3_knee_push = False  # 準決勝で、ひざが痛んでも黙って続けたか
default ch3_semi = ""          # 準決勝のスコア（例：1−2）
default ch3_semi_goal = False  # 準決勝で港北が1点取ったか
default ch3_rumor = ""         # 誘われたことを聞かれたときの返事（honest / hide）
default ch3_fight = ""         # 引退の日に鷹野に聞かれたときの答え（no / undecided / maybe）
default ch3_armband = ""       # キャプテンマーク（ren / takano）
default ch3_xmas_yes = []      # クリスマスに「行く」と返したヒロイン
default ch3_xmas = ""          # クリスマスを過ごした相手（hinata / chika / saki / boys）
default ch3_xmas_left = ""     # 鉢合わせで選ばなかったヒロイン
default ch3_nye = ""           # 大晦日に話した相手（hinata / chika / saki / takano / mother）
default ch3_route = ""         # 大晦日の選択（stay：港北に残る / move：桜嶺へ移る）

init python:
    ## 行動マップの行き先（ch2 と同じ形：id, 名前, x, y, 顔, イベント名, ラベル）
    CH3_SPOTS = {
        "sep": [
            ("council", "生徒会室", 640, 110, "chika", "千夏", "ch3_chika_sep"),
            ("roof", "屋上", 330, 45, "takano", "鷹野", "ch3_takano_sep"),
            ("staff", "職員室", 520, 250, "kuroda", "黒田", "ch3_kuroda_sep"),
            ("shokudo", "はやせ食堂", 850, 460, "hinata", "ひなた", "ch3_hinata_sep"),
            ("pier", "港の防波堤", 330, 560, "saki", "紗希", "ch3_saki_sep"),
        ],
        "oct": [
            ("council", "生徒会室", 640, 110, "chika", "千夏", "ch3_chika_oct"),
            ("clubroom", "部室", 520, 250, "miyoshi", "三好", "ch3_miyoshi_oct"),
            ("judo", "柔道場", 480, 330, "daimon", "大門", "ch3_daimon_oct"),
            ("slope", "港への坂道", 870, 330, "hinata", "ひなた", "ch3_hinata_oct"),
            ("piano", "ピアノの家の前", 330, 560, "saki", "紗希", "ch3_saki_oct"),
        ],
        "nov": [
            ("night", "夜のグラウンド", 290, 120, "takano", "鷹野", "ch3_takano_nov"),
            ("council", "生徒会室", 740, 75, "chika", "千夏", "ch3_chika_nov"),
            ("arcade", "駅前のゲーセン", 1050, 120, "sakaguchi", "坂口たち", "ch3_arcade_nov"),
            ("shokudo", "はやせ食堂", 850, 460, "mother", "母", "ch3_mother_nov"),
            ("pier", "港の防波堤", 330, 560, "saki", "紗希", "ch3_saki_nov"),
        ],
        "dec": [
            ("roof", "屋上", 330, 45, "takano", "鷹野", "ch3_takano_dec"),
            ("clubroom", "部室", 520, 250, "daimon", "大門・坂口", "ch3_team_dec"),
            ("council", "生徒会室", 640, 110, "chika", "千夏", "ch3_chika_dec"),
            ("slope", "港への坂道", 870, 330, "hinata", "ひなた", "ch3_hinata_dec"),
            ("piano", "ピアノの家の前", 330, 560, "saki", "紗希", "ch3_saki_dec"),
        ],
    }

    def ch3_spots(month="sep"):
        f = store.flags
        out = []
        for sid, name, x, y, face, ev, lab in CH3_SPOTS[month]:
            done = (lab != "ch3_practice") and f.get(lab)
            ## 紗希のイベントは、名前を知るまで「？？？」
            if face == "saki" and not f.get("紗希_名前を聞いた"):
                ev = "？？？"
            d = {"id": sid, "name": name, "x": x, "y": y,
                 "event": "" if done else ev, "enabled": not done}
            if face:
                d["face"] = face
            out.append(d)
        return out

    def ch3_spot_label(month, sid):
        for s in CH3_SPOTS[month]:
            if s[0] == sid:
                return s[6]
        return "ch3_practice"

    def heart_total(who):
        h = store.heart.get(who) or {}
        return h.get("ときめき", 0) + h.get("信頼", 0)

    def ch3_xmas_inviters():
        """クリスマスに誘ってくれるヒロイン（気持ちの強い順）"""
        hs = [h for h in ("ひなた", "千夏", "紗希")
              if heart_total(h) >= (CH3_XMAS_INVITE_HINATA if h == "ひなた" else CH3_XMAS_INVITE)]
        return sorted(hs, key=lambda h: -heart_total(h))

    ## 選手権の4−4−2（第2章の三好の相談で、センターバックが変わる）
    def ch3_442():
        if store.ch2_miyoshi_cb == "kiryu":
            cb = [("h", "桐生", (18, 41)), ("h", "宮下", (18, 27)), ("h", "三好", (24, 11))]
        else:
            cb = [("h", "三好", (18, 41)), ("h", "桐生", (18, 27)), ("h", "宮下", (24, 11))]
        return [("h", "大門", (5, 34))] + cb + [
            ("h", "森", (24, 57)), ("h", "坂口", (46, 59)), ("h", "小池", (36, 34)), ("h", "江藤", (46, 9)),
            ("h", "鷹野", (70, 42)), ("h", "野口", (70, 26)),
            ("ren", "蓮", (52, 34)),
        ]


################################################################################
## 第3章のはじまり
################################################################################
label chapter3:
    scene black
    with Dissolve(1.0)
    call show_title("第3章", "冬の扉")

    ############################################################################
    ## シーン1：組み合わせ発表（9月7日・月）
    ############################################################################
    $ set_cal("9月7日（月）", "放課後")
    scene bg clubroom
    with dissolve
    $ bgm("明るい部活の曲")
    ## 第2章の花火大会を、誰と過ごしたか（一言だけ）
    if ch2_fest == "hinata":
        sakaguchi "てか{rb}蓮{/rb}{rt}れん{/rt}、花火の日、篠宮と浴衣で歩いてたろ。見たぞ"
        ren "……見てたのかよ"
    elif ch2_fest == "chika":
        sakaguchi "てか{rb}蓮{/rb}{rt}れん{/rt}、花火の日、生徒会長と歩いてたって、マジ？"
        ren "……視察だって言ってた"
    elif ch2_fest == "boys":
        daimon "あ、あの……花火の日の三人の写真、待ち受けにしました"
        takano "消せ"
    elif ch2_fest == "alone":
        sakaguchi "{rb}蓮{/rb}{rt}れん{/rt}、花火の日、何してたの。誘おうと思ったのに"
        ren "……海、見てた"
    "部室のホワイトボードに、選手権予選の組み合わせ表が貼られていた。"
    show miyoshi smile
    with dissolve
    miyoshi "見ろ！　俺たちの名前、ちゃんと載ってるぞ！"
    sakaguchi "そりゃ載るでしょ。出るんだから"
    miyoshi "去年は、載ってなかったんだよ"
    "誰も、何も言えなくなった。"
    "線をたどる。1回戦、2回戦、3回戦、準々決勝。準決勝の枠の向こうに、「{rb}桜嶺{/rb}{rt}おうりょう{/rt}学園」。"
    show takano narrow at right
    with dissolve
    takano "……同じ山だな"
    "{rb}鷹野{/rb}{rt}たかの{/rt}の目が、桜嶺の名前の上で止まっていた。"
    if flags.get("背番号10") == "takano":
        "鷹野は、カバンの奥の10番のユニフォームに、手を当てた。"
    miyoshi "優勝するって言ったろ！　準決勝でも決勝でも、全部勝てば同じだ！"
    sakaguchi "簡単に言うじゃん"
    miyoshi "言うだけならタダだ！"
    hide takano
    with dissolve

    ## 第2章の三好の相談の答えで、選手権の並びが変わる
    show kuroda board at left
    with dissolve
    kuroda "選手権の並びを言う"
    hide kuroda
    hide miyoshi
    with dissolve
    $ tactics(dots=ch3_442(), caption="選手権予選　港北　4−4−2（中盤はひし形）")
    if ch2_miyoshi_cb == "kiryu":
        kuroda "センターバックは{rb}桐生{/rb}{rt}きりゅう{/rt}と{rb}宮下{/rb}{rt}みやした{/rt}。三好は左だ"
        "夏の終わりに、俺が言ったとおりだった。{rb}三好{/rb}{rt}みよし{/rt}先輩は、何も言わずに、マグネットの位置を見ていた。"
        miyoshi "……左なら、上がっていいんですよね。走りますよ、俺"
        kuroda "走れ。それがお前の仕事だ"
        $ set_flag("ch3_miyoshi_left")
    else:
        kuroda "センターバックは、三好と桐生。変えない"
        miyoshi "……はい！"
    $ tactics_off()
    ## 第2章の作戦ボード（6月1日）で言ったこと（一言だけ）
    if ch2_pos == "center":
        kuroda "{rb}早瀬{/rb}{rt}はやせ{/rt}。6月に、真ん中で全員を動かすと言ったな。選手権でも、それをやれ"
    elif ch2_pos == "goal":
        kuroda "{rb}早瀬{/rb}{rt}はやせ{/rt}。6月に、前で点を取りたいと言ったな。……取りに行くなら、そのぶん戻れ"
    elif ch2_pos == "takano":
        kuroda "{rb}早瀬{/rb}{rt}はやせ{/rt}。6月に、鷹野に全部つなぐと言ったな。選手権でも、それでいい"
    kuroda "1回戦まで、ひと月。夏に作った体で、冬を戦え"
    ## 夏の2回戦（西海学院）の作戦とスコアを、ここで一言だけ回収する
    show miyoshi smile
    with dissolve
    if ch2_2nd_score == "0−1":
        miyoshi "夏の{rb}西海{/rb}{rt}さいかい{/rt}戦は、0−1だった。……あと1点だったんだ。今度は、その1点を取りに行く"
    elif ch2_2nd_score == "1−3":
        miyoshi "夏の{rb}西海{/rb}{rt}さいかい{/rt}戦は、1−3。でも、1点は取れた。今度は、それ以上取る"
    elif ch2_2nd == "attack":
        miyoshi "夏の{rb}西海{/rb}{rt}さいかい{/rt}戦は、0−3。全員で攻めて、1点も取れなかった。……今度は、取る"
    else:
        miyoshi "夏の{rb}西海{/rb}{rt}さいかい{/rt}戦は、0−3。……最後の10分で、足が止まった。もう、あんな負け方はしない"
    if ch2_2nd == "attack":
        "あの日、全員で前に出た。あの後半を、三好先輩は、まだ覚えていた。"
    elif ch2_2nd == "hold":
        "あの日、全員で下がって耐えた。あの後半を、三好先輩は、まだ覚えていた。"
    hide miyoshi
    with dissolve
    ## セットプレーのノートは、練習の出来事（ch3_pr_set）で黒田の話を聞いたときに出る

    ## その夜：神城の取り消しのこと
    scene black
    with dissolve
    $ set_cal("9月7日（月）", "夜")
    scene bg ren_room_night
    with dissolve
    $ bgm("静かな夜の曲")
    "ベッドで、{rb}神城{/rb}{rt}かみしろ{/rt}とのトークを開いた。いちばん下に、「神城がメッセージの送信を取り消しました」の灰色の文字。"
    "決勝のことで、言わなきゃいけないこと。返事を打ちかけて、やめた。"
    "試合で会おう、と、あいつは書いた。なら、試合で聞けばいい。"

    ############################################################################
    ## シーン2：9月の自由行動（3日）
    ############################################################################
    call ch3_free_loop("sep")

    ## 格下との練習試合の負けと、坂口が辞めかける話（chapter3_more.rpy）
    call ch3_slump

    ############################################################################
    ## シーン3：生徒会室（9月28日・月）――「港北は、なくなるかもしれません」
    ############################################################################
    scene black
    with dissolve
    $ set_cal("9月28日（月）", "放課後")
    scene bg student_council
    with dissolve
    $ bgm("張りつめた静かな曲")
    "登録メンバーの用紙を、生徒会室に出しに行った。{rb}三好{/rb}{rt}みよし{/rt}先輩の字は、相変わらず枠からはみ出していた。"
    show chika normal
    with dissolve
    chika "……確認しました。11人。ちょうどですね"
    chika "……戻ってきたんですね"
    chika "言ったでしょう。名簿は、毎日見ていると"
    ren "ぎりぎりです。一人でもケガをしたら、10人で戦うことになります"
    "{rb}千夏{/rb}{rt}ちか{/rt}先輩は、用紙に判を押した。"
    ## 第2章のビデオ通話で、コルクボードの新聞の切り抜きを見ていたとき（一言だけ）
    if flags.get("千夏_切り抜き"):
        "判の横のクリアファイルに、新聞の切り抜き。『県大会　潮見FC・早瀬　決勝へ導く2アシスト』。6月に、画面の向こうで見た記事だった。"
        chika "……生徒会の資料です"
        "千夏先輩は、こっちを見ないまま、ファイルを裏返した。"
    "その手が、書類の山のいちばん下の紙で止まった。『県立高校の再編計画（案）』。"
    if flags.get("統廃合を知る"):
        "夏に見た書類だった。あのときより分厚くなって、{rb}港北{/rb}{rt}こうほく{/rt}の名前の横に、赤い線が二本引かれていた。"
        show chika narrow
        chika "……あのとき、決めさせないと言いました"
        chika "でも、決めるのは、私ではありませんでした"
    elif flags.get("統廃合_見た"):
        ## 第2章の夏休みに、この書類を見たのに「見てません」と答えた人
        "夏休みに、この机で見た書類だった。あのとき、俺は「見てません」と答えた。"
        "{rb}港北{/rb}{rt}こうほく{/rt}の名前の横の赤い線が、二本に増えていた。"
        show chika narrow
        chika "……夏に、見なかったことにしてくれた紙です"
        chika "もう、見なかったことにしておける紙では、なくなりました"
    else:
        "港北の名前の横に、赤い線が引かれていた。"
        ren "……これ、何ですか"
        show chika narrow
        "千夏先輩は、少しのあいだ、紙を裏返さずにいた。隠そうと思えば、隠せたはずだった。"
    chika "4月の、県の会議で決まります"
    chika "{rb}港北{/rb}{rt}こうほく{/rt}は、なくなるかもしれません"
    $ bgm("（止まる）")
    "窓の外で、野球部の打球音がした。それきり、生徒会室は静かになった。"
    ren "……なくなるって、学校が？"
    chika "となりの学区の高校と、一つになります。名前も、校舎も、残るのは向こうです"
    chika "部活も。……サッカー部も"
    chika "決まれば、新しい1年生をとるのは、あと一回だけです"
    menu:
        "「三好先輩たちには、まだ言わないでください」":
            $ heart_up("千夏", "信頼", 5)
            $ set_flag("ch3_統廃合_秘密")
            show chika soft
            chika "……言うつもりは、ありませんでした"
            chika "最後の大会の前に、言うことではありませんから"
        "「勝てば、変わりますか」":
            $ heart_up("千夏", "ときめき", 5)
            $ lean("野心型")
            show chika normal
            chika "……変わりません。会議の人たちは、サッカーを見ませんから"
            chika "でも"
            "千夏先輩は、机の上のフィルムカメラに、一度だけ触れた。"
            chika "残せるものは、あります"
    $ set_flag("統廃合を知る")
    hide chika
    with dissolve
    "生徒会室を出ると、グラウンドから三好先輩の、いつもと同じでかすぎる声が聞こえた。"
    $ amb_stop()

    ## 黒田の地味な特訓（chapter3_more.rpy）
    call ch3_drill

    jump ch3_tournament


################################################################################
## 選手権予選：1回戦〜3回戦（10月）
##   1・2回戦はダイジェスト。3回戦だけ遊ぶ
################################################################################
label ch3_tournament:
    scene black
    with Dissolve(1.0)
    ## 1回戦ははやせ食堂から、2回戦は職員室から（chapter3_more.rpy）
    call ch3_r1
    call ch3_r2

    ############################################################################
    ## 3回戦：対 明誠学院（10月17日・土）
    ############################################################################
label ch3_third:      # 試合のテスト用の目印（コンソールで jump ch3_third）
    $ set_cal("10月17日（土）", "選手権予選3回戦　対 明誠学院")
    scene bg pref_ground_autumn
    with Dissolve(1.0)
    $ bgm("緊迫した試合の曲")
    "3回戦の相手は、私立{rb}明誠{/rb}{rt}めいせい{/rt}学院。背の高い、体をぶつけてくるチームだった。"
    "土手の上に、見覚えのある大きな背中が並んでいた。"
    judo_senpai "{rb}大門{/rb}{rt}だいもん{/rt}ーっ！　受け身ーっ！"
    daimon "せ、先輩たち……！　来ないでくださいって言ったのに……"
    "柔道着のまま来た人たちに、まわりの保護者が道をあけていた。"

    $ se("キックオフの笛")
    $ sb_set("前半", 0, 0, 0, 0, "#2a5bd7", "#7a1f2b", "港北", "明誠学院")
    scene bg pref_ground_autumn at cam_jog
    with dissolve
    show screen letterbox
    show screen scoreboard
    "前半は、ほとんど相手のボールだった。競り合うたびに、誰かが土の上に転がる。"
    $ sb_set(mm=31)
    scene bg pref_ground_autumn at cam_snap(1.15)
    with hpunch
    if ch2_miyoshi_cb == "kiryu":
        "前半31分。相手のロングボールが落ちてくる場所に、{rb}桐生{/rb}{rt}きりゅう{/rt}先輩が、もう立っていた。"
        kiryu "……来ると思った"
        "ヘディングで、静かにはね返した。"
        $ learn("zone")
    else:
        "前半31分。相手のFWが、{rb}三好{/rb}{rt}みよし{/rt}先輩を振り切った。飛び出した大門のわきを、ボールが抜ける。――入る。"
        $ se("土を蹴る足音")
        "ゴールラインの手前で、泥だらけの足がボールをかき出した。振り切られたはずの三好先輩だった。"
        miyoshi "抜かれても、追いつく！　言ったろ！"
        $ bond_up("三好", 3)
    $ se("前半終了の笛")
    "前半は、0−0で終わった。"

    $ sb_set("後半", 38)
    scene bg pref_ground_autumn at cam_push(6.0, 1.15)
    with dissolve
    $ bgm("試合の曲（終盤）")
    "後半38分。0−0。相手の足が、やっと止まりはじめた。夏に走った、走らされた分だけ、今、前に出られる。"
    $ tactics(caption="後半38分　0−0", dots=[
        ("h", "大門", (5, 34)), ("h", "桐生", (30, 30)), ("h", "宮下", (40, 18)),
        ("h", "三好", (60, 12), (78, 8), 0.3, 1.0) if ch2_miyoshi_cb == "kiryu" else ("h", "三好", (34, 40)),
        ("h", "坂口", (74, 60), (84, 58), 0.6, 0.8),
        ("h", "鷹野", (78, 40), (84, 38), 0.4, 0.8),
        ("a", "", (86, 30)), ("a", "", (88, 42)), ("a", "", (80, 50)), ("a", "", (72, 36)),
        ("a", "", (102, 34)),
        ("ren", "蓮", (64, 34)),
        ("ball", "", (65.5, 35.5)),
        ])
    "右に{rb}坂口{/rb}{rt}さかぐち{/rt}。中に鷹野。"
    if ch2_miyoshi_cb == "kiryu":
        "そして左の外を、三好先輩が全力で駆け上がってくる。"
    $ tactics_off()
    menu:
        "坂口に出して、クロスを待つ":
            $ ch3_3rd = "cross"
            $ lean("仲間型")
            $ bond_up("坂口", 4)
            "右へ、はたく。坂口は、ゲームと同じ角度でクロスを上げた。"
            $ se("ボールを蹴る音")
            "ゴール前に飛びこんだのは、{rb}鷹野{/rb}{rt}たかの{/rt}と――"
            if ch2_miyoshi_cb == "kiryu":
                "左から走りこんできた、三好先輩だった。"
                $ goal("港北", home=1, mm=39)
                with vpunch
                "頭に当てただけのボールが、キーパーの手の先を抜けた。"
                miyoshi "入ったあああ！？　俺！？　俺か！？"
            else:
                "鷹野だった。"
                $ goal("港北", home=1, mm=39)
                with vpunch
                "ニア――ゴールの手前側で、頭を振る。ボールは、キーパーの逆を抜けた。"
                $ learn("near")
        "鷹野に預けて、裏へ走る":
            $ ch3_3rd = "takano"
            $ lean("求道型")
            "鷹野に当てて、走る。"
            ## v0.29.13：鷹野との絆で、返ってくるボールが変わる（テスターT7の声。運は入れない）
            ##   最高＝相手を引きつけてから、空いた場所に落とす／高い＝黒田の、低く出て曲がるボールが返ってくる／ふつう＝返さずに自分で撃つ
            $ ch3_3rd_lv = bond_level("鷹野", 30, 45)
            if ch3_3rd_lv == 2:
                "鷹野は、すぐには返さなかった。一歩、二歩。相手のセンターバックが二人とも、鷹野に吸い寄せられる。"
                "空いた二人のあいだに、鷹野は、俺を見ないまま、そっとボールを置いた。{rb}黒田{/rb}{rt}くろだ{/rt}の、あのボールより、やさしかった。"
                $ se("ボールを蹴る音")
                $ goal("港北", home=1, mm=39)
                with vpunch
                "キーパーと一対一。右足で、ゆっくり流しこんだ。"
                takano "……走ってくるのが、見えてた。それだけだ"
                $ bond_up("鷹野", 6)
            elif ch3_3rd_lv == 1:
                "鷹野が振り向きざまに蹴った左足のボールは、{rb}黒田{/rb}{rt}くろだ{/rt}の、あのボールだった。低く出て、相手の足の先で曲がって、俺の前にぴたりと収まる。"
                $ se("ボールを蹴る音")
                $ goal("港北", home=1, mm=39)
                with vpunch
                "右足で、流しこんだ。"
                takano "……今の、まねじゃねえからな"
                $ bond_up("鷹野", 4)
            else:
                "鷹野は、返さなかった。振り向いて、そのまま左足を振り抜いた。俺のほうを、一度も見なかった。"
                $ se("ボールを蹴る音")
                "キーパーが横っ飛びではじく。こぼれたボールが、走りこんでいた俺の足もとに転がってきた。"
                $ goal("港北", home=1, mm=39)
                with vpunch
                "押しこむだけだった。"
                takano "……走ってたのかよ。……見てなかった"
                "鷹野は、ゴールを決めた俺より、むすっとした顔をしていた。"
                $ bond_up("鷹野", 2)
        "自分で持ちこむ":
            $ ch3_3rd = "self"
            $ lean("野心型")
            $ up("技術", 2)
            "一人目を、体の向きだけでかわす。"
            if check("技術", 53):
                "二人目の足が届く前に、右足を振り抜いた。"
                $ se("ボールを蹴る音")
                $ goal("港北", home=1, mm=39)
                with vpunch
                "ゴールの右上。ネットが揺れた。"
            else:
                "二人目に倒された。笛が鳴る。"
                shinpan "フリーキック"
                "ゴール前、少し右。ボールを置いたのは、鷹野だった。"
                takano "どけ。俺が蹴る"
                $ se("ボールを蹴る音")
                $ goal("港北", home=1, mm=39)
                with vpunch
                "左足で巻いたボールが、壁の上を越えて落ちた。"
                $ bond_up("鷹野", 2)
    $ learn("counter")
    $ se("試合終了の笛")
    $ win("港北", "1−0")
    pause 1.0
    hide screen win_banner
    hide screen scoreboard
    hide screen letterbox
    judo_senpai "大門ーっ！　よく倒れなかったーっ！"
    "土手の柔道部の人たちが、胴上げしそうな勢いで騒いでいた。{rb}港北{/rb}{rt}こうほく{/rt}が、県のベスト8に残った。"

    python:
        _rows = [("スコア", "1−0")]
        _rows.append(("前半31分", "桐生先輩が、落ちてくる場所を読んではね返した" if ch2_miyoshi_cb == "kiryu" else "抜かれた三好先輩が、ゴールラインの手前でかき出した"))
        _rows.append(("後半39分", {"cross": "坂口のクロス　→　" + ("三好先輩のヘディング" if ch2_miyoshi_cb == "kiryu" else "鷹野のヘディング"),
                                   "takano": ("鷹野が相手を引きつけて、空いた場所へ　→　蓮が決めた" if ch3_3rd_lv == 2 else
                                              "鷹野に預けて裏へ　→　左足の曲がるボールを蓮が決めた" if ch3_3rd_lv == 1 else
                                              "鷹野が自分で撃った　→　こぼれ球を蓮が押しこんだ"),
                                   "self": "自分で持ちこんだ"}.get(ch3_3rd, "―")))
        _rows.append(("勝因", "夏に走りこんだ足。最後の10分、相手より先に動けた"))
    call screen match_report("選手権予選3回戦　港北 対 明誠学院", _rows, "ひなた：三好先輩、試合のあと、ずっとグラウンドの土をさわってた")

    ## 試合のあと：土手の上の鷹野（必ず通る場面。鷹野を気にかけると、絆が多く上がる）
    scene bg pref_ground_eve
    with dissolve
    $ bgm("少しとがった曲")
    "片づけのあと、土手の上で、{rb}鷹野{/rb}{rt}たかの{/rt}が一人で、スパイクのひもをほどいていた。"
    show takano match
    with dissolve
    takano "……あと一つ勝ったら、{rb}桜嶺{/rb}{rt}おうりょう{/rt}だ"
    if flags.get("真壁"):
        takano "5月に、真壁に、ボールだけきれいに取られた。……覚えてるか"
    else:
        takano "5月に、あの14番に、ボールだけきれいに取られた。……覚えてるか"
    menu:
        "「覚えてる。次は、14番の前で、お前に出す」":
            $ bond_up("鷹野", 6)
            $ lean("仲間型")
            takano "……出すだけじゃねえ。俺が抜ける場所に出せ"
        "「その前に、準々決勝だ」":
            $ bond_up("鷹野", 2)
            $ up("戦術眼", 1)
            $ lean("求道型")
            takano "……分かってるよ。うるせえな"
    hide takano
    with dissolve

    ## その夜
    scene black
    with dissolve
    $ set_cal("10月17日（土）", "夜")
    scene bg ren_room_night
    with dissolve
    $ bgm("静かな夜の曲")
    $ se("トークアプリの通知音（連続）")
    window auto hide
    $ talk_start("港北サッカー部（12）", "21:12")
    $ talk("三好", "ベスト8！！！！！")
    $ talk("坂口", "三好先輩、それもう12回目")
    $ talk("大門", "柔道部の先輩たちに、焼肉をおごってもらいました")
    $ talk("桐生", "なんで大門だけ")
    $ talk("森", "焼肉……")
    $ talk("宮下", "わろた")
    $ talk("三好", "準々決勝、勝ったら桜嶺だ！！")
    $ talk("鷹野", "知ってる")
    window auto hide
    $ talk_end()
    "既読は、今日も11だった。"

    ############################################################################
    ## 10月の自由行動（3日）
    ############################################################################
    call ch3_free_loop("oct")

    ############################################################################
    ## 準々決勝（10月31日・土）――ダイジェスト
    ############################################################################
    ## 生徒会室の千夏と、スタンドの紗希から（chapter3_more.rpy）
    call ch3_qf

    jump ch3_knee


################################################################################
## ひざ（11月1日・日）――準決勝の出方を決める
################################################################################
label ch3_knee:
    scene black
    with dissolve
    $ set_cal("11月1日（日）", "朝")
    scene bg ren_room_morning
    with dissolve
    $ bgm("静かなピアノ")
    "目が覚めると、右ひざが、自分のものじゃないみたいに重かった。布団をめくる。お皿のまわりが、ぷっくりと腫れていた。"
    $ learn("knee")
    "冬に、ぷつんと切れた、あの場所。――元どおりには、たぶん戻らない。医者の声が、耳の奥で鳴った。"
    if ch2_night == "knee":
        "――もし俺が無理してたら、止めてくれ。"
        "夏合宿の夜、暗い体育館で、自分でそう言ったのを思い出した。"
    $ se("小走りの足音")
    "階段を上がってくる足音がした。ノックもなしに、ドアが開く。"
    show hinata serious
    with dissolve
    if ch2_knee == "honest":
        hinata "{rb}千鶴{/rb}{rt}ちづる{/rt}さんから聞いた。……見せて"
        "ひなたは、腫れたひざを見ても顔色を変えず、カバンから、テーピングと氷のうと、{rb}黒田{/rb}{rt}くろだ{/rt}の字のメモを出した。"
        hinata "黒田先生とね、話してあったの。こうなったときのこと"
        hinata "準決勝。前半は下がり目で、ひざを残す。……それなら、最後まで走れるって"
        $ heart_up("ひなた", "信頼", 4)
    else:
        hinata "……千鶴さんが、氷を三回も替えてたって"
        "ひなたは、腫れたひざを見て、それから俺の顔を見た。"
        show hinata stare
        hinata "いつから？"
        ren "……昨日の試合のあと"
        hinata "うそ"
        "ひなたは、カバンからノートを出した。いちばん後ろのページ。"
        hinata "6月。練習の終わりに、右足かばってたでしょ。あのとき{rb}蓮{/rb}{rt}れん{/rt}、なんて言ったか覚えてる？"
        ren "…………"
        hinata "「大丈夫だって」"
        show hinata teary
        hinata "書いてあるの。全部。……わたしが、一個ずつ書いてるの"
        "ひなたは、泣いていなかった。泣くのを、我慢していた。"
        hinata "書くの、もうやだよ"
        $ heart_up("ひなた", "さみしさ", 5)

    "ひなたには、言っていないことが一つある。冬に、医者に言われたこと。――次にやったら、手術だ。"
    menu:
        "医者に言われたことを、全部話す":
            $ set_flag("ch3_医者の話")
            $ heart_up("ひなた", "信頼", 8)
            $ up("無理ゲージ", -5)
            ren "……ひなた。冬に、医者に言われたことがある"
            ren "元どおりには、たぶん戻らない。次にやったら、手術だって"
            "ひなたは、しばらく何も言わなかった。"
            show hinata serious
            hinata "……知ってた"
            ren "え"
            hinata "眉毛。病院から帰ってきたとき、ずっと上がってた"
            hinata "言ってくれるの、待ってた。……十か月、待った"
            if ch2_knee == "honest":
                "ひなたは、カバンからノートを出して、いちばん後ろのページを開いた。それから、何も書かずに閉じた。"
            else:
                "ひなたは、ノートを閉じた。いちばん後ろのページには、もう何も書き足さなかった。"
            $ set_flag("ひなた_うそ一覧_閉じた")
        "言わない。今は、試合のことだけ考える":
            $ heart_up("ひなた", "さみしさ", 4)
            ren "……大丈夫。昨日、ちょっとひねっただけだ"
            show hinata forcesmile
            hinata "……そっか"
            if ch2_knee == "honest":
                "ひなたは、カバンからノートを出して、何かを書き足して、閉じた。"
            else:
                "ひなたは、ノートに何かを書き足して、閉じた。"
            "何を書いたのかは、聞かなかった。聞けなかった。"

    show hinata serious
    hinata "準決勝、どうするの"
    menu:
        "「最後まで出る。神城と、90分やる」":
            $ ch3_knee_plan = "full"
            $ lean("野心型")
            $ up("無理ゲージ", 10)
            $ up("メンタル", 3)
            hinata "……そう言うと思った"
            hinata "じゃあ、テーピングは、わたしが巻く。ほかの人には巻かせない"
        "「前半は下がり目で、ひざを残す。勝負は後半」":
            $ ch3_knee_plan = "half"
            $ lean("求道型")
            $ heart_up("ひなた", "信頼", 4)
            $ up("戦術眼", 2)
            hinata "……うん"
            "ひなたは、少しだけ笑った。泣きそうな顔のまま。"
            hinata "前半は、無理に前に行かないでね。うしろから、{rb}神城{/rb}{rt}かみしろ{/rt}くんのこと、ずっと見てて"
            ren "11人しかいないんだ。下がっても、ピッチにはいる"
            hinata "知ってる。だから、最後まで立っててって言ってるの"
    hide hinata
    with dissolve
    $ amb_stop()

    ############################################################################
    ## 11月の自由行動（3日）
    ############################################################################
    call ch3_free_loop("nov")
    call ch3_knee_warn

    ## 桜嶺戦の前の夜、朝の食堂、バス、会場、ロッカールーム（chapter3_more.rpy）
    call ch3_semi_eve
    call ch3_semi_morning

    jump ch3_semi


################################################################################
## 準決勝：対 桜嶺学園（11月14日・土）
################################################################################
label ch3_semi:      # 試合のテスト用の目印（コンソールで jump ch3_semi）
    ## 入場の通路で、神城と並ぶ（chapter3_more.rpy）
    call ch3_semi_entrance
    scene bg stadium_semi_eve at cam_push(6.0, 1.06)
    with Dissolve(1.0)
    "整列。芝の上に並ぶと、スタンドの声が、急に遠くなった。"
    show kamishiro match
    with dissolve
    "握手の手は、冷たかった。"
    "神城の目が、一瞬だけ、{rb}桜嶺{/rb}{rt}おうりょう{/rt}のベンチへ動いた。"
    "黒いロングコートの男が、腕を組んで、こっちを見ていた。"
    "{rb}鬼塚{/rb}{rt}おにづか{/rt}監督。"
    hide kamishiro
    with dissolve
    "整列の列の中に、白の14番もいた。"
    if flags.get("真壁"):
        "{rb}真壁{/rb}{rt}まかべ{/rt}。5月にBチームにいた、{rb}鷹野{/rb}{rt}たかの{/rt}とジュニアユースで一緒だったあいつだ。この秋、Aに上がった。"
    elif flags.get("ch1_takano2"):
        "5月にBチームにいた、{rb}鷹野{/rb}{rt}たかの{/rt}とジュニアユースで一緒だったあいつだ。この秋、Aに上がったらしい。"
    else:
        "5月にBチームで、鷹野の横を笑って走り抜けたあいつだ。この秋、Aに上がったらしい。"
    "鷹野は、14番のほうを見なかった。見ないようにしていた。"
    if ch3_knee_plan == "half":
        "俺の場所は、いつもより十メートルうしろ。センターバックのすぐ前。右ひざに、ひなたの巻いたテーピング。"

    $ se("キックオフの笛")
    $ sb_set("前半", 0, 0, 0, 0, "#2a5bd7", "#f2f2ee", "港北", "桜嶺")
    scene bg stadium_semi_eve at cam_jog
    with dissolve
    show screen letterbox
    show screen scoreboard
    $ bgm("緊迫した試合の曲")

    if ch3_knee_plan == "half":
        call ch3_semi_deep
    else:
        call ch3_semi_first

    ## 後半（ハーフタイムのあいだは、スコアボードを消す）
    $ se("前半終了の笛")
    hide screen scoreboard
    scene bg stadium_semi_eve
    with dissolve
    show kuroda normal
    with dissolve
    "ハーフタイム。{rb}黒田{/rb}{rt}くろだ{/rt}は、作戦ボードを出さなかった。"
    kuroda "……いい試合だ。お前らが、試合をしてる"
    kuroda "0−9のときは、試合になってなかった"
    "誰も、笑わなかった。でも、全員がうなずいていた。"
    if ch3_knee_plan == "half":
        kuroda "{rb}早瀬{/rb}{rt}はやせ{/rt}。もう下がってなくていい。45分、全部使え"
        "ひざは、まだ軽い。前半、ほとんど走らなかった分だけ。"
        "ベンチの前で、ひなたが何も言わずに、背中を一回押した。"
    hide kuroda
    with dissolve

    $ sb_set("後半", 46)
    show screen scoreboard
    scene bg stadium_semi_eve at cam_jog
    with dissolve
    $ bgm("試合の曲（劣勢）")
    "後半。コーナーキックの守り。ゴール前で、{rb}神城{/rb}{rt}かみしろ{/rt}と肩がぶつかった。"
    scene cg ch3_kamishiro_face at cam_push(8.0, 1.06)
    with dissolve
    "審判の笛を待つ、ほんの数秒。"
    kamishiro "……早瀬"
    "神城は、ボールのほうを見たまま言った。俺にしか聞こえない声だった。"
    kamishiro "……今日は、逃げるなよ"
    kamishiro "ここで終わるなら、許さない"
    "何を、と聞く前に、ボールが蹴られた。"
    scene bg stadium_semi_eve at cam_snap(1.15)
    with hpunch
    $ se("鈍い衝突音")
    "{rb}大門{/rb}{rt}だいもん{/rt}が、パンチではじき出す。"
    $ sb_set(mm=60)
    $ goal("桜嶺", home=sb_home, away=sb_away + 1, mm=62)
    with vpunch
    "そのこぼれ球を、14番が蹴りこんだ。"
    if ch3_knee_plan == "full":
        call ch3_semi_knee
    call ch3_semi_last

    ## 試合終了
    $ se("試合終了の笛")
    $ ch3_semi = "%d−%d" % (sb_home, sb_away)
    pause 1.0
    hide screen scoreboard
    hide screen letterbox
    scene bg stadium_semi_eve
    with Dissolve(1.0)
    $ bgm("静かなピアノ（試合の音が遠のく）")
    "長い笛が鳴った。"
    "[ch3_semi]。"
    "スコアボードの数字は、それきり動かなかった。"
    "{rb}三好{/rb}{rt}みよし{/rt}先輩が、センターサークルの真ん中で、仰向けに倒れていた。"
    scene cg miyoshi_lying at cam_push(10.0, 1.05)
    with Dissolve(1.0)
    "近づくと、先輩は、空を見たまま笑っていた。"
    miyoshi "……{rb}蓮{/rb}{rt}れん{/rt}"
    miyoshi "楽しかったなあ"
    miyoshi "3年間で、いちばん楽しかった。……いや、今日だけじゃないな。お前が来てから、ずっとだ"
    "先輩の目尻から、泥といっしょに、涙が流れていた。"
    "{rb}坂口{/rb}{rt}さかぐち{/rt}が、しゃがみこんで顔をおおっていた。大門は、ゴールポストにしがみついて泣いていた。"
    "鷹野は、14番に背を向けて、一人で芝を見ていた。"
    ## ロッカールームの円陣で言ったこと（一言だけ）
    if ch3_huddle == "ouryo":
        "5月の0−9を、今日で終わらせよう。円陣で、俺はそう言った。"
        "スコアボードの[ch3_semi]が、その返事だった。"
    elif ch3_huddle == "miyoshi":
        "三好先輩の最後の試合を、今日にしない。……円陣でそう言ったのは、俺だった。"
    elif ch3_huddle == "love":
        "楽しもう、と、円陣で俺は言った。先輩は、楽しかった、と言った。"
    $ bond_up("三好", 5)
    hide miyoshi
    with dissolve

    python:
        _rows = [("スコア", ch3_semi + "（負け）")]
        _rows.append(("前半", {"deep": "下がり目で、ひざを残して神城を見ていた",
                              "turn": "神城を背負って前を向いた",
                              "touch": "ワンタッチで鷹野へ",
                              "back": "一度下げた",
                              "lost": "神城にボールを奪われた（前半40分の失点）"}.get(store.flags.get("ch3_semi_m1", "deep"), "―")))
        _rows.append(("14番と鷹野", {"win": "鷹野が14番を抜いた（シュートはバー）",
                                    "lose": "鷹野が14番に止められた",
                                    "pair": ("鷹野が14番を連れて走り、空いた道に落とした（シュートはバー）" if ch3_semi_pair_lv == 2 else
                                             "二人でワンツー。初めて桜嶺を崩した" if ch3_semi_pair_lv == 1 else
                                             "鷹野は返さずに、一人で14番に仕掛けて止められた")}.get(store.flags.get("ch3_semi_m2", ""), "蓮は下がり目にいた")))
        if ch3_knee_plan == "full":
            _rows.append(("ひざ", "痛みを隠して続けた（後半30分の失点）" if ch3_knee_push else "自分から合図して、うしろに下がった"))
        _rows.append(("最後の5分", "港北の1点" if ch3_semi_goal else "届かなかった"))
        _memo = "ひなた：0−9が、" + ch3_semi + "になった。半年で"
    call screen match_report("選手権予選準決勝　港北 対 桜嶺学園", _rows, _memo)

    jump ch3_after_semi


## 前半：下がり目で、ひざを残す（後半に上がるとき）
label ch3_semi_deep:
    $ set_flag("ch3_semi_m1", "deep")
    "センターバックのすぐ前から見る{rb}桜嶺{/rb}{rt}おうりょう{/rt}は、真ん中で見るより、ずっと速かった。"
    "前に出たい足を、何回も止めた。そのかわり、ずっと見ていた。"
    "……{rb}神城{/rb}{rt}かみしろ{/rt}は、ボールを持つ前に、一回だけ桜嶺のベンチを見る。毎回。指示を待ってるみたいに。"
    show hinata serious at right
    with dissolve
    hinata "蓮！　神城くん、またベンチ見た！"
    "ベンチの前から、ひなたの声が飛んできた。同じものを、見ていた。"
    hide hinata
    with dissolve
    $ sb_set(mm=15)
    scene bg stadium_semi_eve at cam_snap(1.15)
    with hpunch
    "前半15分。神城が、ペナルティエリアの外から撃った。"
    $ goal("桜嶺", away=1, mm=15)
    with vpunch
    "{rb}大門{/rb}{rt}だいもん{/rt}の指先の、ずっと先だった。"
    $ sb_set(mm=40)
    "そのあとの25分、{rb}港北{/rb}{rt}こうほく{/rt}は一本もシュートを打てなかった。"
    "それでも、2点目は取られなかった。{rb}三好{/rb}{rt}みよし{/rt}先輩の声が、最後まで枯れなかった。"
    return

## 前半：最初から出る
label ch3_semi_first:
    $ sb_set(mm=8)
    scene bg stadium_semi_eve at cam_push(6.0, 1.15)
    with dissolve
    "前半8分。真ん中で、ボールを受けた。"
    "背中に、体温。{rb}神城{/rb}{rt}かみしろ{/rt}が、ぴたりとついている。"
    show screen speedlines
    menu:
        "神城を背負ったまま、前を向く":
            hide screen speedlines
            if check("技術", 57):
                $ set_flag("ch3_semi_m1", "turn")
                "右に体を倒して、左に抜ける。神城の足が、半歩だけ遅れた。"
                "そのまま、ミドルを撃った。キーパーが、はじく。"
                "スタンドが、どよめいた。{rb}港北{/rb}{rt}こうほく{/rt}の、最初のシュートだった。"
                $ up("メンタル", 2)
            else:
                $ set_flag("ch3_semi_m1", "lost")
                "右に体を倒した瞬間、神城の足が、もうボールの上にあった。"
                "……読まれていた。"
        "ワンタッチで、鷹野に落とす":
            hide screen speedlines
            if check("戦術眼", 65):
                $ set_flag("ch3_semi_m1", "touch")
                "見る前に、見えていた。右足のアウトで、{rb}鷹野{/rb}{rt}たかの{/rt}の足もとへ。"
                "鷹野が、一人かわして撃つ。わずかに、左に外れた。"
                takano "……ちっ。もう一本よこせ"
            else:
                $ set_flag("ch3_semi_m1", "lost")
                "出した先に、もう白いユニフォームがいた。"
                "神城が、ベンチを一度だけ見て、指で何かを合図していた。"
        "一度、三好先輩に下げる":
            hide screen speedlines
            $ set_flag("ch3_semi_m1", "back")
            $ lean("求道型")
            "ボールを、後ろに下げる。神城は、追ってこなかった。"
            "かわりに、俺の耳もとで、低く言った。"
            kamishiro "……逃げるのか"
    $ sb_set(mm=15)
    scene bg stadium_semi_eve at cam_snap(1.15)
    with hpunch
    "前半15分。神城が、ペナルティエリアの外から撃った。"
    $ goal("桜嶺", away=1, mm=15)
    with vpunch
    "{rb}大門{/rb}{rt}だいもん{/rt}の指先の、ずっと先だった。"

    ## 前半30分：14番と鷹野
    $ sb_set(mm=30)
    scene bg stadium_semi_eve at cam_push(6.0, 1.12)
    with dissolve
    "前半30分。左サイドで、鷹野にボールが渡る。"
    "目の前に立ったのは、白の14番だった。"
    "14番が、何か言って笑った。5月と、同じ顔で。"
    menu:
        "鷹野に任せる。あいつの勝負だ":
            if check_bond("鷹野", 40):
                $ set_flag("ch3_semi_m2", "win")
                $ bond_up("鷹野", 4)
                "鷹野は、何も言い返さなかった。そのかわり、左足で、ボールを一回またいだ。"
                "14番の重心が、右に流れる。"
                "抜いた。"
                $ se("鈍い衝突音")
                "そのまま撃ったボールは、バーをたたいて、空に跳ねた。"
                takano "……っ！"
                "鷹野は、頭をかきむしった。でも、14番はもう、笑っていなかった。"
            else:
                $ set_flag("ch3_semi_m2", "lose")
                "鷹野は、真っ正面から仕掛けた。14番は、それを待っていた。"
                "ボールだけを、きれいに刈り取られた。5月と、同じように。"
                takano "…………"
        "二人で崩す。鷹野、ワンツーだ":
            $ set_flag("ch3_semi_m2", "pair")
            $ lean("仲間型")
            ren "鷹野！"
            ## v0.29.13：鷹野との絆で、ワンツーの形が変わる（テスターT7の声。運は入れない）
            ##   最高＝14番を連れて走り、空いた場所に落とす／高い＝ワンツーで抜ける／ふつう＝返さずに、一人で14番に仕掛ける
            ##   この試合は負けで決まっているので、どの形でも点にはならない（スコアは変えない）
            $ ch3_semi_pair_lv = bond_level("鷹野", 40, 55)
            if ch3_semi_pair_lv == 2:
                "鷹野は、ボールを俺に当てなかった。"
                "かわりに、ボールを持ったまま、外に走り出した。14番が、ついていく。"
                "真ん中に、誰もいない道が、一本だけできた。"
                "鷹野は、走りながら、その道にボールを流した。俺が走りこむ、ほんの少し先に。"
                $ se("ボールを蹴る音")
                scene bg stadium_semi_eve at cam_snap(1.2)
                with hpunch
                "ダイレクトで撃つ。キーパーの指先が、かすかに触れた。ボールはバーをたたいて、外に出た。"
                takano "……今のは、入れろよ"
                "そう言った鷹野は、少しだけ笑っていた。14番は、もう笑っていなかった。"
                $ bond_up("鷹野", 5)
            elif ch3_semi_pair_lv == 1:
                "鷹野が、ちらっと俺を見た。それから、足もとのボールを、俺に当てた。"
                "返す。鷹野が、14番の背中を走り抜ける。"
                "撃つ。キーパーが、横っ飛びで止めた。"
                takano "……今の、悪くねえ"
                $ bond_up("鷹野", 3)
            else:
                "鷹野は、俺を見なかった。"
                "14番の前で、一人で仕掛けた。……5月と、同じように。"
                "ボールだけを、きれいに刈り取られた。"
                "鷹野は、しばらく、取られた場所に立っていた。"
                takano "…………呼んだの、聞こえてた"
                takano "でも、俺が抜かなきゃ、意味がねえと思った"
                $ bond_up("鷹野", 1)
    if flags.get("ch3_semi_m1") == "lost":
        $ sb_set(mm=40)
        scene bg stadium_semi_eve at cam_snap(1.15)
        with hpunch
        "前半40分。また、神城に読まれた。"
        "奪ったボールを、神城は自分では撃たなかった。ゴール前へ、横に一本。"
        $ goal("桜嶺", away=2, mm=40)
        with vpunch
        "桜嶺のフォワードが、流しこんだ。2点目。"
    return

## 後半：ひざの痛み（最初から出ているとき）
label ch3_semi_knee:
    $ sb_set(mm=70)
    scene bg stadium_semi_eve at cam_push(6.0, 1.1)
    with dissolve
    "後半25分。切り返した瞬間、右ひざの奥で、何かがきしんだ。"
    with red_hit
    "息が、止まる。"
    "ベンチで、ひなたが立ち上がるのが見えた。"
    "まだ、走れる。たぶん。"
    menu:
        "ベンチに合図して、いちばんうしろに下がる":
            ## 部員は11人ちょうど。交代はできないので、ポジションを下げて、ひざを守る
            $ ch3_knee_push = False
            $ heart_up("ひなた", "信頼", 6)
            $ up("無理ゲージ", -3)
            "ベンチに向かって、右ひざを指でたたいた。"
            "{rb}黒田{/rb}{rt}くろだ{/rt}は、一秒も迷わずに、手のひらを下に向けた。――下がれ。"
            "交代の選手はいない。ポジションだけ、下げる。"
            "{rb}三好{/rb}{rt}みよし{/rt}先輩と、場所を入れかわる。先輩は何も聞かずに、俺の背中を一回たたいて、前へ走っていった。"
            "ベンチの前で、ひなたが、もう氷のうを持って立っていた。"
            show hinata teary at right
            with dissolve
            "口が、「ありがと」と動いたように見えた。"
            hide hinata
            with dissolve
            $ set_flag("ch3_semi_sub")
        "黙って、走りつづける":
            $ ch3_knee_push = True
            $ up("無理ゲージ", 15)
            $ heart_up("ひなた", "さみしさ", 4)
            "何も言わなかった。言ったら、終わる気がした。"
            "でも、ひざは言うことを聞かなかった。"
            $ sb_set(mm=75)
            scene bg stadium_semi_eve at cam_snap(1.15)
            with hpunch
            "後半30分。追いつけるはずのボールに、半歩、届かなかった。"
            $ goal("桜嶺", home=sb_home, away=sb_away + 1, mm=75)
            with vpunch
            "{rb}神城{/rb}{rt}かみしろ{/rt}の、2点目だった。"
            "ベンチのひなたが、ノートを胸に抱いて、目をつぶっていた。"
    return

## 後半：最後の5分
label ch3_semi_last:
    $ sb_set(mm=85)
    scene bg stadium_semi_eve at cam_push(6.0, 1.15)
    with dissolve
    $ bgm("試合の曲（終盤）")
    "後半40分。"
    if flags.get("ch3_semi_sub"):
        "いちばんうしろから見るピッチで、{rb}鷹野{/rb}{rt}たかの{/rt}が、ボールを呼んでいた。"
        if check_bond("鷹野", 45):
            ## 前半30分に14番を抜いた道（勝負で勝った・ワンツー）だけ「もう一度」。止められた道などは「今度こそ」
            if flags.get("ch3_semi_m2") == "win" or (flags.get("ch3_semi_m2") == "pair" and ch3_semi_pair_lv == 1):
                "{rb}小池{/rb}{rt}こいけ{/rt}のパスを、鷹野が左足で止める。14番を、もう一度抜いた。"
            else:
                "{rb}小池{/rb}{rt}こいけ{/rt}のパスを、鷹野が左足で止める。14番を、今度こそ抜いた。"
            $ se("ボールを蹴る音")
            $ goal("港北", home=sb_home + 1, mm=86)
            with vpunch
            "低いシュートが、キーパーの股を抜けた。"
            "鷹野は、ゴールの中のボールを拾って、いちばんうしろの俺に向かって、一回だけ突き上げた。"
            $ ch3_semi_goal = True
            $ bond_up("鷹野", 5)
        else:
            "鷹野のシュートは、キーパーの正面だった。"
        return
    "ボールが、真ん中の俺に転がってきた。"
    "前に{rb}神城{/rb}{rt}かみしろ{/rt}。右に鷹野。後ろで、{rb}三好{/rb}{rt}みよし{/rt}先輩が叫んでいる。"
    show screen speedlines
    menu:
        "自分で撃つ":
            hide screen speedlines
            $ lean("野心型")
            if check("技術", 54 if ch3_knee_plan == "half" else 57):
                "神城の足が出る前に、振り抜いた。"
                $ se("ボールを蹴る音")
                $ goal("港北", home=sb_home + 1, mm=86)
                with vpunch
                "ゴールの左上。キーパーの手が、届かなかった。"
                $ ch3_semi_goal = True
            else:
                "振り抜いたボールは、神城の足に当たって、ラインを割った。"
        "鷹野に出す":
            hide screen speedlines
            $ lean("仲間型")
            if check_bond("鷹野", 45):
                "鷹野は、もう走り出していた。出す前に、分かっていた。"
                $ se("ボールを蹴る音")
                $ goal("港北", home=sb_home + 1, mm=86)
                with vpunch
                "左足のダイレクト。ネットが、揺れた。"
                $ ch3_semi_goal = True
                $ bond_up("鷹野", 5)
            else:
                "鷹野の足もとに出したボールに、14番が先に触った。"
        "三好先輩に下げて、セットプレーに賭ける":
            hide screen speedlines
            $ lean("求道型")
            if check("戦術眼", 65):
                "三好先輩のロングボールが、相手の手に当たる。フリーキック。"
                "壁の横に、俺と鷹野と{rb}大門{/rb}{rt}だいもん{/rt}が並んだ。夏に、何度も練習した形。"
                $ se("ボールを蹴る音")
                $ goal("港北", home=sb_home + 1, mm=86)
                with vpunch
                "大門の頭に当たったボールが、ゴールに転がりこんだ。"
                daimon "……は、入りました……？　僕が……？"
                $ ch3_semi_goal = True
                $ bond_up("大門", 4)
            else:
                "三好先輩のロングボールは、神城の頭にはね返された。"
    if ch3_semi_goal:
        "{rb}港北{/rb}{rt}こうほく{/rt}の1点。スタンドの端で、小さな歓声が上がった。"
        "でも、時計は止まらなかった。"
    return


################################################################################
## 試合のあと：神城と鬼塚
################################################################################
label ch3_after_semi:
    scene black
    with dissolve
    $ amb_stop(2.0)
    $ set_cal("11月14日（土）", "試合のあと")
    scene bg stadium_gate_eve
    with dissolve
    $ bgm("重く静かな曲")
    "競技場の外。バスの出る通路で、白と金のジャージが待っていた。"
    show kamishiro normal
    with dissolve
    kamishiro "……{rb}早瀬{/rb}{rt}はやせ{/rt}"
    ren "取り消したやつの続きか"
    "{rb}神城{/rb}{rt}かみしろ{/rt}は、少しだけ笑った。笑ったのに、苦しそうだった。"
    show kamishiro pained
    kamishiro "……決勝のこと、ずっと言えなかった"
    kamishiro "あのタックルは――"
    "神城は、一度だけ、スタンドのほうを見た。"
    kamishiro "あのタックルは、俺が決めたことじゃない"
    ren "……どういう意味だ"
    kamishiro "俺は――"
    "低い声が、通路に響いた。"
    "「神城」"
    "神城の背中が、びくっと固まった。"
    "通路の向こうに、黒いロングコートが立っていた。"
    kamishiro "……今度、ちゃんと話す。今度は、取り消さない"
    "神城は、それだけ言って、黒いコートのほうへ歩いていった。"
    "左の足首を、かばいながら。"
    "足首のテーピングは、試合の前に見たときより、二周ぶん増えていた。"
    "すれちがうとき、コートの男は、神城を見もしなかった。"
    hide kamishiro
    with dissolve

    show onizuka normal
    with dissolve
    "{rb}鬼塚{/rb}{rt}おにづか{/rt}監督が、俺の前で止まった。"
    "面と向かうのは、推薦の面談以来だった。5月の雨の日、ベンチで見たのと同じ、細い目。"
    onizuka "{rb}早瀬蓮{/rb}{rt}はやせれん{/rt}"
    onizuka "右ひざは、どうだ"
    ren "……関係ないでしょう"
    onizuka "関係ある。私の選手になるなら"
    "冷たい風が、通路を吹き抜けた。"
    onizuka "今日の後半を見た。……ひざが半分でも、お前はピッチの全部が見えている"
    onizuka "お前は、{rb}港北{/rb}{rt}こうほく{/rt}で終わる選手じゃない"
    onizuka "4月から、{rb}桜嶺{/rb}{rt}おうりょう{/rt}に来い。特待生で迎える"
    onizuka "転校すれば、半年は公式戦に出られん。夏は、スタンドだ。……それでも来い"
    $ bgm("（止まる）")
    "息が、止まった。"
    "冬に取り消された推薦。それを、一本の電話で終わらせた人が、目の前で、同じ言葉を言っている。"
    ren "……推薦を取り消したのは、あなたでしょう"
    onizuka "あのときのお前は、壊れた。壊れたものは、使えない"
    onizuka "本物は、壊れない。壊れたなら、本物じゃなかったというだけだ"
    onizuka "……だが、お前は戻ってきた。半分のひざで、この芝に"
    onizuka "それが、知りたかった"
    ren "……知りたかった？"
    "鬼塚監督は、答えなかった。"
    onizuka "今のお前は、使える。それだけだ"
    onizuka "返事は年が明けてからでいい。……本物なら、来い"
    "鬼塚監督は、それだけ言って、背を向けた。"
    hide onizuka
    with dissolve
    $ set_flag("鬼塚_誘い")
    $ meet("鬼塚")
    "通路の出口で、白いブレザーの女の子が、立ち止まってこっちを見ていた。"
    "色素の薄い、短い髪。"
    "[saki_call]は、俺と目が合うと、何も言わずに走っていった。"
    $ amb_stop()

    jump ch3_rumor


################################################################################
## 噂（11月15日・日）――誘われたことが知られる
################################################################################
label ch3_rumor:
    scene black
    with dissolve
    $ set_cal("11月15日（日）", "夜")
    scene bg ren_room_night
    with dissolve
    $ bgm("静かな夜の曲")
    "試合の次の日は、一日じゅう、何もする気になれなかった。"
    $ se("トークアプリの通知音")
    window auto hide
    $ talk_start("港北サッカー部（12）", "22:41")
    $ talk("坂口", "なあ蓮")
    $ talk("坂口", "きのう、通路の自販機のとこにいたんだけど")
    $ talk("坂口", "桜嶺の監督と、何話してたの")
    $ talk_system("既読　11")
    "誰も、何も書きこまなかった。全員が、俺の返事を待っていた。"
    $ ch3_r = talk_choose([("誘われた。4月から来いって。まだ何も決めてない", "honest"), ("なんでもない。ひざのこと聞かれただけ", "hide")])
    $ ch3_rumor = ch3_r
    if ch3_r == "honest":
        $ talk_me("誘われた。4月から来いって。まだ何も決めてない")
        $ talk("大門", "…………")
        $ talk("坂口", "マジか")
        $ talk("三好", "すげえじゃん！！　桜嶺から誘われるとか！！")
        $ talk("三好", "……すげえじゃん")
        $ talk("鷹野", "で、行くのかよ")
        $ talk_me("まだ決めてないって書いた")
        $ talk("鷹野", "そうかよ")
        $ talk_system("鷹野が退出しました")
        $ talk_system("三好が鷹野を招待しました")
        $ talk("三好", "勝手に抜けるな！！")
    else:
        $ talk_me("なんでもない。ひざのこと聞かれただけ")
        $ talk("坂口", "そっか")
        $ talk("坂口", "ならいいや。てか顔こわかったからさ")
        $ talk("三好", "ひざ大事にしろよ！！")
        $ talk("鷹野", "…………")
        "{rb}鷹野{/rb}{rt}たかの{/rt}の「…………」だけが、いつまでも画面のいちばん下に残っていた。"
    window auto hide
    $ talk_end()
    "スマホを伏せた。今日も、既読は11だった。その数字が、少しだけ、こわかった。"

    ############################################################################
    ## 三好先輩の引退（11月20日・金）――仲間割れ
    ############################################################################
    scene black
    with dissolve
    $ set_cal("11月20日（金）", "放課後")
    scene bg kohoku_ground_eve
    with dissolve
    $ bgm("あたたかいアコースティックギター")
    "{rb}三好{/rb}{rt}みよし{/rt}先輩の、最後の練習の日だった。"
    "3年は、三好先輩ひとり。引退式といっても、グラウンドの真ん中で、輪になっただけだった。"
    show miyoshi smile
    with dissolve
    miyoshi "えー、じゃあ、引退のあいさつ！"
    sakaguchi "もう泣いてるじゃん"
    miyoshi "泣いてねえ！"
    "泣いていた。"
    miyoshi "……俺さ、中学の3年間、ずっと補欠だった。高校に入ったら、部員が3人だった"
    miyoshi "それでも毎日来てたのは、いつか11人で試合がしたかったからだ"
    if ch3_semi_goal:
        miyoshi "それが、ベスト4だぞ。……{rb}桜嶺{/rb}{rt}おうりょう{/rt}から、点取ったんだぞ。お前ら、ほんとに、すげえよ"
    else:
        miyoshi "それが、ベスト4だぞ。桜嶺に、0−9から、[ch3_semi]だぞ。お前ら、ほんとに、すげえよ"
    miyoshi "ありがとな。……以上！"
    "拍手が、なかなかやまなかった。"
    hide miyoshi
    with dissolve

    show takano jersey_narrow
    with dissolve
    takano "……最後に、一個いいすか"
    "鷹野が、輪の真ん中に出てきた。俺の前で止まる。"
    if ch3_rumor == "hide":
        takano "「なんでもない」って書いたよな、お前"
        takano "試合のあと、14番が言ってたぞ。「お前んとこの真ん中、春からうちに来るんだろ」って"
        "空気が、凍った。"
        sakaguchi "……は？　ひざのことって、言ってたじゃん"
        $ bond_up("坂口", -4)
    else:
        takano "桜嶺の監督に、誘われたんだろ"
    takano "……行くのかよ"
    "全員が、俺を見ていた。三好先輩も。{rb}大門{/rb}{rt}だいもん{/rt}も。{rb}坂口{/rb}{rt}さかぐち{/rt}も。"
    "ひなたが、ストップウォッチを握りしめていた。"
    menu:
        "「行かない」":
            $ ch3_fight = "no"
            $ bond_up("鷹野", 3)
            takano "……そうかよ"
            "鷹野は、それ以上何も言わなかった。でも、信じた顔ではなかった。"
            miyoshi "ほらな！　行くわけないだろ、{rb}蓮{/rb}{rt}れん{/rt}が！"
            "三好先輩の声だけが、やけに明るかった。"
            "行かない。そう言った自分の声が、どこか遠くに聞こえた。"
            $ set_flag("ch3_行かないと言った")
        "「……まだ、決められない」":
            $ ch3_fight = "undecided"
            $ bond_up("鷹野", -8)
            $ bond_up("坂口", -3)
            show takano jersey_surprised
            takano "決めてねえのが、答えだろ"
            "鷹野は、足もとのボールを、思いきりフェンスに蹴りつけた。"
            $ se("鈍い衝突音")
            takano "迷うくらいなら、最初から来んなよ。……こんなチームに"
            sakaguchi "鷹野、それ言いすぎ――"
            takano "うるせえ！"
            hide takano
            with dissolve
            "鷹野は、グラウンドを出ていった。"
            daimon "た、鷹野くん！"
            sakaguchi "……ウケねえよ。全然ウケねえ"
        "「……行くかもしれない」":
            $ ch3_fight = "maybe"
            $ lean("野心型")
            $ bond_up("鷹野", -12)
            $ bond_up("坂口", -5)
            $ bond_up("大門", -3)
            "鷹野の手が、俺の胸ぐらをつかんだ。"
            if flags.get("鷹野_俺に出せ"):
                takano "……お前が、言ったんだぞ。「俺に出せ」って。「一人で抜かなくていい」って"
            else:
                takano "……お前が、言ったんだぞ。『11人そろえる』って。……そろえて、自分だけ抜けんのかよ"
            miyoshi "鷹野、やめろ！"
            "三好先輩が、二人のあいだに体をねじこんだ。"
            takano "行けよ。どこにでも"
            hide takano
            with dissolve
            "鷹野は、手を離して、グラウンドを出ていった。"
            "誰も、追いかけなかった。追いかけられなかった。"
    $ set_flag("ch3_fight", ch3_fight)

    ## キャプテンマーク
    scene black
    with dissolve
    scene bg clubroom
    with dissolve
    $ bgm("静かな春の曲")
    "練習のあと、三好先輩に部室に呼ばれた。"
    show miyoshi uniform
    with dissolve
    miyoshi "……さっきは、悪かったな。あいつも、悪気があるわけじゃない"
    ren "分かってます"
    miyoshi "あいつ、お前のことが好きなんだよ。……サッカーの話な"
    "三好先輩は、ロッカーの奥から、色あせた腕章を出した。"
    "黄色い布に、黒い字で「C」。"
    miyoshi "これ、俺が1年のときの先輩から、もらったやつ"
    miyoshi "次のキャプテンに、渡す。……蓮、お前だ"
    "腕章が、目の前に差し出された。"
    menu:
        "受け取る":
            $ ch3_armband = "ren"
            $ bond_up("三好", 5)
            $ up("メンタル", 3)
            scene cg ch3_armband at cam_push(10.0, 1.05)
            with Dissolve(1.0)
            "腕章は、思っていたより、ずっと軽かった。"
            "軽いのに、手のひらから、なかなか離せなかった。"
            miyoshi "どっちに行くにしても、今日から大晦日までは、お前が{rb}港北{/rb}{rt}こうほく{/rt}のキャプテンだ"
            miyoshi "……それ持って、ちゃんと考えろ。逃げずにな"
            $ learn("captain")
        "「鷹野に、渡してほしいです」":
            $ ch3_armband = "takano"
            $ bond_up("鷹野", 6)
            $ lean("仲間型")
            show miyoshi uniform
            miyoshi "……鷹野に？"
            ren "今、いちばん港北のことを考えてるのは、あいつです"
            "三好先輩は、しばらく腕章を見ていた。"
            miyoshi "……そうかもな。あいつ、今日、泣きそうな顔してたもんな"
            miyoshi "分かった。でも、蓮。それは、お前が港北からいなくなるって意味じゃないよな？"
            "答えられなかった。"
            miyoshi "……大晦日までに、答え出しとけよ"
            $ learn("captain")
    hide miyoshi
    with dissolve
    $ set_flag("ch3_armband", ch3_armband)
    $ set_flag("三好_引退")

    ############################################################################
    ## 防波堤の紗希（12月5日・土）――「あなたも、あの人の駒なの？」
    ############################################################################
    scene black
    with dissolve
    $ set_cal("12月5日（土）", "夕方")
    scene bg harbor_winter_eve
    $ coat_on()
    with Dissolve(1.0)
    $ se("波の音、カモメ")
    $ bgm("静かなピアノの旋律")
    "{rb}桜嶺{/rb}{rt}おうりょう{/rt}は、決勝も勝った。年末から、東京で全国大会だ。新聞の地方の面に、{rb}神城{/rb}{rt}かみしろ{/rt}の写真が小さく載っていた。"
    "冬の防波堤で、一人でボールを蹴った。ひざに負担をかけないように、インサイドで、壁に当てるだけ。"
    "誰かが、すぐ後ろに立っていた。"
    show saki normal
    with dissolve
    if flags.get("ch3_saki_nov"):
        saki "……まだ蹴ってる。言ったのに"
    else:
        saki "……ひざ。悪いんでしょ"
    "[saki_call]だった。マフラーに、鼻の下まで顔をうずめている。"
    ## 第2章の満員電車の一言を、自由行動でまだ回収していない人だけ（二度は出ない）
    if ch2_saki_word and not flags.get("ch3_紗希_電車"):
        call ch3_saki_train
        "それだけ言うと、[saki_call]は、少しのあいだ黙った。"
    saki "準決勝のあと、通路で、あの人と話してた"
    ren "……見てたのか"
    if flags.get("紗希_準々決勝を見た"):
        saki "準々決勝も、見てた。……走りすぎ"
    show saki frown
    saki "あの人、何て言ったの。「来い」って？"
    ren "……ああ"
    saki "早瀬、蓮。……でしょ"
    "名乗った覚えは、一度もなかった。"
    ren "……なんで、俺の名前"
    saki "……夏に家に帰ったとき、あの人の机にあった名簿で、見た"
    "[saki_call]は、海のほうを見た。"
    voice "audio/voice/saki_ku.mp3"
    saki "…………"
    voice "audio/voice/saki_koma.mp3"
    saki "あなたも、あの人の駒なの？"
    $ bgm("（止まる）")
    ren "あの人って――"
    voice "audio/voice/saki_chichi.mp3"
    saki "{rb}鬼塚源三{/rb}{rt}おにづかげんぞう{/rt}。……私の、父"
    if flags.get("ch3_紗希_父"):
        ## 第2章の花火の夜に「父が合宿。……サッカーの」と聞いている
        "花火の夜、「父が合宿。……サッカーの」と聞いていた。"
    "楽譜の端に書いてあった名字。桜嶺の監督と同じ名字だとは、気づいていた。"
    "……まさか、と思っていた。"
    "言葉にされると、波の音が、急に大きくなった。"
    saki "「本物は、壊れない」。……あの人の口ぐせ"
    "壊れるまで使って、壊れたら、捨てる。――そういう意味だと、[saki_call]は言った。"
    saki "兄も、そう。桜嶺の10番だった。ひざが痛いって、最後まで言えなかった"
    ren "……今は"
    saki "もう、ボールにさわらない"
    if flags.get("紗希_祖母の家"):
        "[saki_call]が、おばあちゃんの家にいる理由が、やっと分かった。"
    else:
        "[saki_call]が、家ではなくこの町にいる理由が、少しだけ分かった気がした。"
    $ set_flag("紗希_兄")
    saki "勝つためなら、人の足だって――"
    "[saki_call]は、そこで唇をかんで、それ以上、何も言わなかった。"
    "人の足だって。"
    $ memory("cg ren_down", "あの冬の決勝")
    "――あのタックルは、俺が決めたことじゃない。"
    "通路で聞いた{rb}神城{/rb}{rt}かみしろ{/rt}の声が、頭の中で重なった。"
    "じゃあ、誰が。"
    $ memory_off()
    menu:
        "「俺は、誰の駒にもならない」":
            $ heart_up("紗希", "ときめき", 6)
            $ lean("求道型")
            show saki normal
            saki "……みんな、最初はそう言う"
            saki "……その顔、さっきよりは、まし"
        "「……今、何て言いかけた」":
            ## 問いつめる返事なので、好意は上がらない（答えを知りたい気持ちが強くなる）
            $ lean("野心型")
            $ set_flag("ch3_紗希_問いつめた")
            show saki frown
            saki "……言ってない。何も"
            saki "聞きたいなら、本人に聞けば。……聞けるなら"
        "何も言わずに、隣に座る":
            $ heart_up("紗希", "信頼", 6)
            "防波堤のコンクリートは、冷たかった。"
            "[saki_call]は、少し迷ってから、こぶし二つぶん離れて座った。"
            "しばらく、二人で、暗くなっていく海を見ていた。"
            saki "……変な人"
    saki "年が明けたら、返事するんでしょ。……どこに行くか"
    saki "決めたら、教えて。……あの人の口からは、聞きたくないから"
    hide saki
    with dissolve
    $ set_flag("ch3_紗希_駒")
    $ amb_stop()

    ############################################################################
    ## 12月の自由行動（2日）
    ############################################################################
    call ch3_free_loop("dec")

    jump ch3_xmas_invite


################################################################################
## クリスマスの誘い（12月21日・月）――二人に「行く」と返すと、鉢合わせ
################################################################################
define CH3_HID = {"ひなた": "hinata", "千夏": "chika", "紗希": "saki"}
define CH3_HNAME = {"hinata": "ひなた", "chika": "千夏先輩", "saki": "紗希"}

label ch3_xmas_invite:
    ## 終業式のあと：校門の鷹野（必ず通る場面。鷹野を気にかけると、絆が多く上がる）
    call ch3_takano_closing
    scene black
    with dissolve
    $ set_cal("12月21日（月）", "夜")
    scene bg ren_room_night
    with dissolve
    $ bgm("静かな夜の曲")
    "終業式の夜。カレンダーの24日に、まだ何も書いていなかった。"
    python:
        ## 紗希は、チケットをもらっていれば（気持ちの強さに関係なく）選べる。もらっていなければ誘われない
        _inv = [h for h in ch3_xmas_inviters() if h != "紗希"] + (["紗希"] if flags.get("紗希_チケット") else [])
    if not _inv:
        "クリスマスの予定は、何もなかった。部のグループに、{rb}大門{/rb}{rt}だいもん{/rt}の「24日、部室でクリスマス会しませんか」が流れてきた。"
        jump ch3_xmas_decide
    $ ch3_xmas_yes = []
    ## 紗希のチケットがあるときは、トークの前に思い出す。その瞬間に、ほかの人からの連絡が来る（紗希の返事は最後に決める）
    if "紗希" in _inv:
        $ _inv = [h for h in _inv if h != "紗希"] + ["紗希"]
        "机の引き出しの、細長い紙を思い出した。10月に、ピアノの家の前で押しつけられたチケット。――24日、19時。"
        if len(_inv) > 1:
            "引き出しに手をかけた、そのときだった。"
    $ _i = 0
    while _i < len(_inv):
        call expression "ch3_invite_" + CH3_HID[_inv[_i]]
        $ _i += 1
    jump ch3_xmas_decide

label ch3_takano_closing:
    scene black
    with dissolve
    $ set_cal("12月21日（月）", "終業式のあと")
    scene bg kohoku_gate_winter
    $ coat_on()
    with dissolve
    $ bgm("少しとがった曲")
    "終業式が終わって、校門を出ようとしたとき、うしろから呼び止められた。"
    show takano narrow
    with dissolve
    takano "……おい"
    if ch3_fight in ("undecided", "maybe") and not flags.get("ch3_takano_dec"):
        "引退の日から、{rb}鷹野{/rb}{rt}たかの{/rt}のほうから話しかけてきたのは、これが初めてだった。"
    if ch3_armband == "takano":
        "鷹野の腕で、黄色い腕章が揺れていた。"
        takano "冬休みも、グラウンド開ける。……これ巻いてると、鍵当番なんだよ"
    else:
        takano "冬休み、グラウンド開けとけよ。……キャプテンだろ、お前"
    takano "で。来るのか、来ねえのか"
    menu:
        "「毎日行く。お前に出す」":
            $ bond_up("鷹野", 6)
            takano "……毎日は、ひざが死ぬだろ。二日に一回でいい"
            "鷹野は、先に校門を出ていった。いつもより、早足だった。"
        "「行ける日は行く。……年明けの返事も、ちゃんと言う」":
            $ bond_up("鷹野", 3)
            $ up("無理ゲージ", -4)
            takano "……当たり前だ"
    hide takano
    with dissolve
    return

## 誘いへの返事。もう「行く」と返した相手がいるときは、選択肢の文が変わる
init python:
    def ch3_yes_label(base):
        if store.ch3_xmas_yes:
            return base + "（……もう一つの約束のことは、あとで考える）"
        return base

label ch3_invite_hinata:
    ## ひなたの誘いは、ビデオ通話で（トークだと眉毛が見えないから。v0.27.0）
    $ se("トークアプリの通知音")
    window auto hide
    $ talk_start("ひなた", "21:03")
    $ talk("ひなた", "ねえ、24日って空いてる？")
    $ talk("ひなた", "……やっぱり、ビデオにする")
    $ talk_system("ひなたがビデオ通話を開始しました")
    $ se("スマホの着信（ビデオ通話）")
    window auto hide
    $ talk_end()
    scene cg hinata_video at cam_push(10.0, 1.04)
    with Dissolve(0.8)
    ## v0.29.6：食堂（蓮の家の一階）からではなく、ひなたの部屋から。髪を下ろした、お風呂上がりのひなた
    "出ると、画面いっぱいにひなたが映った。一瞬、誰だか分からなかった。"
    "いつものポニーテールじゃない。前髪だけを上でちょこんと結んで、残りの髪は肩に下ろしている。うしろには、見覚えのある勉強机。ひなたの部屋だ。"
    hinata "……なに？"
    ren "いや。……髪"
    hinata "あ"
    "ひなたは、あわてて髪を手でまとめようとして、途中でやめた。"
    hinata "……いいでしょ、別に。お風呂上がりなんだから"
    hinata "トークだと、眉毛が見えないから。大事なことは、顔見て聞くって決めてるの"
    hinata "24日の17時から、お店で子ども食堂のクリスマス会やるの。千鶴さんに頼まれた"
    hinata "手伝ってくれる？　……終わったあと、ちょっとだけ時間ある？"
    menu:
        "「行く。終わったあとも、空けとく」" if not ch3_xmas_yes:
            ren "行く。終わったあとも、空けとく"
            "画面の中のひなたが、ぐっと顔を近づけた。"
            hinata "……眉毛、上がってない"
            hinata "ほんとだ"
            "ひなたは、手のひらで、少しだけ顔を隠した。"
            $ ch3_xmas_yes = ch3_xmas_yes + ["hinata"]
            $ heart_up("ひなた", "ときめき", 3)
        "「行く。終わったあとも、空けとく」（……もう一つの約束のことは、あとで考える）" if ch3_xmas_yes:
            ren "行く。終わったあとも、空けとく"
            "画面の中のひなたが、ぐっと顔を近づけた。"
            hinata "……眉毛、ちょっとだけ上がってる。……でも、信じる"
            $ ch3_xmas_yes = ch3_xmas_yes + ["hinata"]
            $ heart_up("ひなた", "ときめき", 2)
        "「ごめん、その日は……」":
            ren "ごめん、その日は……"
            hinata "……そっか"
            hinata "眉毛、上がってないね。……ほんとに、用事なんだ"
            hinata "じゃあ、お店だけでも。ケーキ、余ったら取っとくね"
            $ heart_up("ひなた", "さみしさ", 5)
    "画面が、ひなたの「おやすみ」の口の形のまま、止まった。"
    scene bg ren_room_night
    with dissolve
    $ talk_start("ひなた", "21:09")
    $ talk_system("ビデオ通話が終了しました（5:48）")
    window auto hide
    $ talk_end()
    return

label ch3_invite_chika:
    $ se("トークアプリの通知音")
    window auto hide
    $ talk_start("千夏", "21:40")
    $ talk("千夏", "24日の17時、生徒会室の片付けを手伝ってもらえませんか")
    $ talk("千夏", "……そのあと、見せたいものがあります")
    $ ch3_r = talk_choose([(ch3_yes_label("行きます"), "yes"), ("すみません、その日は……", "no")])
    if ch3_r == "yes":
        $ talk_me("行きます")
        $ talk("千夏", "遅刻は認めません")
        $ talk("千夏", "……ありがとうございます")
        $ ch3_xmas_yes = ch3_xmas_yes + ["chika"]
    else:
        $ talk_me("すみません、その日は……")
        $ talk("千夏", "そうですか。了解しました")
        $ talk("千夏", "よいクリスマスを")
        $ heart_up("千夏", "さみしさ", 5)
    window auto hide
    $ talk_end()
    return

label ch3_invite_saki:
    "引き出しから出した、細長い紙。「冬のピアノ発表会　12月24日　19時　{rb}潮見{/rb}{rt}しおみ{/rt}市民ホール」。裏に、小さな字で「来なくていい。　S」"
    menu:
        "行く" if not ch3_xmas_yes:
            $ ch3_xmas_yes = ch3_xmas_yes + ["saki"]
            "来なくていい、と書く人は、たぶん、来てほしい人だ。"
        "行く（……もう一つの約束のことは、あとで考える）" if ch3_xmas_yes:
            $ ch3_xmas_yes = ch3_xmas_yes + ["saki"]
            "来なくていい、と書く人は、たぶん、来てほしい人だ。"
        "行かない":
            $ heart_up("紗希", "さみしさ", 5)
            "チケットを、引き出しに戻した。"
    return

label ch3_xmas_decide:
    if not ch3_xmas_yes:
        $ ch3_xmas = "boys"
        if _inv:
            ## 誘いを全部断ったとき：大門のクリスマス会のお知らせは、ここで見る
            "スマホを置こうとしたとき、部のグループに、{rb}大門{/rb}{rt}だいもん{/rt}の「24日、部室でクリスマス会しませんか」が流れてきた。"
        jump ch3_xmas_boys
    if len(ch3_xmas_yes) == 1:
        $ ch3_xmas = ch3_xmas_yes[0]
        jump expression "ch3_xmas_" + ch3_xmas
    ## 二人以上に「行く」と返した → 鉢合わせ
    jump ch3_xmas_clash


################################################################################
## 修羅場：クリスマスの鉢合わせ（12月24日・木）
################################################################################
label ch3_xmas_clash:
    ## 紗希は19時から発表会があるので、いつも「あとから来る側（B）」にする
    python:
        _ord = [h for h in ch3_xmas_yes if h != "saki"]
        if "saki" in ch3_xmas_yes:
            _ord.insert(1, "saki")
        ch3_xmas_yes = _ord
    $ _a = ch3_xmas_yes[0]
    $ _b = ch3_xmas_yes[1]
    $ _an = CH3_HNAME[_a]
    $ _bn = CH3_HNAME[_b]
    scene black
    with dissolve
    $ set_cal("12月24日（木）", "夜")
    "24日。[_an]の用事は、17時から。"
    if _b == "saki":
        "[_bn]の発表会は19時から。市民ホールは駅前の広場の向かいだ。17時の用事を早めに抜ければ、間に合うと思っていた。"
    elif _b == "hinata":
        "ひなたには、「手伝いは途中から行く。終わったら、19時に駅前のツリーの前で」と送った。それで大丈夫だと思っていた。"
    else:
        "[_bn]には、19時に駅前のツリーの前、と時間をずらしてもらった。それで大丈夫だと思っていた。"
    "どっちも、デートってわけじゃない。……たぶん。"
    scene bg station_xmas_night
    $ coat_on()
    with Dissolve(1.0)
    $ bgm("あたたかいアコースティックギター")
    "18時50分。[_an]との時間が長くなって、気がつくと、駅前の広場の大きなツリーの前まで来ていた。"
    call expression "ch3_clash_a_" + _a
    "そのとき、ツリーの向こうから、聞き覚えのある声がした。"
    $ bgm("（止まる）")
    call expression "ch3_clash_b_" + _b
    ## 顔を合わせた二人の、ひとこと
    call ch3_clash_words(_a, _b)
    "[_an]も、[_bn]も、俺の顔を見ていた。"
    "どっちの顔も、まっすぐには見られなかった。"
    menu:
        "（[_an]のそばにいる）":
            $ ch3_xmas = _a
            $ ch3_xmas_left = _b
        "（[_bn]を追いかける）":
            $ ch3_xmas = _b
            $ ch3_xmas_left = _a
    $ _ln = {"hinata": "ひなた", "chika": "千夏", "saki": "紗希"}[ch3_xmas_left]
    $ heart_up(_ln, "ときめき", -15)
    $ heart_up(_ln, "信頼", -10)
    $ heart_up(_ln, "さみしさ", 10)
    $ set_flag("修羅場_クリスマス", ch3_xmas_left)
    call expression "ch3_clash_left_" + ch3_xmas_left
    ## 三人目にも「行く」と返していたら、その子は待ちぼうけ
    if len(ch3_xmas_yes) >= 3:
        $ _cn = {"hinata": "ひなた", "chika": "千夏", "saki": "紗希"}[ch3_xmas_yes[2]]
        $ heart_up(_cn, "ときめき", -10)
        $ heart_up(_cn, "さみしさ", 10)
        $ _cn2 = {"hinata": "ひなた", "chika": "千夏先輩", "saki": saki_call}[ch3_xmas_yes[2]]
        "……[_cn2]との約束を思い出したのは、その夜、ずっとあとになってからだった。"
    jump expression "ch3_xmas_" + ch3_xmas

## 先に会っていた側（A）
label ch3_clash_a_hinata:
    show hinata smile at left
    with dissolve
    "ひなたは、子ども食堂で余ったケーキの箱を、大事そうに抱えていた。"
    hinata "{rb}千鶴{/rb}{rt}ちづる{/rt}さんに、少し抜けていいって。……ねえ、このあと、港のほうまで歩かない？"
    return
label ch3_clash_a_chika:
    show chika soft at left
    with dissolve
    "{rb}千夏{/rb}{rt}ちか{/rt}先輩は、片付けのあと、紙袋を一つ持ってきていた。"
    chika "……見せたいものは、ここでは出せません。場所を変えます"
    return

## あとから来た側（B）
label ch3_clash_b_hinata:
    show hinata stare at right
    with dissolve
    hinata "……{rb}蓮{/rb}{rt}れん{/rt}？"
    "エプロンの上にコートを羽織ったままのひなたが、立っていた。"
    hinata "手伝い、来なかったから。千鶴さんに、少し抜けていいって。……迎えに、来たの"
    "ひなたの目が、俺のとなりに移った。"
    show hinata forcesmile at right
    hinata "……そっか。そういうこと、だったんだ"
    return
label ch3_clash_b_chika:
    show chika narrow at right
    with dissolve
    chika "……{rb}早瀬{/rb}{rt}はやせ{/rt}くん"
    "時間より早く来るのは、{rb}千夏{/rb}{rt}ちか{/rt}先輩の、いつものことだった。"
    "千夏先輩は、俺のとなりを見て、カメラのストラップを、指に強く巻きつけた。"
    chika "……お取り込み中、でしたか"
    return
label ch3_clash_b_saki:
    show saki frown at right
    with dissolve
    "白いコートの[saki_call]が、楽譜の束を抱えて立っていた。"
    saki "……開演前。外の空気、吸いに来ただけ"
    "[saki_call]の目が、俺のとなりで止まった。"
    saki "……やっぱり"
    "[saki_call]は、それ以上、何も言わなかった。"
    return

## 鉢合わせた二人のひとこと（a：先に会っていた側、b：あとから来た側）
label ch3_clash_words(_wa, _wb):
    if _wa == "hinata" and _wb == "chika":
        chika "……{rb}篠宮{/rb}{rt}しのみや{/rt}さん。マネージャーの仕事は、今日はお休みですか"
        hinata "……お店の手伝いです。生徒会長さんこそ、見回りですか"
        "千夏先輩は、答えなかった。ひなたも、ケーキの箱を持つ手をゆるめなかった。"
    elif _wa == "chika" and _wb == "hinata":
        hinata "……生徒会長さん。こんばんは"
        chika "こんばんは、{rb}篠宮{/rb}{rt}しのみや{/rt}さん。……エプロンのままですよ"
        "ひなたは、自分のエプロンを見下ろして、コートの前をぎゅっと合わせた。"
    elif _wa == "hinata" and _wb == "saki":
        saki "……誰"
        hinata "幼なじみ、だけど。……そっちこそ、誰"
        "[saki_call]は、答えなかった。"
    elif _wa == "chika" and _wb == "saki":
        saki "……誰"
        chika "港北高校の生徒会長、{rb}七瀬{/rb}{rt}ななせ{/rt}です。……あなたこそ、どなたですか"
        saki "関係ないでしょ"
    return

## 選ばなかった子の、最後のひとこと
label ch3_clash_left_hinata:
    if ch3_xmas_yes[0] == "hinata":
        "ひなたは、ケーキの箱を、俺の胸に押しつけた。"
    hinata "……メリークリスマス"
    "笑っていた。眉毛は、たぶん、上がっていなかった。"
    "そのまま、ひなたは人ごみの中に消えた。走らずに。ゆっくりと。"
    hide hinata
    with dissolve
    return
label ch3_clash_left_chika:
    chika "規則には、書いてありませんでした。……こういうときの決まりは"
    "{rb}千夏{/rb}{rt}ちか{/rt}先輩は、紙袋を、そっと後ろに隠した。"
    chika "失礼します"
    hide chika
    with dissolve
    "背筋をのばしたまま、一度も振り返らなかった。"
    return
label ch3_clash_left_saki:
    saki "そういう人だと思ってた。……ばか"
    saki "来なくていいって、書いたでしょ"
    "[saki_call]は、楽譜で顔を隠すようにして、ホールのほうへ歩いていった。"
    "その背中が、小さくふるえていた。寒さのせいかどうかは、分からなかった。"
    hide saki
    with dissolve
    return


################################################################################
## クリスマス（12月24日・木）
################################################################################
label ch3_xmas_hinata:
    scene black
    with dissolve
    $ set_cal("12月24日（木）", "夜")
    scene bg shokudo_night
    with dissolve
    $ bgm("あたたかいアコースティックギター")
    if ch3_xmas_left:
        "ひなたと二人で、店に戻った。"
    else:
        "子ども食堂のクリスマス会は、思っていたよりずっと、にぎやかだった。"
        "小さい子たちに、ゆずが紙の王冠を配っている。母さんは、から揚げを三回も揚げ直していた。"
    "片付けが終わったのは、9時すぎだった。"
    show hinata apron
    with dissolve
    if ch3_xmas_left:
        hinata "……さっきのことは、今日は聞かない"
    hinata "……はい、これ"
    "ひなたが、包装紙につつんだ、小さな包みを出した。"
    "中には、手縫いのひざのサポーターが入っていた。"
    hinata "本で調べて、作ったの。テーピングの上からでも、つけられるように"
    hinata "下手だけど。……右ひざ専用"
    menu:
        "「ありがとう。……毎日つける」":
            $ heart_up("ひなた", "ときめき", 6)
            hinata "毎日は、だめ。休む日も、ちゃんと作って"
            "ひなたは、そう言って、笑った。"
        "「……俺、何も用意してない」":
            $ heart_up("ひなた", "信頼", 5)
            hinata "知ってる。{rb}蓮{/rb}{rt}れん{/rt}だもん"
            hinata "じゃあ、来年のクリスマスも、ここで手伝って。それでいい"
    if flags.get("ひなた_来年の花火"):
        hinata "花火の約束も、あるからね。来年は、いっしょに"
    "来年。"
    "その来年を、どこで迎えるのか。ひなたは、聞かなかった。"
    hide hinata
    with dissolve
    $ heart_up("ひなた", "ときめき", 3)
    jump ch3_nye

label ch3_xmas_chika:
    scene black
    with dissolve
    $ set_cal("12月24日（木）", "夜")
    scene bg student_council_night
    with dissolve
    $ bgm("静かな夜の曲")
    if ch3_xmas_left:
        "千夏先輩と二人で、学校に戻った。"
    "夜の生徒会室は、電気ストーブの音だけがしていた。"
    show chika soft
    with dissolve
    chika "……見せたいものは、これです"
    "{rb}千夏{/rb}{rt}ちか{/rt}先輩が、紙袋から一冊のアルバムを出した。"
    "表紙に、手書きで「{rb}港北{/rb}{rt}こうほく{/rt}サッカー部　一年目」。"
    "雨の5月31日。1回戦の、PKのあとの人の山。合宿の夜の、体育館の扉。準決勝の、仰向けの{rb}三好{/rb}{rt}みよし{/rt}先輩。"
    "ページをめくるたびに、知っている顔があった。"
    "最後のページには、色あせた写真が一枚だけ、貼ってあった。"
    "スタンドで、手作りの旗を振っている、中学生くらいの女の子。"
    "部室のアルバムで見た写真と、同じ子だった。"
    chika "……4年前。港北が、県のベスト8まで行った年です"
    chika "これ、私です"
    if flags.get("千夏_旗"):
        chika "……準決勝の前、旗を振ってくださいと言われたとき。……心臓が止まるかと思いました"
    "千夏先輩は、写真を指でなぞった。"
    chika "兄が、ここのサッカー部でした。あの年の、キャプテンでした"
    chika "兄の代が引退して、部員が減って、去年は、毎日来るのは三好先輩一人になって。……なくなるのを、ずっと、記録していました"
    chika "でも、今年は、なくならなかった"
    menu:
        "「先輩が、ずっと見ててくれたからです」":
            $ heart_up("千夏", "ときめき", 6)
            show chika narrow
            chika "……見ていただけです。何もしていません"
            "そう言いながら、千夏先輩は、アルバムを俺の胸に押しつけた。"
            chika "これは、あなたが持っていてください"
        "「このアルバム、続きも作ってください」":
            $ heart_up("千夏", "信頼", 6)
            chika "……続き、ですか"
            chika "学校がなくなっても。……ええ。作ります。約束します"
    $ set_flag("千夏_旗の子")
    hide chika
    with dissolve
    jump ch3_nye

label ch3_xmas_saki:
    scene black
    with dissolve
    $ set_cal("12月24日（木）", "夜")
    scene bg recital_hall
    with dissolve
    $ bgm("（なし）")
    "市民ホールの客席は、半分も埋まっていなかった。"
    "最前列の、いちばん端の席が一つ、ずっと空いていた。"
    "「{rb}鬼塚紗希{/rb}{rt}おにづかさき{/rt}」と、プログラムの最後に書いてあった。"
    scene cg saki_recital at cam_push(14.0, 1.05)
    with Dissolve(1.2)
    "[saki_call]が、ステージに出てきた。白いドレスに、いつもの短い髪。"
    $ bgm("静かなピアノの旋律")
    "弾き始めた曲は、防波堤で何度も聴いた曲だった。"
    "いつも止まる、あの場所が近づいてくる。"
    "[saki_call]の指が、一瞬だけ、止まりかけた。"
    "客席の端の、空いた席のほうを、一度だけ見た。"
    "それから、俺のほうを見た。"
    "――指が、動いた。"
    "曲は、止まらなかった。最後まで、流れた。"
    "拍手は、まばらだった。俺は、手が痛くなるまで叩いた。"
    scene black
    with dissolve
    scene bg recital_hall
    with dissolve
    show saki normal
    with dissolve
    saki "……来なくていいって、書いたのに"
    voice "audio/voice/saki_hajimete.mp3"
    saki "最後まで弾けたの、初めて"
    saki "いつも、あの人の来ない席を見て、止まってた"
    saki "……今日は、うるさいのが一人いたから"
    menu:
        "「いい曲だった。最後まで聴けてよかった」":
            $ heart_up("紗希", "ときめき", 7)
            saki "……曲名、知らないくせに"
            saki "アンダンテ。歩くくらいの速さで、って意味"
        "「……お父さんの席、空いてたな」":
            $ heart_up("紗希", "信頼", 7)
            saki "毎年よ。……冬は、全国の前だから"
            saki "……今年は、どうでもよかった"
    $ set_flag("紗希_最後まで弾けた")
    hide saki
    with dissolve
    jump ch3_nye

## 発表会に行かなかったとき：12月26日の防波堤
label ch3_saki_missed:
    scene black
    with dissolve
    $ set_cal("12月26日（土）", "夕方")
    scene bg harbor_winter_eve
    $ coat_on()
    with dissolve
    $ se("波の音、カモメ")
    $ bgm("（なし）")
    "防波堤の先に、見覚えのある短い髪が座っていた。ひざの上に、楽譜……いや、細長い、市民ホールのプログラム。"
    show saki normal
    with dissolve
    voice "audio/voice/saki_betsuni.mp3"
    saki_v "……別に"
    "まだ何も言っていないのに、[saki_call]は先にそう言った。"
    saki_v "来なくていいって、書いたし。来なかったのは、正しい"
    show saki frown
    saki_v "……途中で、止まった。いつもの場所で"
    saki_v "空いてる席が、一つから二つになっただけ。……どうってことない"
    menu:
        "「……ごめん」":
            $ heart_up("紗希", "信頼", 2)
            saki_v "謝られることじゃない。……でも、覚えとく"
        "「次は、行く」":
            $ heart_up("紗希", "ときめき", 2)
            saki_v "次なんて、決まってない"
            "そう言いながら、[saki_call]はプログラムを、たたまずにカバンにしまった。"
    $ heart_up("紗希", "さみしさ", 4)
    $ set_flag("紗希_発表会に行かなかった")
    hide saki
    with dissolve
    "海風が、プログラムの端をめくって、すぐにやんだ。"
    return

label ch3_xmas_boys:
    scene black
    with dissolve
    $ set_cal("12月24日（木）", "夜")
    scene bg clubroom_night_rain
    with dissolve
    $ bgm("とぼけた日常の曲")
    "部室のクリスマス会は、から揚げとポテトチップスだけだった。"
    "引退したはずの{rb}三好{/rb}{rt}みよし{/rt}先輩が、いちばん最初に来ていた。"
    sakaguchi "男だけのクリスマス。ウケる"
    daimon "ぼ、僕は、楽しいです"
    kiryu "{rb}大門{/rb}{rt}だいもん{/rt}、ずっとそれ言ってる"
    "部室のドアが開いた。"
    show takano casual
    with dissolve
    "{rb}鷹野{/rb}{rt}たかの{/rt}が、コンビニのケーキを片手に立っていた。"
    if ch3_fight in ("undecided", "maybe"):
        takano "……三好先輩に呼ばれたから来ただけだ"
        "鷹野は、俺のとなりにだけは座らなかった。"
        "それでも、ケーキを切るとき、いちばん大きいのを、黙って俺の前に置いた。"
        takano "……あの日のこと、謝んねえからな"
        takano "でも、決めたら、俺に最初に言え。……三好先輩より先に"
        $ bond_up("鷹野", 6)
    else:
        takano "……ケーキ、余ってたから"
        sakaguchi "鷹野が来た。ウケる"
        takano "うるせえ"
        $ bond_up("鷹野", 4)
    hide takano
    with dissolve
    "窓の外で、雪にならない雨が降っていた。"
    "10人と、引退した先輩と、マネージャーのいない、くだらないクリスマスだった。"
    "たぶん、一生忘れない。"
    $ bond_up("大門", 3)
    $ bond_up("坂口", 3)
    jump ch3_nye


################################################################################
## 大晦日（12月31日・木）――「残るか、移るか。――蓮が決めて」
################################################################################
label ch3_nye:
    ## 紗希のチケットをもらっていたのに、発表会に行かなかったとき（鉢合わせで選ばなかったときは、その場で済んでいる）
    if flags.get("紗希_チケット") and ch3_xmas != "saki" and ch3_xmas_left != "saki":
        call ch3_saki_missed
    ## 関係が冷えたヒロインに、ほかの人が近づく兆し（chapter3_more.rpy。当てはまる人がいなければ何も出ない）
    call ch3_sign
    python:
        if ch3_xmas in ("hinata", "chika", "saki"):
            ch3_nye = ch3_xmas
        elif bond.get("鷹野", 0) >= CH3_NYE_TAKANO:
            ch3_nye = "takano"
        else:
            ch3_nye = "mother"
    scene black
    with Dissolve(1.5)
    $ set_cal("12月31日（木）", "大晦日")
    $ bgm("（なし）")
    mono "大晦日。俺は、選ばなければならない。"
    call expression "ch3_nye_" + ch3_nye
    jump ch3_choice

label ch3_nye_hinata:
    scene bg shokudo_night
    with dissolve
    $ bgm("あたたかいアコースティックギター")
    "年越しそばの出前が終わって、店の明かりを半分落とした。"
    show hinata apron
    with dissolve
    "ひなたが、カウンターの端で、ノートを開いていた。"
    hinata "……ねえ、{rb}蓮{/rb}{rt}れん{/rt}"
    hinata "わたしね、{rb}桜嶺{/rb}{rt}おうりょう{/rt}に行ってほしくない"
    hinata "ずっと隣で、テーピング巻いてたい。いっしょに花火見たい。来年も、再来年も"
    "ひなたは、ノートを閉じた。"
    hinata "でも、それ、わたしが決めることじゃないから"
    hinata "残るか、移るか。――{rb}蓮{/rb}{rt}れん{/rt}が決めて"
    hinata "どっちでも、眉毛、見ててあげる"
    hide hinata
    with dissolve
    return

label ch3_nye_chika:
    scene bg shrine_steps_night
    $ coat_on()
    with dissolve
    $ bgm("静かな夜の曲")
    "除夜の鐘には、まだ早い。町の神社の石段には、{rb}提灯{/rb}{rt}ちょうちん{/rt}だけが灯っていた。"
    "石段のいちばん下に、{rb}千夏{/rb}{rt}ちか{/rt}先輩が立っていた。"
    show chika normal
    with dissolve
    chika "……生徒会は、毎年、ここで{rb}甘酒{/rb}{rt}あまざけ{/rt}を配ります。始まるのは、0時からです"
    chika "あなたが来るとは思いませんでした"
    ren "……家にいても、考えがまとまらなくて。歩いてたら、ここに"
    "千夏先輩は、石段の上の鳥居を見上げた。"
    chika "春に、学校がどうなるかは、まだ決まっていません"
    chika "あなたがいなくなれば、サッカー部は、たぶん来年の夏まで持ちません"
    chika "……そう言えば、あなたは残るでしょう。だから、言いません"
    show chika soft
    voice "audio/voice/chika_kimete.mp3"
    chika "残るか、移るか。……{rb}蓮{/rb}{rt}れん{/rt}くんが、決めて"
    if flags.get("千夏_名前の練習"):
        "画面ごしに一度だけ聞いた呼び方だった。今度は、俺に向けて。"
    else:
        "先輩に名前で呼ばれたのは、初めてだった。"
    "千夏先輩は、言ってから、マフラーに口もとをうずめた。"
    chika "どちらを選んでも、私は、写真を撮ります。……あなたの"
    hide chika
    with dissolve
    return

label ch3_nye_saki:
    scene bg harbor_winter_eve
    $ coat_on()
    with dissolve
    $ se("波の音、カモメ")
    $ bgm("静かなピアノの旋律")
    "大晦日の夕方の防波堤に、[saki_call]がいた。"
    show saki normal
    with dissolve
    saki "……来ると思った"
    saki "あの人は、今年も来ない。毎年、年賀状が一枚来るだけ"
    saki "……今年も、東京。全国だから"
    saki "{rb}桜嶺{/rb}{rt}おうりょう{/rt}に行ったら、あなたも、兄みたいになるかもね。……ならないかも。知らない、そんなの"
    "[saki_call]は、マフラーをほどいて、海の風に髪をさらした。"
    voice "audio/voice/saki_kimete.mp3"
    saki "残るか、移るか。――{rb}蓮{/rb}{rt}れん{/rt}が決めて"
    "下の名前だけで呼ばれたのは、初めてだった。"
    saki "決めたら、教えて。約束でしょ"
    hide saki
    with dissolve
    $ amb_stop()
    return

label ch3_nye_takano:
    scene bg kohoku_fence_night
    $ coat_on()
    with dissolve
    $ bgm("少しとがった曲")
    "大晦日の夕方に、{rb}三好{/rb}{rt}みよし{/rt}先輩から、「夜、学校のグラウンドの前に行け」とだけトークが来た。"
    "フェンスの外の歩道に、{rb}鷹野{/rb}{rt}たかの{/rt}が、先にいた。金網の向こうのグラウンドは、真っ暗だった。"
    show takano casual
    with dissolve
    takano "……呼んだの、俺じゃねえからな。{rb}三好{/rb}{rt}みよし{/rt}先輩が、ここに行けって"
    "鷹野は、金網に指をかけて、暗いグラウンドを見ていた。"
    takano "合宿で言ったろ。俺は、上がれないって言われる前に、逃げた"
    takano "お前は、逃げんなよ"
    takano "残るなら、全国まで俺に出しつづけろ。行くなら、決勝で俺が止める"
    takano "残るか、移るか。……{rb}蓮{/rb}{rt}れん{/rt}が決めろ"
    "鷹野は、初めて、俺の名前を呼んだ。"
    hide takano
    with dissolve
    return

label ch3_nye_mother:
    scene bg shokudo_night
    with dissolve
    $ bgm("あたたかいアコースティックギター")
    "年越しそばの出前が終わって、母さんと二人で、カウンターに並んだ。"
    show mother normal
    with dissolve
    haha "……{rb}桜嶺{/rb}{rt}おうりょう{/rt}の監督さん、この前、店に来たよ"
    ren "え"
    haha "名刺だけ置いて、何も食べずに帰った。そば、冷めちゃった"
    show mother sadsmile
    ## 中3の2月に、柱の父の写真のことを聞いた人だけ（プロローグの自由行動）
    if flags.get("pro_父の写真"):
        haha "……2月に、柱の写真のこと、聞いたでしょ。あのときから、いつか話そうと思ってた"
    haha "お父さんもね、昔、大事なことを一人で決めなきゃいけないときがあったの"
    haha "あの人は、自分で決めた。……でも、決めたあとも、全部一人で抱えこんだ。母さんにも、何も言わずに"
    show mother smile
    haha "だから、決めるのは{rb}蓮{/rb}{rt}れん{/rt}でいい。でも、一人で抱えるのは、やめな"
    haha "残るか、移るか。――蓮が決めて"
    voice "audio/voice/haha_yaritai.mp3"
    haha "やりたいことやりな"
    hide mother
    with dissolve
    return


################################################################################
## 最後の選択（12月31日・夜の防波堤）
##   ここを選んだところで、無料で遊べる部分はおしまい
################################################################################
label ch3_choice:
    scene black
    with Dissolve(1.5)
    $ set_cal("12月31日（木）", "23時50分")
    scene bg harbor_newyear_night
    $ coat_on()
    with Dissolve(1.5)
    $ se("波の音、カモメ")
    $ bgm("静かなピアノの旋律")
    "夜の防波堤には、街灯が一本だけ灯っていた。"
    "右ひざに、冬の海の風が冷たい。"
    "遠くの町から、除夜の鐘が聞こえてくる。"
    "ポケットの中で、スマホが短くふるえた。"
    "{rb}神城{/rb}{rt}かみしろ{/rt}からだった。"
    window auto hide
    $ talk_start("神城 凌", "23:52")
    $ talk("神城", "春になったら、全部話す")
    $ talk("神城", "どっちを選んでも、話す。今度は、取り消さない")
    window auto hide
    $ talk_end()
    scene cg ch3_newyear at cam_push(14.0, 1.05)
    with Dissolve(1.5)
    "{rb}港北{/rb}{rt}こうほく{/rt}に残れば、仲間と一緒に、弱いまま、上を目指す。"
    "学校は、なくなるかもしれない。全国は、遠い。"
    "三好先輩が抜けて、部員は10人。4月に1年が入らなければ、11人にもならない。"
    "{rb}桜嶺{/rb}{rt}おうりょう{/rt}へ移れば、いちばん強い場所で、頂点だけを目指す。"
    "{rb}鬼塚{/rb}{rt}おにづか{/rt}監督の下で。神城と同じユニフォームで。……あのタックルの、答えのそばで。"
    if flags.get("紗希_兄"):
        "本物は、壊れない。――壊れたら、捨てられる。"
    if flags.get("神城_足首"):
        "何重にも巻かれた、神城の左の足首。"
    if ch3_armband == "ren":
        "コートのポケットの中で、{rb}三好{/rb}{rt}みよし{/rt}先輩の腕章を握った。"
    if ch3_fight == "no":
        "「行かない」と、みんなの前で言った。あの言葉は、本当だったのか。"
    ## 大晦日に話した人の、本音のひとこと
    if ch3_nye == "hinata":
        "――ずっと隣で、テーピング巻いてたい。"
    elif ch3_nye == "chika":
        "――どちらを選んでも、私は、写真を撮ります。"
    elif ch3_nye == "saki":
        "――決めたら、教えて。約束でしょ。"
    elif ch3_nye == "takano":
        "――行くなら、決勝で俺が止める。"
    else:
        "――やりたいことやりな。"
    ## 運命の選択の前の案内とセーブ（選んだ答えは、あとから取り消せない）
    window auto hide
    tuto "ここは「運命の選択」です。選んだあと、物語の中では取り消せません。"
    tuto "製品版の物語は、この選択から続きます。迷ったら、選ぶ前にセーブしておきましょう。"
    call screen save_prompt
    "除夜の鐘が、百八つ目を打った。"
    menu:
        "港北に残る":
            $ ch3_route = "stay"
            $ lean("仲間型", 2)
        "桜嶺へ移る":
            $ ch3_route = "move"
            $ lean("野心型", 2)
    $ set_flag("ch3_route", ch3_route)
    $ persistent.ch3_route_seen = True
    scene black
    with Dissolve(2.0)
    $ set_cal("1月1日（金）", "0時", quiet=True)
    if ch3_route == "stay":
        mono "年が明けた。"
        mono "俺は、港北に残る。"
        mono "弱いまま、上を目指す。このチームで。"
    else:
        mono "年が明けた。"
        mono "俺は、桜嶺へ行く。"
        mono "いちばん強い場所で、いちばん上を目指す。……あの答えのそばで。"
    call show_title("第3章　冬の扉", "完")
    jump trial_end


################################################################################
## 自由行動のしくみ（9月・10月・11月・12月で共通）
################################################################################
label ch3_free_loop(month):
    $ ch3_dates, ch3_time, ch3_banner, ch3_intro = CH3_FREE[month]
    $ ch3_month = month
    $ recap_text = ch3_recap(month)
    scene black
    with dissolve
    window auto hide
    tuto "自由行動です。[ch3_intro]"
    if month == "sep":
        tuto "行動マップの「港の防波堤」に、[saki_call]のイベントが出るようになりました。"
    if month == "nov":
        tuto "ひざが腫れています。技術とフィジカルの練習は、ひざへの負担がいつもの倍たまります。"
    $ ch3_day = 1
    while ch3_day <= len(ch3_dates):
        $ amb_stop()
        $ set_cal(ch3_dates[ch3_day - 1], ch3_time)
        $ bgm("作戦会議っぽい軽快な曲")
        window auto hide
        ## まず練習メニュー（practice.rpy）。そのあと、行動マップで会いに行く人を選ぶ
        call practice_day(month)
        $ set_cal(ch3_dates[ch3_day - 1], ch3_time)
        $ bgm("作戦会議っぽい軽快な曲")
        window auto hide
        call screen action_map(ch3_spots(month), ch3_banner + "（残り" + str(len(ch3_dates) + 1 - ch3_day) + "日）")
        $ ch3_dest = ch3_spot_label(month, _return)
        $ ch3_res = ""
        if ch3_dest != "ch3_practice":
            $ set_flag(ch3_dest)
        call expression ch3_dest
        $ amb_stop()
        $ _met = ""
        if renpy.has_label("ch3_talk_" + ch3_dest[4:]):
            call ch3_night_talk(ch3_dest)
            $ _met = night_met_of(ch3_dest)
        ## 毎晩、自分からもう1人にトークを送れる（nightcontact.rpy）
        call night_send(ch3_dates[ch3_day - 1], month, met=_met)
        $ ch3_day += 1
    $ amb_stop()
    return

label ch3_night_talk(lab):
    scene black
    with dissolve
    $ set_cal(ch3_dates[ch3_day - 1], "夜")
    scene bg ren_room_night
    with dissolve
    $ bgm("静かな夜の曲")
    $ se("トークアプリの通知音")
    window auto hide
    call expression "ch3_talk_" + lab[4:]
    window auto hide
    $ talk_end()
    return


################################################################################
## グラウンド：練習（その月の場面のうち、まだ見ていないものから1つ）
##   9〜11月は準決勝の前の場面、12月は三好先輩が引退したあとの場面
################################################################################
default ch3_practice_seen = []
default ch3_month = "sep"
define CH3_PRACTICE = {
    "sep": ["ch3_pr_set", "ch3_pr_mark", "ch3_pr_run", "ch3_pr_gk"],
    "oct": ["ch3_pr_set", "ch3_pr_mark", "ch3_pr_run", "ch3_pr_gk"],
    "nov": ["ch3_pr_set", "ch3_pr_mark", "ch3_pr_run", "ch3_pr_gk"],
    "dec": ["ch3_pr_captain", "ch3_pr_set", "ch3_pr_run"],
}
default ch3_pp = ""

label ch3_practice:
    scene bg kohoku_ground_eve
    with dissolve
    python:
        _all = CH3_PRACTICE.get(ch3_month, CH3_PRACTICE["sep"])
        _left = [x for x in _all if x not in ch3_practice_seen]
        if not _left:
            ch3_practice_seen = [x for x in ch3_practice_seen if x not in _all]
            _left = list(_all)
        ## 12月の最初の練習は、かならず「三好先輩のいない練習」
        if "ch3_pr_captain" in _left:
            ch3_pp = "ch3_pr_captain"
        else:
            ch3_pp = renpy.random.choice(_left)
        ch3_practice_seen = ch3_practice_seen + [ch3_pp]
    call expression ch3_pp
    $ up("技術", 2)
    $ up("フィジカル", 2)
    ## 11月（準々決勝のあと）は、ひざが腫れている
    if ch3_dates and ch3_dates[0].startswith("11月"):
        $ up("無理ゲージ", 6)
        "練習のあと、右ひざを氷で冷やした。いつもより、冷たさが奥まで届かない。"
    else:
        $ up("無理ゲージ", 3)
    return

label ch3_pr_set:
    "セットプレーの練習。{rb}黒田{/rb}{rt}くろだ{/rt}が、コーンを四つ並べた。"
    show kuroda normal
    with dissolve
    kuroda "強いチームから点を取るなら、止まったボールだ。動いてる試合で勝てないなら、止めて勝て"
    hide kuroda
    with dissolve
    "{rb}大門{/rb}{rt}だいもん{/rt}が、いちばん背の高い的になった。"
    daimon "ぼ、僕、キーパーなんですけど……"
    "三本目のコーナーで、大門の頭にぴたりと当たった。全員が、思わず黙った。"
    $ learn("setpiece")
    return

label ch3_pr_mark:
    "1対1の練習。相手は{rb}神城{/rb}{rt}かみしろ{/rt}だと思え、と{rb}黒田{/rb}{rt}くろだ{/rt}は言った。神城の役は、{rb}鷹野{/rb}{rt}たかの{/rt}。"
    takano "あいつは、右に行くと見せて、左足のアウトで持ち出す。……一回目のフェイントには、乗るな"
    "言われたとおりにすると、二回に一回、ボールに触れた。"
    $ learn("manmark")
    $ up("戦術眼", 1)
    return

label ch3_pr_run:
    if ch3_month == "dec":
        "冬の走りこみ。息が白い。"
    elif ch3_month == "nov":
        "外周の走りこみ。夕方の風が、もう冷たかった。"
    elif ch3_month == "oct":
        "外周の走りこみ。日が落ちるのが、ずいぶん早くなった。"
    else:
        "外周の走りこみ。夏の名残りの西日が、背中に暑い。"
    if ch3_month == "sep":
        ## 9月の自由行動（8〜14日）は、坂口たちが辞めかける（19〜26日）より前
        "{rb}坂口{/rb}{rt}さかぐち{/rt}たちは、ぶつぶつ文句を言いながら、しりとりをして走っていた。"
    else:
        "{rb}坂口{/rb}{rt}さかぐち{/rt}たちは文句を言わなくなった。そのかわり、しりとりをしながら走っていた。"
    sakaguchi "……ら。ラストスパート"
    mori "と。……とっくに、ラスト"
    if ch3_month == "dec":
        "いちばん後ろで笑っていた人は、もういない。{rb}三好{/rb}{rt}みよし{/rt}先輩の声がしないグラウンドは、少しだけ広かった。"
    elif ch3_month == "nov":
        "{rb}三好{/rb}{rt}みよし{/rt}先輩が、いちばん後ろで笑っていた。最後の冬を、たしかめるみたいに。"
    else:
        "{rb}三好{/rb}{rt}みよし{/rt}先輩が、いちばん後ろで笑っていた。最後の大会を、たしかめるみたいに。"
    return

## 12月：三好先輩が引退したあとの練習
label ch3_pr_captain:
    "三好先輩のいない、冬休み前の練習。10人。11人で組んできた形が、どこか一か所、いつも空いている。"
    if ch3_armband == "ren":
        "腕に、黄色い腕章を巻いた。巻いたら、声を出さないわけにいかなかった。"
        ren "ライン、そろえろ！　3メートル！"
        "自分の声が、思ったより小さかった。三好先輩の声は、もっとうるさかった。"
        sakaguchi "キャプテン、声ちっさ。ウケる"
        ren "……うるさい。外周1周"
        sakaguchi "うわ、三好先輩がうつった"
        $ up("メンタル", 1)
    else:
        show takano jersey_narrow
        with dissolve
        "{rb}鷹野{/rb}{rt}たかの{/rt}の腕に、黄色い腕章があった。"
        takano "……ライン、そろえろ。3メートル"
        "鷹野は、三好先輩みたいには叫ばなかった。でも、同じことを二回は言わせなかった。"
        hide takano
        with dissolve
        $ bond_up("鷹野", 2)
    "フェンスの外で、制服の三好先輩が見ていた。目が合うと、何も言わずに親指を立てて、帰っていった。"
    $ bond_up("三好", 2)
    return

label ch3_pr_gk:
    "シュート練習。{rb}大門{/rb}{rt}だいもん{/rt}は、もう目をつぶらない。十本中、四本。夏の終わりには、一本だった。"
    show daimon jersey
    with dissolve
    daimon "{rb}早瀬{/rb}{rt}はやせ{/rt}くん。準決勝、{rb}神城{/rb}{rt}かみしろ{/rt}くんのシュート、一本は止めます"
    daimon "……一本だけですけど"
    hide daimon
    with dissolve
    $ bond_up("大門", 2)
    return


################################################################################
## 9月の行き先
################################################################################

## 生徒会室：紺色の傘
label ch3_chika_sep:
    scene bg student_council
    with dissolve
    $ bgm("張りつめた静かな曲")
    "生徒会室の傘立てに、一本だけ、紺色の傘がささっていた。"
    "5月31日。雨の{rb}桜嶺{/rb}{rt}おうりょう{/rt}。スタンドの隅で、こっちを向いていた傘と、同じ色。"
    show chika normal
    with dissolve
    chika "……何か用ですか"
    menu:
        "「5月31日、桜嶺に来てましたよね」":
            $ heart_up("千夏", "ときめき", 5)
            $ set_flag("千夏_傘")
            "{rb}千夏{/rb}{rt}ちか{/rt}先輩の、判を押す手が止まった。"
            show chika narrow
            chika "……雨の日に傘をさすのは、規則違反ではありません"
            ren "どこで、とは聞いてません"
            chika "…………"
            "千夏先輩は、傘立ての紺色の傘を、黒い傘のうしろに押しこんだ。"
        "傘のことは言わずに、部費の申請書を出す":
            $ heart_up("千夏", "信頼", 4)
            chika "……受け取りました"
            "千夏先輩は、傘立てのほうを、一度だけ見た。"
    hide chika
    with dissolve
    return

label ch3_talk_chika_sep:
    $ talk_start("千夏", "22:05")
    if flags.get("千夏_傘"):
        $ talk("千夏", "傘のことは、忘れてください")
        $ ch3_r = talk_choose([("忘れません", "no"), ("分かりました", "ok")])
        if ch3_r == "no":
            $ talk_me("忘れません")
            $ talk("千夏", "……規則違反です")
            $ talk("千夏", "おやすみなさい")
            $ heart_up("千夏", "ときめき", 3)
        else:
            $ talk_me("分かりました")
            $ talk("千夏", "ありがとうございます")
            $ heart_up("千夏", "信頼", 2)
    else:
        $ talk("千夏", "部費の申請書に、押し忘れの印が一つありました。明日、取りに来てください")
        $ talk_me("すみません。行きます")
        $ talk("千夏", "……どうせ来るなら、昼休みに")
        $ heart_up("千夏", "信頼", 2)
    return

## 屋上：14番がAに上がった
label ch3_takano_sep:
    scene bg rooftop
    with dissolve
    $ bgm("少しとがった曲")
    "屋上で、{rb}鷹野{/rb}{rt}たかの{/rt}がスマホを見ていた。"
    show takano narrow
    with dissolve
    takano "……あいつ、Aに上がった"
    "画面には、{rb}桜嶺{/rb}{rt}おうりょう{/rt}のトップチームの名簿。白の14番に、{rb}真壁{/rb}{rt}まかべ{/rt}の名前。鷹野とジュニアユースで一緒だった男。"
    takano "勝ち上がったら、準決勝で出てくる"
    if flags.get("鷹野_わざと負け"):
        takano "……それと。合宿で言ったやつ、まだ有効だからな。次は本気で来い"
    menu:
        "「今、ここでやるか。本気で」":
            $ lean("野心型")
            "屋上のすみで、1対1をした。ボールはひとつ。ゴールは、フェンスの一枡。"
            if check("技術", 50):
                "三本目で、鷹野の股を抜いた。"
                takano "……っ、今のは、なし"
                ren "本気で来いって言ったのは、そっちだ"
                show takano surprised
                takano "……ちっ。もう一本"
                $ bond_up("鷹野", 5)
            else:
                "三本とも、鷹野に止められた。"
                takano "お前、ひざかばって、右に逃げる。……桜嶺のやつらにも、バレてるぞ"
                $ bond_up("鷹野", 4)
                $ up("戦術眼", 2)
        "「真壁は、お前が止めろ。俺は神城をやる」":
            $ lean("仲間型")
            $ bond_up("鷹野", 5)
            takano "……言われなくても"
        "「その前に、真壁の試合の動画、全部見よう」":
            $ bond_up("鷹野", 4)
            $ up("戦術眼", 2)
            $ lean("求道型")
            "鷹野のスマホで、桜嶺の試合の動画を二人で見た。真壁は、ボールを受ける前に、必ず一度、左を見る。"
            takano "……知ってる。昔から、そうだ。知ってても、止められなかったんだよ"
            ren "なら、止められるまで見る"
            takano "……しつこいな、お前"
            "そう言いながら、鷹野は、次の動画を再生した。"
    $ set_flag("真壁")
    hide takano
    with dissolve
    return

## 職員室：潮見FCからの電話
label ch3_kuroda_sep:
    scene bg staffroom
    with dissolve
    $ bgm("とぼけた日常の曲")
    "職員室の奥で、{rb}黒田{/rb}{rt}くろだ{/rt}が新聞をかぶって寝ていた。"
    show kuroda peek
    with dissolve
    kuroda "……なんだ。補習か"
    ren "先生。春に、なんで俺のひざのこと、知ってたんですか"
    "新聞が、ゆっくり下がった。"
    show kuroda normal
    kuroda "……{rb}潮見{/rb}{rt}しおみ{/rt}FCの監督から、電話があった。お前が{rb}港北{/rb}{rt}こうほく{/rt}に入る前の日に"
    kuroda "『{rb}早瀬{/rb}{rt}はやせ{/rt}のひざを、頼む。あいつは、自分で止まれないやつだ』ってな"
    if flags.get("ch1_kuroda2"):
        ## 第1章の職員室で「見る前に見えてるタイプだろう」と言われている
        "『見る前に見えてる』――あれも、潮見FCの監督の言葉だった。"
    else:
        "入部届を出した日、黒田は、何も聞かずに俺の右ひざのことを言い当てた。あれは、中学の監督から聞いていたのか。"
    menu:
        "「……先生も、止まれなかったんですか」":
            $ set_flag("黒田の過去", flags.get("黒田の過去", 0) + 1)
            $ up("メンタル", 2)
            kuroda "…………"
            kuroda "……止まれなかったやつを、知ってる"
            "黒田は、それ以上は話さなかった。新聞を、また顔にかぶせた。"
        "「止まれます。たぶん」":
            $ up("無理ゲージ", -3)
            kuroda "たぶん、か"
            kuroda "……ならいい。たぶんでも、言えるうちは大丈夫だ"
    hide kuroda
    with dissolve
    return

## はやせ食堂：ひなたのテーピング
label ch3_hinata_sep:
    scene bg shokudo_day
    with dissolve
    $ bgm("あたたかいアコースティックギター")
    "店のすみの席で、ひなたが分厚い本を開いていた。"
    show hinata apron
    with dissolve
    hinata "あ、ちょうどいい。{rb}蓮{/rb}{rt}れん{/rt}、右足出して"
    "ひなたは、俺のひざにテーピングを巻きはじめた。春より、ずっと手が速い。"
    hinata "……トレーナーとか、理学療法の専門学校、見学に行ってきたの。夏休みに"
    hinata "スポーツの選手のケガを、ケガする前に止める仕事"
    "妹のゆずが、カウンターの向こうから顔を出した。"
    yuzu "ひなちゃん、お兄ちゃんの専属？"
    hinata "ちがう！"
    menu:
        "「専属でいいよ」":
            $ heart_up("ひなた", "ときめき", 6)
            hinata "…………っ"
            "ひなたは、テーピングを一周、多く巻いた。"
            hinata "……高いよ。わたし"
        "「いい仕事だな。ひなたに向いてる」":
            $ heart_up("ひなた", "信頼", 6)
            hinata "……ほんと？"
            hinata "蓮にそう言われると、ちょっとだけ、本気になる"
            $ set_flag("ひなた_トレーナー")
    hide hinata
    with dissolve
    return

## 港の防波堤：紗希とピアノ
## 第2章の満員電車で、紗希に最初に言ったこと（第3章で紗希と会う、いちばん最初の場面で一言だけ）
label ch3_saki_train:
    if flags.get("ch3_紗希_電車") or not ch2_saki_word:
        return
    $ set_flag("ch3_紗希_電車")
    "[saki_call]は、少し黙ってから言った。"
    if ch2_saki_word == "long":
        saki "……夏の電車で、『久しぶり』って言ったでしょ"
        saki "あれ、ちょっと変だった。……変だけど、悪くはなかった"
    elif ch2_saki_word == "ok":
        saki "……夏の電車で、『苦しくない？』って聞いたでしょ"
        saki "あんな満員で、人の心配する人、初めて見た"
    elif flags.get("ch2_電車_名字"):
        saki "……夏の電車で、いきなり名字で呼ばれた"
        saki "……心臓、止まるかと思った"
    else:
        saki "……夏の電車で、2分間、ずっと黙ってたでしょ"
        saki "あれ、ちょっと助かった。……何か言われてたら、たぶん泣いてた"
    return

label ch3_saki_sep:
    scene bg harbor_sunset
    with dissolve
    $ se("波の音、カモメ")
    $ bgm("静かなピアノの旋律")
    "防波堤でボールを蹴っていると、近くの窓から、またあの曲。やっぱり同じところで止まって、しばらくして、家の玄関が開いた。"
    show saki normal
    with dissolve
    saki "……うるさい。ボールの音"
    ren "ピアノのほうが、うるさい"
    saki "っ……"
    "[saki_call]は、なぜか笑いそうになって、それをこらえた。"
    saki "ここ、おばあちゃんの家。……学校は{rb}桜嶺{/rb}{rt}おうりょう{/rt}だけど、住んでるのはこっち"
    saki "桜嶺には、あの人がいるから。家まで同じなのは、無理"
    ren "あの人？"
    saki "……なんでもない"
    menu:
        "「曲、いつも同じところで止まるな」":
            $ heart_up("紗希", "信頼", 5)
            if flags.get("ch2_piano"):
                saki "……また、それ。電車でも、その話したでしょ"
            else:
                saki "聴いてたの？　……最悪"
            saki "あそこ、指が覚えてないわけじゃないの。……止まるの。勝手に"
        "「また、聴きに来ていいか」":
            $ heart_up("紗希", "ときめき", 5)
            saki "……勝手にすれば。窓、開けてるのは私だし"
    $ set_flag("紗希_祖母の家")
    call ch3_saki_train
    hide saki
    with dissolve
    $ amb_stop()
    return


################################################################################
## 10月の行き先
################################################################################

## 生徒会室：署名
label ch3_chika_oct:
    scene bg student_council
    with dissolve
    $ bgm("静かな春の曲")
    "署名が始まって、学校のことは、もうみんなが知っていた。机の上に、『{rb}港北{/rb}{rt}こうほく{/rt}高校の存続を求める署名』の束。"
    show chika normal
    with dissolve
    if flags.get("ch3_統廃合_秘密"):
        chika "……三好先輩たちにも、知られてしまいました。県の会議のことが、新聞に出たので"
    chika "……集めても、会議の人たちは数字しか見ません"
    chika "でも、数字なら、見てもらえます"
    "署名の数は、まだ百にも届いていなかった。"
    menu:
        "「サッカー部で集めます。ベスト8の報告といっしょに」":
            $ heart_up("千夏", "信頼", 6)
            $ set_flag("千夏_署名")
            chika "……{rb}三好{/rb}{rt}みよし{/rt}先輩に言ったら、校門で一日じゅう叫びますよ"
            ren "叫ばせます"
            show chika soft
            chika "…………ふふ"
            "{rb}千夏{/rb}{rt}ちか{/rt}先輩が、声に出して笑ったのを、初めて聞いた。"
        "「写真、展示しませんか。先輩の撮った、試合の写真」":
            $ heart_up("千夏", "ときめき", 6)
            $ set_flag("千夏_展示")
            show chika narrow
            chika "……私は、撮っていません"
            ren "じゃあ、誰かが撮った写真を"
            chika "…………検討します"
    hide chika
    with dissolve
    return

## 部室：三好先輩の最後の大会
label ch3_miyoshi_oct:
    scene bg clubroom
    with dissolve
    $ bgm("静かな春の曲")
    "部室で、{rb}三好{/rb}{rt}みよし{/rt}先輩がスパイクを磨いていた。"
    show miyoshi uniform
    with dissolve
    miyoshi "おう、{rb}蓮{/rb}{rt}れん{/rt}。……なあ。準々決勝に勝ったら、{rb}桜嶺{/rb}{rt}おうりょう{/rt}だよな"
    miyoshi "俺さ、{rb}神城{/rb}{rt}かみしろ{/rt}、止められると思うか？"
    menu:
        "「止められます。先輩なら」":
            $ bond_up("三好", 5)
            $ up("メンタル", 2)
            miyoshi "……お前が言うと、ほんとに止められる気がするな"
        "「止められません。でも、追いつけます」":
            $ bond_up("三好", 5)
            $ up("戦術眼", 2)
            $ lean("求道型")
            show miyoshi smile
            miyoshi "はは！　そうだな。俺はそれしかできねえ"
    miyoshi "春から親父の工務店だ。……だから、この冬が、俺の最後のサッカーだ"
    $ set_flag("三好_工務店")
    "スパイクの泥は、もう全部落ちていた。それでも先輩は、磨くのをやめなかった。"
    hide miyoshi
    with dissolve
    return

## 柔道場：大門と先輩たち
label ch3_daimon_oct:
    scene bg judo_hall
    with dissolve
    $ bgm("とぼけた日常の曲")
    "柔道場の前を通ると、{rb}大門{/rb}{rt}だいもん{/rt}が先輩たちに囲まれていた。"
    judo_senpai "大門！　2回戦の横っ飛び、校内放送で聞いたぞ！　あれは俺たちが教えた受け身だ！"
    show daimon uniform_worried
    with dissolve
    daimon "は、はい……そうです……"
    judo_senpai "おい、サッカー部の。お前も受け身やってけ"
    menu:
        "畳に上がって、受け身を習う":
            $ bond_up("大門", 3)
            $ up("フィジカル", 2)
            "三回投げられて、三回とも、きれいに転がれなかった。大門が、肩をふるわせて笑いをこらえていた。"
            daimon "{rb}早瀬{/rb}{rt}はやせ{/rt}くん、それ、ケガします……"
        "「大門を、借りていきます」":
            $ bond_up("大門", 6)
            daimon "……ありがとうございます。先輩たち、悪い人じゃないんですけど"
            daimon "サッカー部に入ってから、なぜか、前より仲よくなりました"
    hide daimon
    with dissolve
    return

## 港への坂道：ひなたと将来
label ch3_hinata_oct:
    scene bg slope_eve
    with dissolve
    $ bgm("静かな春の曲")
    "練習のあと、ひなたと坂道を下りた。"
    show hinata normal
    with dissolve
    ## 夏のお天気雨で貸したジャージ（第2章7月の坂道を通ったとき。v0.31.0）
    if flags.get("ひなた_ジャージ"):
        "坂の途中で、ひなたが紙袋を差し出した。中に、きれいにたたんだ部のジャージが入っていた。"
        hinata "これ。夏の、お天気雨のとき借りたやつ。……返すの、忘れてた"
        ren "忘れてたって、三か月だぞ"
        show hinata pout
        hinata "…………うそ。忘れてない"
        hinata "合宿のときも、練習試合の日も、カバンに入れてた。……お守り"
        show hinata normal
        hinata "でも、選手権の前だから、本人に返す。蓮が着て、勝って"
        menu:
            "「……まだ、持ってていい」":
                $ heart_up("ひなた", "ときめき", 4)
                "ひなたは、紙袋を、胸の前でぎゅっと抱えなおした。"
                hinata "……じゃあ、決勝の日まで。それ以上は、借りっぱなしになるから"
            "「ありがとう。これ着て、勝つ」":
                $ heart_up("ひなた", "信頼", 4)
                hinata "……うん。ちゃんと洗ったから、ちょっといい匂いするよ。うちの洗剤"
                "受け取ったジャージは、ほんの少しだけ、はやせ食堂の隣の家の匂いがした。"
        $ set_flag("ひなた_ジャージ_返した")
    hinata "ねえ、{rb}蓮{/rb}{rt}れん{/rt}は、プロになりたい？"
    hinata "前は、ぜったいなるって言ってたでしょ。小学生のとき"
    menu:
        "「なりたい。今でも」":
            $ heart_up("ひなた", "信頼", 4)
            $ lean("野心型")
            hinata "……そっか"
            hinata "じゃあ、わたしも、本気でトレーナーの勉強する。蓮のひざ、プロまで持たせる"
        "「分からない。今は、港北で勝ちたい」":
            $ heart_up("ひなた", "ときめき", 4)
            $ lean("仲間型")
            hinata "……そっか"
            "ひなたは、ほっとした顔をした。それを、すぐに隠した。"
    hide hinata
    with dissolve
    return

label ch3_talk_hinata_oct:
    $ talk_start("ひなた", "22:30")
    $ talk("ひなた", "今日の、なんか、ごめんね。急に変なこと聞いて")
    $ ch3_r = talk_choose([("変じゃない", "ok"), ("ひなたは、どうしたいの", "ask")])
    if ch3_r == "ok":
        $ talk_me("変じゃない")
        $ talk("ひなた", "そっか")
        $ heart_up("ひなた", "信頼", 2)
    else:
        $ talk_me("ひなたは、どうしたいの")
        $ talk("ひなた", "……ないしょ")
        $ talk("ひなた", "眉毛見えないから、ずるい質問")
        $ heart_up("ひなた", "ときめき", 3)
    ## 打っては消す（v0.31.0）：何を打っていたのかは、最後まで分からない
    $ talk_typing("ひなた", 3)
    "「入力中」の表示が、出ては消えた。三回。"
    $ talk("ひなた", "おやすみ")
    "何を打って、何を消したのかは、分からない。"
    "次の日の朝、聞いてみた。ひなたは「何が？」と言って、いつもの顔で、俺の右ひざを指でつついた。"
    $ set_flag("ひなた_入力中")
    return

## ピアノの家の前：発表会のチケット
label ch3_saki_oct:
    scene bg harbor_sunset
    with dissolve
    $ se("波の音、カモメ")
    $ bgm("静かなピアノの旋律")
    "ピアノの家の前を通ると、ちょうど[saki_call]が出てきた。"
    show saki normal
    with dissolve
    saki "……また来た"
    "[saki_call]は、ポケットから細長い紙を出して、俺の胸に押しつけた。"
    saki "おばあちゃんが、勝手に二枚くれたの。いらないから"
    "「冬のピアノ発表会　12月24日　19時　{rb}潮見{/rb}{rt}しおみ{/rt}市民ホール」"
    saki "来なくていい。……捨てるのが、もったいないだけ"
    $ set_flag("紗希_チケット")
    $ _sk_gone = False
    menu:
        "「行けたら、行く」":
            $ heart_up("紗希", "信頼", 4)
            saki "……それ、来ない人の言い方"
        "「行く」":
            $ heart_up("紗希", "ときめき", 6)
            saki "……っ。来なくていいって言ったでしょ"
            "[saki_call]は、走って家に戻った。窓が、ばたんと閉まった。その夜、ピアノは、いつもより長く鳴っていた。"
            $ _sk_gone = True
    if not _sk_gone:
        call ch3_saki_train
    hide saki
    with dissolve
    $ amb_stop()
    return


################################################################################
## 11月の行き先（準決勝の前）
################################################################################

## 夜のグラウンド：鷹野の左足
label ch3_takano_nov:
    scene bg kohoku_ground_night
    with dissolve
    $ bgm("静かな夜の曲")
    "一つだけの照明の下で、{rb}鷹野{/rb}{rt}たかの{/rt}が一人、左足でボールを蹴っていた。{rb}黒田{/rb}{rt}くろだ{/rt}の、あのボール。低く出て、途中でぐんと曲がる。"
    show takano jersey
    with dissolve
    takano "……見てんじゃねえよ"
    if flags.get("真壁"):
        takano "真壁は、俺の右足しか知らねえ。……だから、左で抜く"
    else:
        takano "あの14番は、俺の右足しか知らねえ。……だから、左で抜く"
    menu:
        "「ひざがこれだから、少しだけな。付き合う」":
            $ bond_up("鷹野", 5)
            $ up("無理ゲージ", 3)
            "鷹野の左足のボールを、ひたすら止めて、返した。二十本目で、ボールは、狙ったコーンをきれいに倒した。"
            takano "……今の、お前のパスがよかったからじゃねえからな"
        "「帰れ。準決勝の前に、お前がケガしたら終わりだ」":
            $ bond_up("鷹野", 3)
            takano "……お前に言われたくねえよ。そのひざで"
    hide takano
    with dissolve
    return

## 生徒会室：準決勝を見に行くか
label ch3_chika_nov:
    scene bg student_council
    with dissolve
    $ bgm("静かな春の曲")
    ## 気持ちが強いときだけ：居眠りの千夏（メガネを外した寝顔）
    if heart_total("千夏") >= CH3_SPECIAL_CHIKA:
        call ch3_chika_sleep
    show chika normal
    with dissolve
    chika "……準決勝の会場の行き方を、調べておきました"
    "{rb}千夏{/rb}{rt}ちか{/rt}先輩は、駅からの道順を書いたメモを、机の上に置いた。"
    ren "先輩も、来るんですか"
    chika "生徒会として、各部の活動を把握する必要がありますから"
    chika "……フィルムを、新しく二本、買いました"
    menu:
        "「旗も、振ってください」":
            $ heart_up("千夏", "ときめき", 6)
            show chika narrow
            "千夏先輩の手が、ぴたりと止まった。"
            chika "…………なぜ、旗を"
            ren "なんとなくです"
            chika "……生徒会長は、旗を振りません"
            $ set_flag("千夏_旗")
        "「先輩の写真、楽しみにしてます」":
            $ heart_up("千夏", "信頼", 6)
            chika "……撮るとは、言っていません"
            "そう言いながら、メモの端に、そっと「がんばってください」と書き足した。"
    ## 手帳から落ちた一枚（v0.31.0）
    "{rb}千夏{/rb}{rt}ちか{/rt}先輩が、生徒会の手帳を閉じた拍子に、何かが床にすべり落ちた。"
    "拾い上げると、写真だった。雨のグラウンドを走る、誰かの横顔。ピントが、少しだけずれている。"
    "……俺だった。"
    show chika narrow
    chika "……っ"
    "先輩は、俺の手から写真を取って、表を伏せた。"
    chika "記録用です。……ピンぼけなので、捨てるところでした"
    menu:
        "「捨てるなら、ください」":
            $ heart_up("千夏", "ときめき", 3)
            chika "…………だめです。生徒会の記録ですから"
            ren "今、捨てるって"
            chika "記録です"
        "「今度は、ピントの合ったのを撮ってください」":
            $ heart_up("千夏", "信頼", 3)
            chika "……準決勝で、撮れたら、です"
    "先輩は、写真を、ごみ箱ではなく、手帳のいちばん後ろのページに戻した。"
    $ set_flag("千夏_手帳の写真")
    hide chika
    with dissolve
    return

## ゲーセン：坂口たちの作戦
label ch3_arcade_nov:
    scene bg game_center
    with dissolve
    $ bgm("ゲームセンターの曲")
    "ゲーセンのサッカーゲームの前で、5人組が画面をにらんでいた。"
    show sakaguchi normal
    with dissolve
    sakaguchi "{rb}蓮{/rb}{rt}れん{/rt}。見て。{rb}桜嶺{/rb}{rt}おうりょう{/rt}、作った"
    sakaguchi "エディットで、桜嶺の選手全員、能力入れた。ネットの記録から。{rb}神城{/rb}{rt}かみしろ{/rt}、能力99"
    noguchi "で、毎日ボコボコにされてる"
    sakaguchi "ウケる。……でも、5人とも、桜嶺のパターン、覚えてきた"
    menu:
        "「一回、やらせて」":
            $ bond_up("坂口", 5)
            "ゲームの神城に、三回抜かれた。四回目で、止めた。5人が、悲鳴みたいな歓声を上げた。"
        "「本物は、もっと速いぞ」":
            $ bond_up("坂口", 4)
            $ up("戦術眼", 2)
            sakaguchi "知ってる。……だから、ゲームくらいでは、勝っときたいんだよ"
    hide sakaguchi
    with dissolve
    return

## はやせ食堂：母のかつ丼
label ch3_mother_nov:
    scene bg shokudo_night
    with dissolve
    $ bgm("あたたかいアコースティックギター")
    "閉店した店で、母さんがかつ丼を作っていた。"
    show mother smile
    with dissolve
    haha "はい。準決勝の前は、これでしょ"
    ren "……試合、まだ先だけど"
    haha "前の日にも作るよ。今日のは、練習"
    show mother normal
    haha "……ひざ、どう"
    menu:
        "「正直、痛い」":
            $ up("無理ゲージ", -4)
            haha "そう。……言ってくれて、ありがと"
            haha "痛いって言える子は、大丈夫。言えない子が、いちばん心配"
        "「平気」":
            show mother sadsmile
            haha "……お父さんも、そう言ってた"
            "母さんは、それ以上、何も言わなかった。"
    hide mother
    with dissolve
    return

## 港の防波堤：紗希の問い
label ch3_saki_nov:
    scene bg harbor_winter_eve
    with dissolve
    $ se("波の音、カモメ")
    $ bgm("静かなピアノの旋律")
    "秋の終わりの夕方の防波堤。[saki_call]が、先にいた。"
    ## 気持ちが強いときだけ：海風でスカートがあおられる
    if heart_total("紗希") >= CH3_SPECIAL_SAKI:
        call ch3_saki_wind
    show saki normal
    with dissolve
    saki "……そのひざで、まだ蹴るの"
    ren "なんで分かる"
    saki "歩き方。……うちで、見たことあるから"
    saki "壊れるまで、蹴らされる人"
    ren "誰に"
    "[saki_call]は答えなかった。"
    saki "あなたは、誰のために蹴ってるの"
    menu:
        "「自分のため」":
            $ heart_up("紗希", "信頼", 5)
            saki "……そう。それなら、まだまし"
        "「チームのため」":
            $ heart_up("紗希", "ときめき", 4)
            saki "……そういう人が、いちばん、使われるのよ"
    ## イヤホンを片方ずつ（v0.31.0）
    "[saki_call]は、コートのポケットから、白いイヤホンを出した。片方を、黙って俺のほうへ差し出した。"
    saki "……発表会の曲。家で、録った。……人に聴かせたこと、ない"
    "片方を右耳に入れた。[saki_call]が、もう片方を左耳に入れた。コードが短くて、肩が触れそうなところまで、並んで座ることになった。"
    $ bgm("静かなピアノの旋律")
    "波の音の向こうで、あの曲が鳴った。いつものところで、止まった。少しして、また最初から。"
    "録音は、そこで終わっていた。"
    "[saki_call]は、イヤホンを外さなかった。俺も、外さなかった。何も鳴っていないイヤホンを、二人で片方ずつ、耳に入れたままでいた。"
    saki "……なんで外さないの"
    ren "そっちこそ"
    saki "…………寒いから。耳が"
    $ heart_up("紗希", "ときめき", 3)
    $ set_flag("紗希_イヤホン")
    call ch3_saki_train
    hide saki
    with dissolve
    $ amb_stop()
    return


################################################################################
## ヒロインごとの、ほんの少しだけドキッとする場面（気持ちが強いときだけ。一枚絵つき）
##   ひなた：準決勝の朝、ロッカールームでひざのテーピング（chapter3_more.rpy の ch3_hinata_tape）
##   千夏：11月の生徒会室で、メガネを外したまま居眠り
##   紗希：11月の防波堤で、海風にスカートがあおられる
################################################################################
##   本気でその人を追ったときだけ届く高さ（ひなたは最初から40あり、ふつうに遊んでも11月に90前後になる。
##   紗希は第3章で初めてちゃんと会うので、9月・10月の紗希の場面に両方行って、11月で20前後）
define CH3_SPECIAL_HINATA = 120
define CH3_SPECIAL_CHIKA = 70
define CH3_SPECIAL_SAKI = 20

label ch3_chika_sleep:
    "ノックをしても、返事がなかった。そっとドアを開けると、{rb}千夏{/rb}{rt}ちか{/rt}先輩が、書類の山に腕をのせて眠っていた。"
    scene cg chika_sleep at cam_push(10.0, 1.05)
    with Dissolve(1.0)
    "メガネは、書類の上にたたんであった。メガネのない顔は、初めて見た。思っていたより、ずっと幼い。"
    "長い黒髪が、腕から机の上にこぼれている。小さな寝息に合わせて、書類の端がかすかに揺れた。"
    menu:
        "上着を、そっと肩にかける":
            $ heart_up("千夏", "ときめき", 5)
            "ブレザーを脱いで、肩にかけた。千夏先輩が、眠ったまま、少しだけそれを引き寄せた。"
            $ set_flag("千夏_上着")
        "しばらく、起こさずに待つ":
            $ heart_up("千夏", "信頼", 5)
            "向かいの椅子に座って、窓の外の夕焼けが紺色になるまで待った。"
    ## 起こさずに待ったときは、外がもう暗い
    if flags.get("千夏_上着"):
        scene bg student_council
    else:
        scene bg student_council_night
    with dissolve
    show chika normal
    with dissolve
    voice "audio/voice/chika_mimashitaka.mp3"
    chika "…………見ましたか"
    "起きてすぐの声だった。メガネをかけ直す手が、いつもより遅い。"
    show chika narrow
    chika "メガネのない顔は、記録にありません。……忘れてください"
    if flags.get("千夏_上着"):
        chika "……上着は、洗って返します。それも、記録にはありません"
    hide chika
    with dissolve
    $ set_flag("千夏_寝顔")
    return

label ch3_saki_wind:
    $ se("強い海風")
    scene cg saki_wind at cam_snap(1.06)
    with hpunch
    "[saki_call]のスカートが、大きくあおられた。[saki_call]は、両手で押さえて、真っ赤な顔でこっちをにらんだ。"
    voice "audio/voice/saki_mita.mp3"
    saki_v "……見た？"
    menu:
        "「見てない」":
            $ heart_up("紗希", "信頼", 3)
            saki_v "……嘘ついてる顔じゃない。……なら、いい"
        "「……ちょっとだけ」":
            $ heart_up("紗希", "ときめき", 5)
            voice "audio/voice/saki_baka2.mp3"
            saki_v "……ばか"
            "[saki_call]は、そっぽを向いた。耳まで赤かった。"
    scene bg harbor_winter_eve
    with dissolve
    $ set_flag("紗希_風")
    return


################################################################################
## 12月の行き先（仲間割れのあと）
################################################################################

## 屋上：鷹野
label ch3_takano_dec:
    scene bg rooftop_winter
    $ coat_on()
    with dissolve
    $ bgm("少しとがった曲")
    "屋上に、{rb}鷹野{/rb}{rt}たかの{/rt}がいた。"
    show takano narrow
    with dissolve
    if ch3_fight in ("undecided", "maybe"):
        takano "……なんだよ"
        "引退の日から、鷹野とは一度も口をきいていなかった。"
        menu:
            "「あの日は、悪かった」":
                $ bond_up("鷹野", 8)
                takano "……謝んなよ。答え、出てねえんだろ"
                takano "謝るのは、答えが出てからにしろ"
                "鷹野は、ポケットから手を出して、俺の肩を小突いた。"
            "「答えは、年が明けたら言う」":
                $ bond_up("鷹野", 5)
                $ up("メンタル", 2)
                takano "……そうかよ"
                takano "なら、それまでは、俺に出しつづけろ。練習でもな"
    else:
        takano "……{rb}桜嶺{/rb}{rt}おうりょう{/rt}の監督、まだ連絡してくんのか"
        ren "年が明けたら返事しろ、だって"
        takano "そうかよ"
        takano "……「行かない」って言ったの、覚えてるからな"
        $ bond_up("鷹野", 4)
    if ch3_armband == "takano":
        "鷹野の腕に、{rb}三好{/rb}{rt}みよし{/rt}先輩の黄色い腕章があった。"
        takano "……これ、重てえんだよ。お前のせいだぞ"
    hide takano
    with dissolve
    return

## 部室：大門と坂口
label ch3_team_dec:
    scene bg clubroom
    with dissolve
    $ bgm("静かな春の曲")
    "部室に、{rb}大門{/rb}{rt}だいもん{/rt}と{rb}坂口{/rb}{rt}さかぐち{/rt}がいた。"
    show daimon uniform_worried at left
    show sakaguchi normal at right
    with dissolve
    daimon "は、{rb}早瀬{/rb}{rt}はやせ{/rt}くん……"
    if ch3_fight == "no":
        daimon "あの日、行かないって言ったの……本当に、本当ですよね？"
    else:
        daimon "あの、{rb}桜嶺{/rb}{rt}おうりょう{/rt}に、行っちゃうんですか"
    if ch3_rumor == "hide":
        sakaguchi "……ひざのこと聞かれただけって、言ったよな。グループで"
        sakaguchi "別に、怒ってないけどさ。……ウケなかった"
    else:
        sakaguchi "大門、それ聞くなって言ったじゃん"
    menu:
        ## 約束がうれしいのは大門、だまって謝られるほうが楽なのは坂口（どちらかが上位にならないように）
        "「まだ決めてない。でも、ちゃんと最初に言う」":
            $ bond_up("大門", 6)
            $ bond_up("坂口", 2)
            daimon "……はい。待ってます"
            sakaguchi "最初に言うの、{rb}三好{/rb}{rt}みよし{/rt}先輩な。じゃないとあの人、泣くから"
        "「……ごめん」":
            $ bond_up("大門", 2)
            $ bond_up("坂口", 6)
            daimon "あ、謝らないでください……"
            "大門は、泣きそうな顔で笑った。坂口は、何も言わずにゲームの話をはじめた。"
    hide daimon
    hide sakaguchi
    with dissolve
    return

## 生徒会室：会議の日程
label ch3_chika_dec:
    scene bg student_council_night
    with dissolve
    $ bgm("静かな夜の曲")
    show chika normal
    with dissolve
    "{rb}千夏{/rb}{rt}ちか{/rt}先輩は、窓の外の暗くなったグラウンドを見ていた。"
    chika "……県の会議の日が、決まりました。4月19日です"
    if flags.get("千夏_署名"):
        chika "署名は、412人分になりました。{rb}三好{/rb}{rt}みよし{/rt}先輩が、本当に校門で叫んでいました"
    chika "……早瀬くんは、どうするんですか。春から"
    menu:
        "「先輩には、決めたら一番に言います」":
            $ heart_up("千夏", "ときめき", 6)
            show chika narrow
            chika "……一番は、三好先輩にしてください。順番は、守ってください"
            chika "二番で、いいです"
        "「先輩は、残ってほしいですか」":
            $ heart_up("千夏", "信頼", 6)
            chika "生徒会長として、答える立場にありません"
            chika "……{rb}七瀬千夏{/rb}{rt}ななせちか{/rt}としては、答えたくありません"
    hide chika
    with dissolve
    return

## 港への坂道：ひなた
label ch3_hinata_dec:
    scene bg slope_eve
    $ coat_on()
    with dissolve
    $ bgm("静かな春の曲")
    "坂道で、ひなたが待っていた。"
    ## コート・マフラーの絵があるのは smile / stare / pout / forcesmile だけ
    show hinata smile
    with dissolve
    hinata "……寒いね"
    "マフラーに顔をうずめて、ひなたは、いつもどおりの声で言った。引退の日のことも、{rb}桜嶺{/rb}{rt}おうりょう{/rt}のことも、何も聞いてこなかった。"
    menu:
        "「聞かないのか。桜嶺のこと」":
            $ heart_up("ひなた", "信頼", 6)
            hinata "聞いたら、{rb}蓮{/rb}{rt}れん{/rt}、眉毛上げるでしょ"
            hinata "眉毛上げた蓮の答えは、聞きたくないの"
        "何も言わずに、並んで歩く":
            $ heart_up("ひなた", "ときめき", 5)
            "坂の下まで、二人とも、何も話さなかった。家の前で、ひなたが、俺のマフラーを直した。"
            hinata "……ひざ、冷やさないでね"
    hide hinata
    with dissolve
    return

## ピアノの家の前：発表会の練習
## ピアノの部屋：ドの音だけ（12月。紗希が窓を閉めなかったとき。v0.31.0）
##   止まるところは、まだ越えない（越えるのは12/24の発表会。「うるさいのが一人いたから」につながる）
label ch3_saki_piano:
    hide saki
    scene cg saki_piano at cam_push(12.0, 1.04)
    with Dissolve(1.0)
    "古いアップライトのピアノが、窓ぎわに一台。おばあさんはお茶を置くと、にこにこしたまま、台所へ戻っていった。"
    saki "……そこ、立ってないで。座って。端っこ"
    "ピアノの椅子の端に座ると、[saki_call]が、俺の右手を取った。冷たい指だった。"
    "そのまま、鍵盤の上に置かれた。人さし指の下に、白い鍵が一つ。"
    ## 重なった手が枠に隠れないように、一度だけ枠を消して見せる
    window hide
    pause 2.5
    window auto
    saki "ここ、ド。……私が止まったら、それだけ押して"
    ren "止まったら？"
    saki "……いいから"
    "[saki_call]が弾きはじめた。防波堤で何度も聴いた曲が、すぐ隣で鳴っていた。"
    "いつものところで、指が止まった。"
    "俺は、ドを押した。ポーン、と、間の抜けた音が一つ、部屋に響いた。"
    "[saki_call]が、ふき出した。声を出して笑ったのを、初めて聞いた。"
    saki "……変な音。……ほんとに、下手"
    saki "でも。止まったあと、静かじゃないの、初めて"
    "それから[saki_call]は、自分の手が、まだ俺の手の上に重なったままなのに気づいて、ぱっと離した。"
    "俺も、言われるまで、気づかなかったふりをした。"
    $ heart_up("紗希", "ときめき", 4)
    $ set_flag("紗希_ドの音")
    "帰りぎわ、玄関の戸を閉める前に、[saki_call]は一度だけ、こっちを見た。"
    scene bg harbor_winter_eve
    with dissolve
    return

label ch3_saki_dec:
    scene bg harbor_winter_eve
    $ coat_on()
    with dissolve
    $ se("波の音、カモメ")
    $ bgm("静かなピアノの旋律")
    "少し開いた窓から、あの曲が聞こえる。止まる。また最初から。七回目で、窓から[saki_call]が顔を出した。"
    show saki frown
    with dissolve
    saki "……ずっと、そこにいるつもり？"
    $ _sk_gone = False
    menu:
        "「止まるところまで、毎回聴いてる」":
            $ heart_up("紗希", "ときめき", 5)
            saki "……うるさい"
            "窓が閉まった。八回目の曲は、止まるところの、二小節先まで進んだ。"
            $ _sk_gone = True
        "「寒いから、窓閉めろよ」":
            $ heart_up("紗希", "信頼", 5)
            saki "……閉めたら、あなたに聞こえないでしょ"
            "言ってから、[saki_call]は、しまった、という顔をした。"
            ## ピアノの部屋で、ドの音だけ（v0.31.0）。止まるところは、まだ越えない（越えるのは12/24の発表会）
            saki "…………寒いなら、入れば。おばあちゃんが、お茶いれるって"
            call ch3_saki_piano
            $ _sk_gone = True
    if not _sk_gone:
        call ch3_saki_train
    hide saki
    with dissolve
    $ amb_stop()
    return
