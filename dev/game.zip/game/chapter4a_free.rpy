## chapter4a_free.rpy ―― 第4章（ルートA）の自由行動
##   ① 4月：新入生の勧誘（4日・学校の地図）。5か所のうち4か所を回る。回った順で、なじみ方が変わる
##   ② 5月・③ 7月：4日ずつ。毎日「練習メニュー → 行動マップで会いに行く人」（practice.rpy と同じ流れ）
##   紗希は「休日の港」でしか会えない（7月は 7/19 の海の日だけ、港の防波堤が開く）。ルートAで会えるのは 5/23 と 7/19 の2回だけ
##   夜のトークは chapter4a_night.rpy

################################################################################
## ① 4月：新入生の勧誘
################################################################################
define A4_RECRUIT_DATES = ["4月8日（木）", "4月9日（金）", "4月12日（月）", "4月13日（火）"]

init python:
    ## 学校を大きくした地図（images/bg/map_school.jpg）の上の位置
    A4_RECRUIT_SPOTS = [
        ("gate", "校門", 930, 520, "sakaguchi", "ビラ配り"),
        ("gym", "体育館の裏", 1100, 330, "daimon", "体の大きな1年"),
        ("ground", "グラウンド", 420, 300, "takano", "生意気な1年"),
        ("hall", "1年の昇降口", 700, 100, "", "まっすぐな目の1年"),
        ("council", "生徒会室", 1000, 170, "chika", "千夏"),
    ]

    def a4_recruit_spots():
        out = []
        for sid, name, x, y, face, ev in A4_RECRUIT_SPOTS:
            done = sid in store.a4_recruit
            d = {"id": sid, "name": name, "x": x, "y": y,
                 "event": "" if done else ev, "enabled": not done}
            if face:
                d["face"] = face
            out.append(d)
        return out

default a4_day = 1

label a4_recruit_loop:
    $ recap_text = "三好先輩が卒業して、部員は10人。\n11人そろわなければ、インターハイ予選に出られない。\n\n入部届の締め切りは、4月15日。\n去年は誘われる側だった。今年は、誘う側。"
    $ a4_day = 1
    while a4_day <= len(A4_RECRUIT_DATES):
        $ amb_stop()
        $ set_cal(A4_RECRUIT_DATES[a4_day - 1], "放課後")
        $ bgm("作戦会議っぽい軽快な曲")
        window auto hide
        call screen action_map(a4_recruit_spots(), "どこへ誘いに行く？（残り" + str(len(A4_RECRUIT_DATES) + 1 - a4_day) + "日）", area="school")
        $ a4_recruit = a4_recruit + [_return]
        call expression "a4_rc_" + _return
        $ a4_day += 1
    $ amb_stop()
    ## 最初に誘いに行った相手と、いちばん仲よくなる
    python:
        _first = a4_recruit[0] if a4_recruit else ""
        if _first == "gate":
            bond_up("坂口", 3)
        elif _first == "gym":
            bond_up("大門", 3)
        elif _first == "ground":
            bond_up("鷹野", 3)
    return

## 校門でビラ配り（坂口たち・ひなた）→ 名前のない1年が3人
label a4_rc_gate:
    scene bg kohoku_gate_morning
    with dissolve
    "放課後の校門で、ビラを配った。"
    show sakaguchi normal
    with dissolve
    sakaguchi "蓮、見てて。こうやって配んの"
    sakaguchi "サッカー部でーす。今入ると、ゲーセンのクーポンついてきまーす"
    ren "つかない"
    sakaguchi "つけるよ。俺の"
    hide sakaguchi
    with dissolve
    "ひなたは、ビラを受け取らなかった1年にも、一人ずつ「ありがとう」と言っていた。"
    show hinata smile
    with dissolve
    hinata "蓮。……去年の三好先輩、こんな気持ちだったのかな"
    ren "……あの人は、もっと声がでかかった"
    hinata "うん。でも、たぶん、同じ気持ち"
    hide hinata
    with dissolve
    "夕方までに、3人の1年が、部室をのぞきに来た。一人は経験者。一人は「走るのは好き」。一人は「坂口先輩が、おもしろかったんで」。"
    $ a4_members += 3
    $ bond_up("坂口", 2)
    $ heart_up("ひなた", "信頼", 1)
    return

## 体育館の裏：倉田（大門を尊敬する、控えのGK）
label a4_rc_gym:
    scene bg gym_back
    with dissolve
    "体育館の裏で、バスケ部の勧誘を断っている1年がいた。背は大門と同じくらいなのに、肩をすぼめて、小さくなろうとしていた。"
    show kurata uniform at right
    with dissolve
    ichinen "す、すみません、バスケは……ボールが顔に来ると、目をつぶっちゃうので……"
    show daimon jersey at left
    with dissolve
    daimon "……あの"
    "いっしょに来ていた{rb}大門{/rb}{rt}だいもん{/rt}が、一歩前に出た。"
    daimon "僕も、つぶってました。去年の、今ごろまで"
    kurata "あ……！　去年の夏の、PK戦の……！"
    kurata "{rb}倉田{/rb}{rt}くらた{/rt}です。中学で、キーパーを、ちょっとだけ……。試合には、出たことないです"
    kurata "1回戦のPK、スタンドで見てました。最後の一本、横に飛んだやつ"
    daimon "あ、あれは、その……たまたまで……"
    kurata "たまたまで、あんなに飛べないです！"
    "大門は、耳まで赤くなって、俺のほうを見た。助けを求める顔だった。"
    ren "……キーパー、二人いると助かる。来てくれ"
    kurata "は、はい！　あ、友だちも一人、連れてっていいですか。あいつ、足だけは速いんで"
    hide daimon
    hide kurata
    with dissolve
    $ a4_members += 2
    $ bond_up("大門", 3)
    $ meet("倉田")
    return

## グラウンド：赤坂（鷹野に抜かれて悔しがる、生意気なFW）
label a4_rc_ground:
    scene bg kohoku_ground_eve
    with dissolve
    "グラウンドで、1年が勝手にボールを蹴っていた。シュートは、強い。そのたびに、こっちを見る。見てほしいのが、丸わかりだった。"
    show akasaka uniform
    with dissolve
    akasaka "あの。ここのフォワード、誰っすか"
    show akasaka uniform at left
    show takano jersey at right
    with dissolve
    takano "……俺だけど"
    akasaka "{rb}赤坂{/rb}{rt}あかさか{/rt}です。中学で、市の得点王でした。……1対1、やってもらえます？"
    akasaka "桜嶺のセレクションも受かったけど、蹴りました。100人いるとこで3年ベンチより、すぐ出られるとこで点取ったほうが、目立つんで"
    akasaka "勝ったら、俺がスタメンでいいっすよね"
    "鷹野は、何も言わずに、ボールを足の裏で止めた。三回やって、三回とも、鷹野が抜いた。三回目は、赤坂がしりもちをついた。"
    akasaka "……っ、もう一回！"
    takano "今日は終わりだ。続きは、入部してからにしろ"
    hide takano
    show akasaka uniform at center
    with dissolve
    akasaka "……入りますよ。勝ち逃げは、させないんで"
    akasaka "あと、同じクラスにもう一人、キーパー以外ならなんでもやるってやつがいるんで、連れてきます"
    hide akasaka
    with dissolve
    $ a4_members += 2
    $ bond_up("鷹野", 2)
    $ meet("赤坂")
    return

## 1年の昇降口：小早川（誘う前から、入部届を書いていた）
label a4_rc_hall:
    scene bg kohoku_hall_spring
    with dissolve
    "1年の昇降口は、新しい上ばきの匂いがした。ビラを配っていると、一人の1年が、まっすぐこっちに歩いてきた。"
    show kobayakawa uniform
    with dissolve
    kobayakawa "サッカー部の方ですよね。入部届、どこに出せばいいですか"
    "差し出された紙は、もう全部、きれいな字で埋まっていた。希望のポジションの欄に、「ボランチ」。"
    ren "……誘いに来たのに、先に出された"
    kobayakawa "すみません。合格発表の日から、書いてあったので"
    ren "締め切りは15日だ。部室に、自分で持ってきてくれ。……みんなに、顔を見せてほしい"
    kobayakawa "はい。……あの、先輩"
    kobayakawa "先輩は、パスを出す前に、どこを見てるんですか"
    "答える前に、チャイムが鳴った。小早川は、頭を下げて、教室へ戻っていった。"
    hide kobayakawa
    with dissolve
    $ up("戦術眼", 1)
    return

## 生徒会室：千夏（部活紹介の掲示と、県の会議の日）
label a4_rc_council:
    scene bg student_council
    with dissolve
    show chika normal
    with dissolve
    chika "部活紹介の掲示ですね。……サッカー部の分は、もう貼ってあります"
    ren "え"
    chika "去年の試合の写真です。勝手に、私が選びました"
    "掲示板の写真は、去年の夏、PK戦に勝った瞬間の一枚だった。全員の顔が、ぐしゃぐしゃだった。"
    chika "……いちばん、入りたくなる写真だと思ったので"
    chika "県の会議は、19日です。……決まったら、最初に、あなたに言います"
    $ a4_heard_meeting = True
    $ heart_up("千夏", "信頼", 3)
    hide chika
    with dissolve
    return


################################################################################
## ② 5月・③ 7月：練習メニュー → 行動マップ
################################################################################
define A4_FREE = {
    "a4may": (["5月12日（水）", "5月14日（金）", "5月17日（月）", "5月19日（水）"], "放課後", "5月の放課後、どこへ行く？"),
    "a4jul": (["7月14日（水）", "7月15日（木）", "7月16日（金）", "7月19日（月）"], "放課後", "7月、どこへ行く？"),
}
## 休日（港の防波堤が開く日）
define A4_HOLIDAYS = ["7月19日（月）"]

init python:
    A4_SPOTS = {
        "a4may": [
            ("roof", "屋上", 330, 45, "takano", "鷹野", "a4_may_takano"),
            ("council", "生徒会室", 740, 75, "chika", "千夏", "a4_may_chika"),
            ("clubroom", "部室", 600, 170, "daimon", "1年生たち", "a4_may_first"),
            ("staff", "職員室", 480, 250, "kuroda", "黒田", "a4_may_kuroda"),
            ("shokudo", "はやせ食堂", 850, 460, "hinata", "ひなた", "a4_may_hinata"),
            ("station", "港北駅", 1050, 120, "ageha", "あげは", "a4_may_ageha"),
        ],
        "a4jul": [
            ("council", "生徒会室", 740, 75, "chika", "千夏", "a4_jul_chika"),
            ("clubroom", "部室", 600, 170, "", "桐生・宮下", "a4_jul_3rd"),
            ("arcade", "駅前のゲーセン", 1050, 120, "sakaguchi", "坂口たち", "a4_jul_arcade"),
            ("slope", "港への坂道", 870, 330, "hinata", "ひなた", "a4_jul_hinata"),
            ("pier", "港の防波堤", 330, 560, "saki", "紗希", "a4_jul_pier"),
            ("shotengai", "商店街", 1170, 300, "ageha", "あげは", "a4_jul_ageha"),
        ],
    }

    def a4_spots(month):
        f = store.flags
        today = A4_FREE[month][0][store.a4_day - 1]
        out = []
        for sid, name, x, y, face, ev, lab in A4_SPOTS[month]:
            done = f.get(lab)
            enabled = not done
            ## 港の防波堤は、休日しか開かない
            if sid == "pier" and today not in A4_HOLIDAYS:
                enabled = False
                ev = "休日だけ"
            d = {"id": sid, "name": name, "x": x, "y": y,
                 "event": "" if done else ev, "enabled": enabled}
            if face:
                d["face"] = face
            out.append(d)
        return out

    def a4_spot_label(month, sid):
        for s in A4_SPOTS[month]:
            if s[0] == sid:
                return s[6]
        return ""

define A4_RECAP = {
    "a4may": "港北の統合が決まった。今年の1年生が、港北に入る最後の1年生。\n俺たちは、11人で戦える最後の代になった。\n\n4月29日、港で神城が言った。\n「あのタックルは、俺が決めた」\n\n黒田が、小早川を入れた新しい並びを考えている。\n6月の終わりから、インターハイ予選。",
    "a4jul": "インターハイ予選は、ベスト4。準決勝で、桜嶺に0−2で負けた。\n神城は、出てこなかった。\n\n鷹野に、強い私立から、編入の誘いが来ている。\n3年の桐生先輩と宮下先輩は、ここで引退するか、冬まで残るかを決める。",
}

label a4_free_loop(month):
    $ a4_dates, a4_time, a4_banner = A4_FREE[month]
    $ recap_text = A4_RECAP[month]
    scene black
    with dissolve
    window auto hide
    if month == "a4may":
        tuto "自由行動です。練習メニューを選んでから、行動マップで会いに行く人を選びます。5月の放課後は4日。"
    else:
        tuto "自由行動です。7月は4日。19日（海の日）だけは、港の防波堤にも行けます。"
    $ a4_day = 1
    while a4_day <= len(a4_dates):
        $ amb_stop()
        $ set_cal(a4_dates[a4_day - 1], a4_time)
        $ bgm("作戦会議っぽい軽快な曲")
        window auto hide
        call practice_day(month)
        $ set_cal(a4_dates[a4_day - 1], a4_time)
        $ bgm("作戦会議っぽい軽快な曲")
        window auto hide
        call screen action_map(a4_spots(month), a4_banner + "（残り" + str(len(a4_dates) + 1 - a4_day) + "日）")
        $ _lab = a4_spot_label(month, _return)
        $ set_flag(_lab)
        call expression _lab
        $ amb_stop()
        ## 夜のトーク（chapter4a_night.rpy。送れるのは月の最後の夜だけ）
        call a4_night_send(a4_dates[a4_day - 1], month)
        $ a4_day += 1
    $ amb_stop()
    return

default a4_dates = []
default a4_time = ""
default a4_banner = ""


################################################################################
## 5月の行き先
################################################################################

## 屋上：鷹野と、赤坂のこと
label a4_may_takano:
    scene bg rooftop
    with dissolve
    $ bgm("少しとがった曲")
    show takano normal
    with dissolve
    "屋上のフェンスの前で、{rb}鷹野{/rb}{rt}たかの{/rt}がパンをかじっていた。"
    takano "……赤坂のやつ、毎日1対1やれって言ってくる"
    ren "やってやれよ"
    takano "やってる。毎日、抜いてる。……毎日、もう一回って言う"
    takano "うぜえ。……昔の俺みてえで"
    takano "ジュニアユースのとき、上の学年のフォワードに、毎日挑んでた。一回も勝てなかった"
    takano "あの人、今は大学で、ベンチにも入ってねえらしい"
    menu:
        "「赤坂に、一回だけ負けてやれ」":
            $ lean("仲間型")
            $ bond_up("鷹野", 2)
            takano "……ふざけんな。わざと負けたら、あいつ、一生気づくぞ"
            takano "……でも、まあ。シュートの打ち方くらいは、教えてやってもいい"
        "「絶対に負けるな。赤坂のために」":
            $ lean("野心型")
            $ bond_up("鷹野", 3)
            takano "……当たり前だ"
            takano "負けたら、あいつ、そこで止まる。俺は止まらなかったから、ここにいる"
    hide takano
    with dissolve
    $ up("メンタル", 1)
    return

## 生徒会室：千夏と「港北の記録」（5年前のキャプテン＝千夏の兄）
label a4_may_chika:
    scene bg student_council
    with dissolve
    $ bgm("静かな春の曲")
    show chika normal
    with dissolve
    chika "「港北の記録」です。閉校までに、部活ごとに、残せる写真を全部集めます"
    chika "サッカー部は、5年前の分から"
    "いちばん上の写真は、県のベスト8のときの集合写真だった。真ん中に、腕章を巻いた3年生がいた。"
    chika "……兄です"
    chika "あのころは、部員が30人いました。今の、倍です"
    chika "兄は、家ではサッカーの話を、一度もしませんでした。だから私は、写真でしか知りません"
    menu:
        "「先輩のお兄さんにも、見てもらいましょう。最後の代を」":
            $ heart_up("千夏", "信頼", 5)
            chika "……そうですね。兄は、たぶん、文句を言いながら見に来ます"
        "「今年の写真も、ここに並べてください」":
            $ heart_up("千夏", "信頼", 4)
            $ up("メンタル", 1)
            chika "そのつもりです。……5年前より、いい写真を撮ります"
    if a4_chika_call != "早瀬くん":
        "帰りぎわ、廊下に誰もいないのを確かめてから、先輩は言った。"
        chika "……[a4_chika_call]。明日も、練習を撮りに行きます"
    hide chika
    with dissolve
    $ set_flag("千夏_記録")
    return

## 部室：1年生たち（小早川・倉田・赤坂）
label a4_may_first:
    scene bg clubroom
    with dissolve
    $ bgm("とぼけた日常の曲")
    "部室で、1年たちが、去年のスコアブックを読んでいた。"
    show kobayakawa jersey at gang(0.22)
    show akasaka jersey at gang(0.5)
    show kurata jersey at gang(0.78)
    with dissolve
    kobayakawa "早瀬先輩。去年の5月31日、桜嶺に0−9って、本当ですか"
    ren "本当だ"
    akasaka "うわ、ひっど。俺なら一点は取ってますね"
    "鷹野が部室の前を通りかかって、赤坂の頭を、スコアブックで軽くたたいていった。"
    kurata "あの、大門先輩……0−9のとき、どんな気持ちでしたか"
    hide kobayakawa
    hide akasaka
    hide kurata
    show daimon jersey
    with dissolve
    daimon "えっ。あ、えっと……九回目くらいで、もう、数えるのをやめました"
    daimon "でも、次の日も、練習に来ました。……それだけです"
    hide daimon
    with dissolve
    "倉田は、それをノートに書いていた。ひなたの真似らしかった。"
    show kobayakawa jersey
    with dissolve
    if "hall" in a4_recruit:
        kobayakawa "先輩。この前の答え、まだ聞いてません"
    else:
        kobayakawa "先輩。ずっと、聞きたかったことがあって"
    kobayakawa "パスを出す前に、どこを見てるんですか"
    menu:
        "「ボールが来る前に、一回、首を振る。それだけだ」":
            $ up("戦術眼", 1)
            kobayakawa "……一回、だけですか"
            ren "一回で足りるように、来る前から見てる"
            "小早川は、その場で首を振る練習を始めた。三回振って、目が回っていた。"
        "「黒田先生に聞け。俺も教わった」":
            $ lean("仲間型")
            kobayakawa "……先輩も、教わったんですね"
    hide kobayakawa
    with dissolve
    $ bond_up("大門", 2)
    return

## 職員室：黒田の過去の一端と、佐伯
label a4_may_kuroda:
    scene bg staffroom
    with dissolve
    $ bgm("とぼけた日常の曲")
    show kuroda normal
    with dissolve
    "職員室の黒田の机に、見慣れない茶封筒が置いてあった。表に、青い字で「潮見ブルーマリンズ」。"
    kuroda "……のぞくな"
    ren "グラウンドのフェンスのところにいた人、ブルーマリンズの人ですか"
    kuroda "佐伯だ。……ブルーマリンズで、同じ年に入った"
    kuroda "俺がひざで辞めたあとも、あいつは選手を続けて、今はスカウトをやってる"
    kuroda "あいつは、見る目だけはある。……だから、来るたびに、うるさい"
    menu:
        "「先生も、ひざで……」":
            $ lean("求道型")
            $ up("メンタル", 1)
            kuroda "……ああ"
            kuroda "ひざだ。……ひざだけじゃ、ないがな"
            "それ以上は、何も言わなかった。言うつもりがないのが、分かった。"
            $ set_flag("黒田_ひざだけじゃない")
        "「何を見に来てるんですか」":
            $ lean("野心型")
            $ up("注目度", 2)
            kuroda "……知らん。自分で考えろ"
            kuroda "ただ、あいつがメモを取るのは、ボールを持ってないやつのほうだ。昔から"
    hide kuroda
    with dissolve
    $ up("戦術眼", 1)
    return

## はやせ食堂：ひなた（後輩に聞かれたこと・トレーナーの夢）
label a4_may_hinata:
    scene bg shokudo_day
    with dissolve
    $ bgm("あたたかいアコースティックギター")
    show hinata apron
    with dissolve
    "店の手伝いに来ていたひなたが、カウンターをふきながら、急に笑い出した。"
    hinata "ねえ、今日、1年生に聞かれたの。「ひなた先輩と早瀬先輩って、付き合ってるんですか」って"
    ren "……なんて答えたんだよ"
    hinata "「マネージャーと、手のかかる選手です」って"
    hinata "そしたら、「あー」って。みんな、すごく納得してた"
    "母さんが、厨房の奥で、吹き出す音がした。"
    hinata "……それでね。7月に、理学療法の学校の見学に行くの"
    if flags.get("ひなた_トレーナー"):
        hinata "去年、言ったでしょ。トレーナーになりたいって。……ちゃんと、調べ始めた"
    else:
        hinata "けがした人が、また走れるようになるのを手伝う仕事。……トレーナー、って言うのかな"
    menu:
        "「ひなたなら、向いてる。俺が保証する」":
            $ heart_up("ひなた", "信頼", 5)
            hinata "……保証人、いちばん手のかかる選手なんですけど"
        "「見学の話、あとで聞かせてくれ」":
            $ heart_up("ひなた", "信頼", 4)
            $ up("メンタル", 1)
            hinata "うん。……ひざの話も、ついでに聞いてくるね"
    hide hinata
    with dissolve
    $ set_flag("ひなた_トレーナー")
    return


################################################################################
## 7月の行き先
################################################################################

## 生徒会室：受験の夏の千夏
label a4_jul_chika:
    scene bg student_council
    with dissolve
    $ bgm("静かな春の曲")
    show chika normal
    with dissolve
    "生徒会室の机の半分が、参考書で埋まっていた。もう半分は、まだ写真だった。"
    chika "……受験生ですから。でも、写真の整理は、やめられません"
    chika "生徒会長の任期は、9月の終わりまでです"
    chika "それが終わったら、私はこの部屋に来なくなります。……来る理由が、なくなります"
    if flags.get("兆し") == "chika":
        chika "前の副会長の{rb}相良{/rb}{rt}さがら{/rt}さんから、同じ大学を受けないかと言われています。……勉強会に誘われました"
        "先輩は、なんでもないことのように言った。"
        ## 関係が冷えているときの「ほかの人」の話（相良）。第5章まで取り返せる（v0.31.1・Claude の下書き）
        menu:
            "「……行けばいいと思います。先輩の大学のことだし」":
                $ heart_up("千夏", "さみしさ", 3)
                chika "……そうですね。そうします"
                "先輩は、写真の束を、一枚だけ裏返した。"
            "「その勉強会、俺も数学を教わりに行っていいですか」":
                $ heart_up("千夏", "ときめき", 4)
                $ heart_up("千夏", "さみしさ", -3)
                show chika narrow
                chika "……2年生が、3年生の受験の勉強会に、ですか"
                chika "…………考えておきます。相良さんへの返事も、考えておきます"
                show chika normal
    menu:
        "「卒業しても、写真、撮りに来てください」":
            $ heart_up("千夏", "信頼", 5)
            chika "……OGとして、ですか"
            chika "考えておきます。三好先輩みたいに、声は出しませんけど"
        "「受験、がんばってください。俺たちも、勝ちます」":
            $ heart_up("千夏", "信頼", 3)
            $ up("メンタル", 1)
            chika "……はい。どちらも、結果を出しましょう"
    hide chika
    with dissolve
    return

## 部室：桐生・宮下（インターハイで引退するか、冬まで残るか）
label a4_jul_3rd:
    scene bg clubroom
    with dissolve
    $ bgm("静かな春の曲")
    show kiryu jersey at gang(0.3)
    show miyashita jersey at gang(0.7)
    with dissolve
    "部室に、3年の二人だけが残っていた。"
    miyashita "あ、早瀬くん。……ちょうど、その話してたの"
    kiryu "……引退。インターハイで終わるか、冬まで残るか"
    miyashita "うちの親は、受験しろって。……でも、去年まで名前だけの部員だったのに、今さら一番楽しいんだよね。ふふっ、変なの"
    kiryu "…………早瀬は、どう思う"
    menu:
        "「冬まで、一緒にやってください」":
            $ set_flag("a4_3年_冬まで")
            $ lean("仲間型")
            kiryu "……そう言うと思った"
            miyashita "じゃあ、受験は冬のあと。……三好先輩みたいに、ぎりぎりまでやろっか"
        "「先輩たちが決めてください。どっちでも、ついていきます」":
            $ set_flag("a4_3年_自分で")
            $ lean("求道型")
            kiryu "……ずるいな、それ"
            miyashita "ふふっ。……でも、うれしい。ちゃんと二人で決めるね"
            "その日の夜、二人から同じ文面のトークが届いた。「冬まで」。"
    hide kiryu
    hide miyashita
    with dissolve
    $ up("メンタル", 1)
    return

## 駅前のゲーセン：坂口たち（2年になって）
label a4_jul_arcade:
    scene bg game_center
    with dissolve
    $ bgm("ゲームセンターの曲")
    "駅前のゲーセンの、いつもの台の前に、5人と、なぜか赤坂がいた。"
    show sakaguchi normal
    with dissolve
    sakaguchi "あ、蓮。見て、赤坂に教えてんの。サイドからのクロスの打ち方"
    akasaka "……ゲームの話っすよね？"
    sakaguchi "ゲームも本物も、だいたい同じ。ウケる"
    "江藤が、横から無言でコントローラーを奪って、ドリブルだけでゴールを決めた。小池が、画面を指さした。「……たぶん、今のは、右が空いてた」"
    sakaguchi "なあ、蓮。……俺ら、あと1年ちょいで、ここ来なくなんのかな"
    sakaguchi "学校なくなったら、ここが、俺らの部室になったりして"
    menu:
        "「なくならない。俺たちが覚えてる」":
            $ bond_up("坂口", 3)
            $ lean("仲間型")
            sakaguchi "……くっさ。ウケる"
            sakaguchi "…………でも、それでいいわ"
        "「その前に、桜嶺に勝つぞ」":
            $ bond_up("坂口", 2)
            $ lean("野心型")
            if a4_captain == "ren":
                sakaguchi "うわ、出た。キャプテンの決めゼリフ。ウケる"
            else:
                sakaguchi "うわ、出た。キャプテンみたいなこと言う"
            sakaguchi "……でもまあ、0−9からは、だいぶ近くなったもんな"
    hide sakaguchi
    with dissolve
    $ up("戦術眼", 1)
    return

## 港への坂道：ひなた（理学療法の学校の見学のあと）
label a4_jul_hinata:
    scene bg slope_eve
    with dissolve
    $ bgm("あたたかいアコースティックギター")
    show hinata normal
    with dissolve
    "坂道の途中で、ひなたが、学校の名前の入った紙袋を下げていた。"
    hinata "見学、行ってきた。……すごかった。ひざの模型がね、ばらばらになるの"
    if flags.get("兆し") == "hinata":
        hinata "案内してくれた2年の{rb}柏木{/rb}{rt}かしわぎ{/rt}さんって人が、いろいろ教えてくれて。サッカーやってたんだって"
        hinata "今度、勉強の仕方、聞いてみようかなって"
        "ひなたは、楽しそうだった。"
        ## 関係が冷えているときの「ほかの人」の話（柏木）。第5章まで取り返せる（v0.31.1・Claude の下書き）
        menu:
            "「よかったな。……いろいろ、聞いてこいよ」":
                $ heart_up("ひなた", "さみしさ", 3)
                hinata "うん。……蓮、そういうの、気にしないもんね"
                "ひなたは、笑ったまま、紙袋を持ちかえた。"
            "「サッカーの話なら、俺に聞けよ」":
                $ heart_up("ひなた", "ときめき", 4)
                $ heart_up("ひなた", "さみしさ", -3)
                hinata "……え。蓮、今の、やきもち？"
                ren "ちがう"
                hinata "眉毛、上がってる"
                "ひなたは、紙袋で顔の半分を隠して、くすくす笑った。"
    hinata "先生にね、聞いてみたの。……ひざの、前の靱帯のこと"
    hinata "同じところを二回けがすると、手術になることが多いって"
    if flags.get("ひなた_うそ一覧_閉じた"):
        hinata "……蓮から聞いたことと、同じだった。だから、こわくなかった"
    else:
        hinata "……蓮。わたし、まだ聞いてないこと、あるよね"
        "眉毛を見られる前に、目をそらした。"
    menu:
        "「8月の終わりに、検診がある。……一緒に、来てくれるか」":
            $ heart_up("ひなた", "信頼", 6)
            $ set_flag("a4_検診_誘った")
            hinata "……うん。行く"
            hinata "待合室で、眉毛、見ててあげる"
        "「大丈夫だ。今年は、まだ一回も腫れてない」":
            $ heart_up("ひなた", "さみしさ", 3)
            $ up("無理ゲージ", 2)
            hinata "……そっか"
    hide hinata
    with dissolve
    return

## 港の防波堤（7/19 海の日だけ）：紗希
label a4_jul_pier:
    scene bg harbor_sunset
    with dissolve
    $ se("波の音、カモメ")
    if heart_total("紗希") < A4_SAKI_MEET:
        $ bgm("（なし）")
        "海の日の防波堤は、釣りの人でいっぱいだった。"
        "遠くの家の窓から、ピアノの音が、少しだけ聞こえた気がした。"
        "でも、防波堤の先には、誰もいなかった。"
        $ amb_stop()
        return
    $ bgm("静かなピアノの旋律")
    "釣りの人たちから離れた、防波堤のいちばん先に、[saki_call]が座っていた。"
    show saki casual
    with dissolve
    saki "……休みの日にまで、来るんだ"
    ren "準決勝、見てたか"
    saki "……見てた。ベンチのすぐ後ろの席で"
    saki "あの人、試合の間、一回も立たなかった。勝つのが分かってる試合は、立たないの"
    saki "……神城さん、ベンチにもいなかった。いつもは、あの人の目の届くところで走ってるのに"
    menu:
        "「神城は、なんで出なかったんだ」":
            $ heart_up("紗希", "信頼", 4)
            saki "知らない。……知ってても、言わない"
            saki "あなたが知りたいのは、本当は、そういうことじゃないでしょ"
        "「……ピアノ、まだ弾いてるか」":
            $ heart_up("紗希", "信頼", 5)
            saki "弾いてる。……止まらないで、弾けるようになった"
    hide saki
    with dissolve
    $ amb_stop()
    return


################################################################################
## 第4章の練習の出来事（practice.rpy の PRACTICE_EVENTS_A4。月は "a4may" / "a4jul"）
##   1年生が入った港北。いま使える出来事（体験版のうち、三好先輩が出ないもの）も混ぜる
################################################################################
define A4_MONTHS = ("a4may", "a4jul")
define PRACTICE_EVENTS_A4 = [
    ## ── 技術 ──
    ("a4p_koba_scan", "技術", A4_MONTHS),
    ("a4p_akasaka_shoot", "技術", A4_MONTHS),
    ("pr_kuroda_trap", "技術", A4_MONTHS),
    ("pr_eto_1on1", "技術", A4_MONTHS),
    ("pr_sakaguchi_cross", "技術", A4_MONTHS),
    ## ── フィジカル ──
    ("a4p_kurata_run", "フィジカル", A4_MONTHS),
    ("a4p_hinata_taping", "フィジカル", A4_MONTHS),
    ("a4p_ageha_drink", "フィジカル", A4_MONTHS),     # あげは（v0.30.0）
    ("pr_kiryu_stairs", "フィジカル", A4_MONTHS),
    ("pr_daimon_core", "フィジカル", ("a4may",)),
    ## ── 戦術眼 ──
    ("a4p_koba_board", "戦術眼", A4_MONTHS),
    ("a4p_ageha_film", "戦術眼", A4_MONTHS),          # あげは（v0.30.0）
    ("a4p_saeki_fence", "戦術眼", ("a4jul",)),
    ("ch3_pr_set", "戦術眼", A4_MONTHS),
    ("pr_koike_video", "戦術眼", ("a4may",)),
    ## ── メンタル ──
    ("a4p_daimon_kurata", "メンタル", A4_MONTHS),
    ("a4p_miyoshi_ob", "メンタル", A4_MONTHS),
    ("pr_kuroda_before", "メンタル", ("a4may",)),
    ("pr_pier_piano", "メンタル", A4_MONTHS),
]

## 小早川に、首の振り方を教える
label a4p_koba_scan:
    show kobayakawa jersey
    with dissolve
    "パス回しの練習。{rb}小早川{/rb}{rt}こばやかわ{/rt}が、ボールが来る前に、首を振るようになった。振りすぎて、ボールが来たときには、反対を向いていた。"
    kobayakawa "……すみません、見すぎました"
    ren "見るのは、一回でいい。二回目は、体で覚えてる場所を信じろ"
    "十本目。小早川は、一回だけ首を振って、ワンタッチで鷹野に通した。"
    kobayakawa "……今の、見えました"
    hide kobayakawa
    with dissolve
    return

## 赤坂のシュートと、倉田
label a4p_akasaka_shoot:
    show akasaka jersey at left
    show kurata jersey at right
    with dissolve
    "シュート練習。ゴールの前で、{rb}倉田{/rb}{rt}くらた{/rt}が両手を広げていた。"
    akasaka "倉田、目つぶんなよ。痛いぞ、俺の"
    kurata "つ、つぶらない……！"
    "赤坂のシュートは、倉田の顔の横を抜けていった。倉田は、目を開けたままだった。"
    akasaka "……今の、見えてた？"
    kurata "見えてた。……手が、動かなかっただけ"
    hide akasaka
    hide kurata
    with dissolve
    return

## 倉田と、最後尾の外周
label a4p_kurata_run:
    "外周の走りこみ。いちばん後ろを、倉田が走っていた。去年、森が走っていた場所だった。"
    show kurata jersey at right
    show mori jersey at left
    with dissolve
    mori "……倉田。先、行かなくていい。最後尾には、最後尾の仕事がある"
    kurata "し、仕事、ですか"
    mori "前のやつが倒れたら、拾う。……それだけ"
    hide mori
    hide kurata
    with dissolve
    "森は、倉田と並んで、最後まで走った。俺も、その後ろについた。"
    $ bond_up("坂口", 1)
    return

## ひなたが、1年にテーピングを教える
label a4p_hinata_taping:
    "走りこみの前。ベンチで、ひなたが1年たちにテーピングの巻き方を教えていた。"
    show hinata normal
    with dissolve
    hinata "足首は、ここから。強く引っぱりすぎると、血が止まるからね"
    ichinen "篠宮先輩、早瀬先輩のひざも、先輩が巻いてるんですか"
    hinata "うん。いちばん手のかかる足だから"
    hinata "蓮、座って。見本"
    "見本にされたひざは、いつもより、ていねいに巻かれた。"
    hide hinata
    with dissolve
    $ set_flag("a4p_hinata_taping")     # 夜のトーク（A4_NIGHT_NEED）の前提
    $ heart_up("ひなた", "信頼", 1)
    $ up("無理ゲージ", -1)
    return

## 小早川と小池、二人のボランチ
label a4p_koba_board:
    "作戦ボードの前で、{rb}小池{/rb}{rt}こいけ{/rt}と小早川が、マグネットを動かしていた。"
    show koike jersey at left
    show kobayakawa jersey at right
    with dissolve
    koike "小早川が前、俺が後ろ。……たぶん、そのほうがいい"
    kobayakawa "小池先輩、前に出ないんですか"
    koike "前に出ると、迷子になるんで"
    "小早川は、真剣な顔で、ノートに「小池先輩は前に出ると迷子」と書いていた。"
    hide koike
    hide kobayakawa
    with dissolve
    "黒田が、ボードを見て、マグネットを一つだけ動かした。俺のマグネットだった。"
    return

## フェンスの外の佐伯（7月）
label a4p_saeki_fence:
    "練習の途中。フェンスの外に、また、あの人が立っていた。"
    show saeki normal
    with dissolve
    "青いジャンパー。手帳。ボールではなく、ボールを持っていない選手を見ている。"
    hide saeki
    show kuroda peek
    with dissolve
    kuroda "……気にするな。見られて変わるなら、それまでだ"
    hide kuroda
    with dissolve
    "それから、ボールを持っていないときの自分の位置が、少しだけ気になった。気になったぶん、いつもより、よく見えた。"
    $ up("注目度", 1)
    return

## 大門が、倉田にPKを教える（去年、蓮が大門に言ったこと）
label a4p_daimon_kurata:
    "PKの練習。ゴールの前に、大門と倉田が並んでいた。"
    show daimon jersey at left
    show kurata jersey at right
    with dissolve
    daimon "倉田くん。……目、つぶらないで。ボールが来るのを、最後まで見て"
    "去年の夏、俺が大門に言った言葉だった。"
    kurata "は、はい。最後まで、見ます"
    "十本目。倉田の手が、初めてボールに触れた。大門は、自分が止めたときより、うれしそうだった。"
    hide daimon
    hide kurata
    with dissolve
    $ bond_up("大門", 1)
    return

## 三好先輩（OB）が、工務店のトラックで来る
label a4p_miyoshi_ob:
    "練習の終わりごろ、グラウンドの横に、軽トラックが止まった。荷台に「三好工務店」。"
    show miyoshi work
    with dissolve
    miyoshi "おーい！　声が小さいぞ、港北ーっ！"
    "作業着のまま仕事を抜けてきた三好先輩が、フェンスをよじのぼりそうな勢いで叫んでいた。"
    miyoshi "1年！　声出しの練習だ！　一番言いたいことを、一番でかい声で！"
    "1年たちが、きょとんとした顔で、俺を見た。"
    ren "……勝つぞ"
    "去年と同じ言葉を、去年より大きな声で言った。[a4_members]人が、同じ言葉を叫んだ。"
    miyoshi "それだ！　……じゃあな！　仕事中だ！"
    hide miyoshi
    with dissolve
    $ bond_up("三好", 2)
    return
