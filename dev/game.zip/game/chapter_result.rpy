################################################################################
## 章のまとめ（リザルト画面）v0.37.0
##   章の終わりに、ひなたのノートの1ページとして出す。中身は5つ：
##   ・この章の試合（スコアと、自分のプレーのひとこと）
##   ・能力の伸び（章のはじめから、どれだけ伸びたか。棒グラフ）
##   ・ヒロインとの距離（ひとことと目盛り。数字は出さない）
##   ・大きな選択（この章で選んだこと 2〜3個）
##   ・次の章へのヒント（黒田か、ひなたのひとこと）
##   取り逃したイベントの数は出さない（出すとしても2周目から）。
##   セーブの区切りも兼ねる（セーブする／つづける）。第3章のあとは、製品版（第4章）へのつなぎになる。
##   使い方：call chres_show("ch1")   ※ "pro" / "ch1" / "ch2" / "ch3"（曲を流して、画面を出して、曲を止める）
##   v0.37.0 第3版：タイトル・5つのパートを1ページずつ流す（作者の声「各パートを順番に流す」）。見た目は確認ページ第13回の「A4-3」。
##   タップで次のページ（動いている途中のタップは、そのページの動きを最後まで飛ばす）。「とばす」で最後のページへ
##   章のはじめの能力と気持ちは、ラベル prologue / chapter1 / chapter2 / chapter3 に入ったときに覚える。
##   その前のセーブから続けた人は、はじめの値がないので、伸びは出さずに今の値だけを出す
################################################################################

default chres_start = {}

define CHRES_START_LABELS = {"prologue": "pro", "chapter1": "ch1", "chapter2": "ch2", "chapter3": "ch3"}

## (タイトル, 時期)
define CHRES_META = {
    "pro": ("プロローグ　止まった冬", "中3の冬〜春"),
    "ch1": ("第1章　はじまりの十一人", "4月〜5月"),
    "ch2": ("第2章　泥だらけの夏", "6月〜9月"),
    "ch3": ("第3章　冬の扉", "9月〜大晦日"),
}

## ヒロインとの距離のひとこと（low / mid / high × 信頼寄り trust / ときめき寄り heart）
define CHRES_HEROINE_LINES = {
    "ひなた": {"low": "いつもの幼なじみ。近すぎて、よく見えない",
             "mid_trust": "何も言わなくても、だいたい通じる",
             "mid_heart": "ときどき、ひなたが知らない人に見える",
             "high_trust": "隣にいるのが、当たり前になっている",
             "high_heart": "目が合うと、どちらからともなくそらす"},
    "千夏": {"low": "記録をつけている人。こっちも、記録されている",
            "mid_trust": "正直に話せば、ちゃんと聞いてくれる",
            "mid_heart": "カメラの向こうで、少しだけ笑うようになった",
            "high_trust": "部のことを、いちばん分かってくれている先輩",
            "high_heart": "ファインダー越しじゃない顔を、見せてくれる"},
    "紗希": {"low": "港で会った子。まだ、何も知らない",
            "mid_trust": "サッカーが嫌いな理由を、少しだけ聞いた",
            "mid_heart": "言い返されるのが、ちょっと楽しい",
            "high_trust": "自分のことを、少しずつ話してくれる",
            "high_heart": "次に港で会える日を、数えている"},
}

init python:
    def chres_snap(name, abnormal):
        """章のはじめの能力と気持ちを覚える"""
        k = CHRES_START_LABELS.get(name)
        if k:
            d = dict(store.chres_start)
            d[k] = {"stats": dict(store.stats),
                    "heart": dict((h, dict(v)) for h, v in store.heart.items()),
                    "plays": list(store.plays_learned),
                    "notes": list(store.note_learned),
                    "bond": dict(store.bond)}
            store.chres_start = d

    config.label_callbacks.append(chres_snap)

    def chres_next(k):
        """フッターの「つぎは」"""
        if k == "pro":
            return "つぎは　第1章「はじまりの十一人」"
        if k == "ch1":
            return "つぎは　第2章「泥だらけの夏」"
        if k == "ch2":
            return "つぎは　第3章「冬の扉」"
        return "つぎは　第4章（ここから製品版）"

    def chres_matches(k):
        """(日付, 試合, スコア, 結果 win/lose/pk, ひとこと)"""
        if k == "pro":
            return [("12/14", "中3の県大会　決勝", "0−1", "lose", "後半40分、神城と競り合って、右ひざをケガした")]
        if k == "ch1":
            note = {"dribble": "前半39分、自分で持ち出して、奪われた",
                    "pass": "前半39分、鷹野へ。港北の初めてのシュート",
                    "back": "前半39分、一度下げて、落ち着かせた"}.get(store.m531_play, "")
            return [("5/31", "練習試合　桜嶺学園B", "0−9", "lose", note)]
        if k == "ch2":
            n1 = ("蓮のPKは決まった" if store.ch2_pk_ok else "蓮のPKは外れた") + "。最後は大門の横っ飛び"
            if store.ch2_2nd == "attack":
                n2 = "後半、全員で攻めた。" + ("鷹野が1点返した" if store.ch2_2nd_score == "1−3" else "空いたうしろを突かれた")
            elif store.ch2_2nd == "hold":
                n2 = "0−1のまま耐えた。" + ("最後まで足が止まらなかった" if store.ch2_2nd_score == "0−1" else "最後の10分で足が止まった")
            else:
                n2 = ""
            return [("6/27", "インターハイ予選1回戦　白浜工業", "1−1", "pk", n1),
                    ("7/4", "インターハイ予選2回戦　西海学院", store.ch2_2nd_score, "lose", n2)]
        if k == "ch3":
            n3 = {"cross": "後半39分、坂口のクロスから決勝点",
                  "takano": "後半39分、鷹野に預けて蓮が決めた",
                  "self": "後半39分、自分で持ちこんだ"}.get(store.ch3_3rd, "")
            plan = {"look": "神城のくせ", "makabe": "14番の裏", "ck": "ファーを守る",
                    "sub": "交代を待つ", "kuroda": "黒田に任せた"}.get(store.ch3_plan, "")
            ns = ("作戦：%s　情報 %d/%d" % (plan, len(store.scout_cards), len(SCOUT))) if plan else ""
            return [("9/19", "練習試合　潮見北", "0−2", "lose", ""),
                    ("10/10", "選手権予選1回戦　緑ヶ丘", "2−0", "win", ""),
                    ("10/11", "選手権予選2回戦　県立工業", "1−0", "win", ""),
                    ("10/17", "選手権予選3回戦　明誠学院", "1−0", "win", n3),
                    ("10/31", "選手権予選準々決勝　潮見南", "2−1", "win", ""),
                    ("11/14", "選手権予選準決勝　桜嶺学園", store.ch3_semi or "-", "lose", ns)]
        return []

    def chres_stats(k):
        """(能力, はじめ, 今)。はじめの値がなければ、はじめ＝今"""
        s0 = store.chres_start.get(k, {}).get("stats") or {}
        out = []
        for key in STAT_KEYS:
            v = store.stats.get(key, 0)
            out.append((key, s0.get(key, v), v))
        return out

    def chres_seg(t, s):
        """ときめきと信頼から、目盛り（5マス）のいくつ目まで塗るか"""
        return rel_segments(min(100, (t + s) * 0.75))

    def chres_tier(nm, t, s):
        c = (t + s) / 2.0
        lines = CHRES_HEROINE_LINES[nm]
        if c < 15:
            return lines["low"]
        kind = "heart" if t > s else "trust"
        return lines[("mid_" if c < 35 else "high_") + kind]

    def chres_heroines(k):
        """(名前, 顔の画像, 今の目盛り, はじめの目盛り, ひとこと)。出会った人だけ"""
        h0 = store.chres_start.get(k, {}).get("heart") or {}
        out = []
        for nm, fid in (("ひなた", "hinata"), ("千夏", "chika"), ("紗希", "saki")):
            if not rel_heroine_shown(nm):
                continue
            h = store.heart.get(nm, {})
            t, s = h.get("ときめき", 0), h.get("信頼", 0)
            o = h0.get(nm, {})
            t0, s0 = o.get("ときめき", t), o.get("信頼", s)
            out.append((rel_name(nm), "gui/relations/face_%s.png" % fid,
                        chres_seg(t, s), min(chres_seg(t0, s0), chres_seg(t, s)), chres_tier(nm, t, s)))
        return out

    def chres_choices(k):
        """この章の大きな選択（2〜3個）"""
        f = store.flags
        c = []
        if k == "pro":
            if f.get("母_八人"):
                c.append("母に「続ける。まだ終わってない」と言った")
            else:
                c.append("母に「……もう、いいよ」と言った。スパイクは、ひなたが持ってきた")
            went = [w for lbl, w in (("pro_feb_hinata", "坂道でひなたと"), ("pro_feb_mother", "はやせ食堂で母と"),
                                     ("pro_feb_pier", "防波堤でボールと")) if f.get(lbl)]
            if went:
                c.append("2月の土曜日は、" + "、".join(went))
            if f.get("pro_父の写真"):
                c.append("父の写真のことを、母に聞いた")
        elif k == "ch1":
            days = [(d, w) for w, d in store.ch1_join.items() if d <= 3]
            if days:
                w = min(days)[1]
                c.append("4月、いちばん先に誘ったのは" + {"5人組": "坂口たち5人組"}.get(w, w))
            if f.get("520_正直"):
                c.append("千夏先輩に「正直、まだです」と言った")
            elif f.get("520_言い切った"):
                c.append("千夏先輩に「出られます」と言い切った")
            if f.get("紗希_名前を聞いた"):
                c.append("港で楽譜を拾った子に、名前を聞いた")
            elif f.get("紗希_出会い遅れ"):
                c.append("港で楽譜を拾った子を、何も言わずに見送った")
            elif rel_saki_seen():
                c.append("港で楽譜を拾った子に「何かあったのか」と聞いた")
        elif k == "ch2":
            c.append({"honest": "ひざの痛みを、ひなたに正直に言った",
                      "hide": "ひざの痛みを、ひなたに隠した"}.get(store.ch2_knee, ""))
            c.append({"hinata": "夏祭りに、ひなたを誘った", "chika": "夏祭りに、千夏先輩を誘った",
                      "boys": "夏祭りは、鷹野と大門と行った", "alone": "夏祭りは、一人で行った"}.get(store.ch2_fest, ""))
            c.append({"stay": "三好先輩に「いちばん後ろにいてください」と言った",
                      "kiryu": "三好先輩に「真ん中は桐生先輩たちに」と言った"}.get(store.ch2_miyoshi_cb, ""))
        elif k == "ch3":
            c.append({"ren": "三好先輩のキャプテンマークを、受け取った",
                      "takano": "キャプテンマークを、鷹野に渡してもらった"}.get(store.ch3_armband, ""))
            c.append({"hinata": "クリスマスは、ひなたと過ごした", "chika": "クリスマスは、千夏先輩と過ごした",
                      "saki": "クリスマスは、紗希と過ごした", "boys": "クリスマスは、部室でみんなと過ごした"}.get(store.ch3_xmas, ""))
            c.append({"stay": "大晦日、港北に残ると決めた", "move": "大晦日、桜嶺へ移ると決めた"}.get(store.ch3_route, ""))
        return [x for x in c if x][:3]

    def chres_hint(k):
        """(顔の画像, 名前, ひとこと)"""
        if k == "pro":
            return ("hinata", "ひなた", "まずは11人そろえよう。誰から声をかけるかで、変わるよ")
        if k == "ch1":
            return ("kuroda", "黒田", "夏は走れ。体ができてないと、最後の10分で足が止まる")
        if k == "ch2":
            return ("hinata", "ひなた", "冬は相手を調べよ。桜嶺を知ってる人の話、ちゃんと聞いて")
        if store.ch3_route == "move":
            return ("kuroda", "黒田", "桜嶺は強い者しか残さん。向こうで、自分の場所を取ってこい")
        return ("kuroda", "黒田", "春から2年だ。新入生が来る。……今度は、お前が教える番だ")


################################################################################
## 画面（v0.37.0 第3版：確認ページ第13回で決まった「A4-3」）
##   作者の声：第10回「メモのデザインじゃなくていい」→ 第11回「A（試合中継）を軸に、タイトルロゴの色で」
##   → 第12回「A4 を軸に」「モーションは必要最低限（ゲージが上がる、くらい）」「背景は章ごとの一枚絵」
##   → 第13回「ベースは A4-3 でよい。画面の切りかえにはエフェクトを」
##   ・色：ロゴの紺 #0b1f52・クリーム #fdf3ec・赤 #e8231f・白
##   ・背景：その章の一枚絵を、紺と赤の2色にしたもの（gui/chres/duo/。見たことのある絵だけ）
##   ・形：まん中に大きな字（ロゴと同じ「クリームの字・紺のふち・赤い影・少し斜め」）、下に札を横に並べる
##   ・ページ：タイトル → 試合 → 能力 → ヒロイン → 仲間 → 選択 → 次の章へ（7ページ）
##   ・動き：ページの切りかえ（斜めの紺の帯が横切る）、能力のゲージが伸びる、数字が上がる、ヒロインの目盛りが増える。だけ
################################################################################

define CHRES_NAVY = "#0b1f52"
define CHRES_NAVY2 = "#06133a"
define CHRES_CREAM = "#fdf3ec"
define CHRES_RED = "#e8231f"
define CHRES_SUB = "#aab6da"

## 見出しの字（Dela Gothic One・Bebas Neue・Zen Kaku Gothic New。どれも無料・商用OK。fonts/ に入れれば使う。ないときは Noto Sans の太字）
init 1 python:
    CHRES_F_HEAD = "fonts/DelaGothicOne-Regular.ttf" if renpy.loadable("fonts/DelaGothicOne-Regular.ttf") else FONT_JP_B
    CHRES_F_NUM = "fonts/BebasNeue-Regular.ttf" if renpy.loadable("fonts/BebasNeue-Regular.ttf") else FONT_JP_B
    CHRES_F_BODY = "fonts/ZenKakuGothicNew-Black.ttf" if renpy.loadable("fonts/ZenKakuGothicNew-Black.ttf") else FONT_JP_B

## 能力のランク（作者の声：OVR ではなく「総合力」に、ランクもつける）。体験版の終わりで D〜C、第1部の終わりで A 前後
define CHRES_RANKS = [(90, "S"), (85, "A+"), (80, "A"), (75, "B+"), (70, "B"), (65, "C+"), (60, "C"), (55, "D+"), (50, "D"), (45, "E+"), (40, "E")]

define CHRES_PAGES = [("RESULT", ""), ("MATCH RESULTS", "この章の試合"), ("GROWTH", "能力の伸び"),
                      ("HEROINES", "ヒロインとの距離"), ("TEAMMATES", "仲間との絆"), ("CHOICES", "大きな選択"), ("NEXT", "次の章へ")]
define CHRES_LAST = 6

## 港北の総合力（チームのランク）。物語で決まった値（章のはじめ → 終わり）。プロローグは、まだチームがない
##   作者の声「他の選手たちのステータスは？　見せかけだけにはなると思うけど」→ 選手ひとりずつではなく、チームの力をランク1つで
define CHRES_TEAM = {"pro": None, "ch1": ("-", "E"), "ch2": ("E", "D"), "ch3": ("D", "C")}

## 仲間との絆（数字は出さない）。(名前, 顔, 相関図の名前, 肩書き)。神城はライバル
define CHRES_MATES = [("鷹野", "takano", "鷹野", "FW"), ("大門", "daimon", "大門", "GK"), ("三好", "miyoshi", "三好", "キャプテン"),
                      ("坂口", "sakaguchi", "坂口", "5人組"), ("神城", "kamishiro", "神城", "RIVAL")]
define CHRES_MATE_LINES = {
    "鷹野": ("口は悪い。目は合わない", "パスを出せば、走ってくれる", "言わなくても、同じところを見ている"),
    "大門": ("まだ、ボールがこわい", "キーパーとして、蓮の声を待っている", "ゴールの前を、まかせられる"),
    "三好": ("ひとりで走り続けているキャプテン", "背中を押してくれる先輩", "この人のために、勝ちたい"),
    "坂口": ("ゲームの話しかしない5人組", "文句を言いながら、最後まで走る", "声をかければ、5人で返してくれる"),
    "神城": ("あの冬から、止まったまま", "試合で会おう、とだけ言う", "言えなかったことが、少しずつ届く"),
}

## 英字の章の名前
define CHRES_EN = {"pro": "PROLOGUE", "ch1": "CHAPTER 1", "ch2": "CHAPTER 2", "ch3": "CHAPTER 3"}

## 試合のページの、大きな字の下のひとこと
define CHRES_MATCH_MEMO = {
    "pro": "右ひざのリハビリ中。春までは、走れない",
    "ch1": "0−9。でも、11人全員が、最後までピッチにいた",
    "ch2": "港北、公式戦で初めての1勝",
    "ch3": "選手権予選　県ベスト4",
}

## ページごとの背景にする一枚絵（2色にしたもの）。見たことのある絵だけ。どれも見ていなければ CHRES_BASE
define CHRES_BG = {
    "pro": [["op_open"], ["op_kamishiro"], ["op_breath"], ["pro_hinata_choco", "ren_down"], ["op_kamishiro"], ["ren_down"], ["op_clear"]],
    "ch1": [["m531_warmup"], ["m531_huddle"], ["practice_chaos"], ["saki_meet", "bus_hinata"], ["practice_takano", "practice_daimon"], ["m531_final"], ["miyoshi_rain"]],
    "ch2": [["kuroda_kick"], ["daimon_pk"], ["gym_takano"], ["fw_hinata", "fw_chika", "fw_saki", "fw_boys"], ["gym_miyoshi"], ["album_photos"], ["gym_door_light"]],
    "ch3": [["ch3_entrance8", "ch3_entrance"], ["ch3_entrance"], ["practice_rope"], ["hinata_taping"], ["miyoshi_lying"], ["ch3_armband"], ["ch3_newyear"]],
}
define CHRES_BASE = {"pro": "op_kamishiro", "ch1": "m531_huddle", "ch2": "daimon_pk", "ch3": "ch3_newyear"}

## 確認用（作者の画面写真）：見ていない絵も背景に出す
default chres_all_seen = False

init python:
    def chres_bg(k, pg):
        c = list(CHRES_BG.get(k, [[]] * 7)[pg])
        if k == "ch2" and pg == 3:
            ## 夏祭りは、いっしょに行った人の絵を先に
            c.sort(key=lambda x: x != "fw_" + store.ch2_fest)
        for cg in c:
            if (store.chres_all_seen or renpy.seen_image("cg " + cg)) and renpy.loadable("gui/chres/duo/%s.jpg" % cg):
                return "gui/chres/duo/%s.jpg" % cg
        return "gui/chres/duo/%s.jpg" % CHRES_BASE.get(k, "ch3_newyear")

    def chres_plays(k):
        """この章で覚えたプレー（名前）。はじめの値がなければ出さない"""
        p0 = store.chres_start.get(k, {}).get("plays")
        if p0 is None:
            return []
        return [play_name(p) for p in store.plays_learned if p not in p0]

    def chres_notes(k):
        """この章でサッカーノートに増えた数"""
        n0 = store.chres_start.get(k, {}).get("notes")
        if n0 is None:
            return 0
        return len([n for n in store.note_learned if n not in n0])

    def chres_record(k):
        m = chres_matches(k)
        w = len([x for x in m if x[3] != "lose"])
        return w, len(m) - w

    def chres_tiles(k):
        """試合の札：(日付, 大会, 相手, スコア, 結果, ひとこと)"""
        out = []
        for d, nm, sc, r, note in chres_matches(k):
            parts = nm.split("　")
            comp = parts[0].replace("インターハイ予選", "IH予選 ").replace("選手権予選", "")
            out.append((d, comp, parts[-1], sc.replace("−", "-"), r, note))
        return out

    def chres_mates(k):
        """仲間との絆：(名前, 顔, 肩書き, 今の目盛り, はじめの目盛り, ひとこと)。出会った人だけ"""
        b0 = store.chres_start.get(k, {}).get("bond") or {}
        out = []
        for nm, fid, key, role in CHRES_MATES:
            if nm not in store.met and key not in store.met:
                continue
            v = store.bond.get(key, 0)
            v0 = b0.get(key, v)
            seg = lambda x: rel_segments(min(100, x * 2))
            lines = CHRES_MATE_LINES[nm]
            line = lines[0] if v < 15 else (lines[1] if v < 35 else lines[2])
            label = "坂口たち" if nm == "坂口" else nm
            out.append((label, "gui/relations/face_%s.png" % fid, role, seg(v), min(seg(v0), seg(v)), line))
        return out

    def chres_ovr(stats_list):
        """総合力：4つの能力の平均"""
        return int(round(sum(stats_list) / float(len(stats_list))))

    def chres_rank(v):
        """能力のランク（5きざみ）。第1部（高校）の終わりで A〜A+ くらい。S（90〜）は2部のためにとっておく"""
        for th, r in CHRES_RANKS:
            if v >= th:
                return r
        return "F"

    def chres_count_dd(a, b, delay, style_name, suffix=""):
        """数字が a から b へ上がる（0.6秒）"""
        def f(st, at):
            k = min(1.0, max(0.0, (st - delay) / 0.6))
            v = int(round(a + (b - a) * k))
            return Text("%d%s" % (v, suffix), style=style_name), (None if k >= 1.0 else 0.03)
        return DynamicDisplayable(f)

    def chres_sfx(name):
        return Play("ui", "audio/se/%s.ogg" % name)

    def chres_title_parts(k):
        t = CHRES_META[k][0]
        return t.split("　", 1)[-1]


label chres_show(k):
    window hide
    $ bgm("章のまとめの曲")
    call screen chapter_result(k)
    $ music_stop(1.0)
    return


## ---- 動き（必要なものだけ） ----
## ゲージ・目盛り：左から伸びる
transform chres_grow(d=0.0, t=0.6):
    crop (0.0, 0.0, 0.0, 1.0)
    pause d
    easeout t crop (0.0, 0.0, 1.0, 1.0)

## ページの切りかえ：斜めの紺の帯が、左から右へ横切る（まん中で画面が切りかわる）
transform chres_wipe_t:
    xpos -1760
    easein 0.26 xpos -230
    easeout 0.30 xpos 1320

transform chres_blink:
    alpha 1.0
    linear 0.8 alpha 0.35
    linear 0.8 alpha 1.0
    repeat

## 少し斜めにする（ロゴの字に合わせる）
transform chres_skew(s=-0.18):
    matrixtransform Matrix([1.0, s, 0.0, 0.0,  0.0, 1.0, 0.0, 0.0,  0.0, 0.0, 1.0, 0.0,  0.0, 0.0, 0.0, 1.0])


## 上の見出し（赤い札に英字、クリームの札に日本語）と、右上のロゴ
screen chres_top(pg, k):
    $ _en, _jp = CHRES_PAGES[pg]
    if pg > 0:
        hbox:
            pos (70, 40)
            at chres_skew(-0.25)
            frame:
                background Solid(CHRES_RED)
                padding (18, 0, 18, 0)
                ysize 44
                text _en style "chres3_tag_en" yalign 0.5
            frame:
                background Solid(CHRES_CREAM)
                padding (18, 0, 18, 0)
                ysize 44
                text _jp style "chres3_tag_jp" yalign 0.5
        vbox:
            xpos 1224
            xanchor 1.0
            ypos 30
            spacing 2
            add Transform("gui/title_logo.png", zoom=0.25) xalign 1.0
            text CHRES_META[k][0] style "chres3_chap" xalign 1.0

## 札（上に赤い線、紺の地）
screen chres_tile(w, h, lose=False):
    fixed:
        xysize (w, h)
        add Solid("#06133ad9") xysize (w, h)
        add Solid("#33416b" if lose else CHRES_RED) xysize (w, 6)
        transclude

## 0：タイトル
screen chres3_p0(k, f):
    vbox:
        xalign 0.5
        yalign 0.46
        spacing 8
        hbox:
            xalign 0.5
            spacing 22
            text CHRES_EN[k] style "chres3_k1"
            add Solid(CHRES_RED, xysize=(10, 10)) yalign 0.5
            text "RESULT" style "chres3_k1"
        text chres_title_parts(k) style "chres3_hd" size 120 xalign 0.5 at chres_skew()
        text CHRES_META[k][1] style "chres3_k3" xalign 0.5
        null height 10
        add Transform("gui/title_logo.png", zoom=0.38) xalign 0.5
    if f:
        timer 0.3 action SetScreenVariable("fast", True)

## 1：この章の試合
screen chres3_p1(k, f):
    $ _t = chres_tiles(k)
    $ _w, _l = chres_record(k)
    $ _n = max(1, len(_t))
    $ _tw = min(300, int((1180 - 12 * (_n - 1)) / _n))
    vbox:
        xalign 0.5
        ypos 120
        spacing 10
        hbox:
            xalign 0.5
            at chres_skew()
            text "%d" % _w style "chres3_hd" size 160
            text "勝" style "chres3_hd" size 76 yalign 0.82
            text "%d" % _l style "chres3_hd" size 160
            text "敗" style "chres3_hd" size 76 yalign 0.82
        frame:
            xalign 0.5
            background Solid(CHRES_RED)
            padding (16, 4, 16, 6)
            text CHRES_MATCH_MEMO.get(k, "") style "chres3_memo"
    $ _tm = CHRES_TEAM.get(k)
    if _tm:
        vbox:
            pos (70, 116)
            spacing 4
            text "港北の総合力" style "chres3_ovrl"
            hbox:
                spacing 12
                frame:
                    background Solid(CHRES_CREAM if _tm[0] != "-" else "#ffffff30")
                    padding (12, 4, 12, 0)
                    at chres_skew(-0.25)
                    text _tm[0] style "chres3_rank" color CHRES_NAVY
                text "→" style "chres3_ovrl" yalign 0.5
                frame:
                    background Solid(CHRES_RED)
                    padding (14, 4, 14, 0)
                    at chres_skew(-0.25)
                    text _tm[1] style "chres3_rankb" size 46 color "#ffffff"
    hbox:
        xalign 0.5
        yanchor 1.0
        ypos 662
        spacing 12
        for _d, _comp, _opp, _sc, _r, _note in _t:
            use chres_tile(_tw, 236, _r == "lose"):
                vbox:
                    xalign 0.5
                    ypos 18
                    xsize _tw - 16
                    spacing 4
                    text _d style "chres3_date" xalign 0.5
                    text _comp style "chres3_comp" xalign 0.5
                    frame:
                        xalign 0.5
                        background Solid(CHRES_CREAM)
                        padding (14, 2, 14, 0)
                        text _sc style "chres3_score"
                    text _opp style "chres3_opp" xalign 0.5
                    frame:
                        xalign 0.5
                        background Solid("#33416b" if _r == "lose" else CHRES_RED)
                        padding (12, 2, 12, 0)
                        text {"win": "WIN", "lose": "LOSE", "pk": "PK WIN"}[_r] style "chres3_res" color ("#cfd6ea" if _r == "lose" else "#ffffff")
                    if _note:
                        text _note style "chres3_note" xalign 0.5 text_align 0.5
    if f:
        timer 0.3 action SetScreenVariable("fast", True)

## 2：能力の伸び
screen chres3_p2(k, f):
    $ _st = chres_stats(k)
    $ _pl = chres_plays(k)
    $ _nt = chres_notes(k)
    $ _o0 = chres_ovr([b for _, b, v in _st])
    $ _o1 = chres_ovr([v for _, b, v in _st])
    hbox:
        xalign 0.5
        ypos 104
        spacing 34
        add Transform("gui/relations/face_ren.png", zoom=1.0) yalign 0.5
        vbox:
            yalign 0.5
            text "早瀬 蓮" style "chres3_name"
            text "KOHOKU / MF" style "chres3_pos"
        vbox:
            yalign 0.5
            spacing 0
            text "総合力" style "chres3_ovrl"
            hbox:
                spacing 14
                if f and _o1 != _o0:
                    add chres_count_dd(_o0, _o1, 0.3, "chres3_ovr")
                else:
                    text "%d" % _o1 style "chres3_ovr"
                frame:
                    yalign 0.62
                    background Solid(CHRES_RED if chres_rank(_o1) != chres_rank(_o0) else CHRES_CREAM)
                    padding (16, 6, 16, 0)
                    at chres_skew(-0.25)
                    text chres_rank(_o1) style "chres3_rankb" color ("#ffffff" if chres_rank(_o1) != chres_rank(_o0) else CHRES_NAVY)
                if chres_rank(_o1) != chres_rank(_o0):
                    text "RANK UP" style "chres3_rankup" yalign 0.62
    hbox:
        xalign 0.5
        yanchor 1.0
        ypos 600
        spacing 16
        for _i, _row in enumerate(_st):
            $ _key, _b, _v = _row
            $ _dl = (0.3 + 0.2 * _i) * f
            use chres_tile(278, 156):
                vbox:
                    pos (20, 18)
                    xsize 238
                    spacing 6
                    text _key style "chres3_slab"
                    hbox:
                        xsize 238
                        if f and _v != _b:
                            add chres_count_dd(_b, _v, _dl, "chres3_snum")
                        else:
                            text "%d" % _v style "chres3_snum"
                        $ _ru = chres_rank(_v) != chres_rank(_b)
                        frame:
                            yalign 0.6
                            xoffset 10
                            background Solid(CHRES_RED if _ru else CHRES_CREAM)
                            padding (10, 3, 10, 0)
                            text chres_rank(_v) style "chres3_rank" color ("#ffffff" if _ru else CHRES_NAVY)
                        if _v > _b:
                            frame:
                                xalign 1.0
                                yalign 0.5
                                background Solid(CHRES_RED)
                                padding (10, 2, 10, 0)
                                at chres_skew(-0.25)
                                text "+%d" % (_v - _b) style "chres3_plus"
                    fixed:
                        xysize (238, 14)
                        add Solid("#ffffff24") xysize (238, 14)
                        add Solid(CHRES_CREAM) xysize (int(238 * _b / 100.0), 14)
                        if _v > _b:
                            add Solid(CHRES_RED) xysize (max(1, int(238 * (_v - _b) / 100.0)), 14) xpos int(238 * _b / 100.0) at chres_grow(_dl, 0.6 * f)
    if _pl or _nt:
        hbox:
            xalign 0.5
            ypos 622
            spacing 12
            if _pl:
                text "NEW PLAY" style "chres3_chipl" yalign 0.5
                for _p in _pl:
                    frame:
                        background Solid(CHRES_CREAM)
                        padding (16, 5, 16, 5)
                        at chres_skew(-0.25)
                        text _p style "chres3_chip"
            if _nt:
                frame:
                    background Solid(CHRES_CREAM)
                    padding (16, 5, 16, 5)
                    at chres_skew(-0.25)
                    text "サッカーノート +%d" % _nt style "chres3_chip"
    if f:
        timer 1.6 action SetScreenVariable("fast", True)

## 3：ヒロインとの距離（数字は出さない）
screen chres3_p3(k, f):
    $ _hs = chres_heroines(k)
    hbox:
        xalign 0.5
        ypos 150
        spacing 18
        if not _hs:
            text "まだ、だれとも出会っていない" style "chres3_line"
        for _i, _row in enumerate(_hs):
            $ _nm, _face, _n, _n0, _line = _row
            use chres_tile(392, 470):
                vbox:
                    xalign 0.5
                    ypos 30
                    xsize 364
                    spacing 14
                    add Transform(_face, zoom=1.0) xalign 0.5
                    text _nm style "chres3_hname" xalign 0.5
                    hbox:
                        xalign 0.5
                        spacing 4
                        for _j in range(5):
                            if _j < _n0:
                                add "gui/chres/seg_on.png"
                            elif _j < _n:
                                fixed:
                                    xysize (52, 18)
                                    add "gui/chres/seg_bg.png"
                                    add "gui/chres/seg_new.png" at chres_grow((0.3 + 0.2 * _i + 0.15 * (_j - _n0)) * f, 0.3 * f)
                            else:
                                add "gui/chres/seg_bg.png"
                    if _n > _n0:
                        frame:
                            xalign 0.5
                            background Solid(CHRES_RED)
                            padding (12, 3, 12, 4)
                            text "この章で近づいた" style "chres3_closer"
                    else:
                        null height 30
                    text _line style "chres3_line" xalign 0.5 text_align 0.5
    if f:
        timer 1.6 action SetScreenVariable("fast", True)

## 4：仲間との絆（数字は出さない。神城はライバル）
screen chres3_p4(k, f):
    $ _ms = chres_mates(k)
    $ _n = max(1, len(_ms))
    $ _tw = min(300, int((1180 - 14 * (_n - 1)) / _n))
    hbox:
        xalign 0.5
        ypos 170
        spacing 14
        if not _ms:
            text "まだ、仲間はいない" style "chres3_line"
        for _i, _row in enumerate(_ms):
            $ _nm, _face, _role, _n1, _n0, _line = _row
            use chres_tile(_tw, 410, _role == "RIVAL"):
                vbox:
                    xalign 0.5
                    ypos 30
                    xsize _tw - 30
                    spacing 12
                    add Transform(_face, zoom=0.86) xalign 0.5
                    text _nm style "chres3_hname" xalign 0.5
                    frame:
                        xalign 0.5
                        background Solid("#33416b" if _role == "RIVAL" else CHRES_CREAM)
                        padding (12, 2, 12, 0)
                        text _role style ("chres3_res" if _role == "RIVAL" else "chres3_roletx") color ("#ffffff" if _role == "RIVAL" else CHRES_NAVY)
                    hbox:
                        xalign 0.5
                        spacing 3
                        for _j in range(5):
                            if _j < _n0:
                                add Transform("gui/chres/seg_on.png", zoom=0.8)
                            elif _j < _n1:
                                fixed:
                                    xysize (42, 15)
                                    add Transform("gui/chres/seg_bg.png", zoom=0.8)
                                    add Transform("gui/chres/seg_new.png", zoom=0.8) at chres_grow((0.3 + 0.15 * _i + 0.12 * (_j - _n0)) * f, 0.3 * f)
                            else:
                                add Transform("gui/chres/seg_bg.png", zoom=0.8)
                    if _n1 > _n0:
                        frame:
                            xalign 0.5
                            background Solid(CHRES_RED)
                            padding (10, 3, 10, 4)
                            text "この章で近づいた" style "chres3_closer"
                    else:
                        null height 28
                    text _line style "chres3_mline" xalign 0.5 text_align 0.5 xmaximum _tw - 30
    if f:
        timer 1.6 action SetScreenVariable("fast", True)

## 5：大きな選択
screen chres3_p5(k, f):
    $ _cs = chres_choices(k)
    $ _n = max(1, len(_cs))
    $ _tw = min(380, int((1180 - 18 * (_n - 1)) / _n))
    hbox:
        xalign 0.5
        ypos 190
        spacing 18
        for _i, _c in enumerate(_cs):
            use chres_tile(_tw, 300):
                vbox:
                    pos (26, 24)
                    xsize _tw - 52
                    spacing 10
                    text "%02d" % (_i + 1) style "chres3_no"
                    text _c style "chres3_choice"
                    if _c.startswith("大晦日"):
                        frame:
                            background Solid(CHRES_RED)
                            padding (14, 4, 14, 5)
                            at chres_skew(-0.25)
                            text "運命の選択" style "chres3_closer"
    if f:
        timer 0.3 action SetScreenVariable("fast", True)

## 6：次の章へ（ここでセーブもできる）
screen chres3_p6(k, f):
    $ _hface, _hwho, _hline = chres_hint(k)
    hbox:
        xalign 0.5
        ypos 130
        spacing 26
        add Transform("gui/relations/face_%s.png" % _hface, zoom=1.0) yalign 0.5
        frame:
            yalign 0.5
            background Fixed(Solid("#06133ad9"), Solid(CHRES_RED, xsize=6))
            left_padding 34
            right_padding 30
            top_padding 18
            bottom_padding 20
            xmaximum 780
            vbox:
                spacing 6
                text _hwho style "chres3_who"
                text _hline style "chres3_quote"
    vbox:
        xalign 0.5
        ypos 370
        spacing 6
        text "NEXT CHAPTER" style "chres3_k1" color CHRES_RED xalign 0.5
        text chres_next(k)[4:] style "chres3_hd" size 62 xalign 0.5 at chres_skew()
    hbox:
        xalign 0.5
        ypos 560
        spacing 26
        textbutton "セーブする" action ShowMenu("save") style "chres3_btn_r" text_style "chres3_btn_text" text_color "#ffffff" at chres_skew(-0.25)
        textbutton "つづける" action Return() style "chres3_btn" text_style "chres3_btn_text" at chres_skew(-0.25)
    if f:
        timer 0.3 action SetScreenVariable("fast", True)

screen chapter_result(k, start_pg=0, start_fast=False):
    ## start_pg / start_fast は確認用（作者の画面写真で、とちゅうのページを開く）
    modal True
    zorder 150
    default pg = start_pg
    default fast = start_fast
    default wipe = 0         ## ページを切りかえているとき：行き先のページ＋1
    $ _f = 0.0 if fast else 1.0

    add chres_bg(k, pg)
    if pg > 0:
        add "gui/chres/shade.png"
    else:
        add Solid("#06133a59")

    ## タップ（画面のどこか）で次へ。ボタンより前に置く（Ren'Py は、あとに書いたものから先にクリックを受けとる。
    ##   ここをボタンのあとに書いていたので、「前へ」「とばす」「セーブする」「つづける」のクリックまで、このキーが先に取っていた。11/18 直した）
    if pg < CHRES_LAST:
        key "dismiss" action If(wipe, NullAction(), If(fast, [SetScreenVariable("wipe", pg + 2), chres_sfx("advance")], SetScreenVariable("fast", True)))
    else:
        key "dismiss" action SetScreenVariable("fast", True)
    key "game_menu" action ShowMenu("save")

    use chres_top(pg, k)
    if pg == 0:
        use chres3_p0(k, _f)
    elif pg == 1:
        use chres3_p1(k, _f)
    elif pg == 2:
        use chres3_p2(k, _f)
    elif pg == 3:
        use chres3_p3(k, _f)
    elif pg == 4:
        use chres3_p4(k, _f)
    elif pg == 5:
        use chres3_p5(k, _f)
    else:
        use chres3_p6(k, _f)

    ## 下：前へ／とばす／ページの印／タップで次へ
    hbox:
        pos (60, 680)
        spacing 26
        if pg > 0:
            textbutton "◀ 前へ" action If(wipe, NullAction(), [SetScreenVariable("wipe", pg), chres_sfx("advance")]) style "chres3_nav" text_style "chres3_nav_text"
        if pg < CHRES_LAST:
            textbutton "とばす" action If(wipe, NullAction(), [SetScreenVariable("wipe", CHRES_LAST + 1), chres_sfx("advance")]) style "chres3_nav" text_style "chres3_nav_text"
    hbox:
        xalign 0.5
        ypos 696
        spacing 8
        for _i in range(CHRES_LAST + 1):
            add Solid(CHRES_RED if _i == pg else ("#ffffff99" if _i < pg else "#ffffff40"), xysize=(30 if _i == pg else 12, 6)) yalign 0.5
    if pg < CHRES_LAST:
        text "タップで次へ ▶" style "chres3_tap" xpos 1220 xanchor 1.0 ypos 684 at chres_blink

    ## ページの切りかえ（斜めの紺の帯）。帯がまん中に来たところで、ページを変える
    if wipe:
        add "gui/chres/wipe.png" at chres_wipe_t
        timer 0.26 action [SetScreenVariable("pg", wipe - 1), SetScreenVariable("fast", False)]
        timer 0.58 action SetScreenVariable("wipe", 0)


init 2:
    style chres3_tag_en:
        font CHRES_F_NUM
        size 34
        color "#ffffff"
    style chres3_tag_jp:
        font CHRES_F_BODY
        size 20
        color CHRES_NAVY
    style chres3_chap:
        font CHRES_F_BODY
        size 16
        color CHRES_CREAM
    style chres3_hd:
        font CHRES_F_HEAD
        size 120
        color CHRES_CREAM
        outlines [(6, CHRES_NAVY, 0, 0), (6, CHRES_RED, 6, 6)]
    style chres3_k1:
        font CHRES_F_NUM
        size 44
        color "#ffffff"
        kerning 8
    style chres3_k3:
        font CHRES_F_BODY
        size 24
        color "#ffffff"
        kerning 6
    style chres3_memo:
        font CHRES_F_BODY
        size 26
        color "#ffffff"
    style chres3_date:
        font CHRES_F_NUM
        size 27
        color CHRES_SUB
    style chres3_comp:
        font CHRES_F_BODY
        size 16
        color CHRES_SUB
    style chres3_score:
        font CHRES_F_NUM
        size 48
        color CHRES_NAVY
    style chres3_opp:
        font CHRES_F_BODY
        size 20
        color "#ffffff"
    style chres3_res:
        font CHRES_F_NUM
        size 26
    style chres3_note:
        size 13
        color "#ffb3a8"
        line_spacing 2
    style chres3_name:
        font CHRES_F_BODY
        size 36
        color "#ffffff"
    style chres3_pos:
        font CHRES_F_NUM
        size 30
        color CHRES_CREAM
        kerning 4
    style chres3_ovr:
        font CHRES_F_NUM
        size 120
        color "#ffffff"
    style chres3_ovrl:
        font CHRES_F_BODY
        size 22
        color CHRES_CREAM
    style chres3_rankb:
        font CHRES_F_NUM
        size 58
    style chres3_rank:
        font CHRES_F_NUM
        size 32
    style chres3_rankup:
        font CHRES_F_NUM
        size 30
        color "#ff8c80"
        kerning 2
    style chres3_slab:
        font CHRES_F_BODY
        size 22
        color "#ffffff"
    style chres3_snum:
        font CHRES_F_NUM
        size 62
        color "#ffffff"
    style chres3_plus:
        font CHRES_F_NUM
        size 30
        color "#ffffff"
    style chres3_chipl:
        font CHRES_F_NUM
        size 26
        color CHRES_CREAM
        kerning 3
    style chres3_chip:
        font CHRES_F_BODY
        size 18
        color CHRES_NAVY
    style chres3_hname:
        font CHRES_F_BODY
        size 32
        color "#ffffff"
    style chres3_closer:
        font CHRES_F_BODY
        size 16
        color "#ffffff"
    style chres3_roletx:
        font CHRES_F_BODY
        size 15
    style chres3_mline:
        font CHRES_F_BODY
        size 16
        color "#e6eaf7"
    style chres3_line:
        font CHRES_F_BODY
        size 17
        color "#e6eaf7"
        xmaximum 364
    style chres3_no:
        font CHRES_F_NUM
        size 92
        color CHRES_RED
    style chres3_choice:
        font CHRES_F_BODY
        size 23
        color "#ffffff"
        line_spacing 6
    style chres3_who:
        font CHRES_F_BODY
        size 20
        color "#ff8c80"
    style chres3_quote:
        font CHRES_F_BODY
        size 25
        color "#ffffff"
        line_spacing 8
    style chres3_btn is button:
        background Solid(CHRES_CREAM)
        hover_background Solid("#ffffff")
        padding (40, 12, 40, 14)
    style chres3_btn_r is chres3_btn:
        background Solid(CHRES_RED)
        hover_background Solid("#ff3b36")
    style chres3_btn_text is button_text:
        font CHRES_F_BODY
        size 26
        color CHRES_NAVY
    style chres3_nav is button:
        background None
        hover_background None
        padding (4, 4, 4, 4)
    style chres3_nav_text is button_text:
        size 18
        color "#ffffffaa"
        hover_color "#ffffff"
    style chres3_tap:
        size 18
        color "#ffffffaa"
