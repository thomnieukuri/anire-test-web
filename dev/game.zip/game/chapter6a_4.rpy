## chapter6a_4.rpy ―― 第6章（ルートA）の④：12〜1月・全国大会と初詣（v0.33.0・Claude の第1稿）
##   12月：全国の前（決勝でひざが止まった人は、大学病院。全国はベンチから）
##   → 12/30 全国1回戦（遊べる試合）→ 12/31 2回戦（結果だけ）→ 1/1 初詣（ひなたの告白の日）
##   → 全国の最後の試合（何回戦まで行けるかは、能力・絆・注目度で決まる）→ 佐伯さんからの電話 → 終章へ
##   ひなたの告白は「来た順に答える」：付き合っている人がいれば、蓮は気持ちを受け止めて断る（heart_close）
##   終章に渡すもの：a6_nat_best（全国の成績）・a6_knee（ひざの状態）・a6_hinata_end・a6_lover・注目度・正史の印（flags の「正史_」）

define A6_HINATA_LOVE = 60        # ひなたが告白する、ときめき
define A6_HINATA_TRUST = 70       # 恋人になるのに要る、信頼
define A6_HINATA_PARTNER = 75     # 相棒（専属トレーナーの約束）になる、信頼

default a6_nat_win1 = False       # 全国1回戦に勝ったか（1/1 を大会の宿で迎えるか）
default a6_nat_best = ""          # 全国の成績："1回戦" / "2回戦" / "3回戦" / "ベスト8" / "ベスト4"
default a6_knee = ""              # 第6章の終わりのひざ："ok"（手術して治った）/ "hold"（痛み止めでもった）/ "broke"（決勝で止まった）
default a6_hinata_end = ""        # 初詣：lover / refused（付き合っている人がいて断った）/ partner / miss / alone


label chapter6a_4:
    call a6_dec
    call a6_nat_first
    if a6_nat_best:                 # 1回戦で負けた（12/30 で終わり）
        call a6_nat_locker
    call a6_nat_second
    if a6_nat_best == "2回戦":      # 2回戦で負けた（12/31 で終わり）
        call a6_nat_locker
    call a6_hatsumode               # まだ大会に残っている人は、大会の宿の裏の神社
    if not a6_nat_best:
        call a6_nat_more
        call a6_nat_locker
    jump a6_end


################################################################################
## 12月：全国の前
################################################################################
label a6_dec:
    scene black
    with dissolve
    if a6_knee_broke:
        $ set_cal("11月14日（火）", "大学病院")
        scene bg a5_clinic
        with dissolve
        $ bgm("重く静かな曲")
        "去年の秋と、同じ診察室だった。同じ先生が、同じように、画像をゆっくり指でなぞった。"
        isha "……今度は、切れています。全国大会には、出られません"
        isha "手術は、大会のあとでいい。……ベンチに座るのは、止めません"
        if a5_tell == "alone" and not flags.get("a6_黒田に点数を言った"):
            "診察室の外で、母さんが待っていた。……今度は、最初から、待合室にいた。"
        else:
            "診察室の外で、母さんが待っていた。"
        "帰りのバスで、母さんは、何も言わなかった。降りる前に、一回だけ、俺のひざに手を置いた。"
        $ a6_knee = "broke"
    else:
        $ set_cal("12月24日（日）", "夜")
        scene bg shokudo_night
        with dissolve
        $ bgm("日常の静かな曲")
        "全国大会の前の、最後の日曜。はやせ食堂は、港北サッカー部の貸し切りになっていた。"
        "壁に、三好先輩が作った横断幕が貼ってあった。「港北　最後の世代　全国へ」。"
        show mother smile
        with dissolve
        haha "からあげ、何個でも揚げるよ。……お父さんの分も、お皿に盛っとくからね"
        hide mother
        with dissolve
        $ a6_knee = "ok" if a5_surgery else "hold"
    $ set_cal("12月28日（木）", "朝")
    scene bg bus_team_morning
    with dissolve
    $ bgm("明るい春の曲")
    "全国大会の会場へ、バスで向かった。窓の外が、だんだん、知らない町になった。"
    "あげはが、バスの中で、ずっと配信していた。一年の春、バスに乗る11人を、だれも撮っていなかった。"
    return


################################################################################
## 12月30日（土）全国大会1回戦
################################################################################
label a6_nat_first:
    scene black
    with dissolve
    $ set_cal("12月30日（土）", "全国大会1回戦")
    scene cg a6_nat_stadium
    with Dissolve(1.0)
    $ se("スタンドの応援（太鼓）")
    $ bgm("張りつめた静かな曲")
    "全国のスタジアムは、県の競技場の、三倍の大きさだった。それでも、芝は、芝だった。"
    "相手は、北陸の、全国大会に7年連続で出ている高校だった。"
    $ se("キックオフの笛")
    $ sb_set("前半", 0, 0, 0, 0, "#2a5bd7", "#4b4b4b", "港北", "北陸")
    scene bg stadium_winter_eve at cam_jog
    with dissolve
    show screen letterbox
    show screen scoreboard
    $ bgm("緊迫した試合の曲")
    if a6_knee_broke:
        "ベンチから見た全国の試合は、思っていたより、速かった。……速さに、港北は、少しずつ慣れていった。"
        $ _p = a6_team_power()
        $ a6_nat_win1 = (_p >= 80)
        if a6_nat_win1:
            "後半30分、鷹野のゴールで、1−0。最後の10分、大門が、二本止めた。"
        else:
            "後半30分、相手の9番に、一本だけ決められた。0−1。港北のシュートは、最後まで、ポストの外だった。"
    else:
        "前半は、相手の速さに、追いつくだけで終わった。0−0。"
        $ sb_set("後半", 45)
        $ sb_set(mm=74)
        "後半29分。小早川から、縦パス。全国の芝の上で、初めて、前を向けた。"
        menu:
            "自分で打つ":
                $ lean("野心型")
                $ _ok = check("技術", 76)
            "鷹野に落とす":
                $ lean("仲間型")
                $ _ok = check_bond("鷹野", 85)
        if _ok or a6_team_power() >= 92:
            $ se("ボールを蹴る音")
            $ goal("港北", home=1, away=0, mm=75)
            with vpunch
            "1−0。全国の一点目は、一年の県大会の一点目より、ずっと静かに入った。……静かすぎて、だれも、すぐには気づかなかった。"
            $ a6_nat_win1 = True
        else:
            "シュートは、キーパーの正面だった。そのあとの5分で、相手のセットプレーから、一点を取られた。0−1。"
            $ a6_nat_win1 = False
    $ se("試合終了の笛")
    pause 1.0
    hide screen scoreboard
    hide screen letterbox
    scene bg stadium_winter_eve
    with Dissolve(1.0)
    if a6_nat_win1:
        mono "全国大会、1回戦突破。"
        mono "港北の、全国初勝利だった。"
        $ up("注目度", 8)
    else:
        mono "全国大会、1回戦敗退。"
        mono "最後の世代の冬は、12月30日で終わった。"
        $ a6_nat_best = "1回戦"
        $ up("注目度", 3)
    return

init python:
    def a6_team_power():
        """全国大会で何回戦まで行けるか（v0.33.0 の目安）。能力の平均＋鷹野・大門の絆＋注目度。ひざが止まった人は −10"""
        s = store.stats
        p = (s["技術"] + s["フィジカル"] + s["戦術眼"] + s["メンタル"]) / 4.0
        p += store.bond.get("鷹野", 0) / 10.0 + store.bond.get("大門", 0) / 10.0 + store.hidden.get("注目度", 0) / 10.0
        if store.a6_knee_broke:
            p -= 10
        return p


################################################################################
## 12月31日（日）2回戦（結果だけ）
################################################################################
label a6_nat_second:
    if not a6_nat_win1:
        return
    scene black
    with dissolve
    $ set_cal("12月31日（日）", "全国大会2回戦")
    scene bg stadium_winter_eve
    with dissolve
    $ bgm("緊迫した試合の曲")
    $ _p = a6_team_power()
    if _p >= 88:
        "2回戦は、関西の私立に、2−1で勝った。決勝点は、坂口のクロスから、赤坂だった。"
        "赤坂は、ゴールのあと、ベンチの倉田のところまで走っていって、二人で抱き合っていた。"
    else:
        "2回戦は、関西の私立に、1−2で負けた。最後のシュートは、鷹野の、三年で一番いいシュートだった。キーパーの指先に、当たった。"
        $ a6_nat_best = "2回戦"
    return


################################################################################
## 1月1日（月）初詣：ひなたの告白の日
################################################################################
label a6_hatsumode:
    scene black
    with dissolve
    $ set_cal("1月1日（月）", "夜")
    if not a6_nat_best:
        scene bg shrine_steps_night
        with dissolve
        $ bgm("静かな夜の曲")
        "大会の宿の裏に、小さな神社があった。夜、部のみんなで、初詣に行った。"
        "賽銭箱の前で、坂口が「全国優勝！」と大声で言って、黒田に頭をはたかれた。"
    else:
        scene bg shrine_steps_night
        with dissolve
        $ bgm("静かな夜の曲")
        "港北の神社。毎年、元日に来ている石段だった。"
        "大会は、もう終わっていた。部のみんなと、夜の初詣に来た。"
    python:
        _hn = heart["ひなた"]
        if "ひなた" in heart_closed:
            a6_hinata_end = "partner" if _hn["信頼"] >= A6_HINATA_PARTNER else "alone"
        elif a6_lover and a6_lover != "ひなた":
            a6_hinata_end = "refused" if _hn["ときめき"] >= A6_HINATA_LOVE else ("partner" if _hn["信頼"] >= A6_HINATA_PARTNER else "alone")
        elif _hn["ときめき"] >= A6_HINATA_LOVE and _hn["信頼"] >= A6_HINATA_TRUST:
            a6_hinata_end = "lover"
        elif _hn["ときめき"] >= A6_HINATA_LOVE:
            a6_hinata_end = "miss"
        elif _hn["信頼"] >= A6_HINATA_PARTNER:
            a6_hinata_end = "partner"
        else:
            a6_hinata_end = "alone"
    if a6_hinata_end == "alone":
        jump a6_hatsu_alone
    "お参りのあと、ひなたが、俺のコートの袖を、うしろから引いた。"
    show hinata normal
    with dissolve
    voice "audio/voice/hinata_a6_hatsu_01.mp3"
    hinata "……ちょっとだけ、いい？"
    "ひなたは、俺の袖をつかんだまま、石段の下のみんなに向かって、声を張った。"
    voice "audio/voice/hinata_a6_hatsu_02.mp3"
    hinata "みんなー！　先に帰ってて！　わたし、蓮のひざ、見てから帰るから！"
    sakaguchi "ひざぁ？　正月からかよ！　ひざなら、俺のも――"
    "坂口が言い終わる前に、あげはが、坂口の背中を両手で押した。"
    voice "audio/voice/ageha_a6_hatsu_01.mp3"
    ageha "はいはい、行くよー。……空気、読も？"
    "鷹野は、振り返らずに、片手だけ上げた。大門が、まだ何か言いたそうな坂口の肩をつかんで、石段を下りていった。"
    "……全員、分かっている顔だった。"
    voice "audio/voice/hinata_a6_hatsu_03.mp3"
    hinata "……ひざは、うそ。ひざ、関係ない"
    "石段の上に、二人だけになった。息が白かった。"
    if a6_hinata_end != "partner":
        voice "audio/voice/hinata_a6_hatsu_04.mp3"
        hinata "決勝のあと、すぐには言えなかった。蓮の頭、全国でいっぱいだったから。……年が明けたら言うって、決めてたの"
    if a6_hinata_end == "lover":
        jump a6_hatsu_lover
    elif a6_hinata_end == "refused":
        jump a6_hatsu_refused
    elif a6_hinata_end == "miss":
        jump a6_hatsu_miss
    jump a6_hatsu_partner

## 恋人：10年分の「好き」
label a6_hatsu_lover:
    scene cg a6_hatsumode_hinata
    with Dissolve(1.0)
    $ bgm("静かなピアノ")
    voice "audio/voice/hinata_a6_hlov_01.mp3"
    hinata "勝ったら、言うって言ったでしょ。……勝ったから、言う"
    voice "audio/voice/hinata_a6_hlov_02.mp3"
    hinata "幼稚園で、蓮が転んで泣いたとき、わたし、自分のハンカチ、貸したの。覚えてないよね"
    voice "audio/voice/hinata_a6_hlov_03.mp3"
    hinata "あのときから、ずっと、言えなかった。マネージャーだから、幼なじみだから、って。……言わない理由ばっかり、ノートに書いてた"
    show hinata teary
    voice "audio/voice/hinata_a6_hlov_04.mp3"
    hinata "でも、もう、いい。……蓮のことが、好き。10年以上、ずっと、ずっと、好き！"
    "石段の下まで聞こえそうな声だった。言い終わったひなたは、自分の声に驚いたみたいに、肩で息をしていた。"
    voice "audio/voice/hinata_a6_hlov_05.mp3"
    hinata "……ひざのノートも、全部、そのせい。マネージャーだからじゃ、なかった。……やっと、言えた"
    menu:
        "「俺も、好きだ」":
            $ a6_lover = "ひなた"
            ren "……俺も、好きだ"
            ren "ハンカチは、覚えてない。でも、それから、ずっと、お前が横にいたのは、覚えてる"
            "ひなたが、石段を一段上がった。目の高さが、同じになった。顔が、近かった。"
            "ひなたは、泣き顔のまま、じっと俺を見ていた。……まさか、と思った。"
            "次の瞬間、ひなたは、思いっきり、俺に飛びついてきた。"
            "背中に回った腕が、コートごと、ぎゅうっと締まった。石段の上で、二人とも、少しよろけた。"
            voice "audio/voice/hinata_a6_hlov_06.mp3"
            hinata "……びっくりした？　今、何か、ちがうこと考えたでしょ"
            ren "……考えてない"
            voice "audio/voice/hinata_a6_hlov_07.mp3"
            hinata "うそ。耳、赤いもん。……10年分だから、ちょっと長いよ。がまんして"
            "ひなたは、なかなか離れなかった。初詣の帰りの人が、石段の下を通って、笑っていた。"
            voice "audio/voice/hinata_a6_hlov_08.mp3"
            hinata "……っ、ずるい。そういうのは、先に言ってよ。10年、待ったんだから"
            voice "audio/voice/hinata_a6_hlov_09.mp3"
            hinata "……今、眉毛、見ないでね。ぐしゃぐしゃだから"
            ren "見ない"
            voice "audio/voice/hinata_a6_hlov_10.mp3"
            hinata "……うそ。見て。これから、ずっと、見て"
            $ heart_up("ひなた", "ときめき", 10)
            $ heart_up("ひなた", "信頼", 5)
            $ set_flag("ひなた_恋人")
        "「……ごめん」":
            $ a6_hinata_end = "partner"
            ren "……ごめん。ひなたのことは、大事だ。でも、それは、たぶん、違う大事だ"
            "ひなたは、少しだけ目を閉じた。それから、マネージャーの顔で、うなずいた。"
            voice "audio/voice/hinata_a6_hlov_11.mp3"
            hinata "……うん。知ってた、かも。言えて、すっきりした"
            voice "audio/voice/hinata_a6_hlov_12.mp3"
            hinata "じゃあ、約束して。蓮がどこでサッカーしても、ひざは、わたしが見る。……専属トレーナー、予約ね"
            $ heart_close("ひなた")
    hide hinata
    with dissolve
    return

## 付き合っている人がいるときの告白（来た順に答える）
label a6_hatsu_refused:
    $ _lv_call = {"千夏": "千夏先輩"}.get(a6_lover, a6_lover)
    voice "audio/voice/hinata_a6_href_01.mp3"
    hinata "……知ってるよ。[_lv_call]のこと。おめでとう、って、ちゃんと言えてなかったね"
    voice "audio/voice/hinata_a6_href_02.mp3"
    hinata "だから、これは、答えはいらない話。……ただ、言わないと、わたしが前に進めないの"
    show hinata teary
    voice "audio/voice/hinata_a6_href_03.mp3"
    hinata "蓮のことが、好きだった。10年以上。……勝ったら言うって、決めてたから。勝ったから、言った"
    ren "……ありがとう。ごめん"
    voice "audio/voice/hinata_a6_href_04.mp3"
    hinata "謝らないで。……ちゃんと断ってくれて、うれしい。ずるくしないの、蓮らしい"
    voice "audio/voice/hinata_a6_href_05.mp3"
    hinata "これからは、幼なじみとトレーナーで、いさせて。……ひざは、わたしが見る。それは、だれにもゆずらない"
    $ heart_close("ひなた")
    $ heart_up("ひなた", "信頼", 4)
    $ a6_hinata_end = "refused"
    hide hinata
    with dissolve
    return

## すれ違い：「今の蓮には、まだ言えない」
label a6_hatsu_miss:
    voice "audio/voice/hinata_a6_hmiss_01.mp3"
    hinata "勝ったら、言うって言ったよね。……言おうと思って、ここまで来たんだけど"
    show hinata forcesmile
    if a5_tell == "hinata":
        voice "audio/voice/hinata_a6_hmiss_02.mp3"
        hinata "やっぱり、今の蓮には、まだ言えない。……蓮、まだ、わたしのこと、マネージャーとしてしか見てないでしょ"
        voice "audio/voice/hinata_a6_hmiss_03.mp3"
        hinata "そうじゃなくなる日が来たら、わたし、全部言う。……それまで、とっとく"
    else:
        voice "audio/voice/hinata_a6_hmiss_04.mp3"
        hinata "やっぱり、今の蓮には、まだ言えない。……蓮、ひざのこと、まだ、わたしに全部は言ってないでしょ"
        voice "audio/voice/hinata_a6_hmiss_05.mp3"
        hinata "全部言ってくれる日が来たら、わたしも、全部言う。……それまで、とっとく"
    "ひなたは、手袋のまま、俺の手を一回だけ握って、離した。"
    $ heart_up("ひなた", "さみしさ", 4)
    hide hinata
    with dissolve
    return

## 相棒：専属トレーナーの約束
label a6_hatsu_partner:
    voice "audio/voice/hinata_a6_hpt_01.mp3"
    hinata "ねえ、蓮。……この春から、わたし、理学療法の学校に行く。受かったら、だけど"
    voice "audio/voice/hinata_a6_hpt_02.mp3"
    hinata "4年かかる。4年たったら、トレーナーになれる"
    show hinata smile
    voice "audio/voice/hinata_a6_hpt_03.mp3"
    hinata "だから、予約。……蓮がどこのチームに行っても、蓮のひざは、わたしが見る。専属トレーナー"
    ren "……高いぞ、俺のひざは"
    voice "audio/voice/hinata_a6_hpt_04.mp3"
    hinata "知ってる。ノートの分だけ、知ってる"
    $ se("トークアプリの通知音")
    "ポケットのスマホが鳴った。坂口だった。「早瀬、どこだ！　下のコンビニでおでん。男だけの新年会な」"
    ren "……悪い。坂口たちが、下で待ってる。おでんだって"
    voice "audio/voice/hinata_a6_hpt_05.mp3"
    hinata "男子って、元日もおでんなんだ。……いってらっしゃい。ひざ、冷やさないでね"
    "石段を下りる途中で、一回だけ振り返った。ひなたは、もうスマホを見ながら、「明けましておめでとう！今から行くね……？」を打っていた。"
    $ heart_up("ひなた", "信頼", 5)
    $ set_flag("ひなた_専属トレーナー")
    hide hinata
    with dissolve
    return

## ひとり：みんなと
label a6_hatsu_alone:
    "ひなたは、お参りのあと、スマホを見ながら、先に石段を下りていった。……だれかと、トークをしているみたいだった。"
    if heart["ひなた"]["ときめき"] < 35 and heart["ひなた"]["さみしさ"] >= 20:
        "画面の上に、「柏木先輩」の名前が見えた。見えたことを、だれにも言わなかった。"
    "坂口が、おみくじで大吉を引いて、全員に見せて回っていた。……今年の大吉は、もう、使い道が決まっていた。"
    $ bond_up("坂口", 2)
    return


################################################################################
## 全国の3回戦から（1/1 のあと）
################################################################################
label a6_nat_more:
    $ _p = a6_team_power()
    if _p >= 106:
        $ a6_nat_best = "ベスト4"
    elif _p >= 97:
        $ a6_nat_best = "ベスト8"
    else:
        $ a6_nat_best = "3回戦"
    scene black
    with dissolve
    if a6_nat_best == "3回戦":
        $ set_cal("1月2日（火）", "全国大会3回戦")
        scene bg stadium_winter_eve
        with dissolve
        $ bgm("試合の曲（劣勢）")
        "3回戦は、関東の強豪に、0−2で負けた。二点目のあと、大門が、だれよりも長く、ゴールの前に立っていた。"
    elif a6_nat_best == "ベスト8":
        $ set_cal("1月3日（水）", "全国大会準々決勝")
        scene bg stadium_winter_eve
        with dissolve
        $ bgm("試合の曲（劣勢）")
        "3回戦は、1−0で勝った。準々決勝は、去年の全国準優勝の高校に、PK戦で負けた。"
        "外したのは、だれでもなかった。相手のキーパーが、5人目まで、全部、正しい方向に飛んだ。"
    else:
        $ set_cal("1月7日（日）", "全国大会準決勝")
        scene bg stadium_winter_eve
        with dissolve
        $ bgm("試合の曲（劣勢）")
        "準々決勝まで、勝った。準決勝は、国立競技場だった。1−3。……国立の芝も、芝だった。"
    return


################################################################################
## 全国の最後の試合のあと：ロッカールームと、小早川への腕章（負けた日のうちに）
################################################################################
label a6_nat_locker:
    $ up("注目度", {"1回戦": 0, "2回戦": 3, "3回戦": 6, "ベスト8": 10, "ベスト4": 15}.get(a6_nat_best, 0))
    scene bg locker_room
    with dissolve
    $ bgm("あたたかいアコースティックギター")
    "最後の試合のあと、ロッカールームで、黒田が、全員を座らせた。"
    show kuroda normal
    with dissolve
    kuroda "……お前らが一年の春、この部は、11人で、0−9で負けた"
    $ _res = {"1回戦": "今日、全国の芝の上で、負けた", "2回戦": "全国で、一つ勝った", "3回戦": "全国で、二つ勝った",
              "ベスト8": "全国で、ベスト8だ", "ベスト4": "全国で、ベスト4だ。国立の芝を踏んだ"}.get(a6_nat_best, "")
    kuroda "[_res]"
    kuroda "俺は、お前たちに何も教えてない。……止まれ、と言っただけだ"
    "黒田は、ポケットから、青いリボンを一本出した。あの小包のリボンだった。……それで、ストップウォッチを、首にかけ直した。"
    hide kuroda
    with dissolve
    if a4_captain == "takano":
        "鷹野が、腕章を外して、俺に渡した。三好先輩から受け取った、黄色い腕章だった。俺は、それを、小早川に渡した。"
    else:
        "ロッカールームを出る前に、キャプテンの腕章を外した。三好先輩から受け取った、黄色い腕章だった。それを、小早川に渡した。"
    show kobayakawa jersey
    with dissolve
    "小早川は、両手で受け取った。7人になる来年の港北の、最後のキャプテン。"
    if flags.get("a6_小早川に残す"):
        kobayakawa "……先輩、4月に「一個、残す」って言ってくれましたよね"
        ren "これだ。……あと、もう一個。7人でも、11人のつもりで走れ"
        kobayakawa "はい。……ノートの最後のページ、今、書けます"
    else:
        kobayakawa "……来年、7人で、ここまで来ます。来られなくても、来るつもりで走ります"
    hide kobayakawa
    with dissolve
    return


################################################################################
## 第6章の終わり：佐伯さんからの電話 → 終章へ
################################################################################
label a6_end:
    scene black
    with dissolve
    $ set_cal("1月9日（火）", "夜")
    scene bg ren_room_night
    with dissolve
    $ bgm("静かな夜の曲")
    "その夜、あの夏から一度も使わなかった名刺を、机の引き出しから出した。"
    $ se("スマホの着信（ビデオ通話）")
    "そのとき、スマホが鳴った。知らない番号。……名刺の番号と、同じだった。"
    saeki "佐伯だ。……全国、見てた"
    if a6_knee == "broke":
        saeki "ひざのことも、聞いた。……それでも、話をさせてくれ。全部、聞かせてくれ"
    else:
        saeki "名刺を使うときが来た、と思う。……高校の大会が全部終わった。黒田さんも一緒に、話をさせてくれ"
    saeki "ブルーマリンズのことだけじゃない。……お前の、これからの話だ"
    "電話を切ったあと、窓を開けた。港のほうから、冬の潮風が入ってきた。"
    mono "高3の冬が、終わった。"
    mono "次は、選ぶ番だ。……どこで、だれと、蹴るのか。"
    ## 終章に渡すもの（README「終章に渡すもの」）
    $ set_flag("正史_全国出場")
    $ set_flag("a6_全国_" + (a6_nat_best or "なし"))
    $ set_flag("a6_ひざ_" + a6_knee)
    $ set_flag("a6_ひなた_" + a6_hinata_end)
    if a6_lover:
        $ set_flag("a6_恋人_" + a6_lover)
    $ up("注目度", 2)
    call show_title("第6章　潮風の決勝", "完")
    ## 終章は、まだない
    scene black
    with dissolve
    window auto hide
    tuto "終章（進路と結末）は、制作中です。ここまで遊んでくれて、ありがとうございました。"
    return
