## chapter4a_ageha.rpy ―― 第4章（ルートA）の新しいヒロイン・桃井あげは（v0.30.0）
##   桃井あげは（ももい・あげは、「あげちゃん」）：港北の1年。サッカー部のマネージャー。ミルクティー色の巻き髪の平成ギャル
##   高1の選手権の桜嶺戦で、蓮の切り抜きがSNSでバズったのを見て「この人推せる」と、入試の直前に志望校を港北に変えた
##   ルートBでは、同じ人が桜嶺の1年のマネージャーになる（制服だけ変わる）
##
##   ここに入っている場面
##     4/15  入部（a4_ageha_join。a4_kobayakawa のあと、必ず通る）
##     5月   自由行動「港北駅」（a4_may_ageha）  7月 自由行動「商店街」（a4_jul_ageha）
##     練習の出来事 2本（a4p_ageha_film・a4p_ageha_drink。chapter4a_free.rpy の PRACTICE_EVENTS_A4 に登録）
##     夜のトーク（a4nc_ageha_*。chapter4a_night.rpy の一覧に登録）
##     7月の終わり 信頼の特別イベント「相棒」（a4_trust_ageha。信頼が A4_TRUST_SPECIAL_AGEHA 以上）
##     8/15 夏祭り（a4_fes_ageha）
##   恋愛の場面（ときめき）は v0.31.1 で Claude が下書きした（夏祭りの続き・chapter4a_heart.rpy の告白の前ぶれ）
##
##   声（v0.30.0）：ElevenLabs のボイスデザインで作った「Anire Ageha」。名前は「あげわ」と読まれるので、声の台本ではカタカナ（モモイアゲハ・アゲちゃん）、港北は「こうほく」とひらがなで書く
##   あげはの話し方：一人称「あたし」。蓮を「蓮パイセン」、ひなたを「ひなたパイセン」、千夏を「会長」、黒田を「クロセン」と呼ぶ。
##   「マジ」「ウケる」「推せる」「てか」「〜じゃん」「〜っしょ」。坂口と言葉づかいが似ている（坂口がそれを気にする）
##   ときめきは「推し」として最初から高め、信頼は 0 から。信頼を育てると、推しではなく、一人の人として蓮を見るようになる

## あげはの「相棒」の場面に届く信頼（入部が4月なので、ほかの3人の A4_TRUST_SPECIAL より低い。本気で追ったときだけ届く高さ）
define A4_TRUST_SPECIAL_AGEHA = 24

default a4_ageha_word = ""     # 入部の日に、蓮があげはに言ったこと（help：マネは助かる / lost：切り抜きの俺は負けてる）
default a4_ageha_post = ""     # 7月の夜、準決勝の動画を上げていいか聞かれて（post：上げろ / wait：今はやめてくれ）


################################################################################
## 4月15日：あげはが入部する（小早川のあと、同じ日の放課後）
################################################################################
label a4_ageha_join:
    "名簿に小早川の名前が書かれて、すぐ。"
    $ se("戸が勢いよく開く音")
    "部室の戸が、ノックなしで、いきおいよく開いた。"
    show ageha normal
    with dissolve
    $ bgm("明るい部活の曲")
    voice "audio/voice/ageha_chiwassu.mp3"
    ageha "ちわーっす！　ここ、サッカー部で合ってます？"
    "灰色がかったミルクティー色の、くるくるした長い髪。ブレザーの前は全開で、袖からカーディガンがはみ出していた。足もとは、だぼっとした白い靴下。"
    "その子は、部室の中を一周見まわして、俺のところで止まった。"
    voice "audio/voice/ageha_honnin.mp3"
    ageha "……いた。てか、ガチの本人じゃん！　ウケる！"
    "その子は、スマホの画面を、俺の顔の前に突きつけた。"
    "画面の中で、青いユニフォームの、去年の冬の俺が、白と金のユニフォームに倒されていた。"
    "倒されて、立ち上がって、もう一度走り出す。十五秒くらいの動画だった。"
    ageha "これ、去年の冬の、桜嶺戦の切り抜き。再生回数、えぐいことになってんの。知らなかった？"
    ren "……知らない"
    voice "audio/voice/ageha_maji.mp3"
    ageha "マジか。本人が知らないの、逆にエモいんだけど"
    voice "audio/voice/ageha_name.mp3"
    ageha "マネージャー希望、1年の{rb}桃井{/rb}{rt}ももい{/rt}あげはでーす。あげちゃんって呼んでいいよ"
    voice "audio/voice/ageha_oshi.mp3"
    ageha "志望校、入試の2週間前に変えたんだよね。推しのいる高校にしよ、って"
    "部室が、静かになった。小早川のときとは、ちがう静かさだった。"
    show sakaguchi normal at left
    with dissolve
    sakaguchi "……推し？　蓮が？　推し？"
    sakaguchi "てか、待って。この子、俺らと同じ言葉しゃべってない？"
    ageha "え、パイセンもギャル語いける人？　推せる"
    sakaguchi "……ウケる。ウケねえ。どっちだ"
    hide sakaguchi
    with dissolve
    show hinata stare at left
    with dissolve
    hinata "……マネージャーの仕事、ラクじゃないよ"
    ageha "知ってる知ってる。ドリンク作るやつっしょ？"
    hinata "ドリンクと、洗濯と、スコアと、テーピングと、ボールの空気と、それから……"
    voice "audio/voice/ageha_ee.mp3"
    ageha "え、待って、多くない？"
    hinata "……全部、教えるから。明日から、6時15分に来て"
    ageha "朝の！？"
    hide hinata
    with dissolve
    "あげはは、スマホを胸に当てて、もう一度、俺のほうを見た。"
    ageha "で、どう？　推しに会えたファンに、なんか一言"
    menu:
        "「……推しとか、よく分からない。でも、マネージャーは助かる」":
            $ a4_ageha_word = "help"
            $ heart_up("あげは", "信頼", 2)
            ageha "うわ、塩。……でも、助かるって言った。今の、録音しとけばよかった"
        "「切り抜きの俺は、負けてるぞ」":
            $ a4_ageha_word = "lost"
            $ heart_up("あげは", "信頼", 3)
            voice "audio/voice/ageha_sorena.mp3"
            ageha "それな。負けてんのに、立つじゃん"
            show ageha serious
            voice "audio/voice/ageha_sokoga.mp3"
            ageha "……そこがいいんじゃん"
            "あげはは、それだけ言って、すぐにまた笑った。"
            show ageha normal
    show kuroda normal at right
    with dissolve
    kuroda "……数を言う。マネージャーが、二人だ"
    kuroda "篠宮、教えてやれ。……桃井、ここは遊びに来るところじゃない。走るやつらの、うしろを守るところだ"
    voice "audio/voice/ageha_kurosen.mp3"
    ageha "りょ。……あ、はい！　クロセン！"
    kuroda "……クロセン"
    hide kuroda
    with dissolve
    hide ageha
    with dissolve
    "推し、という言葉の意味は、よく分からなかった。"
    "分かったのは、俺が倒れて、立ち上がるところを、知らない誰かが、何万回も見ていたということだけだった。"
    python:
        heart_fill()
        ## あげはは、最初から蓮の「推し」なので、ときめきだけ高めから始まる（信頼は 0 から育てる）
        heart["あげは"]["ときめき"] = max(heart["あげは"]["ときめき"], 15)
    $ meet("あげは")
    window auto hide
    tuto "新しく、マネージャーの「あげは」が仲間になりました。相関図で、あげはの気持ちも確かめられます。"
    return


################################################################################
## 5月の自由行動：港北駅。部のアカウントを作るあげは
##   ヒロインの行き先は、その人らしい能力が少し上がる（ひなた＝フィジカル、千夏＝戦術眼、あげは＝技術）
################################################################################
label a4_may_ageha:
    scene bg kohoku_station_gate_eve
    with dissolve
    $ bgm("明るい春の曲")
    show ageha normal
    with dissolve
    "港北駅の改札の前のベンチで、あげはが、スマホを横にして、すごい速さで指を動かしていた。"
    ageha "あ、蓮パイセン。ちょうどいいとこに。見て見て"
    "画面には、見覚えのあるグラウンドが映っていた。今日の練習だった。"
    ageha "部のアカウント、作った。「港北サッカー部【最後の世代】」。フォロワー、まだ3人だけど。1人はあたし"
    ren "……あと2人は"
    ageha "ひなたパイセンと、坂口パイセン。坂口パイセン、1秒でフォローしてきた。ウケる"
    "あげはは、動画をゆっくりに切りかえた。俺がパスを受ける場面だった。"
    show ageha serious
    ageha "てかさ、これ。パイセン、ボール止めるとき、右足だけ、毎回ちょっと遅くない？"
    ageha "スローにすると分かるの。左は、ぽんって止まるのに、右は、一回、待ってから止めてる"
    "……右ひざを、かばうときの癖だった。ひなたにも、言われたことがなかった。"
    show ageha normal
    ageha "あたし、サッカーは全然わかんないけど、動画なら毎日見てるから。ちがうとこ探すのは、得意"
    menu:
        "「俺を撮るより、チームを撮ってくれ。最後の代を、全員」":
            $ heart_up("あげは", "信頼", 5)
            $ lean("仲間型")
            ageha "……全員？　[a4_members]人？　えぐ"
            ageha "でも、それ、いいかも。最後の代、全員。……推しの仲間も、推せる気がしてきた"
        "「右足のこと、ほかにも気づいたら教えてくれ」":
            $ heart_up("あげは", "信頼", 4)
            $ up("技術", 1)
            ageha "まかせて。推しの粗探し、全力でやるから"
            ageha "……あ、粗探しって言っちゃった。応援。応援の粗探し"
    hide ageha
    with dissolve
    "その夜、部のアカウントに、初めての動画が上がった。[a4_members]人が、ぐちゃぐちゃに走っているだけの、二十秒の動画だった。"
    $ up("技術", 2)
    $ up("注目度", 1)
    $ set_flag("あげは_アカウント")
    return


################################################################################
## 7月の自由行動：商店街のコンビニ。数学の補習のあげは
################################################################################
label a4_jul_ageha:
    scene bg shotengai_eve
    with dissolve
    $ bgm("あたたかいアコースティックギター")
    show ageha serious
    with dissolve
    "商店街のコンビニの、外のベンチ。あげはが、数学のプリントをにらんでいた。"
    voice "audio/voice/ageha_a4_jul_01.mp3"
    ageha "……蓮パイセン。助けて。クロセンの補習、マジで意味わかんない"
    voice "audio/voice/ageha_a4_jul_02.mp3"
    ageha "期末、数学だけ、赤点だったの。追試で落ちたら、夏休みの合宿、来ちゃだめって"
    "プリントには、黒田の、四角くて小さい字で、二次関数の問題が並んでいた。去年の夏、同じプリントで、坂口が同じ顔をしていた。"
    ren "……ここは、グラフを描け。描けば分かる"
    voice "audio/voice/ageha_nn.mp3"
    ageha "グラフ、ぐにゃってなるやつ？"
    ren "ぐにゃってなるやつだ"
    "三十分かかって、あげはは、プリントの半分を埋めた。"
    show ageha normal
    voice "audio/voice/ageha_yaba.mp3"
    ageha "……やば。あたし、今、ちょっと分かった気がする"
    voice "audio/voice/ageha_a4_jul_03.mp3"
    ageha "パイセン、教えるの、うまくない？　推しが先生とか、課金したいんだけど"
    show ageha serious
    voice "audio/voice/ageha_a4_jul_04.mp3"
    ageha "……ねえ。準決勝、負けたじゃん"
    voice "audio/voice/ageha_a4_jul_05.mp3"
    ageha "あたし、ベンチの横で、ずっと撮ってた。後半、パイセン、また右足、待ってた"
    menu:
        "「……知ってる。だから、冬までに直す」":
            $ heart_up("あげは", "信頼", 4)
            $ up("無理ゲージ", -1)
            voice "audio/voice/ageha_a4_jul_06.mp3"
            ageha "……知ってたんだ"
            voice "audio/voice/ageha_a4_jul_07.mp3"
            ageha "じゃあ、あたしは、直ったとこを撮る。ビフォーアフター。そういうの、いちばんバズるから"
        "「今は、お前の追試の話だ」":
            $ heart_up("あげは", "信頼", 3)
            $ up("メンタル", 1)
            voice "audio/voice/ageha_a4_jul_08.mp3"
            ageha "……ずる。話そらした"
            voice "audio/voice/ageha_a4_jul_09.mp3"
            ageha "でも、いいよ。追試、受かったら、また聞くから。逃げらんないからね"
    ## 追試の前祝いのプリクラ（v0.31.0）
    show ageha normal
    voice "audio/voice/ageha_a4_jul_10.mp3"
    ageha "よし、今日の分おわり！　パイセン、ちょっと来て。前祝い"
    ren "まだ受かってない"
    voice "audio/voice/ageha_a4_jul_11.mp3"
    ageha "受かる前に祝うから、受かんの。そういうもん"
    "あげはは、プリントを丸めずに、ていねいにファイルにしまった。"
    "ファイルの表紙には、部のアカウントのアイコンと同じ、青いボールのシールが貼ってあった。"
    scene bg game_center
    with dissolve
    $ bgm("ゲームセンターの曲")
    "商店街のゲーセンの奥。カーテンのついたプリクラの機械の前まで、手首を引っぱられた。"
    scene cg ageha_purikura at cam_push(8.0, 1.04)
    with Dissolve(0.8)
    voice "audio/voice/ageha_a4_jul_12.mp3"
    ageha "はい、こっち見て！　……パイセン、顔、かたっ。笑って"
    ren "笑ってる"
    voice "audio/voice/ageha_a4_jul_13.mp3"
    ageha "それ、試合の前の顔！"
    "フラッシュが三回光った。三回とも、俺は目を閉じていたらしい。"
    scene bg game_center
    with dissolve
    show ageha normal
    with dissolve
    "落書きのコーナーで、あげはは、ペンを高速で動かした。俺の頭の上に、ピンクの字で「推し♡」。"
    ren "勝手に書くな"
    voice "audio/voice/ageha_a4_jul_14.mp3"
    ageha "推しなのは事実だし。……あ、パイセン、全部目つぶってる。ウケる"
    voice "audio/voice/ageha_a4_jul_15.mp3"
    ageha "でも、これがいい。いちばん、パイセンっぽい"
    "あげはは、目をつぶった一枚をはさみで切って、スマホケースの裏に、指でていねいに貼りつけた。"
    voice "audio/voice/ageha_a4_jul_16.mp3"
    ageha "……ほかの人には、見せないから。これ、あたしだけの"
    "言ってから、あげはは、ケースを裏返しにして、ポケットにしまった。"
    $ heart_up("あげは", "ときめき", 3)
    $ set_flag("あげは_プリクラ")
    hide ageha
    with dissolve
    $ up("技術", 2)
    $ set_flag("あげは_追試")
    return


################################################################################
## 練習の出来事（PRACTICE_EVENTS_A4 に登録）
################################################################################

## スタンドの上から撮るあげは（戦術眼）
label a4p_ageha_film:
    "紅白戦。フェンスの外の、使われていない朝礼台の上に、あげはが立っていた。"
    show ageha normal
    with dissolve
    "スマホを横にして、両手で構えている。"
    ageha "上から撮ると、全部見えんの！　パイセンたち、上から見ると、アリみたいでかわいい"
    hide ageha
    with dissolve
    "練習のあと、上からの動画を、部室のテレビで見た。俺と小早川のあいだが、思っていたより、ずっと空いていた。"
    show kuroda peek
    with dissolve
    kuroda "……桃井。明日も、そこから撮れ"
    hide kuroda
    with dissolve
    "朝礼台の上で、あげはが、ピースをしていた。"
    $ heart_up("あげは", "信頼", 1)
    return

## ドリンクの濃さ（フィジカル）
label a4p_ageha_drink:
    "走りこみのあと。ジャグの前に、長い列ができていた。"
    show sakaguchi normal at left
    with dissolve
    sakaguchi "……甘っ！　これ、ジュースじゃん！"
    show ageha normal at right
    with dissolve
    ageha "え、粉、全部入れたんだけど。甘いほうが元気出るっしょ？"
    hide sakaguchi
    show hinata normal at left
    with dissolve
    hinata "あげはちゃん、粉は、半分。今日みたいに暑い日は、塩をひとつまみ"
    hinata "汗の量で、濃さを変えるの。……みんなの顔、見ながら作るんだよ"
    ageha "顔、見ながら……"
    "次の日のドリンクは、少しだけ、しょっぱかった。"
    "あげはは、ジャグの前で、一人ずつ顔を見ながら、紙コップを渡していた。"
    hide hinata
    with dissolve
    ## 飲みかけ（v0.31.0）
    "俺の番で、ちょうどジャグが空になった。"
    ageha "あ、ごめんパイセン。じゃあ、これ飲んで"
    "あげはが、自分のペットボトルを差し出した。キャップに、青いボールのシールが貼ってある。"
    "ひと口飲んで返すと、あげはは、ボトルとキャップを交互に見て、急に静かになった。"
    ageha "…………あ。それ、あたしの飲みかけだった"
    ageha "……ま、いっか。推しだし。……推しだし？"
    "あげはは、ボトルを両手で持ったまま、くるっと後ろを向いた。耳が、日焼けのせいだけではない色をしていた。"
    hide ageha
    with dissolve
    $ set_flag("a4p_ageha_drink")       # 夜のトーク（A4_NIGHT_NEED）の前提
    $ heart_up("あげは", "信頼", 1)
    $ heart_up("あげは", "ときめき", 2)
    $ heart_up("ひなた", "信頼", 1)
    return


################################################################################
## 7月の終わり：信頼の特別イベント「相棒」（信頼が A4_TRUST_SPECIAL_AGEHA 以上）
##   恋愛ではなく、本音の話。推しではなく、一人の人として
################################################################################
label a4_trust_ageha:
    scene black
    with dissolve
    $ set_cal("7月24日（土）", "夏休み・夕方")
    scene bg kohoku_ground_eve
    with dissolve
    $ bgm("あたたかいアコースティックギター")
    "夏休みの練習のあと。みんなが帰ったグラウンドで、あげはが、一人でボールを拾い集めていた。"
    "かごに入れる前に、一つずつ、タオルで土をふいていた。"
    show ageha serious
    with dissolve
    voice "audio/voice/ageha_a4_trust_01.mp3"
    ageha "あ。……パイセン。忘れ物？"
    ren "手伝う"
    voice "audio/voice/ageha_a4_trust_02.mp3"
    ageha "いいって。マネの仕事だし。……ひなたパイセンに、ボールは毎日ふけって言われたの。最初、意味わかんなかった"
    "二人で、残りのボールを拾った。かごが、いっぱいになった。"
    voice "audio/voice/ageha_a4_trust_03.mp3"
    ageha "……ねえ。あたしがマネやってるの、ノリだと思ってるっしょ"
    voice "audio/voice/ageha_a4_trust_04.mp3"
    ageha "推しがいるから来た、とか。そういうの、みんな、ちょっと笑うじゃん"
    voice "audio/voice/ageha_a4_trust_05.mp3"
    ageha "あたし、なんでも3か月でやめてきたんだよね。ピアノも、ダンスも、塾も。続いたこと、一回もない"
    voice "audio/voice/ageha_a4_trust_06.mp3"
    ageha "だから、ノリって言われても、言い返せない。ほんとのことだから"
    "あげはは、かごのふちを、指でなぞった。"
    voice "audio/voice/ageha_a4_trust_07.mp3"
    ageha "でもさ。あの切り抜き、何回見ても分かんなかったの。負けてるのに、なんで立つのか"
    voice "audio/voice/ageha_a4_trust_08.mp3"
    ageha "それ知りたくて、来た。……推しって言ったほうが、かわいいから、そう言ってるだけ"
    voice "audio/voice/ageha_nande.mp3"
    ageha "パイセンは、なんで立つの"
    menu:
        "「……立たないと、終われないからだ」":
            $ a4_trust_answer["あげは"] = "end"
            $ heart_up("あげは", "信頼", 3)
            $ lean("求道型")
            ren "倒れたまま終わったら、そこで終わりだ。……立てば、まだ続く"
            ren "去年の冬、一回、止まった。止まってたら、ここにいない"
            voice "audio/voice/ageha_a4_trust_09.mp3"
            ageha "……続くために、立つんだ"
            voice "audio/voice/ageha_a4_trust_10.mp3"
            ageha "じゃあ、あたしも、続けてみる。……3か月、もう過ぎたし"
        "「見てるやつがいるからだ。仲間も、お前も」":
            $ a4_trust_answer["あげは"] = "seen"
            $ heart_up("あげは", "信頼", 4)
            $ lean("仲間型")
            ren "一人だったら、たぶん、立ってない。……スタンドにも、ベンチにも、誰かがいた"
            ren "今は、朝礼台の上にも、いる"
            "あげはは、何か言いかけて、やめた。それから、ボールのかごを、ぎゅっと抱えた。"
            voice "audio/voice/ageha_a4_trust_11.mp3"
            ageha "……それ、ずるい。推しに言われたら、やめらんないじゃん"
    voice "audio/voice/ageha_kimeta.mp3"
    ageha "決めた。あたし、港北の最後の日まで、マネやる"
    voice "audio/voice/ageha_a4_trust_12.mp3"
    ageha "あたしら、最後の新入生なんだって。だから、あたしが卒業する日が、港北がなくなる日"
    show ageha normal
    voice "audio/voice/ageha_osenai.mp3"
    ageha "最後のマネージャー、あたし。……それ、ちょっと、推せない？"
    "夕方の風が、グラウンドの土を、少しだけ巻き上げた。"
    "あげはは、ボールのかごを持ち上げて、部室のほうへ歩いていった。重そうだったけど、手伝わせてはくれなかった。"
    hide ageha
    with dissolve
    $ set_flag("あげは_相棒")
    $ up("メンタル", 2)
    ## あげはの「ときめき」の場面（告白の前ぶれ）は chapter4a_heart.rpy の a4_heart_ageha（v0.31.1・Claude の下書き）
    return


################################################################################
## 8月15日：夏祭り。あげはと
################################################################################
label a4_fes_ageha:
    show ageha yukata
    with dissolve
    "あげはは、屋台の並びの真ん中で、スマホを高く上げて、みんなを撮っていた。"
    "ひなたに帯を直してもらったという浴衣は、白地に、淡いピンクの花の柄だった。"
    voice "audio/voice/ageha_ukeru.mp3"
    ageha "あ、パイセン！　はぐれた？　ウケる、[a4_members]人もいて全員はぐれてんの"
    voice "audio/voice/ageha_a4_fes_01.mp3"
    ageha "てか、浴衣、どう？　……あ、いい。言わなくていい。顔で分かった"
    $ se("花火の音")
    "最初の花火が上がった。あげはは、花火ではなく、花火を見上げる坂口たちの横顔を撮っていた。"
    voice "audio/voice/ageha_a4_fes_02.mp3"
    ageha "花火の動画って、みんな上げるじゃん。だから、あたしは、見てる人を撮る"
    voice "audio/voice/ageha_matsuri.mp3"
    ageha "あたしの、港北で最初の夏祭り。……来年も、再来年も、撮るから"
    "そう言ってから、あげはは、スマホを下ろして、少しだけ花火を見た。"
    ## ツーショットと、花火に消えた一言（v0.31.1・Claude の下書き。作者の声で、ギャルっぽい大胆さを足した。一枚絵をあとで足す）
    voice "audio/voice/ageha_a4_fes_03.mp3"
    ageha "……てか、パイセン、こっち"
    "いきなり、腕を組まれた。あげはは、そのまま人のあいだをすり抜けて、いちばん前の柵まで俺を引っぱっていった。"
    ren "おい"
    voice "audio/voice/ageha_a4_fes_04.mp3"
    ageha "はぐれ防止。ギャルの基本。……あと、ここ、いちばん映えるとこ"
    "あげはは、組んだ腕をほどかないまま、空いた手でスマホを高く上げた。画面の中に、花火と、あげはと、俺。"
    hide ageha
    scene cg a4_fes_ageha at cam_push(10.0, 1.04)
    with Dissolve(0.8)
    voice "audio/voice/ageha_a4_fes_05.mp3"
    ageha "推しとツーショは、ファンとしてはNGなんだけど。……今日は、マネージャーだから。はい、もっと寄って"
    "シャッターの音と同時に、いちばん大きい花火が開いた。"
    menu:
        "「部のアカウントに上げるのか」":
            $ heart_up("あげは", "ときめき", 4)
            voice "audio/voice/ageha_a4_fes_06.mp3"
            ageha "上げない。……これは、上げない"
            voice "audio/voice/ageha_a4_fes_07.mp3"
            ageha "部のアカウントは、みんなの。これは、あたしの"
        "「もう一回撮るか。目、開いてたか分からない」":
            $ heart_up("あげは", "ときめき", 5)
            voice "audio/voice/ageha_a4_fes_08.mp3"
            ageha "……大丈夫。開いてた。プリクラのときと、ちがう顔してた"
            voice "audio/voice/ageha_a4_fes_09.mp3"
            ageha "どんな顔かは、教えない"
    "最後の花火の前、あげはが背のびをして、俺の耳もとで何か言った。"
    $ se("花火の音")
    "ドン、といちばん大きな音が、その言葉を全部さらっていった。"
    ren "……今、なんて言った"
    voice "audio/voice/ageha_a4_fes_10.mp3"
    ageha "なーいしょ。聞こえなかったなら、パイセンのラッキーってことで"
    scene bg festival_night
    with dissolve
    "あげはは、やっと腕をほどいた。ほどいたほうの手で、自分の頬をぱたぱたあおいでいた。"
    $ heart_up("あげは", "信頼", 4)
    return


## ===========================================================================
## 夜のトーク（chapter4a_night.rpy から呼ばれる）
## ===========================================================================
label a4nc_ageha_a4may:
    $ talk_start("あげは", "22:15")
    $ talk_me("アカウント、見た")
    $ talk("あげは", "見た！？　フォロワー、今日で40人になった！")
    $ talk("あげは", "半分くらい、坂口パイセンのゲーセン仲間だけど")
    $ talk("あげは", "てか、パイセン、いいねして。推しのいいね、ほしい")
    $ _r = talk_choose([("……押した", "a"), ("1年の勧誘に使えるな", "b")])
    if _r == "a":
        $ talk_me("……押した")
        $ talk("あげは", "きた！！！　スクショした！！！")
        $ talk("あげは", "……寝れない。どうしよ")
        $ heart_up("あげは", "ときめき", 2)
        $ heart_up("あげは", "信頼", 1)
    else:
        $ talk_me("1年の勧誘に使えるな")
        $ talk("あげは", "あたしも1年なんだけど")
        $ talk("あげは", "でも、それ、あり。来年の1年、もういないけど。……あ")
        $ talk("あげは", "なんでもない。がんばって、バズらせる")
        $ heart_up("あげは", "信頼", 3)
    return

label a4nc_ageha_a4may_2:
    $ talk_start("あげは", "22:50")
    $ talk_me("統合のこと、聞いたか")
    $ talk("あげは", "聞いた。あたしら、最後の新入生なんでしょ")
    $ talk("あげは", "ウケる。……てか、ウケない")
    $ talk("あげは", "せっかく推しのいる学校に来たのに、学校がなくなるの、運なさすぎ")
    $ talk("あげは", "でも、最後って、ちょっとかっこいいかも。最後の代の、最後のマネ")
    $ heart_up("あげは", "信頼", 2)
    return

label a4nc_ageha_a4jul:
    $ talk_start("あげは", "21:40")
    $ talk_me("起きてるか")
    $ talk("あげは", "起きてる。動画、編集してた")
    $ talk("あげは", "準決勝の。……ねえ、これ、上げていい？　負けたやつ")
    $ talk("あげは", "勝ったのしか上げないアカウント、なんか、うそっぽいから")
    $ _r = talk_choose([("上げろ。負けたのも、俺たちだ", "post"), ("……今は、やめてくれ", "wait")])
    $ a4_ageha_post = _r
    if _r == "post":
        $ talk_me("上げろ。負けたのも、俺たちだ")
        $ talk("あげは", "……りょ")
        $ talk("あげは", "最後の、倒れてから立つとこ、入れていい？　去年の切り抜きと、同じとこ")
        $ talk_me("好きにしろ")
        $ talk("あげは", "好きにする。……推しは、負けても推し")
        $ heart_up("あげは", "信頼", 3)
        $ up("注目度", 1)
    else:
        $ talk_me("……今は、やめてくれ")
        $ talk("あげは", "わかった。消さないで、取っとく")
        $ talk("あげは", "勝ったら、ビフォーアフターで上げるから。それまで、ねかせとく")
        $ heart_up("あげは", "信頼", 2)
        $ up("メンタル", 1)
    return

label a4nc_ageha_more1:
    $ talk_start("あげは", "22:30")
    $ talk_me("ドリンク、今日のはちょうどよかった")
    $ talk("あげは", "マジ！？　ひなたパイセンに、合格もらった！")
    $ talk("あげは", "鷹野パイセンは、何も言わずに3杯飲んでた。あれ、たぶん、おいしいってこと")
    $ heart_up("あげは", "信頼", 1)
    return

label a4nc_ageha_more2:
    $ talk_start("あげは", "23:05")
    $ talk_me("まだ起きてるのか")
    $ talk("あげは", "パイセンこそ。……ひざ、冷やしてる？")
    $ talk("あげは", "動画で見ると、分かるんだよね。練習のあとの、歩き方")
    $ talk("あげは", "あ、だれにも言ってないよ。推しの秘密は、守るのがファン")
    $ heart_up("あげは", "信頼", 1)
    return
