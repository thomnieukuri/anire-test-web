## chapter4a_night.rpy ―― 第4章（ルートA）の夜のトーク
##   自由行動②（5月）・③（7月）の夜（nightcontact.rpy の第4章版。送れるのは月の最後の夜だけ。v0.29.8）
##   相手：ひなた・千夏・あげは（4/15 に入部してから）・三好（OB）・大門・鷹野・坂口・小早川・神城（既読がつかない）
##   話：1回目 a4nc_<id>_<月>、2回目 a4nc_<id>_<月>_2（あれば）、それからは a4nc_<id>_more1, 2…（まだ見ていないもの）
##   恋愛の話（ときめき）は作者が書く。ここは信頼・絆の話だけ

default a4_night_sent = {}
default a4_night_more_seen = []
default a4_night_seen = []      # 見せた 1回目・2回目のトーク（前提の印で1回目を飛ばしたとき、2回目を二度出さないため）

init python:
    ## 話を聞いていないと届かないトーク（ラベル → 必要な印のどれか）
    A4_NIGHT_NEED = {
        "a4nc_hinata_a4jul_2": ("a4_may_hinata", "a4_jul_hinata"),   # 学校見学の話を、ひなたから聞いたとき
        "a4nc_hinata_a4may": ("a4p_hinata_taping",),                # 練習の出来事で、ひなたが1年にテーピングを教えたのを見たとき
        "a4nc_chika_a4may": ("a4_may_chika", "港北の記録_聞いた"),  # 「港北の記録」の話を、千夏から聞いたとき（5月の生徒会室か、4/20）
        "a4nc_ageha_a4may": ("あげは_アカウント",),                 # 5月の港北駅で、部のアカウントを作ったのを見たとき
        "a4nc_ageha_more1": ("a4p_ageha_drink",),                   # 練習の出来事で、あげはのドリンクの場面を見たとき
    }

    def a4_night_ok(lab):
        if not renpy.has_label(lab):
            return False
        need = A4_NIGHT_NEED.get(lab)
        return not need or any(store.flags.get(k) for k in need)

    A4_NIGHT_IDS = {"ひなた": "hinata", "千夏": "chika", "あげは": "ageha", "三好": "miyoshi", "大門": "daimon",
                    "鷹野": "takano", "坂口": "sakaguchi", "小早川": "koba", "神城": "kamishiro"}

    def a4_night_label(who, month):
        nid = A4_NIGHT_IDS[who]
        n = store.a4_night_sent.get((who, month), 0)
        first = "a4nc_%s_%s" % (nid, month)
        if n == 0 and a4_night_ok(first) and first not in store.a4_night_seen:
            store.a4_night_seen.append(first)
            return first
        if n <= 1 and a4_night_ok(first + "_2") and (first + "_2") not in store.a4_night_seen:
            store.a4_night_seen.append(first + "_2")
            return first + "_2"
        k = 1
        spare = ""
        while renpy.has_label("a4nc_%s_more%d" % (nid, k)):
            lab = "a4nc_%s_more%d" % (nid, k)
            if a4_night_ok(lab):
                if lab not in store.a4_night_more_seen:
                    store.a4_night_more_seen.append(lab)
                    return lab
                spare = spare or lab
            k += 1
        return spare or first

default a4_night_date = ""
default a4_night_quiet = 0

init python:
    A4_NIGHT_ORDER = ("ひなた", "千夏", "あげは", "三好", "大門", "鷹野", "坂口", "小早川", "神城")

    def a4_night_can(who):
        ## ルートAでは紗希と連絡先を交換しない（v0.30.0）。紗希のトークはルートBで
        if who == "あげは":
            return "あげは" in store.met
        return who in A4_NIGHT_IDS

    def a4_night_has_new(who, month):
        nid = A4_NIGHT_IDS[who]
        n = store.a4_night_sent.get((who, month), 0)
        first = "a4nc_%s_%s" % (nid, month)
        seen = store.a4_night_seen
        return ((n == 0 and a4_night_ok(first) and first not in seen)
                or (n <= 1 and a4_night_ok(first + "_2") and (first + "_2") not in seen))

    def a4_night_list(month):
        ok = [w for w in A4_NIGHT_ORDER if a4_night_can(w) and a4_night_has_new(w, month)]
        her = [w for w in ok if w in NIGHT_HEROINES]
        mates = sorted([w for w in ok if w not in NIGHT_HEROINES],
                       key=lambda w: (store.night_last.get(w, 0), A4_NIGHT_ORDER.index(w)))
        return (her + mates)[:3]

    def a4_night_incoming(month):
        ok = [w for w in A4_NIGHT_ORDER if w in NIGHT_INCOMING_OPEN and a4_night_can(w) and a4_night_has_new(w, month)]
        if not ok:
            return ""
        ok.sort(key=lambda w: (store.night_last.get(w, 0), A4_NIGHT_ORDER.index(w)))
        return ok[0]

## v0.29.8：体験版の夜のトーク（nightcontact.rpy）と同じ形にそろえた
##   自分から送れるのは、その月の最後の自由行動の夜だけ（★つき・まだ話していないことがある人だけ・最大3人）
##   ほかの夜は、2晩に1晩、まだ話していないことがある人から先に届く。届かない夜は1行で終わる
##   夜のトークで上がる気持ち・絆は2倍（NIGHT_BOOST）
label a4_night_send(date, month):
    $ a4_night_date = date
    $ _a4_send = (A4_FREE[month][0][-1] == date)
    scene black
    with dissolve
    $ set_cal(date, "夜")
    scene bg ren_room_night
    with dissolve
    $ bgm("静かな夜の曲")
    if not _a4_send:
        $ a4_night_quiet += 1
        $ _a4n = a4_night_incoming(month) if a4_night_quiet % 2 == 0 else ""
        if not _a4n:
            $ _ns_close = ("今日は、スマホを見ないまま眠った。", "布団に入ったとたん、意識が落ちた。", "ノートを少しだけ見返して、電気を消した。")[a4_night_quiet // 2 % 3]
            "[_ns_close]"
            return
        $ se("トークアプリの通知音")
        $ _ns_in_name = {"千夏": "千夏先輩", "三好": "三好先輩"}.get(_a4n, _a4n)
        "スマホが鳴った。[_ns_in_name]からだった。"
        $ night_incoming = _a4n
        jump a4_night_open
    $ _a4_who = a4_night_list(month)
    if not _a4_who:
        return
    "布団に入る前に、スマホを手に取った。"
    "……誰かに、送ってみようか。"
    menu:
        "★ ひなたに送る" (nochosen=True) if "ひなた" in _a4_who:
            $ _a4n = "ひなた"
        "★ 千夏先輩に送る" (nochosen=True) if "千夏" in _a4_who:
            $ _a4n = "千夏"
        "★ あげはに送る" (nochosen=True) if "あげは" in _a4_who:
            $ _a4n = "あげは"
        "★ 三好先輩に送る" (nochosen=True) if "三好" in _a4_who:
            $ _a4n = "三好"
        "★ 大門に送る" (nochosen=True) if "大門" in _a4_who:
            $ _a4n = "大門"
        "★ 鷹野に送る" (nochosen=True) if "鷹野" in _a4_who:
            $ _a4n = "鷹野"
        "★ 坂口に送る" (nochosen=True) if "坂口" in _a4_who:
            $ _a4n = "坂口"
        "★ 小早川に送る" (nochosen=True) if "小早川" in _a4_who:
            $ _a4n = "小早川"
        "★ 神城に送る" (nochosen=True) if "神城" in _a4_who:
            $ _a4n = "神城"
        "今日は、やめておく" (nochosen=True):
            $ _a4n = ""
    if not _a4n:
        "スマホを伏せて、目を閉じた。"
        return
label a4_night_open:
    $ _a4lab = a4_night_label(_a4n, month)
    $ a4_night_sent[(_a4n, month)] = a4_night_sent.get((_a4n, month), 0) + 1
    $ night_count += 1
    $ night_last[_a4n] = night_count
    window auto hide
    $ night_boost = True
    call expression _a4lab
    $ night_boost = False
    $ night_incoming = ""
    window auto hide
    $ talk_end()
    return


## ===========================================================================
## ひなた
## ===========================================================================
label a4nc_hinata_a4may:
    $ talk_start("ひなた", "22:10")
    $ talk_me("1年のテーピング、教えてくれて助かった")
    $ talk("ひなた", "倉田くん、自分の指まで巻いてたよ")
    $ talk("ひなた", "でもね、みんな、ちゃんとノート取ってた。去年の蓮たちより、まじめかも")
    $ _r = talk_choose([("……それは、否定できない", "a"), ("去年の俺たちは、走るので精一杯だった", "b")])
    if _r == "a":
        $ talk_me("……それは、否定できない")
        $ talk("ひなた", "でしょ。坂口くんなんて、去年、テーピングをガムテープだと思ってたもん")
        $ heart_up("ひなた", "信頼", 2)
    else:
        $ talk_me("去年の俺たちは、走るので精一杯だった")
        $ talk("ひなた", "うん。知ってる。全部、ノートに書いてあるから")
        $ talk("ひなた", "今年は、1年生のぶんも書くから、ノート2冊になった")
        $ heart_up("ひなた", "信頼", 3)
    return

label a4nc_hinata_a4may_2:
    $ talk_start("ひなた", "22:45")
    $ talk_me("学校、なくなるって。……ひなた、どう思った")
    $ talk("ひなた", "……さみしい、かな")
    $ talk("ひなた", "でも、蓮たちが最後の代って聞いて、ちょっとだけ、かっこいいって思った")
    $ talk("ひなた", "最後の代のマネージャーも、わたしだからね。忘れないでよ")
    $ heart_up("ひなた", "信頼", 2)
    return

label a4nc_hinata_a4jul:
    $ talk_start("ひなた", "21:55")
    $ talk_me("準決勝のノート、見た")
    $ talk("ひなた", "……見たの。恥ずかしい")
    $ talk("ひなた", "後半の途中から、字がぐちゃぐちゃでしょ。泣いてたから")
    $ _r = talk_choose([("次は、勝つところを書かせる", "a"), ("ぐちゃぐちゃでも、読めた", "b")])
    if _r == "a":
        $ talk_me("次は、勝つところを書かせる")
        $ talk("ひなた", "うん。……冬の選手権のページ、もう作ってあるから")
        $ heart_up("ひなた", "信頼", 3)
    else:
        $ talk_me("ぐちゃぐちゃでも、読めた")
        $ talk("ひなた", "「蓮、ひざ、かばってない。えらい」ってとこも？")
        $ talk("ひなた", "……あれ、ほんとだからね")
        $ heart_up("ひなた", "信頼", 2)
        $ up("無理ゲージ", -1)
    return

label a4nc_hinata_a4jul_2:
    $ talk_start("ひなた", "22:20")
    $ talk_me("学校見学、どうだった")
    $ talk("ひなた", "楽しかった！　ひざの模型、ほしくなった")
    $ talk("ひなた", "高いから、写真だけ撮ってきた。あとで見せるね。蓮のひざと比べるから")
    $ talk_me("比べるな")
    $ talk("ひなた", "比べます。マネージャーなので")
    $ heart_up("ひなた", "信頼", 2)
    return

label a4nc_hinata_more1:
    $ talk_start("ひなた", "22:30")
    $ talk_me("明日の朝練、何時だっけ")
    $ talk("ひなた", "6時半。1年生は6時15分に来て、ボール出すの")
    $ talk("ひなた", "去年の蓮たちは、三好先輩に6時に呼ばれてたよ。忘れた？")
    $ talk_me("忘れたかった")
    $ heart_up("ひなた", "信頼", 1)
    return


## ===========================================================================
## 千夏
## ===========================================================================
label a4nc_chika_a4may:
    $ talk_start("千夏", "21:35")
    $ talk_me("「港北の記録」、手伝えることありますか")
    $ talk_system("既読")
    $ talk("千夏", "写真の裏に、日付と名前を書く作業があります。五年分です")
    $ talk("千夏", "……冗談です。半分は、終わっています")
    $ _r = talk_choose([("残りの半分、やります", "a"), ("先輩も冗談、言うんですね", "b")])
    if _r == "a":
        $ talk_me("残りの半分、やります")
        $ talk("千夏", "では、木曜の昼休みに。名前の読み方は、私が確認します")
        $ heart_up("千夏", "信頼", 3)
    else:
        $ talk_me("先輩も冗談、言うんですね")
        $ talk("千夏", "言います。……生徒会長の任期も、あと少しなので")
        $ heart_up("千夏", "信頼", 2)
    return

label a4nc_chika_a4may_2:
    $ talk_start("千夏", "22:05")
    $ talk_me("今日の練習、撮ってましたよね")
    $ talk("千夏", "撮っていました。小早川くんは、写真を撮られると、背筋がのびます")
    $ talk("千夏", "あなたは、撮られていることに、気づかない顔をしています")
    $ talk("千夏", "記録には、そのほうがいいです")
    $ heart_up("千夏", "信頼", 2)
    return

label a4nc_chika_a4jul:
    $ talk_start("千夏", "21:15")
    $ talk_me("準決勝、来てくれてありがとうございました")
    $ talk_system("既読")
    $ talk("千夏", "記録係ですから")
    $ talk("千夏", "……0−2のあと、あなたが最後にスタンドに頭を下げたのも、撮りました")
    $ _r = talk_choose([("それは、消してください", "a"), ("記録に、残してください", "b")])
    if _r == "a":
        $ talk_me("それは、消してください")
        $ talk("千夏", "消しません。記録ですから")
        $ heart_up("千夏", "信頼", 2)
    else:
        $ talk_me("記録に、残してください")
        $ talk("千夏", "はい。……冬に勝ったときの写真と、並べます")
        $ heart_up("千夏", "信頼", 3)
    return

label a4nc_chika_a4jul_2:
    $ talk_start("千夏", "23:02")
    $ talk_me("まだ起きてるんですか")
    $ talk("千夏", "英語の長文が、終わりません")
    $ talk("千夏", "あなたも、早く寝てください。ひざは、寝ている間に治るそうです")
    $ talk("千夏", "……篠宮さんの受け売りです")
    $ heart_up("千夏", "信頼", 2)
    return

label a4nc_chika_more1:
    $ talk_start("千夏", "21:50")
    $ talk_me("生徒会室の電気、まだついてました")
    $ talk("千夏", "消し忘れではありません。写真を見ていました")
    $ talk("千夏", "……今、消しました")
    $ heart_up("千夏", "信頼", 1)
    return


## ===========================================================================
## 三好（OB・工務店）
## ===========================================================================
label a4nc_miyoshi_a4may:
    $ talk_start("三好", "20:40")
    $ talk_me("先輩、仕事どうですか")
    $ talk("三好", "腕が太くなった！！！！")
    $ talk("三好", "腕章、もうきつくて巻けないかもしれん！！！")
    $ talk("三好", "1年は何人だ！？")
    $ talk_me("%d人です。全部で" % a4_members)
    $ talk("三好", "……マジか")
    $ talk("三好", "去年の春は、3人だったぞ。……泣いていいか")
    $ bond_up("三好", 2)
    return

label a4nc_miyoshi_a4jul:
    $ talk_start("三好", "21:00")
    $ talk_me("準決勝、すみませんでした")
    $ talk("三好", "謝るな！！！")
    $ talk("三好", "ベスト4だぞ。港北が。俺、トラックの中で叫んで、親父に怒られた")
    $ talk("三好", "冬は、全国だ。トラックで行くからな！！！")
    $ bond_up("三好", 2)
    $ up("メンタル", 1)
    return

label a4nc_miyoshi_more1:
    $ talk_start("三好", "21:30")
    $ talk_me("おつかれさまです")
    $ talk("三好", "おう！！　今日、学校の前を通ったら、お前らの声が聞こえたぞ！！")
    $ talk("三好", "……ちょっと小さかったな！！")
    $ bond_up("三好", 1)
    return


## ===========================================================================
## 大門
## ===========================================================================
label a4nc_daimon_a4may:
    $ talk_start("大門", "21:45")
    $ talk_me("倉田、どうだ")
    $ talk("大門", "あ、あの……毎日、僕のことを「先輩」って呼ぶんです")
    $ talk("大門", "まだ慣れなくて……三回に一回、返事しそこねます")
    $ _r = talk_choose([("慣れろ。もう先輩だ", "a"), ("俺も、まだ慣れてない", "b")])
    if _r == "a":
        $ talk_me("慣れろ。もう先輩だ")
        $ talk("大門", "……はい。明日から、一回目で返事します")
        $ bond_up("大門", 2)
    else:
        $ talk_me("俺も、まだ慣れてない")
        $ talk("大門", "えっ、早瀬くんも？")
        $ talk("大門", "……ちょっと、安心しました")
        $ bond_up("大門", 3)
    return

label a4nc_daimon_a4jul:
    $ talk_start("大門", "22:00")
    $ talk_me("準決勝の2点目、気にするなよ")
    $ talk("大門", "……気にしてます。でも、倉田くんの前では、気にしてない顔をしてます")
    $ talk("大門", "去年、早瀬くんが、そうしてたので")
    $ bond_up("大門", 2)
    $ up("メンタル", 1)
    return

label a4nc_daimon_more1:
    $ talk_start("大門", "21:20")
    $ talk_me("おつかれ")
    $ talk("大門", "おつかれさまです！　今日、倉田くんが初めて、僕のシュートを止めました")
    $ talk("大門", "……悔しいより、うれしいが勝ちました")
    $ bond_up("大門", 1)
    return


## ===========================================================================
## 鷹野
## ===========================================================================
label a4nc_takano_a4may:
    $ talk_start("鷹野", "22:15")
    $ talk_me("赤坂、今日も挑んできたか")
    $ talk("鷹野", "三回。全部抜いた")
    $ talk("鷹野", "……三回目、ちょっと危なかった")
    $ _r = talk_choose([("伸びてるな、あいつ", "a"), ("お前も伸びろよ", "b")])
    if _r == "a":
        $ talk_me("伸びてるな、あいつ")
        $ talk("鷹野", "言うなよ。調子に乗る")
        $ bond_up("鷹野", 2)
    else:
        $ talk_me("お前も伸びろよ")
        $ talk("鷹野", "……うるせえ。伸びてる")
        $ bond_up("鷹野", 2)
        $ up("メンタル", 1)
    return

label a4nc_takano_a4jul:
    $ talk_start("鷹野", "22:50")
    if a4_takano == "push":
        $ talk_me("清翔のコーチ、怒ってなかったか")
        $ talk("鷹野", "笑ってた。「お前らしい」って")
        $ talk("鷹野", "……屋上のこと、誰にも言うなよ")
        $ talk_me("言わない")
        $ talk("鷹野", "明日、裏に出せ。全部、決めてやる")
        $ bond_up("鷹野", 2)
    else:
        $ talk_me("この前は、悪かった")
        $ talk_system("既読")
        $ talk_wait(12)
        $ talk("鷹野", "悪くねえよ")
        $ talk("鷹野", "残るって決めたのは、俺だ。……それだけだ")
        $ bond_up("鷹野", 1)
    return

label a4nc_takano_more1:
    $ talk_start("鷹野", "22:00")
    $ talk_me("明日、早めに行く")
    $ talk("鷹野", "知ってる。俺も行く")
    $ talk("鷹野", "6時。ボール出しとけ")
    $ bond_up("鷹野", 1)
    return


## ===========================================================================
## 坂口
## ===========================================================================
label a4nc_sakaguchi_a4may:
    $ talk_start("坂口", "23:05")
    $ talk("坂口", "てか聞いて")
    $ talk("坂口", "1年に「坂口先輩」って呼ばれた")
    $ talk("坂口", "ウケる")
    $ talk("坂口", "……ウケねえ。なんか、ちゃんとしなきゃって気になる")
    $ _r = talk_choose([("ちゃんとしろよ、先輩", "a"), ("いつもどおりでいい", "b")])
    if _r == "a":
        $ talk_me("ちゃんとしろよ、先輩")
        $ talk("坂口", "うわ、言われた。……明日、クロスの見本やるわ")
        $ bond_up("坂口", 2)
    else:
        $ talk_me("いつもどおりでいい")
        $ talk("坂口", "……蓮って、たまにそういうこと言うよな")
        $ bond_up("坂口", 3)
    return

label a4nc_sakaguchi_a4jul:
    $ talk_start("坂口", "22:35")
    $ talk("坂口", "準決勝のビデオ、5人で見た")
    $ talk("坂口", "江藤が、2点目のとこで止めて、何回も見てた")
    $ talk("坂口", "……冬、あいつら倒したら、ゲーセンでおごるわ。全員に")
    $ bond_up("坂口", 2)
    return

label a4nc_sakaguchi_more1:
    $ talk_start("坂口", "22:10")
    $ talk_me("おつかれ")
    $ talk("坂口", "おつ。今、野口がゲームで点取って泣いてる")
    $ talk("坂口", "本物で取れって言っといた")
    $ bond_up("坂口", 1)
    return


## ===========================================================================
## 小早川
## ===========================================================================
label a4nc_koba_a4may:
    $ talk_start("小早川", "21:25")
    $ talk_me("首、振りすぎて痛くないか")
    $ talk("小早川", "痛いです。でも、昨日より、二回少なく振れました")
    $ talk("小早川", "先輩。一つ、聞いてもいいですか")
    $ talk("小早川", "先輩は、港北に来たこと、後悔したことありますか")
    $ _r = talk_choose([("ない", "a"), ("一回だけ、ある。今はない", "b")])
    if _r == "a":
        $ talk_me("ない")
        $ talk("小早川", "……よかった。僕も、たぶん、しないです")
        $ up("メンタル", 1)
    else:
        $ talk_me("一回だけ、ある。今はない")
        $ talk("小早川", "……正直ですね。そういう先輩のほうが、信じられます")
        $ up("戦術眼", 1)
    return

label a4nc_koba_a4jul:
    $ talk_start("小早川", "22:05")
    $ talk("小早川", "先輩、準決勝のあと、なんて言えばよかったんですか")
    $ talk("小早川", "僕、何も言えませんでした")
    $ talk_me("何も言わなくていい。次の日、いちばん早く来ればいい")
    $ talk("小早川", "……はい。明日、6時に行きます")
    $ talk_me("6時は鷹野がいる")
    $ talk("小早川", "じゃあ、5時50分に行きます")
    $ up("メンタル", 1)
    return

label a4nc_koba_more1:
    $ talk_start("小早川", "21:40")
    $ talk("小早川", "今日のパス、ノートに書きました")
    $ talk("小早川", "先輩が首を振ったの、ボールが来る1秒半前でした")
    $ talk_me("数えるな")
    $ talk("小早川", "数えます")
    return


## ===========================================================================
## 神城（4/29 から、既読がつかない）
## ===========================================================================
label a4nc_kamishiro_a4may:
    $ talk_start("神城 凌", "23:30")
    $ talk_day("4月29日（木）", "23:14")
    $ talk_me("話したな。全部", read="")
    $ talk_me("それで終わりか", read="")
    $ talk_day(a4_night_date, "23:30")
    $ talk_me("インターハイ、出てくるんだろうな", read="")
    $ talk_system("既読は、つかなかった")
    return

label a4nc_kamishiro_a4jul:
    $ talk_start("神城 凌", "23:40")
    $ talk_me("なんで出なかった", read="")
    $ talk_me("逃げたのか", read="")
    $ talk_system("既読は、つかなかった")
    return

label a4nc_kamishiro_more1:
    $ talk_start("神城 凌", "23:50")
    $ talk_me("……", read="")
    $ talk_system("既読は、つかなかった")
    return
