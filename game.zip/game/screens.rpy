## screens.rpy ―― 画面まわり（デザイン：放課後ノート）
##   セリフ枠・選択肢・タイトル・メニュー・セーブ／ロード・設定・ログ・確認ダイアログ
##   画像パーツは game/gui/ にある（作り直すときは同じファイル名で上書きする）

################################################################################
## 色とフォント
################################################################################

define FONT_JP = "fonts/NotoSansCJKjp-Regular-subset.otf"
define FONT_JP_B = "fonts/NotoSansCJKjp-Bold-subset.otf"

define INK = "#3c2d23"          # 鉛筆の文字
define INK_SOFT = "#8c735f"     # 薄い文字
define PEN_RED = "#cd4646"      # 赤ペン
define PEN_TEAL = "#2f6f76"     # 青緑のペン

## 蛍光ペン（ボタンにマウスを乗せたとき）
define HL = Frame("gui/highlight.png", 16, 10)


################################################################################
## 共通スタイル
################################################################################

style default:
    font FONT_JP
    size 26
    language "japanese-normal"
    color INK
    ## ▶ や ◀ が絵文字（青い四角）にならないように、フォントにある字はフォントで出す
    prefer_emoji False

style button:
    padding (12, 4, 12, 4)
    hover_background HL
    selected_background HL

style button_text:
    color INK_SOFT
    hover_color INK
    selected_color INK
    selected_font FONT_JP_B
    insensitive_color "#c8bba8"

style label_text:
    font FONT_JP_B
    color PEN_RED
    size 24

style frame:
    background Frame("gui/note_small.png", 14, 14)
    padding (22, 14, 22, 18)

style bar:
    ysize 18
    left_bar Solid("#f08c8c")
    right_bar Solid("#e6dbc4")

style slider:
    ysize 26
    xsize 440
    left_bar Solid("#f08c8c")
    right_bar Solid("#e6dbc4")
    thumb "gui/slider_thumb.png"
    thumb_offset 6

style vscrollbar:
    xsize 8
    base_bar Solid("#efe9dc")
    thumb Solid("#b9ab92")
    unscrollable "hide"

style hyperlink_text:
    color PEN_TEAL


################################################################################
## 文字送りの合図（赤い▼が点滅）
################################################################################

image ctc_blink:
    "gui/ctc.png"
    yoffset 4
    block:
        linear 0.45 alpha 0.25
        linear 0.45 alpha 1.0
        repeat


################################################################################
## セリフ枠（ルーズリーフ）。名前はマスキングテープ
################################################################################

screen say(who, what):
    zorder 41       # トーク画面（スマホ）を出したまま地の文を出しても、セリフ枠が上に来るように
    window:
        id "window"

        ## 坂口の仲間（森・小池・江藤・野口）と2年の桐生・宮下が話すときは、セリフ枠の左上に顔の写真を貼る
        ##   4人が一言ずつ続けて話す場面が多いので、立ち絵を出し入れせずに、だれが話しているか分かるようにする（v0.28.0）
        ##   v0.30.0：その人の立ち絵が画面に出ているときは、顔の写真は出さない（二重にならないように）
        $ _sf = side_face_on(who)
        if _sf:
            add side_face(who) at side_photo

        if who is not None:
            window:
                id "namebox"
                style "namebox"
                if _sf:
                    xpos 168
                text who id "who"

        text what id "what"

        if quick_menu:
            use quick_buttons

style window:
    xalign 0.5
    yalign 1.0
    yoffset 6
    xsize 1224
    ysize 200
    background "gui/textbox.png"
    padding (0, 0, 0, 0)

style say_window is window

## 顔の写真（名前 → 画像）。写真は images/chara/face/ に、白いふちと影をつけて少し傾けて作ってある
define SIDE_FACE = {
    "森": "images/chara/face/mori.png",
    "小池": "images/chara/face/koike.png",
    "江藤": "images/chara/face/eto.png",
    "野口": "images/chara/face/noguchi.png",
    "桐生": "images/chara/face/kiryu.png",
    "宮下": "images/chara/face/miyashita.png",
    ## 第4章の人（v0.30.0）
    "小早川": "images/chara/face/kobayakawa.png",
    "倉田": "images/chara/face/kurata.png",
    "赤坂": "images/chara/face/akasaka.png",
    "真壁": "images/chara/face/makabe.png",
    "佐伯": "images/chara/face/saeki.png",
}

## 顔の写真の人の、立ち絵のタグ（その立ち絵が出ているときは、顔の写真を出さない）
define SIDE_TAG = {"森": "mori", "小池": "koike", "江藤": "eto", "野口": "noguchi", "桐生": "kiryu", "宮下": "miyashita",
                   "小早川": "kobayakawa", "倉田": "kurata", "赤坂": "akasaka", "真壁": "makabe", "佐伯": "saeki"}

init python:
    def side_face_on(who):
        if who not in SIDE_FACE:
            return False
        tag = SIDE_TAG.get(who)
        return not (tag and renpy.showing(tag))

init python:
    def side_face(who):
        """セリフ枠の顔の写真。送別旅行のあいだ（trip_outfit）は、私服・浴衣の写真があればそれを出す"""
        base = SIDE_FACE[who]
        o = getattr(store, "trip_outfit", "")
        if o:
            alt = base.replace(".png", "_%s.png" % o)
            if renpy.loadable(alt):
                return alt
        return base

transform side_photo:
    xpos 6
    ypos -148

style namebox:
    xpos 100
    ypos -20
    xysize (262, 62)
    background "gui/namebox.png"
    padding (0, 0, 0, 0)

style say_label:
    font FONT_JP_B
    size 28
    color INK
    outlines [(3, "#fffaf2", 0, 0)]     # 名前を読みやすく（テープの上でも文字がにじまないように）
    xalign 0.5
    yalign 0.5
    yoffset -2

style say_dialogue:
    xpos 120
    ypos 50                 # line_leading の分だけ上げて、罫線の位置は前と同じにしている
    xsize 1060
    size 28
    line_leading 8          # ふりがな（ルビ）を書くすき間
    line_spacing -6         # 行の間隔は前と同じ（42.5px）
    ruby_style style.ruby_text

## ふりがな（ルビ）。台本では {rb}神城{/rb}{rt}かみしろ{/rt} のように書く
style ruby_text:
    size 13
    yoffset -29
    color None


################################################################################
## クイックメニュー（セリフ枠の右下に、鉛筆の文字で）
##   雰囲気をこわさないように、ふだん見えるのは「戻る・ログ・オート・スキップ」だけ。
##   セーブ・ロード・ステータス・相関図・設定などは、画面右上のメニューボタン（mobile.rpy の menu_tab）から開く。
##   右クリック／Esc でもメニューが開く。
################################################################################

default quick_menu = True

screen quick_buttons():
    hbox:
        style_prefix "quick"
        xalign 1.0
        xoffset -44
        ypos 160
        spacing 2

        ## v0.29.12：「戻る」を出して、あまり使わない「次の選択肢へ」は右上のメニューの中だけに
        textbutton "戻る" action Rollback()
        textbutton "ログ" action ShowMenu("history")
        textbutton "オート" action Preference("auto-forward", "toggle")
        textbutton "スキップ" action Skip() alternate Skip(fast=True, confirm=True)

style quick_button:
    padding (6, 0, 6, 2)

style quick_button_text:
    size 15
    color INK_SOFT
    hover_color INK
    selected_color PEN_RED

init python:
    config.overlay_screens.append("calendar_hud")

    ## タイトル画面・セーブ／ロード・設定の画面を Ren'Py の流れにつなぐ
    ## （公式テンプレートでは gui.init() の中で行われている処理）
    layout.defaults()


################################################################################
## 名前入力（使わないが、Ren'Py が必要とする場合に備えて用意）
################################################################################

screen input(prompt):
    style_prefix "input"
    window:
        vbox:
            xpos 120
            ypos 40
            spacing 12
            text prompt
            input id "input"


################################################################################
## 選択肢（ノートの切れ端。マウスを乗せると蛍光ペン）
################################################################################

screen choice(items):
    style_prefix "choice"
    ## 「1つ戻る」のあとで先へ進んだときなどに、古い「先送りの記録」が残っていると、
    ## まだ選んでいない選択肢まで全部押せなくなる。この選択肢の記録がなければ、古い記録を捨てる
    python:
        if renpy.in_fixed_rollback() and renpy.roll_forward_info() is None:
            del renpy.game.log.forward[:]
    ## GOALの帯が残っていたら、選択肢と重ならないように消す
    on "show" action Hide("goal_banner")
    if len(items) > 6:
        ## 答えが多いとき（夜にトークを送る相手など）は、2列に並べる
        $ _half = (len(items) + 1) // 2
        hbox:
            xalign 0.5
            yalign 0.45
            spacing 12
            for _col in (items[:_half], items[_half:]):
                vbox:
                    spacing 0
                    for i in _col:
                        use choice_item(i, 600, 86)
    else:
        vbox:
            for i in items:
                use choice_item(i)

## 選択肢の1つぶん
##   menu の答えに (nochosen=True) を付けると「済」の印を付けない（毎晩使い回す、夜のトークの相手選びなど）
screen choice_item(i, w=928, h=94):
    style_prefix "choice"
    ## 選択肢のヒント（設定でオンのときだけ。systems.rpy の choice_hint）
    $ _h = choice_hint(i.caption)
    ## 前のプレイで選んだことがある答えは、文字を薄くして「済」の印を付ける
    if i.chosen and not (getattr(i, "kwargs", None) or {}).get("nochosen"):
        button:
            xsize w
            yminimum h
            action i.action
            vbox:
                xalign 0.5
                yalign 0.5
                spacing 0
                hbox:
                    xalign 0.5
                    spacing 10
                    text "済" style "choice_chosen_mark"
                    text i.caption style "choice_chosen_text"
                if _h:
                    text _h style "choice_hint_text"
    elif _h:
        button:
            xsize w
            yminimum h
            action i.action
            vbox:
                xalign 0.5
                yalign 0.5
                spacing 0
                text i.caption style "choice_button_text"
                text _h style "choice_hint_text"
    else:
        textbutton i.caption action i.action xsize w yminimum h

style choice_hint_text:
    xalign 0.5
    text_align 0.5
    size 17
    color PEN_TEAL
    hover_color PEN_TEAL

style choice_hint_text:
    variant "small"
    size 20

style choice_chosen_mark:
    yalign 0.5
    size 18
    font FONT_JP_B
    color "#ffffff"
    outlines [(6, INK_SOFT, 0, 0)]

style choice_chosen_text:
    yalign 0.5
    text_align 0.5
    size 26
    color INK_SOFT
    insensitive_color "#8f846e"

style choice_vbox:
    xalign 0.5
    yalign 0.4
    spacing 0

style choice_button:
    xsize 928
    ## v0.30.0：長い選択肢やヒントで文字が枠からはみ出さないように、高さは文字に合わせてのばす（最低 94）
    yminimum 94
    background Frame("gui/choice_idle.png", 80, 30)
    hover_background Frame("gui/choice_hover.png", 80, 30)
    ## 「1つ戻る」で選択肢まで戻ったとき：選んだ答えは目立たせ、ほかの答えは薄くする（押せない）
    selected_background Frame("gui/choice_hover.png", 80, 30)
    insensitive_background Frame(Transform("gui/choice_idle.png", alpha=0.55), 80, 30)
    padding (80, 14, 80, 22)

style choice_button_text:
    xalign 0.5
    yalign 0.5
    text_align 0.5
    size 26
    color INK
    hover_color INK
    hover_font FONT_JP_B
    selected_font FONT_JP_B
    insensitive_color "#8f846e"


################################################################################
## タイトル画面
################################################################################

## 方眼ノート＋マスキングテープの作り（v0.31.1：ちぎった紙のうねうねした形をやめて、真っすぐな紙にした）
##   メニューは、左上をマスキングテープで留めた紙。マウスを乗せると白くなり、左に赤い線。右下に黄色い付箋で版と更新情報
##   部品は tools/make_grid_ui.py で gui/grid/ に作る
##   「前回のつづき」はやめた（「つづきから」と2つ並んで、ちがいが分かりにくいため。オートセーブは「つづきから」の「オート」のページにある）

## タイトルに出る人（v0.31.1）：起動するたびに、蓮か、これまでに会った人のだれかが出る。会うまでは出ない（ネタバレ防止）
##   人ごとに、蓮の絵と同じ「右半分に胸から上のアップ、左はロゴとメニューの余白」の一枚絵（gui/title/title_〜.png、1280×720）。
##   場面は人ごとにちがう（ひなた＝朝、自分の部屋で髪を結ぶ など）。一枚絵がまだない人は、夕方のグラウンドに立ち絵を置く
##   (名前, 一枚絵の id, 一枚絵がないときの立ち絵)
define TITLE_CAST = [
    ("ひなた", "hinata", "images/chara/hinata_smile.png"),
    ("千夏", "chika", "images/chara/chika_normal.png"),
    ("紗希", "saki", "images/chara/saki_normal.png"),
    ("あげは", "ageha", "images/chara/ageha_normal.png"),
    ("鷹野", "takano", "images/chara/takano_jersey.png"),
    ("大門", "daimon", "images/chara/daimon_jersey.png"),
    ("三好", "miyoshi", "images/chara/miyoshi_smile.png"),
    ("神城", "kamishiro", "images/chara/kamishiro_normal.png"),
]
default persistent.title_met = set()

init python:
    class _TitlePick(object):
        cur = None      # 起動しているあいだは同じ人（設定から戻るたびに変わらないように）

    def title_pick():
        """タイトルに出す絵：("full", 一枚絵) か ("sprite", 立ち絵) か (None, "")＝いつもの蓮の絵"""
        if _TitlePick.cur is None:
            met = persistent.title_met or set()
            cands = [(None, "")]
            for nm, tid, spr in TITLE_CAST:
                if nm not in met:
                    continue
                full = "gui/title/title_%s.png" % tid
                cands.append(("full", full) if renpy.loadable(full) else ("sprite", spr))
            _TitlePick.cur = renpy.random.choice(cands)
        return _TitlePick.cur

    def _title_met_from_save():
        """前の版のセーブを読んだときも、会った人をタイトルに出せるようにする"""
        persistent.title_met = set(persistent.title_met or set()) | set(store.met or [])
    config.after_load_callbacks.append(_title_met_from_save)

## メニューの紙が、上から順に貼られていく
transform mm_slide(i):
    alpha 0.0 yoffset -12
    pause 0.05 * i
    easein 0.22 alpha 1.0 yoffset 0

screen main_menu():
    tag menu

    $ _kind, _pick = title_pick()
    if _kind == "full":
        add _pick
        ## 左のメニューが読みやすいように、左側だけ少し暗くする
        add "gui/grid/title_shade.png" alpha 0.6
    elif _kind == "sprite":
        add "images/bg/kohoku_ground_eve.jpg"
        add _pick xalign 1.0 xoffset -60 yalign 1.0 zoom 1.08
        add "gui/grid/title_shade.png"
    else:
        add "gui/title_bg.png"
    add "gui/title_logo.png" xpos 34 ypos 62 zoom 0.70

    $ _items = []
    $ _items.append(("はじめから", Start()))
    $ _items.append(("つづきから", ShowMenu("load")))
    if persistent.trial_cleared or AUTHOR_BUILD:
        $ _items.append(("章えらび", ShowMenu("chapter_select")))
    ## 作者の確認用だけ：ヒロインとのやりとりを1場面ずつ確かめる（heroine_test.rpy）
    if hs_available():
        $ _items.append(("ヒロイン場面", Start("hs_start")))
    $ _items.append(("回想", ShowMenu("gallery")))
    $ _items.append(("設定", ShowMenu("preferences")))
    ## Web 版（テストページ）では「終了」が使えないので、かわりに「アンケート」を出す
    if survey_available():
        $ _items.append(("アンケート", Function(survey_open, False)))
    else:
        $ _items.append(("終了", Quit(confirm=False)))

    vbox:
        xpos 70
        ypos 262
        spacing 10
        for _i, (_label, _act) in enumerate(_items):
            button:
                style "mm_button"
                action _act
                ## いちばん上の項目を最初から選んだ状態にする（キーボード・パッドでもすぐ決定できる）
                default_focus (_i == 0)
                at mm_slide(_i)
                fixed:
                    fit_first True
                    text _label style "mm_button_text"
                add "gui/grid/tape_%d.png" % (_i % 7) xpos -18 ypos -10

    ## 右下：黄色い付箋に、版と「更新情報」
    button:
        style "mm_sticky"
        action ShowMenu("updates")
        vbox:
            xalign 0.5
            yalign 0.5
            spacing 0
            text "ver.[config.version]" style "mm_sticky_ver"
            text "更新情報を見る ▶" style "mm_sticky_text"

    ## 新しい版を初めて開いたときだけ、お知らせを出す（updates.rpy）
    on "show" action If(update_notice_due(), Show("update_notice"))

style mm_button:
    xysize (308, 60)
    background "gui/grid/strip.png"
    hover_background "gui/grid/strip_hover.png"
    padding (40, 0, 0, 8)

style mm_button_text:
    ypos 13
    font FONT_JP_B
    size 23
    color INK
    hover_color PEN_RED

style mm_sticky:
    xysize (238, 78)
    xalign 1.0
    yalign 1.0
    xoffset -20
    yoffset -12
    background "gui/grid/sticky.png"
    hover_background "gui/grid/sticky_hover.png"
    padding (0, 0, 8, 8)

style mm_sticky_ver:
    xalign 0.5
    size 16
    color INK_SOFT

style mm_sticky_text:
    xalign 0.5
    font FONT_JP_B
    size 20
    color INK
    hover_color PEN_RED


################################################################################
## ゲームメニュー共通の枠（夕焼けをぼかした背景に、方眼の紙。左に色の紙のタブ。v0.31.1）
################################################################################

screen navigation():
    ## いちばん使う「ゲームに戻る（タイトルでは「戻る」）」を、いちばん上に赤い付箋で大きく出す。
    ## ほかは「遊ぶ（セーブ・ロード・ログ）」「見る（ステータス・相関図）」「設定」のまとまりに分けて、すき間をあける。
    ## 「タイトルへ」はうっかり押さないように、いちばん下に小さく。クレジット・終了はタイトル画面からだけ。
    vbox:
        style_prefix "navigation"
        xpos 34
        ypos 40
        spacing 0

        if main_menu:
            textbutton "戻る" action Return() style "navigation_back_button" text_style "navigation_back_text"
            null height 18
            use nav_tab("はじめから", Start(), "orange")
            use nav_tab("ロード", ShowMenu("load"), "sky")
            use nav_tab("回想", ShowMenu("gallery"), "pink")
            null height 12
            use nav_tab("設定", ShowMenu("preferences"), "lav")
            use nav_tab("クレジット", ShowMenu("credits"), "green")
        else:
            textbutton "ゲームに戻る" action Return() style "navigation_back_button" text_style "navigation_back_text"
            null height 18
            use nav_tab("セーブ", ShowMenu("save"), "yellow")
            null height 10    # セーブとロードの押しまちがいを防ぐすき間
            use nav_tab("ロード", ShowMenu("load"), "sky")
            use nav_tab("ログ", ShowMenu("history"), "green")
            null height 12
            use nav_tab("ステータス", ShowMenu("status"), "pink")
            use nav_tab("相関図", ShowMenu("relations"), "pink")
            null height 12
            use nav_tab("設定", ShowMenu("preferences"), "lav")

    ## いちばん下の小さなリンク
    hbox:
        xpos 52
        yanchor 1.0
        ypos 700
        spacing 24
        if main_menu:
            if not renpy.variant("mobile") and not renpy.variant("web"):
                textbutton "終了" action Quit(confirm=False) style "navigation_small_button" text_style "navigation_small_text"
        else:
            textbutton "タイトルへ" action MainMenu() style "navigation_small_button" text_style "navigation_small_text"

style navigation_back_button:
    xysize (224, 62)
    background "gui/grid/back.png"
    hover_background "gui/grid/back_hover.png"
    padding (0, 0, 8, 8)

style navigation_back_text:
    xalign 0.5
    yalign 0.5
    font FONT_JP_B
    size 22
    color "#ffffff"
    hover_color "#ffffff"

style navigation_small_button:
    padding (6, 4, 6, 4)
    background None

style navigation_small_text:
    font FONT_JP_B
    size 18
    color "#f3e6c8"
    hover_color "#ffffff"
    underline True

## 色の紙のタブ（v0.31.1：方眼ノートにそろえて、折り目のない真っすぐな紙に。部品は tools/make_grid_ui.py で作る）
##   色で、何の画面かを見分ける：セーブ＝黄、ロード＝水色、ログ・クレジット＝緑、ステータス・相関図・回想＝ピンク、設定＝紫、はじめから＝オレンジ
##   いま開いている画面のタブは、右へ少し出て、紙のほうに差しこまれる
screen nav_tab(label, act, color):
    textbutton label action act style "navigation_button" text_style "navigation_button_text":
        background "gui/grid/tab_%s.png" % color
        hover_background "gui/grid/tab_%s_hover.png" % color
        selected_background "gui/grid/tab_%s_sel.png" % color

style navigation_button:
    xysize (226, 56)
    padding (24, 0, 16, 8)
    selected_xoffset 18

style navigation_button_text:
    yalign 0.5
    font FONT_JP_B
    size 20
    color INK
    hover_color PEN_RED
    selected_color INK

screen game_menu(title, scroll=None, yinitial=0.0):
    style_prefix "game_menu"

    add "gui/menu_bg.png"

    use navigation

    ## 見出し（下半分に黄色の蛍光ペン）
    frame:
        style "game_menu_title_frame"
        text title style "game_menu_title"

    ## スクロールする画面（ログ・更新情報・クレジット・名鑑・回想・サッカーノート）は、文字のうしろに方眼の罫線が出ないよう、
    ## 中身を白いカードに載せる（v0.31.1。ステータスや設定は、項目ごとのカードを自分で並べている）
    frame:
        style ("game_menu_content_card" if scroll == "viewport" else "game_menu_content")

        if scroll == "viewport":
            viewport:
                yinitial yinitial
                scrollbars "vertical"
                mousewheel True
                draggable True
                vbox:
                    spacing 12
                    transclude
        else:
            transclude

style game_menu_title_frame:
    xpos 298
    ypos 46
    padding (6, 0, 6, 0)
    background Frame("gui/grid/title_hl.png", 4, 0)

style game_menu_title:
    font FONT_JP_B
    size 34
    color INK

style game_menu_content:
    ## 方眼の紙（x=252〜1254, y=26〜694。tools/make_grid_ui.py）の内側。v0.31.1
    xpos 304
    ypos 112
    xsize 900
    ysize 568
    background None
    padding (0, 4, 0, 4)

style game_menu_content_card is game_menu_content:
    background Frame("gui/grid/card.png", 4, 4)
    padding (26, 18, 14, 18)


################################################################################
## セーブ・ロード（ポラロイド写真）
################################################################################

screen save():
    tag menu
    use file_slots("セーブ")

screen load():
    tag menu
    use file_slots("ロード")

## セーブとロードを見まちがえないように、見出しの横に「何をする画面か」を色を変えて出す
##   セーブ＝赤ペン、ロード＝青緑のペン（スマホの画面も同じ）
init python:
    def file_hint(title):
        verb = "タップ" if renpy.variant("touch") else "クリック"
        if title == "セーブ":
            return ("%sした枠に、いまの場面を保存します" % verb, PEN_RED)
        return ("%sした枠の場面から、続きを遊びます" % verb, PEN_TEAL)

    ## セーブ枠に、物語の中の日付を書いておく（例：2026年 5月12日（火））
    def _save_name_by_date(d):
        if store.cal_date:
            d["_save_name"] = "%d年 %s" % (store.cal_year, store.cal_date)
    config.save_json_callbacks.append(_save_name_by_date)

    ## セーブのメモ（v0.31.0）：周回するときに「ここは千夏ルートの分かれ道」などと書いておける。
    ##   セーブ画面で枠を押すとメモを書く小さな紙が出て、「保存する」でメモといっしょに保存する
    save_memo_pending = ""
    def _save_memo(d):
        if store.save_memo_pending:
            d["memo"] = store.save_memo_pending
    config.save_json_callbacks.append(_save_memo)

    ## クイックセーブのページは、使い道が分かりにくいので外した（v0.31.1）。前にクイックを開いていた人は1ページ目に戻す
    if persistent._file_page == "quick":
        persistent._file_page = "1"

    ## 書きかけのメモ（メモの紙を出しているあいだだけ使う）
    save_memo_draft = ""
    def memo_web_edit():
        """スマホのブラウザ用：ブラウザの入力欄（スマホのキーボード。日本語も打てる）でメモを書く"""
        ## ブラウザの入力の中で、セーブ用の画面写真が「メモの紙」の写真に撮り直されてしまうので、もとの写真をとっておいて戻す
        _ss = renpy.game.interface.screenshot
        _sss = renpy.game.interface.screenshot_surface
        v = renpy.invoke_in_new_context(renpy.input, "セーブのメモ（20文字まで）。書いたら「決定」を押してください", default=store.save_memo_draft)
        renpy.game.interface.screenshot = _ss
        renpy.game.interface.screenshot_surface = _sss
        store.save_memo_draft = (v or "").strip()[:20]
        renpy.restart_interaction()

    def slot_action(title, slot):
        """セーブ画面ではメモの紙を出す。ロード画面ではそのまま読む"""
        if title == "セーブ":
            return [SetVariable("save_memo_draft", FileJson(slot, "memo", missing="") or ""), Show("save_memo", slot=slot)]
        return FileAction(slot)

## セーブのメモを書く紙（20文字まで。空のままでも保存できる）
screen save_memo(slot):
    modal True
    zorder 200
    default memo_value = VariableInputValue("save_memo_draft", default=True, returnable=False)
    add Solid("#00000077")
    frame:
        xysize (620, 330)
        xalign 0.5
        yalign 0.5
        background "gui/note_big.png"
        padding (50, 40, 50, 30)
        vbox:
            spacing 14
            text ("この枠に上書きします。メモをつけますか？" if FileLoadable(slot) else "メモをつけて保存しますか？") style "memo_title"
            text "（例：千夏ルートの分かれ道　空のままでも保存できます）" size 17 color INK_SOFT
            if renpy.emscripten and renpy.variant("touch"):
                ## スマホのブラウザでは、ふつうの入力欄にすると Ren'Py の英字だけの画面キーボードが
                ## 画面いっぱいに出てしまう（v0.32.1 テスターの声）。押すとスマホのキーボード（日本語も打てる）で書けるようにする
                button:
                    xsize 500
                    ysize 52
                    background Frame("gui/highlight.png", 16, 10)
                    padding (14, 8, 14, 8)
                    action Function(memo_web_edit)
                    text (save_memo_draft if save_memo_draft else "ここを押して書く") size 24 color (INK if save_memo_draft else INK_SOFT) yalign 0.5
            else:
                frame:
                    xsize 500
                    ysize 52
                    background Frame("gui/highlight.png", 16, 10)
                    padding (14, 8, 14, 8)
                    input value memo_value length 20 size 24 color INK
            hbox:
                xalign 0.5
                spacing 60
                textbutton "保存する" action [SetVariable("save_memo_pending", save_memo_draft), FileSave(slot, confirm=False), SetVariable("save_memo_pending", ""), Hide("save_memo")] text_size 26 text_color PEN_RED
                textbutton "やめる" action Hide("save_memo") text_size 26
    key "game_menu" action Hide("save_memo")

style memo_title:
    font FONT_JP_B
    size 23
    color INK

screen file_slots(title):
    $ _hint, _hcol = file_hint(title)
    use game_menu(title):
        vbox:
            spacing 22

            hbox:
                spacing 8
                style_prefix "page"
                textbutton "オート" action FilePage("auto")
                ## セーブは3ページ（18枠）まで（v0.31.0：9ページは多すぎて、ページの数字が並びすぎるため）
                for page in range(1, 4):
                    textbutton "[page]" action FilePage(page)
                if not renpy.variant("touch"):
                    text "※枠にマウスを合わせて Delete キーで消せます" size 15 color INK_SOFT yalign 0.5 xpos 20

            grid 3 2:
                xspacing 24
                yspacing 30
                for i in range(6):
                    $ slot = i + 1
                    ## 方眼の紙に、写真をテープで留めた白いカード（v0.31.1：傾けるのをやめて、真っすぐ並べた）
                    button:
                        style "slot_button"
                        action slot_action(title, slot)
                        fixed:
                            key "save_delete" action FileDelete(slot)
                            if FileLoadable(slot):
                                add FileScreenshot(slot) pos (14, 14)
                            else:
                                ## 空きの枠は、うすい色の四角
                                add Solid("#f3eee3", xysize=(256, 144)) pos (14, 14)
                            $ _memo = FileJson(slot, "memo", missing="") or ""
                            text (FileTime(slot, format="%Y/%m/%d %H:%M", empty="空き") + ("　" + FileSaveName(slot) if FileSaveName(slot) else "")) style "slot_time"
                            if _memo:
                                text _memo style "slot_memo"
                            add "gui/grid/tape_slot.png" xalign 0.5 ypos -12

    text _hint style "file_hint" color _hcol

style file_hint:
    xpos 452
    ypos 60
    font FONT_JP_B
    size 18

## ページのボタン（オート・1〜3）。いま開いているページは黄色
style page_button:
    padding (22, 5, 22, 7)
    xminimum 60
    background "#ece6d6"
    hover_background "#f6e7a6"
    selected_background "#f2c230"

style page_button_text:
    xalign 0.5
    font FONT_JP_B
    size 19
    color INK_SOFT
    hover_color INK
    selected_color INK

style slot_button:
    xysize (284, 226)
    background Frame("gui/grid/card.png", 4, 4)
    hover_background Frame("gui/grid/card_hover.png", 4, 4)
    padding (0, 0, 0, 0)

style slot_time:
    xpos 14
    ypos 166
    size 14
    color INK_SOFT

style slot_memo:
    xpos 14
    ypos 188
    font FONT_JP_B
    size 18
    color PEN_RED


################################################################################
## 設定
################################################################################

## 方眼の紙（game_menu）の中に、タブ「画面と文字／音／ヒント」と、2列の白いカードを並べる（スクロールしない）
##   v0.31.1：項目ごとに白いカードで区切り、見出しはマスキングテープ。2択は選んだほうが黒く塗られる。音量や速さは紫の線とボールのつまみ
default persistent.pref_tab = "display"

define PREF_TABS = [("display", "画面と文字"), ("sound", "音"), ("hint", "ヒント"), ("data", "データ")]

init python:
    def pref_items(tab):
        """そのタブの項目：(見出し, 種類, 中身)。種類は bar（定規）・choice（2択）・button（1つだけのボタン）"""
        P = persistent
        if tab == "sound":
            return [
                ("BGMの音量", "bar", Preference("music volume"), "日常や試合で流れる曲の大きさ"),
                ("効果音の音量", "bar", Preference("sound volume"), "ボールを蹴る音・ホイッスル・トークの通知など"),
                ("ボイスの音量", "bar", Preference("voice volume"), "登場人物の声の大きさ"),
                ("次の文に進んだときのボイス", "choice", [("止める", Preference("voice sustain", "disable")), ("止めない", Preference("voice sustain", "enable"))], "声の途中でクリックしたとき、最後まで聞くかどうか"),
            ]
        if tab == "data":
            ## v0.31.1：すべてのデータを消して、最初からやり直す（確認の紙を2回出す）
            return [
                ("データの初期化", "button", ("すべて消して、最初からやり直す", Show("reset_confirm"), True), "押すと、確認が2回出ます"),
            ]
        if tab == "hint":
            return [
                ("何が上がるか（選択肢）", "choice", [("出さない", SetField(P, "choice_hints", False), not P.choice_hints), ("出す", SetField(P, "choice_hints", True), bool(P.choice_hints))], "能力・絆・気持ちのどれが上がるかを↑↓で出す"),
                ("試合の判定", "choice", [("出さない", SetField(P, "judge_hints", False), not P.judge_hints), ("出す", SetField(P, "judge_hints", True), bool(P.judge_hints))], "大事な場面で、使う能力と必要な数値を出す"),
                ("能力値・絆の変化を出す（テスト用）", "choice", [("出さない", SetField(P, "show_param_notify", False), not P.show_param_notify), ("出す", SetField(P, "show_param_notify", True), bool(P.show_param_notify))], "数値が動いたとき、画面のすみに小さく出す"),
                ## セーブの案内は1回目のプレイだけ出る。もう一度見たいときに押す
                ("セーブの案内", "button", ("最初の選択肢の前に、もう一度出す", [SetField(P, "save_guide_seen", False), Notify("次に最初の選択肢まで進むと、セーブの案内が出ます")], bool(P.save_guide_seen)), "1回目のプレイでだけ出る案内を、もう一度見る"),
            ]
        items = []
        ## ウィンドウ／全画面の切り替えは PC だけ（スマホでは出さない）
        if not renpy.variant("mobile"):
            items.append(("画面", "choice", [("ウィンドウ", Preference("display", "window")), ("全画面", Preference("display", "fullscreen"))], "F キーでも切り替えられます"))
        items += [
            ("スキップ", "choice", [("既読のみ", Preference("skip", "seen")), ("未読も含む", Preference("skip", "all"))], "スキップで飛ばすのを、一度読んだ文だけにするか"),
            ("文字の速さ", "bar", Preference("text speed"), "右ほど速い。いちばん右で、一度に全部出ます（下に見本）"),
            ("オートの速さ", "bar", Preference("auto-forward time"), "オートで、次の文へ進むまでの待ち時間"),
        ]
        return items

screen preferences():
    tag menu
    use game_menu("設定"):
        vbox:
            spacing 20
            hbox:
                spacing 10
                for _k, _l in PREF_TABS:
                    textbutton _l style "pref_tab" text_style "pref_tab_text" action SetField(persistent, "pref_tab", _k) selected (persistent.pref_tab == _k)

            ## 2列に並べる（左の列・右の列の順に、上から）
            $ _items = pref_items(persistent.pref_tab)
            hbox:
                spacing 26
                for _col in (_items[0::2], _items[1::2]):
                    vbox:
                        spacing 18
                        for _label, _kind, _arg, _desc in _col:
                            use pref_item(_label, _desc):
                                if _kind == "bar":
                                    bar value _arg style "pref_ruler"
                                elif _kind == "choice":
                                    use pref_choice(_arg)
                                else:
                                    textbutton _arg[0] action _arg[1] sensitive _arg[2] style "prefc_button" text_style "prefc_button_text"

            if persistent.pref_tab == "data":
                text "セーブ・回想で見た一枚絵・読んだ文（既読）・会った人・体験版のクリアの記録などを、すべて消します。元には戻せません。\n購入した内容と、音量や文字の速さなどの設定は残ります。" size 16 color INK_SOFT xsize 900

            if persistent.pref_tab == "hint":
                text "ヒントを出さないと、蓮になったつもりで選べます。出すと、ねらった結末に向かいやすくなります。" size 16 color INK_SOFT xsize 900

            ## v0.32.2：文字の速さの見本（数秒ごとに、いまの速さで打ち直す）
            if persistent.pref_tab == "display":
                use note_card("文字の速さの見本", 900):
                    use pref_text_sample()

## 項目1つ（白いカードに、紫のマスキングテープの見出し）。v0.32.2：下に1行の説明
screen pref_item(label, desc=""):
    fixed:
        xsize 437
        yfit True
        frame:
            style "pref_card"
            ypos 14
            vbox:
                spacing 8
                transclude
                if desc:
                    text desc style "pref_desc"
        frame:
            style "pref_tape"
            xpos 14
            text label style "pref_label"

## 白いカードに、マスキングテープの見出し（ステータスなど、文字の多い画面で使う。方眼の罫線が文字のうしろに出ないように）
screen note_card(label, w, col="#d9cdf2c0"):
    fixed:
        xsize w
        yfit True
        frame:
            style "pref_card"
            xsize w
            ypos 14
            vbox:
                xsize w - 44
                transclude
        frame:
            style "pref_tape"
            background col
            xpos 14
            text label style "pref_label"

## 2択（角の丸いボタン。選んだほうが黒く塗られる）。items: (名前, action) か (名前, action, 選ばれているか)
screen pref_choice(items):
    hbox:
        spacing 10
        for _it in items:
            if len(_it) > 2:
                textbutton _it[0] action _it[1] selected _it[2] style "prefc_button" text_style "prefc_button_text"
            else:
                textbutton _it[0] action _it[1] style "prefc_button" text_style "prefc_button_text"

style pref_tab:
    padding (26, 7, 26, 9)
    background "#ece6d6"
    hover_background "#e4dcf5"
    selected_background "#a58fd6"

style pref_tab_text:
    font FONT_JP_B
    size 19
    color INK_SOFT
    hover_color INK
    selected_color "#ffffff"
    selected_hover_color "#ffffff"

style pref_card:
    xsize 437
    background Frame("gui/grid/card.png", 4, 4)
    padding (22, 32, 22, 20)

style pref_tape:
    padding (16, 3, 16, 5)
    background "#d9cdf2c0"

style pref_label:
    font FONT_JP_B
    size 17
    color INK

style pref_desc:
    size 14
    color INK_SOFT
    xsize 393

## 文字の速さの見本。4秒ごとに文を入れ替えて、はじめから打ち直す
define PREF_SAMPLES = [
    "スパイクのひもを、きつく結び直した。グラウンドの向こうで、ホイッスルが鳴った。",
    "「……ほら、眉毛。また上がってる」ひなたが、笑いながら俺の顔をのぞきこんだ。",
]
screen pref_text_sample():
    default _n = 0
    timer 4.5 repeat True action SetScreenVariable("_n", _n + 1)
    text PREF_SAMPLES[_n % len(PREF_SAMPLES)] slow_cps True size 20 color INK xsize 856 min_width 856

style prefc_button:
    padding (20, 5, 20, 7)
    background Frame("gui/grid/seg.png", 8, 8)
    hover_background Frame("gui/grid/seg_hover.png", 8, 8)
    selected_background Frame("gui/grid/seg_sel.png", 8, 8)
    selected_hover_background Frame("gui/grid/seg_sel.png", 8, 8)
    insensitive_background Frame("gui/grid/seg.png", 8, 8)

style prefc_button_text:
    xalign 0.5
    font FONT_JP_B
    size 18
    color INK_SOFT
    hover_color INK
    selected_color "#ffffff"
    selected_hover_color "#ffffff"
    insensitive_color "#c8bba8"

style pref_ruler:
    xsize 393
    ysize 36
    left_bar Frame("gui/grid/bar_l.png", 4, 0)
    right_bar Frame("gui/grid/bar_r.png", 4, 0)
    thumb "gui/note/ball_thumb.png"
    thumb_offset 18


################################################################################
## ログ（バックログ）
################################################################################

define config.history_length = 250

screen history():
    tag menu
    predict False

    use game_menu("ログ", scroll="viewport", yinitial=1.0):
        style_prefix "history"

        for h in _history_list:
            vbox:
                spacing 0
                if h.who:
                    text h.who style "history_name"
                text h.what substitute False style "history_text"

        if not _history_list:
            text "ログはまだありません。"

style history_name:
    font FONT_JP_B
    size 19
    color PEN_RED

## ふりがな（ログ画面用）。使うスタイルより先に作っておく
style ruby_history:
    size 11
    yoffset -20
    color None

style history_text:
    size 22
    xsize 830
    ruby_line_leading 10
    ruby_style style.ruby_history


################################################################################
## 確認ダイアログ（大きな付箋）
################################################################################

screen confirm(message, yes_action, no_action):
    modal True
    zorder 200

    add Solid("#00000077")

    fixed:
        xysize (580, 300)
        xalign 0.5
        yalign 0.5
        add "gui/note_big.png"
        vbox:
            xalign 0.5
            yalign 0.5
            yoffset -6
            xsize 480
            spacing 30
            text message xalign 0.5 text_align 0.5 size 24
            hbox:
                xalign 0.5
                spacing 80
                textbutton "はい" action yes_action text_size 28
                textbutton "いいえ" action no_action text_size 28

    key "game_menu" action no_action

################################################################################
## データの初期化（設定の「データ」のタブから。v0.31.1）
##   うっかり押さないように、確認を2回出す。消すもの：セーブ（オートも）と persistent（回想・既読・会った人・クリアの記録など）
##   残すもの：購入の記録（persistent._iap_purchases）と設定（persistent._preferences）。persistent._clear は「_」で始まるものを消さない
################################################################################

init python:
    def reset_all_data():
        for _slot in renpy.list_saved_games(regexp=r".", fast=True):
            try:
                renpy.unlink_save(_slot)
            except Exception:
                pass
        persistent._clear(progress=True)
        _TitlePick.cur = None
        renpy.save_persistent()
        renpy.full_restart()

screen reset_confirm():
    modal True
    zorder 210
    default step = 1
    add Solid("#000000aa")
    frame:
        xysize (700, 380)
        xalign 0.5
        yalign 0.5
        background Frame("gui/grid/card.png", 4, 4)
        padding (50, 40, 50, 34)
        vbox:
            spacing 18
            if step == 1:
                text "すべてのデータを消しますか？" font FONT_JP_B size 28 color PEN_RED
                text "セーブ（オートセーブも）、回想で見た一枚絵、読んだ文（既読）、会った人、体験版のクリアの記録などが、すべて消えます。" size 19 color INK
                text "購入した内容と、音量や文字の速さなどの設定は残ります。" size 17 color INK_SOFT
                null height 6
                hbox:
                    xalign 0.5
                    spacing 40
                    textbutton "消す" action SetScreenVariable("step", 2) style "reset_button" text_style "reset_button_text"
                    textbutton "やめる" action Hide("reset_confirm") style "prefc_button" text_style "prefc_button_text"
            else:
                text "本当に消しますか？" font FONT_JP_B size 30 color PEN_RED
                text "消したデータは、元に戻せません。消したあとは、タイトル画面に戻ります。" size 19 color INK
                null height 40
                hbox:
                    xalign 0.5
                    spacing 40
                    textbutton "すべて消す" action Function(reset_all_data) style "reset_button" text_style "reset_button_text"
                    textbutton "やめる" action Hide("reset_confirm") style "prefc_button" text_style "prefc_button_text"
    key "game_menu" action Hide("reset_confirm")

style reset_button:
    padding (26, 6, 26, 8)
    background PEN_RED
    hover_background "#b33838"

style reset_button_text:
    font FONT_JP_B
    size 20
    color "#ffffff"
    hover_color "#ffffff"

################################################################################
## セーブの案内（最初の選択肢の前に1回だけ出す。大きな付箋）
################################################################################

screen save_prompt():
    modal True
    zorder 200

    add Solid("#00000077")

    fixed:
        xysize (580, 300)
        xalign 0.5
        yalign 0.5
        add "gui/note_big.png"
        vbox:
            xalign 0.5
            yalign 0.5
            yoffset -6
            xsize 480
            spacing 26
            text "ここでセーブしておこう" xalign 0.5 font FONT_JP_B size 30 color INK
            text "あとで、ここから別の答えを試せます" xalign 0.5 size 20 color INK_SOFT
            hbox:
                xalign 0.5
                spacing 60
                textbutton "セーブする" action ShowMenu("save") text_size 28 text_color PEN_RED text_hover_color INK
                textbutton "つづける" action Return() text_size 28

    key "game_menu" action ShowMenu("save")

init python:
    layout.ARE_YOU_SURE = "よろしいですか？"
    layout.DELETE_SAVE = "このセーブデータを削除しますか？"
    layout.OVERWRITE_SAVE = "上書きしますか？"
    layout.LOADING = "ロードすると、保存していない進み具合は失われます。よろしいですか？"
    layout.QUIT = "ゲームを終了しますか？"
    layout.MAIN_MENU = "タイトル画面に戻りますか？保存していない進み具合は失われます。"
    layout.END_REPLAY = "回想を終了しますか？"
    layout.SLOW_SKIP = "スキップを始めますか？"
    layout.FAST_SKIP_SEEN = "次の選択肢まで既読をスキップしますか？"
    layout.FAST_SKIP_UNSEEN = "次の選択肢までスキップしますか？"


################################################################################
## 通知・スキップ中の表示（小さな付箋）
################################################################################

screen notify(message):
    zorder 150
    frame at fade_in_out:
        xalign 0.5
        ypos 12
        text "[message!tq]" size 20
    timer 3.0 action Hide("notify")

screen skip_indicator():
    zorder 100
    frame:
        xpos 14
        yalign 0.66
        text "スキップ中 ▶▶" size 20 color PEN_RED

transform fade_in_out:
    on show:
        alpha 0.0
        linear 0.25 alpha 1.0
    on hide:
        linear 0.4 alpha 0.0
