## images.rpy ―― 画像の定義（立ち絵・背景・スチルはすべて ChatGPT で作成済み。同じファイル名で上書きすれば差し替わる）

## 背景（1280×720、JPG）。ChatGPT で作成済み
image bg clubroom = "images/bg/clubroom.jpg"
image bg clubroom_rain = "images/bg/clubroom_rain.jpg"     # 部室・梅雨の雨の日（第2章のアルバム）
image bg game_center = "images/bg/game_center.jpg"
image bg harbor_sunset = "images/bg/harbor_sunset.jpg"
image bg hospital_lobby_night = "images/bg/hospital_lobby_night.jpg"
image bg judo_hall = "images/bg/judo_hall.jpg"
image bg kohoku_gate_morning = "images/bg/kohoku_gate_morning.jpg"
image bg kohoku_gate_rain = "images/bg/kohoku_gate_rain.jpg"     # 同じ校門の、雨の朝（5/31の集合）
image bg bus_rain = "images/bg/bus_rain.jpg"                     # 古いマイクロバスの車内・雨
image bg ouryo_gate_rain = "images/bg/ouryo_gate_rain.jpg"       # 桜嶺学園の正門・雨
image bg kohoku_ground_eve = "images/bg/kohoku_ground_eve.jpg"
image bg kohoku_ground_night = "images/bg/kohoku_ground_night.jpg"   # 港北のグラウンド・夏の夜（照明が1つだけ）
image bg map = "images/bg/map.jpg"
image bg map_school = "images/bg/map_school.jpg"     # 学校のまわりを大きくした地図（行き先が学校の中だけのとき）
image bg ouryo_ground_rain = "images/bg/ouryo_ground_rain.jpg"
image bg ouryo_side_rain = "images/bg/ouryo_side_rain.jpg"
image bg ren_room_night = "images/bg/ren_room_night.jpg"
image bg rooftop = "images/bg/rooftop.jpg"
image bg shokudo_day = "images/bg/shokudo_day.jpg"
image bg shokudo_night = "images/bg/shokudo_night.jpg"
image bg stadium_winter_eve = "images/bg/stadium_winter_eve.jpg"
image bg staffroom = "images/bg/staffroom.jpg"
image bg slope_eve = "images/bg/slope_eve.jpg"
image bg student_council = "images/bg/student_council.jpg"

## 第2章「泥だらけの夏」の背景
image bg pref_ground_day = "images/bg/pref_ground_day.jpg"         # 県営グラウンド（土）・夏の晴れ（インターハイ予選）
image bg pref_ground_eve = "images/bg/pref_ground_eve.jpg"         # 県営グラウンド・夕方（PK戦のあと）
image bg pk_away_eve = "images/bg/pk_away_eve.jpg"                 # PK戦：港北のゴールを正面から（夕方・相手が蹴る）
image bg pk_home_eve = "images/bg/pk_home_eve.jpg"                 # PK戦：相手のゴールを正面から（夕方・港北が蹴る）
image bg gym_day = "images/bg/gym_day.jpg"                         # 港北の体育館・昼（夏合宿）
image bg gym_night = "images/bg/gym_night.jpg"                     # 港北の体育館・夜（電気を消して、月明かりだけ）
image bg train_eve = "images/bg/train_eve.jpg"                     # 満員の電車の中・夕方（乗客は影のシルエット）
image bg kohoku_station_eve = "images/bg/kohoku_station_eve.jpg"   # 港北駅のホーム・夕方（海の向こうに潮見港のクレーン）
image bg shiomi_station_eve = "images/bg/shiomi_station_eve.jpg"   # 潮見港駅（花火大会の会場の駅）・夕方
image bg festival_night = "images/bg/festival_night.jpg"           # 夏祭りの夜店通り・夜
## 第3章
image bg harbor_winter_eve = "images/bg/harbor_winter_eve.jpg"       # 港の防波堤・12月の夕方
image bg harbor_newyear_night = "images/bg/harbor_newyear_night.jpg" # 港の防波堤・大晦日の夜（街灯が一本）
image bg station_xmas_night = "images/bg/station_xmas_night.jpg"     # 駅前のツリーの広場・クリスマスの夜
image bg recital_hall = "images/bg/recital_hall.jpg"                 # 潮見市民ホール（ピアノの発表会）
image bg stadium_gate_eve = "images/bg/stadium_gate_eve.jpg"         # 競技場の選手の出入り口（準決勝のあと）
image bg bus_team_morning = "images/bg/bus_team_morning.jpg"    # 第3章：桜嶺戦の朝、試合に向かうバスの中
image bg locker_room = "images/bg/locker_room.jpg"    # 第3章：競技場のロッカールーム

## イベント絵・スチル（1280×720、JPG）。ChatGPT で作成済み
image cg miyoshi_rain = "images/cg/miyoshi_rain.jpg"
image cg ren_down = "images/cg/ren_down.jpg"
image cg saki_meet = "images/cg/saki_meet.jpg"
image cg bus_hinata = "images/cg/bus_hinata.jpg"     # 5/31の朝、バスで蓮の肩にもたれて眠るひなた

## プロローグ冒頭（県大会決勝）の一枚絵
image cg op_breath = "images/cg/op_breath.jpg"          # 白い息を吐く蓮の横顔
image cg op_clear = "images/cg/op_clear.jpg"            # 夕空に高く跳ねたボール
image cg op_trap = "images/cg/op_trap.jpg"              # 胸でボールを受ける蓮
image cg op_open = "images/cg/op_open.jpg"              # 前を向いた蓮の視界（ゴールまで30m）
image cg op_kamishiro = "images/cg/op_kamishiro.jpg"    # 左から迫る神城
image cg op_cutback = "images/cg/op_cutback.jpg"        # 右足アウトの切り返し

## 第1章 5/31 練習試合（対 桜嶺学園B）の一枚絵
image cg m531_warmup = "images/cg/m531_warmup.jpg"          # 雨の天然芝。アップする桜嶺Bと、立ち尽くす港北
image cg m531_kamishiro = "images/cg/m531_kamishiro.jpg"    # スタンドの屋根の下の神城
image cg m531_huddle = "images/cg/m531_huddle.jpg"          # キックオフ前の円陣
image cg m531_tackle = "images/cg/m531_tackle.jpg"          # スライディングでボールを刈り取られる蓮
image cg m531_keeper = "images/cg/m531_keeper.jpg"          # 大門の手が届かず、ネットが揺れる
image cg m531_final = "images/cg/m531_final.jpg"            # 試合終了。雨の空を見上げる蓮
image cg m531_surrounded = "images/cg/m531_surrounded.jpg"  # 二人に囲まれる蓮
image cg practice_chaos = "images/cg/practice_chaos.jpg"  # 5/20、11人がそろった初めての練習（みんなバラバラ）

## 第2章の一枚絵
image cg kuroda_kick = "images/cg/kuroda_kick.jpg"    # 第2章：サンダルのまま、助走なしで蹴る黒田（夕方）
image cg gym_futons = "images/cg/gym_futons.jpg"    # 第2章：合宿の夜、11枚の布団が並ぶ体育館
image cg gym_miyoshi = "images/cg/gym_miyoshi.jpg"    # 第2章：合宿の夜、布団で照れながら話す三好
image cg gym_takano = "images/cg/gym_takano.jpg"    # 第2章：合宿の夜、腕で目を隠す鷹野
image cg item_knee_night = "images/cg/item_knee_night.jpg"    # 小物：夜、右ひざに手を当てる蓮
image cg gym_door_light = "images/cg/gym_door_light.jpg"    # 第2章：体育館の扉のすき間の光と、誰かの影
image cg daimon_pk = "images/cg/daimon_pk.jpg"      # PK戦の最後の一本を、横っ飛びで止める大門（夕方）
image cg album_photos = "images/cg/album_photos.jpg"  # 雨の部室。机に広がる試合の写真と、古いアルバム
image cg train_saki = "images/cg/train_saki.jpg"    # 満員電車で背中合わせの蓮と紗希
image cg fw_hinata = "images/cg/fw_hinata.jpg"      # 花火とひなた（浴衣で振り返る）
image cg fw_chika = "images/cg/fw_chika.jpg"        # 花火と千夏（浴衣で、こちらにカメラを構える）
image cg fw_boys = "images/cg/fw_boys.jpg"          # 花火を見上げる蓮・鷹野・大門
image cg fw_saki = "images/cg/fw_saki.jpg"          # 堤防の先で、花火ではなく海を見ている紗希（遠景）
## 第3章
image cg ch3_kamishiro_face = "images/cg/ch3_kamishiro_face.jpg"  # 準決勝のコーナーキック。肩を並べて、ボールを見たまま話す神城
image cg ch3_armband = "images/cg/ch3_armband.jpg"                # 部室。三好先輩から黄色いキャプテンマークを受け取る
image cg ch3_newyear = "images/cg/ch3_newyear.jpg"                # 大晦日の夜の防波堤。街灯の下に一人で立つ蓮の背中
image cg practice_rope = "images/cg/practice_rope.jpg"    # 第3章：ロープでつながれた4人の守備練習と黒田
image cg item_spikes = "images/cg/item_spikes.jpg"    # 小物：机の上の新しいスパイクと、中学のスパイク
image cg ch3_entrance = "images/cg/ch3_entrance.jpg"    # 第3章：入場の通路で、神城と並ぶ（蓮の背番号10）
image cg ch3_entrance8 = "images/cg/ch3_entrance8.jpg"    # 同じ絵で、蓮の背番号8（10番を鷹野に渡したとき）

## 立ち絵（横700×縦720、背景は透過）。ファイル名は「キャラ_表情.png」。身長差に合わせて大きさと位置をそろえてある
image chika narrow = "images/chara/chika_narrow.png"
image chika normal = "images/chara/chika_normal.png"
image chika yukata = "images/chara/chika_yukata.png"        # 第2章：浴衣（カメラをさげる）
image chika soft = "images/chara/chika_soft.png"
image chika window = "images/chara/chika_window.png"
image daimon normal = "images/chara/daimon_normal.png"
image daimon jinbei = "images/chara/daimon_jinbei.png"      # 第2章：甚平（射的の空の皿）
image daimon worried = "images/chara/daimon_worried.png"
image daimon jersey = "images/chara/daimon_jersey.png"      # 練習用ジャージ
image daimon match = "images/chara/daimon_match.png"        # キーパーの試合用ユニフォーム（緑）
image daimon uniform = "images/chara/daimon_uniform.png"        # 制服（入部後の学校の場面）
image daimon uniform_worried = "images/chara/daimon_uniformw.png"   # 制服・困った顔
image hinata breath = "images/chara/hinata_breath.png"
image hinata forcesmile = "images/chara/hinata_forcesmile.png"
image hinata normal = "images/chara/hinata_normal.png"
image hinata pout = "images/chara/hinata_pout.png"
image hinata proud = "images/chara/hinata_proud.png"
image hinata serious = "images/chara/hinata_serious.png"
image hinata smile = "images/chara/hinata_smile.png"
image hinata stare = "images/chara/hinata_stare.png"
image hinata teary = "images/chara/hinata_teary.png"
image hinata yukata = "images/chara/hinata_yukata.png"      # 第2章：浴衣（はにかむ）
image hinata apron = "images/chara/hinata_apron.png"          # はやせ食堂を手伝うときのエプロン姿
image kuroda normal = "images/chara/kuroda_normal.png"
image kuroda peek = "images/chara/kuroda_peek.png"
image kuroda umbrella = "images/chara/kuroda_umbrella.png"
image kuroda yawn = "images/chara/kuroda_yawn.png"
image kuroda board = "images/chara/kuroda_board.png"        # 第2章：作戦ボードを抱える
image miyoshi smile = "images/chara/miyoshi_smile.png"
image miyoshi match = "images/chara/miyoshi_match.png"      # 試合用ユニフォーム（キャプテンマーク）
image miyoshi uniform = "images/chara/miyoshi_uniform.png"    # 制服（ジャージ以外の場面）
image mother down = "images/chara/mother_down.png"
image mother normal = "images/chara/mother_normal.png"
image mother sadsmile = "images/chara/mother_sadsmile.png"
image mother serious = "images/chara/mother_serious.png"
image mother smile = "images/chara/mother_smile.png"
image sakaguchi normal = "images/chara/sakaguchi_normal.png"
image sakaguchi jersey = "images/chara/sakaguchi_jersey.png"      # 練習用ジャージ
image sakaguchi match = "images/chara/sakaguchi_match.png"      # 試合用ユニフォーム
image saki frown = "images/chara/saki_frown.png"
image saki normal = "images/chara/saki_normal.png"
image saki casual = "images/chara/saki_casual.png"          # 第2章：私服（発表会帰りのワンピース・顔をそむける）
image takano lying = "images/chara/takano_lying.png"
image takano narrow = "images/chara/takano_narrow.png"
image takano normal = "images/chara/takano_normal.png"
image takano surprised = "images/chara/takano_surprised.png"
image takano jersey = "images/chara/takano_jersey.png"      # 練習用ジャージ
image takano jersey_narrow = "images/chara/takano_jersey_narrow.png"
image takano jersey_surprised = "images/chara/takano_jersey_surprised.png"
image takano match = "images/chara/takano_match.png"      # 試合用ユニフォーム
image takano casual = "images/chara/takano_casual.png"      # 第2章：私服
image kamishiro normal = "images/chara/kamishiro_normal.png"     # 第3章：桜嶺のジャージ
image kamishiro pained = "images/chara/kamishiro_pained.png"     # 第3章：言いたいことが言えない顔
image onizuka normal = "images/chara/onizuka_normal.png"         # 第3章：桜嶺の監督。黒いロングコートで腕を組む
