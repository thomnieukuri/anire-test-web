## images.rpy ―― 画像の定義（立ち絵・背景・スチルはすべて ChatGPT で作成済み。同じファイル名で上書きすれば差し替わる）

## 背景（1280×720、JPG）。ChatGPT で作成済み
image bg clubroom = "images/bg/clubroom.jpg"
image bg game_center = "images/bg/game_center.jpg"
image bg harbor_sunset = "images/bg/harbor_sunset.jpg"
image bg hospital_lobby_night = "images/bg/hospital_lobby_night.jpg"
image bg judo_hall = "images/bg/judo_hall.jpg"
image bg kohoku_gate_morning = "images/bg/kohoku_gate_morning.jpg"
image bg kohoku_gate_rain = "images/bg/kohoku_gate_rain.jpg"     # 同じ校門の、雨の朝（5/31の集合）
image bg bus_rain = "images/bg/bus_rain.jpg"                     # 古いマイクロバスの車内・雨
image bg ouryo_gate_rain = "images/bg/ouryo_gate_rain.jpg"       # 桜嶺学園の正門・雨
image bg kohoku_ground_eve = "images/bg/kohoku_ground_eve.jpg"
image bg map = "images/bg/map.jpg"
image bg map_school = "images/bg/map_school.jpg"     # 学校のまわりを大きくした地図（行き先が学校の中だけのとき）
image bg ouryo_ground_rain = "images/bg/ouryo_ground_rain.jpg"
image bg ouryo_side_rain = "images/bg/ouryo_side_rain.jpg"
image bg ren_room_night = "images/bg/ren_room_night.jpg"
image bg rooftop = "images/bg/rooftop.jpg"
image bg shokudo_day = "images/bg/shokudo_day.jpg"
image bg shokudo_night = "images/bg/shokudo_night.jpg"
image bg stadium_winter_eve = "images/bg/stadium_winter_eve.jpg"
image bg staffroom = "images/bg/staffroom.jpg"
image bg slope_eve = "images/bg/slope_eve.jpg"
image bg student_council = "images/bg/student_council.jpg"

## イベント絵・スチル（1280×720、JPG）。ChatGPT で作成済み
image cg miyoshi_rain = "images/cg/miyoshi_rain.jpg"
image cg ren_down = "images/cg/ren_down.jpg"
image cg saki_meet = "images/cg/saki_meet.jpg"
image cg bus_hinata = "images/cg/bus_hinata.jpg"     # 5/31の朝、バスで蓮の肩にもたれて眠るひなた

## プロローグ冒頭（県大会決勝）の一枚絵
image cg op_breath = "images/cg/op_breath.jpg"          # 白い息を吐く蓮の横顔
image cg op_clear = "images/cg/op_clear.jpg"            # 夕空に高く跳ねたボール
image cg op_trap = "images/cg/op_trap.jpg"              # 胸でボールを受ける蓮
image cg op_open = "images/cg/op_open.jpg"              # 前を向いた蓮の視界（ゴールまで30m）
image cg op_kamishiro = "images/cg/op_kamishiro.jpg"    # 左から迫る神城
image cg op_cutback = "images/cg/op_cutback.jpg"        # 右足アウトの切り返し

## 第1章 5/31 練習試合（対 桜嶺学園B）の一枚絵
image cg m531_warmup = "images/cg/m531_warmup.jpg"          # 雨の天然芝。アップする桜嶺Bと、立ち尽くす港北
image cg m531_kamishiro = "images/cg/m531_kamishiro.jpg"    # スタンドの屋根の下の神城
image cg m531_huddle = "images/cg/m531_huddle.jpg"          # キックオフ前の円陣
image cg m531_tackle = "images/cg/m531_tackle.jpg"          # スライディングでボールを刈り取られる蓮
image cg m531_keeper = "images/cg/m531_keeper.jpg"          # 大門の手が届かず、ネットが揺れる
image cg m531_final = "images/cg/m531_final.jpg"            # 試合終了。雨の空を見上げる蓮
image cg m531_surrounded = "images/cg/m531_surrounded.jpg"  # 二人に囲まれる蓮

## 立ち絵（横700×縦720、背景は透過）。ファイル名は「キャラ_表情.png」。身長差に合わせて大きさと位置をそろえてある
image chika narrow = "images/chara/chika_narrow.png"
image chika normal = "images/chara/chika_normal.png"
image chika soft = "images/chara/chika_soft.png"
image chika window = "images/chara/chika_window.png"
image daimon normal = "images/chara/daimon_normal.png"
image daimon worried = "images/chara/daimon_worried.png"
image hinata breath = "images/chara/hinata_breath.png"
image hinata forcesmile = "images/chara/hinata_forcesmile.png"
image hinata normal = "images/chara/hinata_normal.png"
image hinata pout = "images/chara/hinata_pout.png"
image hinata proud = "images/chara/hinata_proud.png"
image hinata serious = "images/chara/hinata_serious.png"
image hinata smile = "images/chara/hinata_smile.png"
image hinata stare = "images/chara/hinata_stare.png"
image hinata teary = "images/chara/hinata_teary.png"
image kuroda normal = "images/chara/kuroda_normal.png"
image kuroda peek = "images/chara/kuroda_peek.png"
image kuroda umbrella = "images/chara/kuroda_umbrella.png"
image kuroda yawn = "images/chara/kuroda_yawn.png"
image miyoshi smile = "images/chara/miyoshi_smile.png"
image mother down = "images/chara/mother_down.png"
image mother normal = "images/chara/mother_normal.png"
image mother sadsmile = "images/chara/mother_sadsmile.png"
image mother serious = "images/chara/mother_serious.png"
image mother smile = "images/chara/mother_smile.png"
image sakaguchi normal = "images/chara/sakaguchi_normal.png"
image saki frown = "images/chara/saki_frown.png"
image saki normal = "images/chara/saki_normal.png"
image takano lying = "images/chara/takano_lying.png"
image takano narrow = "images/chara/takano_narrow.png"
image takano normal = "images/chara/takano_normal.png"
image takano surprised = "images/chara/takano_surprised.png"
