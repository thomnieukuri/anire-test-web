## images.rpy ―― 画像の定義（立ち絵・背景・スチルはすべて ChatGPT で作成済み。同じファイル名で上書きすれば差し替わる）

## 季節の服の切りかえ（v0.21.0）
##   set_cal の月で outfit が決まる：6〜9月は "summer"（夏服）、それ以外は "winter"（ブレザー）。
##   12〜2月の外の場面では、その場面の set_cal のあとで $ coat_on() と書くと "coat"（コート・マフラー）になる。
##   images/chara/summer/〜.png、winter/〜.png、coat/〜.png があればそれを、なければいつもの絵を出す。
default outfit = "winter"

init -1 python:
    def outfit_img(file):
        alts = []
        for kind in ("summer", "coat", "winter"):
            path = "images/chara/%s/%s.png" % (kind, file)
            if renpy.loadable(path):
                cond = "store.outfit == %r" % kind
                if kind == "winter":
                    cond = "store.outfit in ('winter', 'coat')"
                alts += [cond, path]
        ## コートの絵がないときは、冬の絵（なければいつもの絵）にする
        return ConditionSwitch(*(alts + ["True", "images/chara/%s.png" % file]))

## 背景（1280×720、JPG）。ChatGPT で作成済み
image bg clubroom = "images/bg/clubroom.jpg"
image bg clubroom_rain = "images/bg/clubroom_rain.jpg"     # 部室・梅雨の雨の日（第2章のアルバム）
image bg game_center = "images/bg/game_center.jpg"
image bg harbor_sunset = "images/bg/harbor_sunset.jpg"
image bg hospital_lobby_night = "images/bg/hospital_lobby_night.jpg"
image bg judo_hall = "images/bg/judo_hall.jpg"
image bg kohoku_gate_morning = "images/bg/kohoku_gate_morning.jpg"
image bg kohoku_gate_march = "images/bg/kohoku_gate_march.jpg"      # 3月の港北高校の昇降口前（合格発表の掲示板・桜はつぼみ）
image bg kohoku_gate_rain = "images/bg/kohoku_gate_rain.jpg"     # 同じ校門の、雨の朝（5/31の集合）
image bg bus_rain = "images/bg/bus_rain.jpg"                     # 古いマイクロバスの車内・雨
image bg ouryo_gate_rain = "images/bg/ouryo_gate_rain.jpg"       # 桜嶺学園の正門・雨
image bg kohoku_ground_eve = "images/bg/kohoku_ground_eve.jpg"
image bg kohoku_ground_night = "images/bg/kohoku_ground_night.jpg"   # 港北のグラウンド・夏の夜（照明が1つだけ）
image bg map = "images/bg/map.jpg"
image bg map_school = "images/bg/map_school.jpg"     # 学校のまわりを大きくした地図（行き先が学校の中だけのとき）
image bg ouryo_ground_rain = "images/bg/ouryo_ground_rain.jpg"
image bg ouryo_side_rain = "images/bg/ouryo_side_rain.jpg"
image bg ren_room_night = "images/bg/ren_room_night.jpg"
image bg rooftop = "images/bg/rooftop.jpg"
image bg shokudo_day = "images/bg/shokudo_day.jpg"
image bg shokudo_night = "images/bg/shokudo_night.jpg"
image bg stadium_winter_eve = "images/bg/stadium_winter_eve.jpg"
image bg stadium_semi_eve = "images/bg/stadium_semi_eve.jpg"    # 準決勝の試合中：観客で埋まったスタンド（左が白と金の桜嶺、右はしに青の港北）
image bg staffroom = "images/bg/staffroom.jpg"
image bg slope_eve = "images/bg/slope_eve.jpg"
image bg student_council = "images/bg/student_council.jpg"

## 第2章「泥だらけの夏」の背景
image bg pref_ground_day = "images/bg/pref_ground_day.jpg"         # 県営グラウンド（土）・夏の晴れ（インターハイ予選）
image bg pref_ground_eve = "images/bg/pref_ground_eve.jpg"         # 県営グラウンド・夕方（PK戦のあと）
image bg pk_away_eve = "images/bg/pk_away_eve.jpg"                 # PK戦：港北のゴールを正面から（夕方・相手が蹴る）
image bg pk_home_eve = "images/bg/pk_home_eve.jpg"                 # PK戦：相手のゴールを正面から（夕方・港北が蹴る）
image bg gym_day = "images/bg/gym_day.jpg"                         # 港北の体育館・昼（夏合宿）
image bg gym_night = "images/bg/gym_night.jpg"                     # 港北の体育館・夜（合宿。電気を消して、布団に寝ころんだ高さから。月明かりだけ）
image bg train_eve = "images/bg/train_eve.jpg"                     # 満員の電車の中・夕方（乗客は影のシルエット）
image bg kohoku_station_eve = "images/bg/kohoku_station_eve.jpg"   # 港北駅のホーム・夕方（海の向こうに潮見港のクレーン）
image bg shiomi_station_eve = "images/bg/shiomi_station_eve.jpg"   # 潮見港駅（花火大会の会場の駅）・夕方
image bg festival_night = "images/bg/festival_night.jpg"           # 夏祭りの夜店通り・夜
## 第3章
image bg harbor_winter_eve = "images/bg/harbor_winter_eve.jpg"       # 港の防波堤・12月の夕方
image bg harbor_newyear_night = "images/bg/harbor_newyear_night.jpg" # 港の防波堤・大晦日の夜（街灯が一本）
image bg station_xmas_night = "images/bg/station_xmas_night.jpg"     # 駅前のツリーの広場・クリスマスの夜
image bg recital_hall = "images/bg/recital_hall.jpg"                 # 潮見市民ホール（ピアノの発表会）
image bg stadium_gate_eve = "images/bg/stadium_gate_eve.jpg"         # 競技場の通路・夕方（準決勝のあと。朝の stadium_gate_morning と同じ場所）
image bg bus_team_morning = "images/bg/bus_team_morning.jpg"    # 第3章：桜嶺戦の朝、試合に向かうバスの中
image bg locker_room = "images/bg/locker_room.jpg"    # 第3章：競技場のロッカールーム

## 第3章で使う新しい背景（v0.21.0）。絵はまだないので、いまは似た絵を「仮」に指している
##   絵ができたら、右のファイル名の絵を作って、左の行の "images/bg/…" をそのファイルに変える
image bg pref_ground_autumn = "images/bg/pref_ground_autumn.jpg"    # 県営グラウンド・10月（3回戦）
image bg kohoku_gate_winter = "images/bg/kohoku_gate_winter.jpg"    # 12月の校門・夕方（終業式）
image bg kohoku_gate_summer = "images/bg/kohoku_gate_summer.jpg"    # 6〜9月の校門・朝（青葉）
image bg kohoku_gate_autumn = "images/bg/kohoku_gate_autumn.jpg"        # 秋〜冬の校門・朝（桜なし）。今の絵は桜が満開なので、早めに作る
image bg ren_room_morning = "images/bg/ren_room_morning.jpg"               # 蓮の部屋・朝（窓の外が明るく、スタンドは消えている）
image bg clubroom_night_rain = "images/bg/clubroom_night_rain.jpg"             # 夜・雨の部室（12/24 の男だけのクリスマス会）
image bg student_council_night = "images/bg/student_council_night.jpg"         # 夜の生徒会室（電気ストーブ）
image bg rooftop_winter = "images/bg/rooftop_winter.jpg"                        # 冬の屋上（11月以降）
image bg shotengai_eve = "images/bg/shotengai_eve.jpg"                       # 港北の商店街・夕方（年末の人ごみ）
image bg kohoku_station_gate_eve = "images/bg/kohoku_station_gate_eve.jpg"    # 港北駅の改札前・夕方（雪がちらつく）
image bg stadium_gate_morning = "images/bg/stadium_gate_morning.jpg"         # 競技場の入口・朝（準決勝の朝）
image bg stadium_stand_day = "images/bg/stadium_stand_day.jpg"          # 満員のスタンド・昼（半分が白と金の桜嶺の応援）
image bg pref_stand_day = "images/bg/pref_stand_day.jpg"                # 県の会場のスタンドの上から、ピッチを見下ろす（準々決勝の紗希）
image bg breakwater_night = "images/bg/breakwater_night.jpg"         # 夜の防波堤（第2章の花火の夜、堤防の端の会話）

## イベント絵・スチル（1280×720、JPG）。ChatGPT で作成済み
image cg miyoshi_rain = "images/cg/miyoshi_rain.jpg"
image cg ren_down = "images/cg/ren_down.jpg"
image cg saki_meet = "images/cg/saki_meet.jpg"
image cg bus_hinata = "images/cg/bus_hinata.jpg"     # 5/31の朝、バスで蓮の肩にもたれて眠るひなた

## プロローグ冒頭（県大会決勝）の一枚絵
image cg op_breath = "images/cg/op_breath.jpg"          # 白い息を吐く蓮の横顔
image cg op_clear = "images/cg/op_clear.jpg"            # 夕空に高く跳ねたボール
image cg op_trap = "images/cg/op_trap.jpg"              # 胸でボールを受ける蓮
image cg op_open = "images/cg/op_open.jpg"              # 前を向いた蓮の視界（ゴールまで30m）
image cg op_kamishiro = "images/cg/op_kamishiro.jpg"    # 左から迫る神城
image cg op_cutback = "images/cg/op_cutback.jpg"        # 右足アウトの切り返し

## 第1章 5/31 練習試合（対 桜嶺学園B）の一枚絵
image cg m531_warmup = "images/cg/m531_warmup.jpg"          # 雨の天然芝。アップする桜嶺Bと、立ち尽くす港北
image cg m531_kamishiro = "images/cg/m531_kamishiro.jpg"    # スタンドの屋根の下の神城
image cg m531_huddle = "images/cg/m531_huddle.jpg"          # キックオフ前の円陣
image cg m531_tackle = "images/cg/m531_tackle.jpg"          # スライディングでボールを刈り取られる蓮
image cg m531_keeper = "images/cg/m531_keeper.jpg"          # 大門の手が届かず、ネットが揺れる
image cg m531_final = "images/cg/m531_final.jpg"            # 試合終了。雨の空を見上げる蓮
image cg m531_surrounded = "images/cg/m531_surrounded.jpg"  # 二人に囲まれる蓮
image cg practice_chaos = "images/cg/practice_chaos.jpg"  # 5/20、11人がそろった初めての練習（みんなバラバラ）

## 第2章の一枚絵
image cg kuroda_kick = "images/cg/kuroda_kick.jpg"    # 第2章：サンダルのまま、助走なしで蹴る黒田（夕方）
image cg kuroda_kick_goal = "images/cg/kuroda_kick_goal.jpg"    # 第2章：ゴールの右上に突き刺さったボールを、立たされた蓮と鷹野がふり返って見上げる（手前に口を開けた坂口）
image cg gym_futons = "images/cg/gym_futons.jpg"    # 第2章：合宿の夜、銭湯から戻ると11枚の布団が並んでいる体育館（人はいない）
image cg gym_miyoshi = "images/cg/gym_miyoshi.jpg"    # 第2章：合宿の夜、布団で照れながら話す三好
image cg gym_takano = "images/cg/gym_takano.jpg"    # 第2章：合宿の夜、腕で目を隠す鷹野
image cg item_knee_night = "images/cg/item_knee_night.jpg"    # 小物：夜、右ひざに手を当てる蓮
image cg gym_door_light = "images/cg/gym_door_light.jpg"    # 第2章：体育館の扉のすき間の光と、誰かの影
image cg daimon_pk = "images/cg/daimon_pk.jpg"      # PK戦の最後の一本を、横っ飛びで止める大門（夕方）
image cg album_photos = "images/cg/album_photos.jpg"  # 雨の部室。机に広がる試合の写真と、古いアルバム
image cg train_saki = "images/cg/train_saki.jpg"    # 満員電車で背中合わせの蓮と紗希
image cg saki_window = "images/cg/saki_window.jpg"    # 7/8 雨上がりの夕方、防波堤の近くの家の窓。カーテンのすき間に紗希の髪とピアノ
image cg chika_video = "images/cg/chika_video.jpg"    # 6/1の夜、ビデオ通話に気づかずに文を打つ風呂上がりの千夏（蓮のスマホの画面）
image cg miyoshi_lying = "images/cg/miyoshi_lying.jpg"    # 準決勝のあと、センターサークルで仰向けに倒れて泣き笑いする三好
image cg saki_recital = "images/cg/saki_recital.jpg"    # 12/24、市民ホールのステージで白いドレスの紗希がピアノに向かう
image cg chika_video_eyes = "images/cg/chika_video_eyes.jpg"    # 同じ画面で、千夏が顔を上げて目が合った瞬間
image cg chika_video_fall = "images/cg/chika_video_fall.jpg"    # 「カメラ、ついてます」のあと、タブレットが倒れて天井の照明が映る
image cg fw_hinata = "images/cg/fw_hinata.jpg"      # 花火とひなた（浴衣で振り返る）
image cg fw_chika = "images/cg/fw_chika.jpg"        # 花火と千夏（浴衣で、こちらにカメラを構える）
image cg fw_boys = "images/cg/fw_boys.jpg"          # 花火を見上げる蓮・鷹野・大門
image cg fw_saki = "images/cg/fw_saki.jpg"          # 堤防の先で、花火ではなく海を見ている紗希（遠景）
## 第3章
image cg ch3_kamishiro_face = "images/cg/ch3_kamishiro_face.jpg"  # 準決勝のコーナーキック。肩を並べて、ボールを見たまま話す神城
image cg ch3_armband = "images/cg/ch3_armband.jpg"                # 部室。三好先輩から黄色いキャプテンマークを受け取る
image cg ch3_newyear = "images/cg/ch3_newyear.jpg"                # 大晦日の夜の防波堤。街灯の下に一人で立つ蓮の背中
image cg practice_rope = "images/cg/practice_rope.jpg"    # 第3章：ロープでつながれた4人の守備練習と黒田（いちばん前で引っぱるのが三好）
image cg item_spikes = "images/cg/item_spikes.jpg"    # 小物：机の上の新しいスパイクと、中学のスパイク
image cg ch3_entrance = "images/cg/ch3_entrance.jpg"    # 第3章：入場の通路で、神城と並ぶ（蓮の背番号10）
image cg ch3_entrance8 = "images/cg/ch3_entrance8.jpg"    # 同じ絵で、蓮の背番号8（10番を鷹野に渡したとき）
image cg hinata_taping = "images/cg/hinata_taping.jpg"    # 第3章：準決勝の朝、ロッカールームで蓮のひざにテーピングを巻くひなた（ひなたの気持ちが強いとき）
image cg chika_sleep = "images/cg/chika_sleep.jpg"    # 第3章：11月の生徒会室で、メガネを外して居眠りする千夏（千夏の気持ちが強いとき）
image cg saki_wind = "images/cg/saki_wind.jpg"    # 第3章：11月の防波堤で、海風にあおられたスカートを押さえる紗希（紗希の気持ちが強いとき）
image cg ch3_kamishiro_ankle = "images/cg/ch3_kamishiro_ankle.jpg"    # 準決勝の前：白いソックスの上から何重にも巻いた、神城の左足首のテーピング

## 立ち絵（横700×縦720、背景は透過）。ファイル名は「キャラ_表情.png」。身長差に合わせて大きさと位置をそろえてある
image chika narrow = outfit_img("chika_narrow")
image chika normal = outfit_img("chika_normal")
image chika yukata = "images/chara/chika_yukata.png"        # 第2章：浴衣（カメラをさげる）
image chika soft = outfit_img("chika_soft")
image chika window = outfit_img("chika_window")
image daimon normal = "images/chara/daimon_normal.png"
image daimon jinbei = "images/chara/daimon_jinbei.png"      # 第2章：甚平（射的の空の皿）
image daimon worried = "images/chara/daimon_worried.png"
image daimon jersey = "images/chara/daimon_jersey.png"      # 練習用ジャージ
image daimon match = "images/chara/daimon_match.png"        # キーパーの試合用ユニフォーム（緑）
image daimon uniform = outfit_img("daimon_uniform")        # 制服（入部後の学校の場面）
image daimon uniform_worried = outfit_img("daimon_uniformw")   # 制服・困った顔
image hinata breath = outfit_img("hinata_breath")
image hinata forcesmile = outfit_img("hinata_forcesmile")
image hinata normal = outfit_img("hinata_normal")
image hinata pout = outfit_img("hinata_pout")
image hinata proud = outfit_img("hinata_proud")
image hinata serious = outfit_img("hinata_serious")
image hinata smile = outfit_img("hinata_smile")
image hinata stare = outfit_img("hinata_stare")
image hinata teary = outfit_img("hinata_teary")
image hinata yukata = "images/chara/hinata_yukata.png"      # 第2章：浴衣（はにかむ）
image hinata apron = "images/chara/hinata_apron.png"          # はやせ食堂を手伝うときのエプロン姿
image kuroda normal = "images/chara/kuroda_normal.png"
image kuroda peek = "images/chara/kuroda_peek.png"
image kuroda umbrella = "images/chara/kuroda_umbrella.png"
image kuroda yawn = "images/chara/kuroda_yawn.png"
image kuroda board = "images/chara/kuroda_board.png"        # 第2章：作戦ボードを抱える
image miyoshi smile = "images/chara/miyoshi_smile.png"
image miyoshi match = "images/chara/miyoshi_match.png"      # 試合用ユニフォーム（キャプテンマーク）
image miyoshi uniform = outfit_img("miyoshi_uniform")    # 制服（ジャージ以外の場面）
image mother down = "images/chara/mother_down.png"
image mother normal = "images/chara/mother_normal.png"
image mother sadsmile = "images/chara/mother_sadsmile.png"
image mother serious = "images/chara/mother_serious.png"
image mother smile = "images/chara/mother_smile.png"
image sakaguchi normal = outfit_img("sakaguchi_normal")
image sakaguchi jersey = "images/chara/sakaguchi_jersey.png"      # 練習用ジャージ
image sakaguchi match = "images/chara/sakaguchi_match.png"      # 試合用ユニフォーム
image saki frown = outfit_img("saki_frown")
image saki normal = outfit_img("saki_normal")
image saki casual = "images/chara/saki_casual.png"          # 第2章：私服（発表会帰りのワンピース・顔をそむける）
image takano lying = outfit_img("takano_lying")
image takano narrow = outfit_img("takano_narrow")
image takano normal = outfit_img("takano_normal")
image takano surprised = outfit_img("takano_surprised")
image takano jersey = "images/chara/takano_jersey.png"      # 練習用ジャージ
image takano jersey_narrow = "images/chara/takano_jersey_narrow.png"
image takano jersey_surprised = "images/chara/takano_jersey_surprised.png"
image takano match = "images/chara/takano_match.png"      # 試合用ユニフォーム
image takano casual = outfit_img("takano_casual")      # 第2章：私服
image kamishiro normal = "images/chara/kamishiro_normal.png"     # 第3章：桜嶺のジャージ
image kamishiro match = "images/chara/kamishiro_match.png"     # 第3章：桜嶺の試合用ユニフォーム（白と金）
image kamishiro pained = "images/chara/kamishiro_pained.png"     # 第3章：言いたいことが言えない顔
image onizuka normal = "images/chara/onizuka_normal.png"         # 第3章：桜嶺の監督。黒いロングコートで腕を組む
