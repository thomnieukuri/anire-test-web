## relations.rpy ―― 相関図
##   出会った人だけが、蓮のまわりに出てくる。線は tools/make_relation_lines.py で作った画像。
##   はじめて登場する場面で $ meet("三好") のように呼ぶ。

default met = []

init python:
    def meet(name):
        """相関図に、その人を出すようにする"""
        if name not in store.met:
            store.met = store.met + [name]

    def rel_meter(v):
        """0〜100 の値を、★5つで表す"""
        n = max(0, min(5, int(round(v / 20.0))))
        return "★" * n + "☆" * (5 - n)

## 相関図は「ヒロイン」「チームメイト」「まわりの人」のタブに分けて、1人ずつカードで見せる
##   顔は立ち絵から切り出した丸い絵（gui/relations/face_*.png。tools/make_relation_faces.py で作り直せる）
##   (名前, id, 蓮との関係, 色)
define REL_GROUPS = [("heroine", "ヒロイン"), ("team", "チームメイト"), ("others", "まわりの人")]
define REL_PEOPLE = {
    "heroine": [
        ("ひなた", "hinata", "幼なじみ・マネージャー", "#c9643a"),
        ("千夏", "chika", "生徒会長（2年）", "#34478f"),
        ("紗希", "saki", "港で会った、桜嶺の子", "#5a5a80"),
    ],
    "team": [
        ("三好", "miyoshi", "キャプテン（3年）", "#7a4508"),
        ("大門", "daimon", "GK（1年・元柔道部）", "#356b30"),
        ("鷹野", "takano", "FW（1年）", "#664600"),
        ("坂口", "sakaguchi", "5人組（1年）", "#6a3a8a"),
    ],
    "others": [
        ("母", "mother", "母・はやせ食堂", "#9c3a55"),
        ("黒田", "kuroda", "顧問（数学の先生）", "#4a4a4a"),
        ("神城", "kamishiro", "因縁の相手（桜嶺）", "#55431a"),
    ],
}

init python:
    def rel_segments(v):
        """0〜100 の値を、5つのマスのうちいくつ塗るかにする（少しでも上がっていれば1マス）"""
        if v <= 0:
            return 0
        return max(1, min(5, int(round(v / 20.0))))

    def rel_memo(nm):
        """カードの下に出す、いまの様子のひとこと（話が進むと変わる）"""
        f = store.flags
        if nm == "ひなた":
            if f.get("ひなた_トレーナー"):
                return "トレーナーになりたい、と打ち明けてくれた。最初の患者は、俺らしい。"
            if store.ch2_knee == "honest":
                return "ひざのことを正直に話してから、テーピングを巻いてくれるようになった。"
            if store.ch2_knee == "hide":
                return "ひざのことは、何も聞いてこない。玄関に、湿布が一箱だけ置いてあった。"
            return "10年来の幼なじみ。サッカー部のマネージャーになって、ストップウォッチを首にかけている。"
        if nm == "千夏":
            if f.get("統廃合を知る"):
                return "「港北」に赤い線が引かれた書類を、ひとりで抱えている。「……決めさせません」"
            if f.get("千夏_キーホルダー"):
                return "カメラのキーホルダーは、4年前の県大会でスタンドで配っていたものらしい。"
            if f.get("千夏_アルバム") or f.get("千夏_写真"):
                return "部室に届いた試合の写真。撮ったのは……もしかして。"
            if f.get("ch2_first_win"):
                return "1回戦の土手の端に、日傘とフィルムカメラがあった。"
            return "規則にきびしい生徒会長。古いフィルムカメラを持ち歩いている。"
        if nm == "紗希":
            if store.ch2_saki_word:
                return "夏祭りの日、満員電車で背中合わせになった。堤防の先で、海を見ていた。"
            if f.get("紗希_ピアノ2") or f.get("ch2_piano"):
                return "防波堤の近くの家から、同じ曲のピアノが聞こえる。"
            return "港で、風に飛ばされた楽譜を拾った。桜嶺の制服を着ていた。"
        if nm == "三好":
            if f.get("三好_引退"):
                return "選手権が終わったら引退して、家の工務店で働くつもりらしい。"
            return "3年のキャプテン。中学の3年間は補欠。誰よりも走って、誰よりも声がでかい。"
        if nm == "大門":
            if f.get("ch2_first_win"):
                return "PK戦で、最後の一本を止めた。人の山のいちばん下で、泣きながら笑っていた。"
            return "元柔道部。顔はこわいが、気は優しい。受け身は部でいちばん。"
        if nm == "鷹野":
            if f.get("ch2_takano_night"):
                return "夜のグラウンドで、黒田の左足のキックを一人で練習している。"
            return "元Jクラブのジュニアユース。口は悪いが、サッカーには誰よりもまじめ。"
        if nm == "坂口":
            if f.get("ch2_arcade"):
                return "ゲームでも本物でも、右サイドを上がりっぱなし。癖を直すと言っていた。"
            return "駅前のゲーセンの5人組のリーダー格。口ぐせは「ウケる」。"
        if nm == "母":
            return "はやせ食堂を一人で切り盛りしている。口ぐせは「やりたいことやりな」。"
        if nm == "黒田":
            if f.get("黒田_一本"):
                return "元潮見ブルーマリンズ。J1で4年。ひざのケガで、28歳で引退した。"
            return "数学の先生で、サッカー部の顧問。いつも新聞をかぶって寝ている。"
        if nm == "神城":
            return "桜嶺のエース。U-15日本代表。中3の決勝で、最後にぶつかった相手。"
        return ""

screen rel_meter_row(label, v, col):
    hbox:
        spacing 6
        text label style "rel_meter_label"
        hbox:
            spacing 3
            yalign 0.5
            $ n = rel_segments(v)
            for i in range(5):
                add Solid(col if i < n else "#e3d9c6", xysize=(30, 16))

## ヒロインのカード（縦長）
screen rel_card_heroine(nm, rid, rel, col):
    frame:
        style "rel_card"
        xsize 292
        ysize 500
        if nm in met:
            vbox:
                xalign 0.5
                spacing 6
                add Solid(col, xysize=(272, 6))
                add Transform("gui/relations/face_%s.png" % rid, zoom=0.85) xalign 0.5
                text nm style "rel_card_name" xalign 0.5
                text rel style "rel_card_rel" xalign 0.5
                null height 4
                use rel_meter_row("ときめき", heart[nm]["ときめき"], "#e0708a")
                use rel_meter_row("信頼　　", heart[nm]["信頼"], PEN_TEAL)
                null height 4
                text rel_memo(nm) style "rel_card_memo"
        else:
            vbox:
                xalign 0.5
                yalign 0.4
                spacing 10
                text "？？？" style "rel_card_name" xalign 0.5 color INK_SOFT
                text "まだ出会っていない" style "rel_card_rel" xalign 0.5

## チームメイト・まわりの人のカード（横長）
screen rel_card_wide(nm, rid, rel, col):
    frame:
        style "rel_card"
        xsize 446
        ysize 200
        hbox:
            spacing 12
            add Transform("gui/relations/face_%s.png" % rid, zoom=0.82) yalign 0.5
            vbox:
                spacing 4
                xsize 300
                hbox:
                    spacing 10
                    text ("坂口たち" if nm == "坂口" else nm) style "rel_card_name"
                    text rel style "rel_card_rel" yalign 1.0
                if nm in bond:
                    use rel_meter_row("絆", bond[nm], col)
                text rel_memo(nm) style "rel_card_memo"

screen relations(start="heroine"):
    tag menu
    default tab = start
    use game_menu("相関図"):
        vbox:
            spacing 12
            hbox:
                spacing 8
                for key, label in REL_GROUPS:
                    textbutton label style "rel_tab" text_style "rel_tab_text" action SetScreenVariable("tab", key) selected (tab == key)
            if tab == "heroine":
                hbox:
                    spacing 13
                    for nm, rid, rel, col in REL_PEOPLE["heroine"]:
                        use rel_card_heroine(nm, rid, rel, col)
            else:
                $ people = [p for p in REL_PEOPLE[tab] if p[0] in met]
                if people:
                    hbox:
                        box_wrap True
                        spacing 12
                        box_wrap_spacing 12
                        xsize 910
                        for nm, rid, rel, col in people:
                            use rel_card_wide(nm, rid, rel, col)
                else:
                    text "まだ、だれとも出会っていません。" color INK_SOFT size 24

    ## 選手名鑑（第2章の作戦ボードの日から）。タイトルの行の右はしに出す
    if roster_open():
        textbutton "選手名鑑 ▶" style "roster_link" text_style "roster_link_text" xanchor 1.0 xpos 1236 ypos 40 action ShowMenu("roster")

## 色やフォント（FONT_JP_B・INK など）は screens.rpy で決めているので、init 1 にしてそのあとで作る
init 1:

    style rel_tab:
        xysize (180, 50)
        background "#ffffff66"
        hover_background "#ffffffaa"
        selected_background PEN_RED
        padding (0, 0, 0, 0)

    style rel_tab_text:
        xalign 0.5
        yalign 0.5
        font FONT_JP_B
        size 22
        color INK
        selected_color "#ffffff"
        hover_color PEN_RED
        selected_hover_color "#ffffff"

    style rel_card:
        background "#fffdf6"
        padding (10, 10, 10, 10)

    style rel_card_name:
        font FONT_JP_B
        size 30
        color INK

    style rel_card_rel:
        size 18
        color "#6e5a3c"

    style rel_meter_label:
        font FONT_JP_B
        size 19
        color INK
        min_width 86
        yalign 0.5

    style rel_card_memo:
        size 19
        color INK
        line_spacing 3

## スマホ（small）では文字を大きくする
init 1:
    style rel_card_name:
        variant "small"
        size 34
    style rel_card_rel:
        variant "small"
        size 22
    style rel_card_memo:
        variant "small"
        size 23
        line_spacing 2
    style rel_meter_label:
        variant "small"
        size 23
        min_width 104
    style rel_tab_text:
        variant "small"
        size 26
