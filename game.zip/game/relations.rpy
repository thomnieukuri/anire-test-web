## relations.rpy ―― 相関図
##   出会った人だけが、蓮のまわりに出てくる。線は tools/make_relation_lines.py で作った画像。
##   はじめて登場する場面で $ meet("三好") のように呼ぶ。

default met = []

init python:
    def meet(name):
        """相関図に、その人を出すようにする"""
        if name not in store.met:
            store.met = store.met + [name]
        ## タイトル画面に出す人（v0.31.1。セーブをまたいで覚えておく）
        if name not in (persistent.title_met or set()):
            persistent.title_met = set(persistent.title_met or set()) | {name}

    def rel_meter(v):
        """0〜100 の値を、★5つで表す"""
        n = max(0, min(5, int(round(v / 20.0))))
        return "★" * n + "☆" * (5 - n)

## 相関図の人の一覧（v0.31.1 から図にした。グループ分けは「ヒロイン」「チームメイト」「まわりの人」のまま）
##   顔は立ち絵から切り出した丸い絵（gui/relations/face_*.png。tools/make_relation_faces.py で作り直せる）
##   (名前, id, 蓮との関係, 色)
## 第4章（高2）からの肩書き（v0.30.0。学年が上がり、三好は卒業）
define REL_LABEL_A4 = {"ひなた": "幼なじみ・マネージャー（2年）", "あげは": "マネージャー（1年）", "千夏": "生徒会長（3年）", "三好": "OB（工務店）", "大門": "GK（2年・元柔道部）", "鷹野": "FW（2年）",
                       "坂口": "5人組（2年）", "小早川": "ボランチ（1年）", "倉田": "GK（1年）", "赤坂": "FW（1年）"}

init python:
    def grade_up_done():
        """高2の肩書きにするか。第4章（ルートA）の4月7日（入学式）から（v0.31.1：それまでは1/1 に切りかわり、卒業前の三好が「OB」になっていた）"""
        if "chapter4a" not in (getattr(store, "play_marks", None) or {}):
            return False
        if store.cal_year > 2027:
            return True
        d = _doy(store.cal_date)
        return store.cal_year == 2027 and d is not None and d >= _doy("4月7日")

    def rel_label(nm, rel):
        if grade_up_done():
            return REL_LABEL_A4.get(nm, rel)
        return rel

define REL_GROUPS = [("heroine", "ヒロイン"), ("team", "チームメイト"), ("others", "まわりの人")]
define REL_PEOPLE = {
    "heroine": [
        ("ひなた", "hinata", "幼なじみ・マネージャー", "#c9643a"),
        ("千夏", "chika", "生徒会長（2年）", "#34478f"),
        ("紗希", "saki", "港で会った、桜嶺の子", "#5a5a80"),
        ## v0.30.0：第4章（製品版）から。出会うまでカードは出ない
        ("あげは", "ageha", "1年のマネージャー", "#b04a72"),
    ],
    "team": [
        ("三好", "miyoshi", "キャプテン（3年）", "#7a4508"),
        ("大門", "daimon", "GK（1年・元柔道部）", "#356b30"),
        ("鷹野", "takano", "FW（1年）", "#664600"),
        ("坂口", "sakaguchi", "5人組（1年）", "#6a3a8a"),
        ## 第4章（製品版）で入る1年。顔は v0.30.0 から立ち絵の顔（tools/make_relation_faces.py）
        ("小早川", "kobayakawa", "ボランチ（新1年）", "#2f6f76"),
        ("倉田", "kurata", "GK（新1年）", "#356b30"),
        ("赤坂", "akasaka", "FW（新1年）", "#b8432f"),
    ],
    "others": [
        ("母", "mother", "母・はやせ食堂", "#9c3a55"),
        ("黒田", "kuroda", "顧問（数学の先生）", "#4a4a4a"),
        ("神城", "kamishiro", "因縁の相手（桜嶺）", "#55431a"),
        ("鬼塚", "onizuka", "桜嶺の監督", "#2a2a2a"),
        ("真壁", "makabe", "桜嶺の14番", "#5a4a2a"),
        ("佐伯", "saeki", "ブルーマリンズのスカウト", "#2a4f8a"),
    ],
}

init python:
    def rel_segments(v):
        """0〜100 の値を、5つのマスのうちいくつ塗るかにする（少しでも上がっていれば1マス）"""
        if v <= 0:
            return 0
        return max(1, min(5, int(round(v / 20.0))))

    def rel_name(nm):
        """カードに出す名前。紗希は、名前を聞くまで「楽譜の子」"""
        if nm == "紗希" and not store.flags.get("紗希_名前を聞いた"):
            return "楽譜の子"
        return nm

    def rel_saki_seen():
        """第1章の港で、楽譜を拾って会ったか（名前を聞いていなくても）
        meet("紗希") は名前が分かったときに呼ぶので、それより前は、ここで見る。
        港の場面の選択肢：名前を聞く（紗希_名前を聞いた）／何かあったのか（紗希の信頼が上がる）／見送る（紗希_出会い遅れ）"""
        f = store.flags
        h = store.heart.get("紗希", {})
        return bool(f.get("紗希_名前を聞いた") or f.get("紗希_出会い遅れ")
                    or h.get("ときめき", 0) > 0 or h.get("信頼", 0) > 0)

    def rel_heroine_shown(nm):
        """ヒロインのカードを表に出すか（出会っていれば出す。紗希は、名前を知らなくても会っていれば出す）"""
        if nm in store.met:
            return True
        return nm == "紗希" and rel_saki_seen()

    def rel_memo(nm):
        """カードの下に出す、いまの様子のひとこと（話が進むと変わる）"""
        f = store.flags
        ## 第4章（ルートA）の様子（v0.31.1：第4章に入っても第3章までのメモのままだったため）
        a4 = rel_memo_a4(nm, f)
        if a4:
            return a4
        if nm == "ひなた":
            if f.get("兆し") == "hinata":
                return "年末の商店街で、理学療法の学校の先輩・柏木さんと歩いていた。「練習の帰り、一緒に帰るの、しばらくやめるね」"
            if f.get("修羅場_クリスマス") == "hinata":
                return "クリスマスの駅前で、走らずに、ゆっくり歩いていった。"
            if f.get("ch3_医者の話"):
                return "冬に医者に言われたことを、全部話した。「十か月、待った」と言われた。"
            if f.get("ひなた_トレーナー"):
                return "トレーナーになりたい、と打ち明けてくれた。最初の患者は、俺らしい。"
            if store.ch2_knee == "honest":
                return "ひざのことを正直に話してから、テーピングを巻いてくれるようになった。"
            if store.ch2_knee == "hide":
                return "ひざのことは、何も聞いてこない。玄関に、湿布が一箱だけ置いてあった。"
            return "10年来の幼なじみ。サッカー部のマネージャーになって、ストップウォッチを首にかけている。"
        if nm == "千夏":
            if f.get("兆し") == "chika":
                return "年末の駅前で、前の副会長の相良くんと、紺色の傘に入っていた。"
            if f.get("修羅場_クリスマス") == "chika":
                return "「こういうときの決まりは、規則に書いてありませんでした」"
            if f.get("千夏_旗の子"):
                return "4年前、スタンドで旗を振っていたのは千夏先輩だった。あの年のキャプテンは、先輩のお兄さん。"
            if f.get("千夏_傘"):
                return "5月31日、雨の桜嶺のスタンドに、紺色の傘でいた。「規則違反ではありません」"
            if f.get("統廃合を知る"):
                return "「港北」に赤い線が引かれた書類を、ひとりで抱えている。「港北は、なくなるかもしれません」"
            if f.get("千夏_キーホルダー"):
                return "カメラのキーホルダーは、4年前の県大会でスタンドで配っていたものらしい。"
            if f.get("千夏_アルバム") or f.get("千夏_写真"):
                return "部室に届いた試合の写真。撮ったのは……もしかして。"
            if f.get("ch2_first_win"):
                return "1回戦の土手の端に、日傘とフィルムカメラがあった。"
            return "規則にきびしい生徒会長。古いフィルムカメラを持ち歩いている。"
        if nm == "あげは":
            if f.get("あげは_相棒"):
                return "「港北の最後の日まで、マネやる。最後のマネージャー、あたし」"
            if f.get("あげは_追試"):
                return "クロセンの数学の追試に向けて、二次関数のグラフを、ぐにゃっと描く練習をしている。"
            if f.get("あげは_アカウント"):
                return "部のアカウント「港北サッカー部【最後の世代】」を作った。俺の右足の癖に、ひなたより先に気づいた。"
            return "切り抜き動画を見て、入試の2週間前に港北を受け直したらしい。俺のことを「推し」と呼ぶ。"
        if nm == "紗希":
            if f.get("兆し") == "saki":
                return "年末、ピアノ教室の氷室という男子が、楽譜のかばんを持っていた。一度も振り返らなかった。"
            if f.get("修羅場_クリスマス") == "saki":
                return "「来なくていいって、書いたでしょ」"
            if f.get("紗希_最後まで弾けた"):
                return "クリスマスの発表会で、いつも止まる曲を、最後まで弾いた。"
            if f.get("ch3_紗希_駒"):
                return "父は、桜嶺の鬼塚監督。「あなたも、あの人の駒なの？」"
            if store.ch2_saki_word:
                if f.get("紗希_祭り"):
                    return "満員電車で背中合わせになった。花火の夜、堤防の先で海を見ていた。父は、夏は合宿らしい。"
                return "満員電車で背中合わせになった。「さっきのは事故だから。忘れて」"
            if f.get("紗希_ピアノ2") or f.get("ch2_piano"):
                return "防波堤の近くの家から、同じ曲のピアノが聞こえる。"
            if f.get("紗希_ピアノ_帰り道"):
                return "防波堤の近くの家から、いつも同じところで止まるピアノが聞こえた。カーテンのすき間に、あの子と同じ色の髪。"
            if f.get("紗希_出会い遅れ"):
                return "港で、風に飛ばされた楽譜を拾った。桜嶺の制服を着ていた。名前は、聞かなかった。"
            return "港で、風に飛ばされた楽譜を拾った。桜嶺の制服を着ていた。"
        if nm == "三好":
            if f.get("ch3_armband"):
                return "準決勝のあと引退。黄色いキャプテンマークを、" + ("蓮" if f.get("ch3_armband") == "ren" else "鷹野") + "に託した。"
            if f.get("三好_工務店"):
                return "選手権が終わったら引退して、家の工務店で働くつもりらしい。"
            return "3年のキャプテン。中学の3年間は補欠。誰よりも走って、誰よりも声がでかい。"
        if nm == "大門":
            if f.get("ch2_first_win"):
                return "PK戦で、最後の一本を止めた。人の山のいちばん下で、泣きながら笑っていた。"
            return "元柔道部。顔はこわいが、気は優しい。受け身は部でいちばん。"
        if nm == "鷹野":
            if f.get("ch3_fight") == "maybe":
                return "三好先輩の引退の日、胸ぐらをつかまれた。「行けよ。どこにでも」"
            if f.get("ch3_fight") == "undecided":
                return "三好先輩の引退の日、ボールをフェンスに蹴りつけた。「決めてねえのが、答えだろ」"
            if f.get("ch2_takano_night"):
                return "夜のグラウンドで、黒田のあのキックを、左足でまねしている。"
            return "元Jクラブのジュニアユース。口は悪いが、サッカーには誰よりもまじめ。"
        if nm == "坂口":
            if f.get("ch3_坂口_戻った"):
                return "格下に負けて、5人で辞めかけた。登録の締め切りの二日前、ばらばらに、全員戻ってきた。"
            if f.get("ch2_arcade"):
                return "ゲームでも本物でも、右サイドを上がりっぱなし。癖を直すと言っていた。"
            return "駅前のゲーセンの5人組のリーダー格。口ぐせは「ウケる」。"
        if nm == "母":
            return "はやせ食堂を一人で切り盛りしている。口ぐせは「やりたいことやりな」。"
        if nm == "黒田":
            if f.get("黒田_一本"):
                return "元潮見ブルーマリンズ。J1で4年。ひざのケガで、28歳で引退した。"
            return "数学の先生で、サッカー部の顧問。いつも新聞をかぶって寝ている。"
        if nm == "小早川":
            return "港北に入る、最後の1年生。去年の冬の準決勝をスタンドで見て、港北を選んだ。"
        if nm == "倉田":
            return "大門にあこがれて入った、2人目のキーパー。ボールが顔に来ると、目をつぶってしまう。"
        if nm == "赤坂":
            return "中学で市の得点王。桜嶺のセレクションを蹴って港北に来た。毎日、鷹野に1対1を挑んでは、抜かれている。"
        if nm == "真壁":
            return "鷹野とジュニアユースで一緒だった。準決勝で、ずっと蓮の背中に体を当ててきた。"
        if nm == "佐伯":
            return "黒田と、ブルーマリンズに同じ年に入った。ボールを持っていない選手を見ている。"
        if nm == "鬼塚":
            if f.get("紗希_兄"):
                return "桜嶺の監督。紗希の父。口ぐせは「本物は、壊れない」。壊れるまで使って、壊れたら捨てる。"
            return "桜嶺の監督。黒いロングコート。準決勝のあと、「本物なら、来い」と言った。"
        if nm == "神城":
            if f.get("鬼塚_誘い") and f.get("神城_足首"):
                return "準決勝のあと、「あのタックルは、俺が決めたことじゃない」と言いかけた。左の足首のテーピングを「監督には言うな」と隠している。"
            if f.get("鬼塚_誘い"):
                return "準決勝のあと、「あのタックルは、俺が決めたことじゃない」と言いかけた。"
            if f.get("神城_取り消し"):
                return "元U-15日本代表。高1で、もう桜嶺のAチームのエース。中3の決勝で、最後にぶつかった相手。「決勝のことで」と送ってきて、取り消した。"
            return "元U-15日本代表。高1で、もう桜嶺のAチームのエース。中3の決勝で、最後にぶつかった相手。"
        return ""

init python:
    def rel_memo_a4(nm, f):
        """第4章（ルートA）に入ってからのメモ。当てはまらなければ None（第3章までのメモを使う）"""
        if "chapter4a" not in (getattr(store, "play_marks", None) or {}):
            return None
        if nm == "神城":
            k = f.get("神城_うそ")
            if k == "grab":
                return "4月の港で「あのタックルは、俺が決めた」と言った。胸ぐらをつかんでも、一度もこっちを見なかった。"
            if k == "turn":
                return "4月の港で「あのタックルは、俺が決めた」と言った。背を向けたとき「……それでいい」と、少しほっとしたような声だった。"
            if k == "final":
                return "4月の港で「あのタックルは、俺が決めた」と言った。「決勝で、返す」と言ったら「……来いよ。決勝まで」。"
            return "桜嶺の3年。高2の冬に「春になったら、全部話す」と言った。"
        if nm == "千夏":
            if f.get("千夏_相棒"):
                return "白いままのカードを、ファイルの最後のページにはさんでいる。「卒業式の日でも、かまいません」"
            if f.get("千夏_記録"):
                return "港北の最後の世代を、記録に残すつもりらしい。「5年前より、いい写真を撮ります」"
            if f.get("統合_決定"):
                return "統合が決まった。生徒会長として、最後の港北をどう残すか考えている。"
            return None
        if nm == "ひなた":
            if f.get("ひなた_相棒"):
                return "「今日も、走っていいひざです」。テーピングの最後の一巻きが、いつもより少しだけきつかった。"
            return None
        if nm == "鷹野":
            if f.get("鷹野_相棒"):
                return "誘いを断った。「まだ、お前からもらってねえパスがある。全国の決勝で出すやつが」"
            if f.get("鷹野_溝"):
                return "残ると言った。「『行け』って言われたかったのかもしんねえ。一回くらい」"
            return None
        if nm == "黒田":
            if f.get("黒田_ひざだけじゃない"):
                return "「ひざだ。……ひざだけじゃ、ないがな」。それ以上は、何も言わなかった。"
            return None
        if nm == "三好":
            if grade_up_done():
                return "卒業して、家の工務店で働いている。ときどき、作業着のままグラウンドに顔を出す。"
            return None
        return None

screen rel_meter_row(label, v, col):
    hbox:
        spacing 6
        text label style "rel_meter_label"
        hbox:
            spacing 3
            yalign 0.5
            $ n = rel_segments(v)
            for i in range(5):
                add Solid(col if i < n else "#e3d9c6", xysize=(26, 14))

## ---- 相関図（v0.31.1：カードを並べる形から、蓮を真ん中にした「図」に作り直した）----
##   ・蓮から線をのばし、線の上に関係の名前（幼なじみ・生徒会長・ライバル など）
##   ・港北サッカー部と桜嶺は、点線の枠でまとめる
##   ・まだ会っていない人は、顔も線も出さない（「？？？」の枠も出さない。あと何人いるかが分からないように）
##   ・まだよく知らない関係は点線（紗希は、名前を聞くまで「楽譜の子」で点線）
##   ・話が進むと線が増える（紗希と鬼塚の「父」、黒田と佐伯の「同期」）
##   ・顔を押すと、右の紙にその人の肩書き・目盛り・いまの様子が出る
##   場所は game_menu の中身（幅900×高さ568）の中の座標。図は左の幅610、右の紙は x=632 から

## 顔の大きさ（face_*.png は150px）
define REL_Z = {"big": 0.69, "mid": 0.52, "sm": 0.30}

## 1人ずつの場所と大きさ
define REL_POS = {
    "蓮": (300, 262, "big"),
    "ひなた": (100, 104, "mid"),
    "千夏": (300, 44, "mid"),
    "あげは": (500, 104, "mid"),
    "紗希": (525, 322, "mid"),
    "母": (52, 290, "sm"),
    "黒田": (92, 392, "sm"),
    "佐伯": (30, 484, "sm"),
}

## グループの枠：(名前, 色, x, y, 幅, 高さ, メンバー, メンバーの場所)
define REL_GROUP_BOX = [
    ("港北サッカー部", "#356b30", 140, 396, 270, 160,
        ["三好", "大門", "鷹野", "坂口", "小早川", "倉田", "赤坂"],
        [(175, 436), (240, 436), (305, 436), (370, 436), (207, 506), (272, 506), (337, 506)]),
    ("桜嶺", "#cd4646", 440, 446, 170, 110,
        ["神城", "鬼塚", "真壁"],
        [(472, 492), (525, 492), (578, 492)]),
]

## 蓮からの線の上に出す、関係の名前
define REL_SHORT = {"ひなた": "幼なじみ", "千夏": "生徒会長", "紗希": "港で会った", "あげは": "後輩のマネ",
                    "母": "母", "黒田": "顧問", "佐伯": "スカウト"}

init python:
    import math

    def rel_info(nm):
        """(id, 肩書き, 色, グループ) を返す"""
        for g, people in REL_PEOPLE.items():
            for p in people:
                if p[0] == nm:
                    return p[1], rel_label(nm, p[2]), p[3], g
        return "ren", "港北高校サッカー部", PEN_RED, ""

    def rel_shown(nm):
        if nm == "蓮":
            return True
        if nm in ("ひなた", "千夏", "紗希", "あげは"):
            return rel_heroine_shown(nm)
        return nm in store.met

    def rel_layout():
        """図に出す人の場所 {名前: (x, y, 大きさ)} と、出すグループの枠"""
        pos = {}
        for nm, v in REL_POS.items():
            if rel_shown(nm):
                pos[nm] = v
        boxes = []
        for gname, col, bx, by, bw, bh, members, slots in REL_GROUP_BOX:
            shown = [m for m in members if rel_shown(m)]
            if not shown:
                continue
            ## 会った人だけを、前の場所から順につめて並べる
            for m, (x, y) in zip(shown, slots):
                pos[m] = (x, y, "sm")
            ## 1段に収まるあいだは、枠も1段ぶんの高さにする
            if len(shown) <= 4 and len(slots) > 4:
                bh = 92
            boxes.append((gname, col, bx, by, bw, bh))
        return pos, boxes

    def rel_lines(pos, boxes):
        """線：(x1, y1, x2, y2, 色, 点線か, 太さ, ラベル, ラベルの x, ラベルの y)"""
        f = store.flags
        out = []
        rx, ry, _ = pos["蓮"]
        for nm in ("ひなた", "千夏", "あげは", "紗希", "母", "黒田"):
            if nm not in pos:
                continue
            x, y, size = pos[nm]
            col = rel_info(nm)[2]
            label = REL_SHORT.get(nm, "")
            dashed = False
            if nm == "紗希" and rel_name("紗希") != "紗希":
                label, dashed = "楽譜の子", True
            w = 4 if size == "mid" else 3
            out.append((rx, ry, x, y, col, dashed, w, label, (rx + x) // 2, (ry + y) // 2))
        names = [b[0] for b in boxes]
        if "港北サッカー部" in names:
            out.append((rx, ry, 275, 396, "#356b30", False, 4, "チームメイト", 290, 352))
        if "桜嶺" in names:
            out.append((rx, ry, 525, 446, "#cd4646", True, 4, "ライバル", 420, 360))
        ## 話が進むと増える線
        if "紗希" in pos and "鬼塚" in pos and (f.get("紗希_兄") or f.get("ch3_紗希_駒")):
            sx, sy, _ = pos["紗希"]
            ox, oy, _ = pos["鬼塚"]
            out.append((sx, sy, ox, oy, "#5a5a80", True, 3, "父", sx + 30, 428))
        if "黒田" in pos and "佐伯" in pos:
            kx, ky, _ = pos["黒田"]
            sx, sy, _ = pos["佐伯"]
            out.append((kx, ky, sx, sy, "#4a4a4a", False, 2, "同期", (kx + sx) // 2 - 6, (ky + sy) // 2))
        return out

    def rel_dash(length, col, w=4):
        """点線（長さ length、太さ w）"""
        return Transform(Fixed(Tile("gui/grid/dash.png"), xysize=(int(length), w)), matrixcolor=TintMatrix(col))

    def rel_line_disp(x1, y1, x2, y2, col, dashed, w):
        L = int(math.hypot(x2 - x1, y2 - y1))
        ang = math.degrees(math.atan2(y2 - y1, x2 - x1))
        if dashed:
            d = rel_dash(L, col)
        else:
            d = Solid(col, xysize=(L, w))
        return Transform(d, rotate=ang, rotate_pad=False)

    def rel_default_sel():
        for nm in ("ひなた", "千夏", "紗希", "あげは"):
            if rel_shown(nm):
                return nm
        return None

## 線の上の、関係の名前
screen rel_tag(label, col, x, y):
    frame:
        pos (x, y)
        anchor (0.5, 0.5)
        padding (9, 1, 9, 3)
        background Frame("gui/grid/pill_fill.png", 11, 11)
        foreground Frame(Transform("gui/grid/pill_line.png", matrixcolor=TintMatrix(col)), 11, 11)
        text label size 13 font FONT_JP_B color col

## ヒロインの顔の下の、小さな目盛り（ピンク＝ときめき、青緑＝信頼）
screen rel_mini_meter(nm):
    hbox:
        spacing 6
        xalign 0.5
        for _v, _c in ((heart[nm]["ときめき"], "#e0708a"), (heart[nm]["信頼"], PEN_TEAL)):
            hbox:
                spacing 2
                $ _n = rel_segments(_v)
                for _i in range(5):
                    add Solid(_c if _i < _n else "#e3d9c6", xysize=(9, 7))

## 顔1つ（押すと右の紙に、その人のことが出る）
screen rel_face(nm, x, y, size, sel):
    $ _rid, _rel, _col, _g = rel_info(nm)
    $ _z = REL_Z[size]
    $ _d = int(150 * _z)
    button:
        xpos x
        xanchor 0.5
        ypos y - _d // 2 - 6
        padding (0, 0, 0, 0)
        background None
        action (SetScreenVariable("sel", nm) if nm != "蓮" else NullAction())
        vbox:
            spacing 0
            fixed:
                xysize (_d + 12, _d + 12)
                if sel == nm:
                    add Transform("gui/grid/ring_sel.png", zoom=(_d + 12) / 170.0) align (0.5, 0.5)
                add Transform("gui/relations/face_%s.png" % _rid, zoom=_z) align (0.5, 0.5)
                add Transform("gui/grid/ring.png", zoom=_z, matrixcolor=TintMatrix(_col)) align (0.5, 0.5)
            frame:
                xalign 0.5
                padding (5, 0, 5, 1)
                background "#fffdf6"
                text rel_name(nm) style ("rel_map_name_sm" if size == "sm" else "rel_map_name")
            if nm in heart and size == "mid":
                frame:
                    xalign 0.5
                    padding (4, 2, 4, 2)
                    background "#fffdf6"
                    use rel_mini_meter(nm)

## 右の紙：選んだ人のこと
screen rel_detail(nm):
    frame:
        style "rel_detail"
        if nm:
            $ _rid, _rel, _col, _g = rel_info(nm)
            vbox:
                xfill True
                spacing 6
                fixed:
                    xalign 0.5
                    xysize (124, 124)
                    add Transform("gui/relations/face_%s.png" % _rid, zoom=0.8) align (0.5, 0.5)
                    add Transform("gui/grid/ring.png", zoom=0.8, matrixcolor=TintMatrix(_col)) align (0.5, 0.5)
                text (("坂口たち" if nm == "坂口" else rel_name(nm))) style "rel_card_name" xalign 0.5
                text _rel style "rel_card_rel" xalign 0.5 text_align 0.5
                null height 6
                if nm in heart:
                    use rel_meter_row("ときめき", heart[nm]["ときめき"], "#e0708a")
                    use rel_meter_row("信頼", heart[nm]["信頼"], PEN_TEAL)
                ## 神城の絆は、有料パートで使い始めるまで目盛りを出さない
                elif nm in bond and nm != "神城":
                    use rel_meter_row("絆", bond[nm], _col)
                null height 4
                add Solid("#e2d6bf", xysize=(226, 2)) xalign 0.5
                text "いまの様子" size 15 font FONT_JP_B color PEN_RED
                text rel_memo(nm) style "rel_card_memo"
        else:
            text "顔を押すと、その人のことが\nここに出ます。" size 17 color INK_SOFT xalign 0.5 yalign 0.4 text_align 0.5
    add "gui/grid/tape_4.png" xpos 632 + 134 - 22 ypos -10

screen relations(start=None):
    tag menu
    default sel = rel_default_sel()
    $ _pos, _boxes = rel_layout()
    use game_menu("相関図"):
        fixed:
            xysize (900, 568)
            ## グループの点線の枠
            for _gname, _gcol, _bx, _by, _bw, _bh in _boxes:
                add Solid("#ffffffb0", xysize=(_bw, _bh)) pos (_bx, _by)
                add rel_dash(_bw, _gcol, 3) pos (_bx, _by)
                add rel_dash(_bw, _gcol, 3) pos (_bx, _by + _bh - 3)
                add Transform(rel_dash(_bh, _gcol, 3), rotate=90, rotate_pad=False) pos (_bx + 1, _by + _bh // 2) anchor (0.5, 0.5)
                add Transform(rel_dash(_bh, _gcol, 3), rotate=90, rotate_pad=False) pos (_bx + _bw - 2, _by + _bh // 2) anchor (0.5, 0.5)
            ## 線
            $ _lines = rel_lines(_pos, _boxes)
            for _x1, _y1, _x2, _y2, _c, _dash, _w, _lab, _lx, _ly in _lines:
                add rel_line_disp(_x1, _y1, _x2, _y2, _c, _dash, _w) pos ((_x1 + _x2) // 2, (_y1 + _y2) // 2) anchor (0.5, 0.5)
            ## グループの名前（枠の左上）
            for _gname, _gcol, _bx, _by, _bw, _bh in _boxes:
                frame:
                    pos (_bx + 12, _by - 12)
                    padding (10, 1, 10, 3)
                    background _gcol
                    text _gname size 14 font FONT_JP_B color "#ffffff"
            ## 関係の名前
            for _x1, _y1, _x2, _y2, _c, _dash, _w, _lab, _lx, _ly in _lines:
                if _lab:
                    use rel_tag(_lab, _c, _lx, _ly)
            ## 顔
            for _nm, (_x, _y, _size) in _pos.items():
                use rel_face(_nm, _x, _y, _size, sel)
            ## 右の紙
            use rel_detail(sel)

    ## 見出しの横に、色と線の意味
    text "{color=#e0708a}■{/color} ときめき　{color=#2f6f76}■{/color} 信頼　点線＝まだよく知らない" style "rel_legend" xpos 476 ypos 62

    ## 選手名鑑（第2章の作戦ボードの日から）。タイトルの行の右はしに出す
    hbox:
        xanchor 1.0
        xpos 1236
        ypos 52
        spacing 10
        if note_open():
            textbutton "サッカーノート ▶" style "roster_link" text_style "roster_link_text" action ShowMenu("soccer_note")
        if roster_open():
            textbutton "選手名鑑 ▶" style "roster_link" text_style "roster_link_text" action ShowMenu("roster")

## 色やフォント（FONT_JP_B・INK など）は screens.rpy で決めているので、init 1 にしてそのあとで作る
init 1:

    style rel_tab:
        xysize (180, 50)
        background "#ffffff66"
        hover_background "#ffffffaa"
        selected_background PEN_RED
        padding (0, 0, 0, 0)

    style rel_tab_text:
        xalign 0.5
        yalign 0.5
        font FONT_JP_B
        size 22
        color INK
        selected_color "#ffffff"
        hover_color PEN_RED
        selected_hover_color "#ffffff"

    style rel_card:
        background "#fffdf6"
        padding (10, 10, 10, 10)

    style rel_detail:
        pos (632, 0)
        xysize (268, 556)
        background Frame("gui/grid/card.png", 4, 4)
        padding (20, 22, 20, 16)

    style rel_map_name:
        font FONT_JP_B
        size 17
        color INK
        hover_color PEN_RED

    style rel_map_name_sm:
        font FONT_JP_B
        size 13
        color INK
        hover_color PEN_RED

    style rel_card_name:
        font FONT_JP_B
        size 26
        color INK

    style rel_card_rel:
        size 18
        color "#6e5a3c"

    style rel_meter_label:
        font FONT_JP_B
        size 16
        color INK
        min_width 74
        yalign 0.5

    style rel_card_memo:
        size 16
        color INK
        line_spacing 4

    style rel_legend:
        size 15
        color INK_SOFT

    style rel_legend:
        variant "small"
        size 18

## スマホ（small）では文字を大きくする（右の紙に収まる大きさまで）
init 1:
    style rel_card_name:
        variant "small"
        size 28
    style rel_card_rel:
        variant "small"
        size 19
    style rel_card_memo:
        variant "small"
        size 19
        line_spacing 2
    style rel_meter_label:
        variant "small"
        size 18
        min_width 80
    style rel_map_name:
        variant "small"
        size 19
    style rel_map_name_sm:
        variant "small"
        size 15
