## relations.rpy ―― 相関図
##   出会った人だけが、蓮のまわりに出てくる。線は tools/make_relation_lines.py で作った画像。
##   はじめて登場する場面で $ meet("三好") のように呼ぶ。

default met = []

init python:
    def meet(name):
        """相関図に、その人を出すようにする"""
        if name not in store.met:
            store.met = store.met + [name]

    def rel_meter(v):
        """0〜100 の値を、★5つで表す"""
        n = max(0, min(5, int(round(v / 20.0))))
        return "★" * n + "☆" * (5 - n)

## 人物ごとの、絵の中の位置（相関図の紙の左上からの位置。線の画像と同じにする）
##   (名前, id, 位置x, 位置y, 蓮との関係)
define REL_NODES = [
    ("ひなた", "hinata", 100, 45, "幼なじみ・マネージャー"),
    ("千夏", "chika", 455, 45, "生徒会長（2年）"),
    ("紗希", "saki", 810, 45, "港で会った、桜嶺の子"),
    ("母", "mother", 290, 175, "母・はやせ食堂"),
    ("黒田", "kuroda", 620, 175, "顧問（数学の先生）"),
    ("三好", "miyoshi", 100, 235, "キャプテン（3年）"),
    ("神城", "kamishiro", 810, 235, "因縁の相手（桜嶺）"),
    ("大門", "daimon", 100, 425, "GK（1年・元柔道部）"),
    ("鷹野", "takano", 455, 455, "FW（1年・元ジュニアユース）"),
    ("坂口", "sakaguchi", 810, 425, "ゲーセンの5人組（1年）"),
]

screen relations():
    tag menu
    use game_menu("相関図"):
        fixed:
            xysize (910, 572)
            ## 線（出会った人のぶんだけ）
            for nm, rid, x, y, rel in REL_NODES:
                if nm in met:
                    add "gui/relations/line_%s.png" % rid

            ## まん中の蓮（顔の丸アイコン）
            vbox:
                xpos 455
                ypos 285
                anchor (0.5, 0.42)
                spacing 0
                add "gui/talk/avatar/ren.png" xalign 0.5 zoom 0.95
                text "蓮" style "rel_me_text"

            ## まわりの人
            for nm, rid, x, y, rel in REL_NODES:
                if nm in met:
                    vbox:
                        xpos x
                        ypos y - 36
                        xanchor 0.5
                        spacing 0
                        add "gui/talk/avatar/%s.png" % rid xalign 0.5 zoom 0.76
                        text ("坂口たち" if nm == "坂口" else nm) style "rel_name"
                        text rel style "rel_label"
                        if nm in heart:
                            text "ときめき " + rel_meter(heart[nm]["ときめき"]) style "rel_meter"
                            text "信頼　　 " + rel_meter(heart[nm]["信頼"]) style "rel_meter"
                        elif nm in bond:
                            text "絆 " + rel_meter(bond[nm]) style "rel_meter"

            if len(met) == 0:
                text "まだ、だれとも出会っていません。" xalign 0.5 yalign 0.3 color INK_SOFT size 24

## 色やフォント（FONT_JP_B・INK など）は screens.rpy で決めているので、init 1 にしてそのあとで作る
init 1:

    style rel_me_text:
        xalign 0.5
        yalign 0.5
        font FONT_JP_B
        size 26
        color INK
        outlines [(3, "#fffaf2", 0, 0)]

    style rel_name:
        xalign 0.5
        font FONT_JP_B
        size 22
        color INK
        outlines [(3, "#fffaf2", 0, 0)]

    style rel_label:
        xalign 0.5
        size 15
        color "#6e5a3c"
        outlines [(2, "#fffaf2", 0, 0)]

    style rel_meter:
        xalign 0.5
        size 14
        color PEN_RED
        outlines [(2, "#fffaf2", 0, 0)]
