## chapter2.rpy ―― 第2章「泥だらけの夏」（高1・6〜8月）
##   台本：アンイレ 体験版台本（第2章「泥だらけの夏」のタブ）
##   黒田が初めて練習を見る → インターハイ予選で3年ぶりの勝利（PK戦） → 夏合宿 → 潮見港の花火大会で紗希と再会

## 自由行動の日付・時間帯・地図の見出し（6月・7月・8月に2日ずつ）
define CH2_FREE = {
    "jun": (["6月9日（火）", "6月11日（木）"], "放課後", "6月の放課後、どこへ行く？", "インターハイ予選の1回戦まで、放課後は2日。"),
    "jul": (["7月13日（月）", "7月15日（水）"], "放課後", "7月の放課後、どこへ行く？", "夏合宿まで、放課後は2日。"),
    "aug": (["8月5日（水）", "8月7日（金）"], "夏休み", "夏休み、どこへ行く？", "夏休み。夏祭りまでに、自由に動ける日は2日。"),
}

## 自由行動の前に読める「これまでのこと」
define CH2_RECAP = {
    "jun": "5月31日、桜嶺学園Bとの練習試合は0−9。\n最後まで足を止めなかったのは、三好先輩だけだった。\n\n6月。約束どおり、黒田先生が練習を見に来た。\n黒田先生は、元潮見ブルーマリンズの選手。J1で4年プレーして、28歳のとき、ひざのケガで引退した人だった。\n\n全員のポジションが決まった。俺は、真ん中。\nインターハイ予選の1回戦まで、あと少し。",
    "jul": "インターハイ予選1回戦は、白浜工業にPK戦で勝った。港北にとって、3年ぶりの、公式戦の勝利。\n最後の一本を止めたのは、大門だった。\n\n2回戦は、0−3で負けた。\n黒田先生は「夏で変わる」と言って、学校の体育館を借りてきた。7月の終わりに、泊まりこみの合宿がある。\n\n雨の日、部室に、誰かが撮った試合の写真が届いていた。",
    "aug": "7月の終わり、学校の体育館で、2泊3日の合宿をした。\n夜の体育館で、一人ずつ、サッカーをやっている理由を話した。\n\n夏休み。練習のない日が、何日かある。\n8月15日には、二駅先の潮見港で花火大会がある。",
}

## 夏祭りに誘える条件（千夏の「ときめき＋信頼」がこれ以上のときだけ、千夏先輩を誘える）
##   第1章・第2章で一度も生徒会室に行かないと、だいたい10。どちらかで一度行けば届く
define CH2_CHIKA_INVITE = 13

## 無理ゲージがこれ以上のとき、ひざが痛む（ひざの警告）
define CH2_KNEE_WARN = 40

## ひざの警告は、自由行動の最後の日の「次の日」の練習で起きる（その日の夜のトークより後になるように）
define CH2_KNEE_WARN_DATE = {"7月15日（水）": "7月16日（木）", "8月7日（金）": "8月8日（土）"}


default ch2_video = ""
default ch2_day = 1
default ch2_dest = ""
default ch2_pos = ""          # 作戦ボードで言ったこと（center / goal / takano）
default ch2_knee = ""         # ひざのことを、ひなたに正直に言ったか（honest / hide）。第3章・第5章に影響
default ch2_shot = ""         # 残り5分の判断（shoot / onetwo / back）
default ch2_night = ""        # 夜の体育館で話したこと（knee / ouryo / love）
default ch2_koibana = ""      # 合宿1日目の夜の恋バナで答えたこと（hinata / chika / soccer）。千夏が見回りで聞いている
default ch2_invite = ""       # 夏祭りの誘い文句（ひなた：plain / tease / yukata、千夏：plain / photo / yukata、男子：shoot / honest）
default ch2_fest = ""         # 夏祭りに誘った相手（hinata / chika / boys / alone）
default ch2_saki_word = ""    # 満員電車で紗希に言ったこと（long / ok / none）
default ch2_pk = ""           # 蓮のPKのコース（tr / watch / bl）
default ch2_pk_ok = True      # 蓮のPKが決まったか（外れるとサドンデス）
default ch2_shout = ""        # 大門にかけた声（left / right / none）
default ch2_album = ""        # 雨の部室で、写真を見て言ったこと（guess / keep）
default ch2_res = ""          # 自由行動の結果（夜のトークの中身が変わる）
default ch2_2nd = ""          # 2回戦の後半の作戦（attack / hold）。章の終わりの黒田のひとことが変わる
default ch2_2nd_score = "0−3" # 2回戦のスコア（攻めて鷹野の絆が深いと 1−3、耐えてフィジカルが足りると 0−1）
default ch2_miyoshi_cb = ""   # 三好の相談（stay / kiryu）。第3章の選手権のポジションが変わる
default ch2_r = ""            # 夜のトークで選んだ返事
default ch2_first_join = ""   # 第1章でいちばん早く誘った相手（大門 / 鷹野 / 5人組）。6月1日の20周で一言だけ出る

init python:
    ## 行動マップの行き先。学校の中と港があるので、町の地図に出す
    ##   タグは横に約270ピクセルあるので、重ならないように散らしている
    ##   label は行き先で読むラベル。一度行ったら（済み）になる。グラウンドの練習だけは何度でも行ける
    CH2_SPOTS = {
        "jun": [
            ("council", "生徒会室", 640, 110, "chika", "千夏", "ch2_council"),
            ("clubroom", "部室", 520, 250, "daimon", "大門", "ch2_daimon"),
            ("roof", "屋上", 330, 45, "takano", "鷹野", "ch2_takano"),
        ],
        "jul": [
            ("council", "生徒会室", 640, 110, "chika", "千夏", "ch2_chika_key"),
            ("staff", "職員室", 520, 250, "kuroda", "黒田", "ch2_kuroda_quiz"),
            ("arcade", "駅前のゲーセン", 1050, 120, "sakaguchi", "坂口たち", "ch2_arcade"),
            ("slope", "港への坂道", 870, 330, "hinata", "ひなた", "ch2_hinata_dream"),
        ],
        "aug": [
            ("night", "夜のグラウンド", 290, 130, "takano", "鷹野", "ch2_takano_night"),
            ("council", "生徒会室", 740, 75, "chika", "千夏", "ch2_chika_summer"),
            ("clubroom", "部室", 600, 170, "miyoshi", "三好", "ch2_miyoshi_summer"),
            ("judo", "柔道場", 480, 250, "daimon", "大門", "ch2_daimon_judo"),
            ("shokudo", "はやせ食堂", 850, 460, "hinata", "ひなた・母", "ch2_shokudo"),
        ],
    }

    def ch2_spots(month="jun"):
        f = store.flags
        out = []
        for sid, name, x, y, face, ev, lab in CH2_SPOTS[month]:
            done = (lab != "ch2_practice") and f.get(lab)
            d = {"id": sid, "name": name, "x": x, "y": y,
                 "event": "" if done else ev, "enabled": not done}
            if face:
                d["face"] = face
            out.append(d)
        return out

    def ch2_spot_label(month, sid):
        for s in CH2_SPOTS[month]:
            if s[0] == sid:
                return s[6]
        return "ch2_practice"

    ## 作戦ボード：4−4−2 の11人（青が港北。右へ攻める。画面の下側が右サイド）
    CH2_442 = [
        ("h", "大門", (5, 34)),
        ("h", "三好", (18, 41)), ("h", "桐生", (18, 27)), ("h", "宮下", (24, 11)),
        ("h", "森", (24, 57)), ("h", "坂口", (46, 59)), ("h", "小池", (36, 34)), ("h", "江藤", (46, 9)),
        ("h", "鷹野", (70, 42)), ("h", "野口", (70, 26)),
        ("ren", "蓮", (52, 34)),
    ]

    def ch2_board(n, caption="港北　4−4−2"):
        """作戦ボードに、CH2_442 の最初の n 人を並べる（{rb}黒田{/rb}{rt}くろだ{/rt}が一つずつ置いていく）"""
        tactics(dots=CH2_442[:n], caption=caption)


label chapter2:
    scene black
    with Dissolve(1.0)
    call show_title("第2章", "泥だらけの夏")

    ############################################################################
    ## シーン1：黒田の作戦ボード（6月1日・月曜）
    ############################################################################
    $ set_cal("6月1日（月）", "放課後")
    scene bg kohoku_ground_eve
    with dissolve
    $ bgm("とぼけた日常の曲")

    "月曜日。{rb}黒田{/rb}{rt}くろだ{/rt}は、本当に来た。"
    $ se("サンダルが土をこする音")
    "よれたジャージにサンダル。脇に、緑色の板を抱えている。"
    show kuroda board
    with dissolve
    kuroda "集まれ"
    show miyoshi smile at right
    with dissolve
    miyoshi "はいっ！　全員集合ー！"
    voice "audio/voice/kuroda_koe.mp3"
    kuroda "……{rb}三好{/rb}{rt}みよし{/rt}。声がでかい"
    hide miyoshi
    with dissolve
    "黒田がグラウンドの隅に立てかけたのは、マグネットの作戦ボードだった。"
    "緑の盤面に、白いチョークのライン。端が少しさびている。"
    kuroda "11人いる。だから、今日から11人の場所を決める"
    kuroda "インターハイ予選の1回戦は、27日の土曜だ。それまでに形にする"
    "黒田は、青いマグネットを一つ、ゴールの前に置いた。"

    hide kuroda
    with dissolve
    $ ch2_board(1)
    kuroda "キーパー、{rb}大門{/rb}{rt}だいもん{/rt}"
    voice "audio/voice/daimon_hai.mp3"
    daimon "は、はいっ！"
    kuroda "受け身だけは柔道部でいちばんだったそうだな。倒れるのが怖くないやつは、キーパーに向いてる"
    daimon "……倒れるのは、慣れてます"
    kuroda "ボールが怖いのは、そのうち慣れる"

    "黒田は、ゴール前のすぐ上に、もう一つマグネットを置いた。"
    $ ch2_board(2)
    kuroda "センターバック、三好"
    miyoshi "俺がですか！？　俺、技術ないですよ！"
    kuroda "知ってる。0−9の試合、最後まで走ってたのはお前だけだ"
    kuroda "いちばん走るやつを、いちばん後ろに置く。抜かれても、追いつけるからな"
    $ learn("cb")
    voice "audio/voice/miyoshi_yosha.mp3"
    miyoshi "……っしゃあ！"
    $ ch2_board(4)
    kuroda "その隣に{rb}桐生{/rb}{rt}きりゅう{/rt}。左のサイドバックに{rb}宮下{/rb}{rt}みやした{/rt}"
    ## 2年の2人を、作戦ボードの左右に一度だけ出す（顔と名前を覚えてもらう）
    show kiryu jersey at gang(0.11)
    show miyashita jersey at gang(0.89)
    with dissolve
    kiryu "……名前だけの部員だったのに"
    miyashita "ふふっ……ごめん。ちゃんと場所あるんだと思ったら"
    $ learn("sb")

    hide kiryu
    hide miyashita
    with dissolve
    "黒田は、ゲーセンの5人組のほうを向いた。"
    kuroda "お前ら。ゲームでは、どこをやってる"
    sakaguchi "は？"
    kuroda "サッカーのゲームだ。毎日やってるんだろう"
    ## ゲーセンの5人組を、ここで一度だけ並べて見せる（顔と名前を覚えてもらう）
    $ tactics_off()
    show sakaguchi jersey at gang(0.12)
    show mori jersey at gang(0.31)
    show eto jersey at gang(0.50)
    show koike jersey at gang(0.69)
    show noguchi jersey at gang(0.88)
    with dissolve
    "5人が顔を見合わせた。"
    sakaguchi "……俺は右サイド。上がりっぱなしで、ずっとクロス上げてる"
    mori "右のサイドバック。{rb}坂口{/rb}{rt}さかぐち{/rt}が上がりっぱなしだから、俺がずっと尻ぬぐいしてます"
    eto "左サイド。……ドリブルしかしない"
    koike "真ん中の後ろのほうっす。パスを散らす係"
    noguchi "前。点を取る係。取ったことないけど"
    kuroda "じゃあ、それでいい"
    voice "audio/voice/sakaguchi_maji.mp3"
    sakaguchi "……は？　マジで？"
    kuroda "ゲームでも、自分がどこにいると気持ちいいかは分かってる。それで十分だ"
    hide sakaguchi
    hide mori
    hide eto
    hide koike
    hide noguchi
    with dissolve
    "5人のうち4人のマグネットが、ボードの上に並んでいく。"
    $ ch2_board(8)
    voice "audio/voice/sakaguchi_ukeru.mp3"
    sakaguchi "……ウケる。ゲームと同じじゃん"

    "黒田の手が、最後の三つのマグネットで止まった。"
    $ ch2_board(10)
    kuroda "フォワード、{rb}鷹野{/rb}{rt}たかの{/rt}と野口"
    takano "……当然だろ"
    kuroda "そして、{rb}早瀬{/rb}{rt}はやせ{/rt}"
    $ ch2_board(11)
    "赤い輪のついたマグネットが、ボードのど真ん中に置かれた。"
    kuroda "真ん中だ"
    ren "……トップ下じゃなくて、ですか"
    $ learn("top_shita")
    kuroda "お前は前を向いてボールを持つと、見る前に全部見えてる。そういうやつは、真ん中に置く。全員にボールを配れ"
    kuroda "それに、そのひざだ。前で削られるより、真ん中で受けて、はたけ"
    "4−4−2。11個のマグネットが、緑の盤面に並んだ。"
    $ learn("f442")
    $ learn("cmf")
    $ tactics_off()
    $ set_flag("名鑑")

    show kuroda board
    with dissolve
    menu:
        "真ん中で、全員を動かします":
            $ ch2_pos = "center"
            $ lean("求道型")
            $ up("戦術眼", 3)
            kuroda "それでいい"
            "黒田は、それ以上何も言わなかった。新聞をかぶらずに、最後まで練習を見ていた。"
        "俺は、前で点を取りたいです":
            $ ch2_pos = "goal"
            $ lean("野心型")
            $ up("技術", 3)
            kuroda "取りたきゃ、真ん中から走って取れ。それくらいの体力はつけろ"
            kuroda "……前に出たがるやつは、嫌いじゃない"
        "鷹野に、全部つなぎます":
            $ ch2_pos = "takano"
            $ lean("仲間型")
            $ bond_up("鷹野", 5)
            show takano jersey at right
            with dissolve
            voice "audio/voice/takano_chi.mp3"
            takano "……は？　勝手に決めんな"
            "鷹野は顔をそむけた。でも、そのマグネットを、少しだけ前にずらしていた。"
            hide takano
            with dissolve

    ## 一本だけのキック
    show sakaguchi jersey at right
    with dissolve
    sakaguchi "てかさ、先生ってサッカーできんの？"
    "空気が止まった。"
    miyoshi "{rb}坂口{/rb}{rt}さかぐち{/rt}！"
    sakaguchi "だってさ、ずっと新聞かぶって寝てる人じゃん"
    hide sakaguchi
    with dissolve
    "黒田は、何も言わずにボールを一つ拾った。"
    $ bgm("（止まる）")
    "サンダルのまま。"
    show kuroda normal
    kuroda "早瀬、鷹野。あのゴールの、右上の角に立て"
    hide kuroda
    with dissolve
    "言われたとおりに走る。グラウンドの反対側。50メートル以上ある。"
    "振り返ると、黒田はボールを土の上に置いて、空を見ていた。"
    "風の向きを、見ていたのかもしれない。"
    "グラウンドから、音が消えた。"
    "黒田は助走もしなかった。"
    "左足を引きずったまま、右足を、ただ振った。"
    $ se("ボールを蹴る音")
    $ bgm("見せ場の曲")
    scene cg kuroda_kick at cam_push(3.0, 1.06)
    with flash
    with vpunch
    "サンダルが、夕焼けに跳ね上がった。"
    "眠そうな目のままなのに、蹴り足だけが、教科書の絵みたいにきれいだった。"
    scene bg kohoku_ground_eve at cam_push(4.0, 1.12)
    with dissolve
    show screen speedlines
    "ボールは、低く、まっすぐ伸びてきた。"
    "途中で、ぐんと曲がる。"
    "俺と鷹野が同時に跳んだ。"
    hide screen speedlines
    $ se("ネットが揺れる音")
    scene cg kuroda_kick_goal at cam_push(5.0, 1.05)
    with hpunch
    "どっちの頭にも当たらず、ボールはゴールの右上、ネットの角に突き刺さった。"
    "坂口の口が、開いたまま閉じなかった。"
    "三好先輩も、鷹野も、誰も、何も言えなかった。"
    scene bg kohoku_ground_eve
    with dissolve
    $ bgm("（止まる）")
    show kuroda yawn
    with dissolve
    voice "audio/voice/kuroda_fuaa.mp3"
    kuroda "……今日は、走るだけだ。グラウンド20周"
    show sakaguchi jersey at right
    with dissolve
    sakaguchi "うそだろ！？"
    $ set_flag("黒田_一本")

    ## 第1章で早く誘った相手ほど、4月から練習に来ていたぶん、少し先に進んでいる（chapter1.rpy の ch1_join）
    ##   1日目に誘った相手は絆 +3、2日目は +2、3日目は +1。誘いに行かなかった相手（4）は変わらない
    hide kuroda
    hide sakaguchi
    with dissolve
    python:
        ch2_first_join = ""
        _best = 4
        for _key, _who in (("大門", "大門"), ("鷹野", "鷹野"), ("5人組", "坂口")):
            _d = ch1_join.get(_key, 4)
            if _d <= 3:
                bond_up(_who, 4 - _d)
                if _d < _best:
                    _best = _d
                    ch2_first_join = _key
    if ch2_first_join == "大門":
        "20周のあいだ、いちばん前を走っていたのは{rb}大門{/rb}{rt}だいもん{/rt}だった。"
        "4月、誰より先にグラウンドに来て、それから毎日来ていたやつだ。"
    elif ch2_first_join == "鷹野":
        "{rb}鷹野{/rb}{rt}たかの{/rt}は、20周走っても、息ひとつ乱していなかった。"
        "4月、誰より先に来て、文句を言いながら、いちばん長くボールを蹴ってきたやつだ。"
    elif ch2_first_join == "5人組":
        "{rb}坂口{/rb}{rt}さかぐち{/rt}たちは、文句を言いながら、20周のあいだ一人も歩かなかった。"
        "4月、誰より先に、パーカーのまま走りはじめた5人だ。"
    "20周を走り終わるころには、空はすっかり暗くなっていた。"

    ## その夜のトーク
    scene black
    with dissolve
    $ set_cal("6月1日（月）", "夜")
    scene bg ren_room_night
    with dissolve
    $ bgm("静かな夜の曲")
    $ se("トークアプリの通知音（連続）")
    window auto hide
    $ talk_start("港北サッカー部（12）", "22:07")
    $ talk("鷹野", "黒田修司")
    $ talk("鷹野", "元潮見ブルーマリンズ。J1で4年")
    $ talk("鷹野", "28で引退。ひざのケガ")
    $ talk("坂口", "は？？？？？？")
    $ talk("三好", "すげええええええ！！")
    $ talk("大門", "サ、サインもらったほうがいいですか")
    $ talk("桐生", "数学の先生じゃなかったの")
    "{rb}鷹野{/rb}{rt}たかの{/rt}が、グループに何かを書きこんだのは、これが初めてだった。"
    "既読の数が、また11になった。"
    window auto hide
    $ talk_end()
    "ひざのケガ。28歳。"
    "左足を引きずる黒田の背中を、思い出していた。"
    $ bond_up("鷹野", 3)
    $ set_flag("黒田の過去", flags.get("黒田の過去", 0) + 1)   # 第1章で職員室に行っていれば、もう1つ進んでいる

    ## 同じ夜、千夏からの最初のトーク（ビデオ通話の事故）と、次の朝の校門
    call ch2_chika_videocall

    ############################################################################
    ## シーン2：6月の自由行動（2日）
    ############################################################################
    call ch2_free_loop("jun")

    ############################################################################
    ## シーン3：ひざ（6月中旬）
    ############################################################################
    scene black
    with dissolve
    $ set_cal("6月17日（水）", "放課後")
    scene bg kohoku_ground_eve
    with dissolve
    $ bgm("静かなピアノ")

    "練習の終わり。"
    "ダッシュの最後の一本で、右ひざの奥が、きしんだ。"
    $ learn("knee")
    "痛い、というほどじゃない。"
    "冬に、ぷつんと何かが切れた、あの場所の近くだ。"
    show hinata serious
    with dissolve
    hinata "……{rb}蓮{/rb}{rt}れん{/rt}。今、右足かばったでしょ"
    ren "かばってない"
    hinata "かばった。10年見てるんだから、分かるよ"
    "ひなたは、俺のひざの前にしゃがみこんだ。"

    menu:
        "……少し痛い。正直に言う":
            $ ch2_knee = "honest"
            $ heart_up("ひなた", "信頼", 8)
            $ up("無理ゲージ", -6)
            voice "audio/voice/hinata_un_soft.mp3"
            hinata "……うん"
            hinata "言ってくれて、ありがと"
            "ひなたは、カバンから湿布とテーピングを出した。いつのまにか、ちゃんとした巻き方を覚えている。"
            hinata "{rb}黒田{/rb}{rt}くろだ{/rt}先生にも、言っとくね。メニュー、少し変えてもらう"
            ren "……それは"
            show hinata stare
            hinata "言っとくね"
            "怒ると怖いのは、昔から変わらない。"
        "大丈夫だって。黙って練習を続ける":
            $ ch2_knee = "hide"
            $ up("技術", 3)
            $ up("無理ゲージ", 8)
            $ heart_up("ひなた", "さみしさ", 5)
            show hinata forcesmile
            hinata "……そっか"
            hide hinata
            with dissolve
            "ひなたは立ち上がって、何も言わずにストップウォッチを首にかけ直した。"
            "その夜、玄関に湿布が一箱だけ置いてあった。"
            "メモも何もなかった。"
    $ set_flag("ch2_knee", ch2_knee)

    ############################################################################
    ## シーン4：3年ぶりの勝利（6月下旬・インターハイ予選1回戦）
    ##   朝の集合 → 黒田のマイクロバスで会場へ（車内で背番号10） → 県営グラウンド
    ############################################################################
label ch2_match_morning:      # テスト用の目印（コンソールで jump ch2_match_morning）
    scene black
    with dissolve
    $ set_cal("6月27日（土）", "インターハイ予選1回戦の朝")
    scene bg kohoku_gate_rain
    with Dissolve(1.0)
    $ se("雨の音")
    $ bgm("明るい部活の曲")

    "朝7時。校門の前に、傘が12本並んでいた。"
    "11人と、ひなた。5月の練習試合の朝と、同じ顔ぶれだ。梅雨の細い雨まで、あの日と同じだった。"
    "ちがうのは、今日が公式戦だということだけだ。"
    show hinata proud
    with dissolve
    "ひなたの肩には、あの大きな保冷バッグがかかっていた。"
    hinata "全員ぶんのおにぎり。今日は3時半起き"
    ren "……記録更新だな"
    hinata "ほめていいよ"
    ren "すごいな"
    show hinata smile
    hinata "うん。知ってる"
    hide hinata
    with dissolve
    "古いエンジンの音がして、あの白いマイクロバスが、校門の前に止まった。"
    "今日は、車体に泥はねがなかった。誰かが洗ったらしい。"
    show kuroda normal
    with dissolve
    kuroda "乗れ"
    "運転席の足もとに、使いこんだスポンジが一つ転がっていた。"
    hide kuroda
    with dissolve

    ## 会場へ向かうバス：三好の校歌と、背番号10（第3章で、神城が触れる）
    scene bg bus_rain at cam_jog
    with dissolve
    $ bgm("とぼけた日常の曲")
    "ワイパーが、ぎこぎこと鳴りはじめて、5分もしないうちに。"
    "{rb}三好{/rb}{rt}みよし{/rt}先輩が、また校歌を歌い出した。"
    "今度は、{rb}大門{/rb}{rt}だいもん{/rt}が小さな声でついていった。"
    "{rb}坂口{/rb}{rt}さかぐち{/rt}たちは、スマホで歌詞を調べながら、半分だけついていった。"
    show miyoshi smile
    with dissolve
    miyoshi "調べるなよ！　覚えろよ！"
    show sakaguchi jersey at right
    with dissolve
    sakaguchi "先輩も、2番の歌詞まちがえてたっすよ"
    miyoshi "……えっ"
    hide sakaguchi
    with dissolve
    "歌い終わると、三好先輩は、座席の足もとから段ボールを引っぱり出した。"
    miyoshi "公式戦用のユニフォームだ！　3年ぶりに、箱から出す！"
    "5月の練習試合は、番号がばらばらの古いユニフォームを、適当に着ただけだった。"
    "公式戦には、背番号がいる。メンバー表は、会場の受付で出すらしい。"
    "青い生地は、少し色あせていた。それでも、背中には白い番号がちゃんとついている。"
    miyoshi "ポジションの順に配るぞ。1番、{rb}大門{/rb}{rt}だいもん{/rt}！　2番は俺！"
    "揺れる車内で、1枚ずつ、名前が呼ばれていく。"
    "最後に、2枚が残った。"
    "8番と、10番。"
    miyoshi "8と10は、取っといた"
    miyoshi "10番は、蓮だろ！　{rb}潮見{/rb}{rt}しおみ{/rt}FCの10番！"
    show takano jersey_narrow at right
    with dissolve
    "いちばん後ろの窓際で、{rb}鷹野{/rb}{rt}たかの{/rt}がこっちを見ていた。"
    "何も言わない。でも、目は10番から離れなかった。"
    "10番。中学の3年間、背中にあった数字だ。"
    "中学最後の決勝でも、俺はこの数字をつけていた。"
    menu:
        "「10番は、俺がつける」":
            $ set_flag("背番号10", "ren")
            $ lean("野心型")
            $ bond_up("鷹野", -2)
            $ up("メンタル", 2)
            ren "真ん中から、点も取る。そういう番号だろ"
            takano "……ちっ。まあいい"
            takano "点取って、どっちがエースか分からせてやる"
        "「10番は鷹野だ。点を取るやつの番号だ」":
            $ set_flag("背番号10", "takano")
            $ lean("仲間型")
            $ bond_up("鷹野", 5)
            "10番を、いちばん後ろの席へ放った。"
            show takano jersey_surprised at right
            takano "……は？"
            ren "俺は8番でいい。全員に配る番号だ"
            show takano jersey_narrow at right
            takano "……返さねえぞ"
            "鷹野は、ユニフォームを丸めて、カバンのいちばん奥に押しこんだ。"
    hide takano
    hide miyoshi
    with dissolve
    "窓の外に、土手と、緑のフェンスが見えてきた。"
    "雨は、いつのまにか上がっていた。"
    "バスが止まった。"
    $ amb_stop()

    ## 会場に着く
label ch2_match:      # 試合のテスト用の目印（コンソールで jump ch2_match）
    $ set_cal("6月27日（土）", "インターハイ予選1回戦　対 白浜工業")
    scene bg pref_ground_day
    with Dissolve(1.0)
    $ bgm("緊迫した試合の曲")

    "県営グラウンドは、土だった。"
    "{rb}桜嶺{/rb}{rt}おうりょう{/rt}の芝とはちがう。{rb}港北{/rb}{rt}こうほく{/rt}のグラウンドと同じ、雨上がりの土の匂いがした。"
    "インターハイ予選、1回戦。相手は県立{rb}白浜{/rb}{rt}しらはま{/rt}工業。"
    $ learn("interhigh")
    "去年は2回戦まで進んだチームだ。"
    "{rb}港北{/rb}{rt}こうほく{/rt}が公式戦に出るのは、3年ぶりらしい。"
    "スタンドというほどのものはない。土手に、何人かの保護者が座っているだけだ。"
    "保護者にまじって、妹のゆずが、ひざを抱えて座っていた。俺の試合は、どこでやっても全部見に来る。"
    "土手のいちばん端に、日傘をさした生徒が一人いた。"
    "首から、古いフィルムカメラを下げている。"
    "……{rb}千夏{/rb}{rt}ちか{/rt}先輩？"
    "目が合いそうになった瞬間、日傘が傾いて顔が隠れた。"

    ## キックオフ。黒帯とスコアボード（港北 青／白浜工業 黄）
    $ se("キックオフの笛")
    $ sb_set("前半", 0, 0, 0, 0, "#2a5bd7", "#e8c43a")
    scene bg pref_ground_day at cam_jog
    with dissolve
    show screen letterbox
    show screen scoreboard

    "前半12分。"
    scene bg pref_ground_day at cam_snap(1.15)
    with hpunch
    $ goal("白浜工業", away=1, mm=12)
    "先制された。"
    voice "audio/voice/daimon_sumimasen.mp3"
    daimon "す、すみませんっ！"
    miyoshi "いい！　今のは俺が抜かれた！　次だ次！"
    "前半は、0−1のまま終わった。"

    $ se("前半終了の笛")
    $ sb_set("後半", 18)
    scene bg pref_ground_day at cam_pan_r(10.0)
    with dissolve
    "後半18分。"
    "{rb}坂口{/rb}{rt}さかぐち{/rt}が、右サイドを上がりっぱなしで走る。"
    "ゲームと同じだ。本当に、ずっと上がりっぱなしだ。"
    voice "audio/voice/sakaguchi_kocchi.mp3"
    sakaguchi "{rb}蓮{/rb}{rt}れん{/rt}！　こっち！"
    $ tactics(caption="後半18分　0−1", dots=[
        ("h", "大門", (5, 34)), ("h", "三好", (34, 40)), ("h", "", (34, 26)),
        ("h", "小池", (46, 34)), ("h", "江藤", (66, 12)),
        ("h", "坂口", (66, 58), (86, 60), 0.5, 1.0),
        ("h", "鷹野", (78, 40), (90, 36), 1.4, 0.7),
        ("a", "", (82, 30)), ("a", "", (84, 44)), ("a", "", (72, 52)),
        ("a", "", (62, 28)), ("a", "", (100, 34)),
        ("ren", "蓮", (58, 36)),
        ("ball", "", (59.5, 37.5), (86, 58), 0.3, 0.6),
        ],
        arrows=[((60, 38), (85, 58), 0.2, "y"), ((86, 60), (92, 36), 1.3, "y")])
    "真ん中で受けて、前を向く。見えている。"
    "右へ、はたく。――軽く、短く出す。"
    $ tactics_off()
    $ se("ボールを蹴る音")
    scene bg pref_ground_day at cam_snap(1.2, 0.6, 0.3)
    with flash
    "坂口のクロスに、{rb}鷹野{/rb}{rt}たかの{/rt}が頭から飛びこんだ。"
    $ goal("港北", home=1)
    with vpunch
    miyoshi "うおおおおおお！！"
    sakaguchi "入った！？　今の入った！？　俺のクロス！？"
    "鷹野は、何も言わずに自陣に戻っていく。"
    "でも、すれ違いざまに、俺の背中をぽんとたたいた。"
    "3年ぶりの、公式戦のゴールだった。"
    $ learn("cross")

    ## 残り5分
    $ bgm("試合の曲（終盤）")
    $ sb_set(mm=35)
    scene bg pref_ground_day at cam_push(6.0, 1.15)
    with dissolve
    "後半35分。1−1。"
    "相手の足も、こっちの足も止まりかけている。"
    $ se("ボールが転がる音")
    "ボールが、真ん中の俺に転がってきた。"
    show screen speedlines
    $ tactics(caption="後半35分　1−1", dots=[
        ("h", "大門", (5, 34)), ("h", "三好", (46, 40)), ("h", "坂口", (70, 60)),
        ("h", "小池", (50, 28)), ("h", "江藤", (68, 10)),
        ("h", "鷹野", (76, 44), (79, 45), 0.4, 0.8),
        ("a", "", (82, 20), (88, 21), 0.3, 1.2), ("a", "", (82, 30), (88, 30), 0.3, 1.2),
        ("a", "", (82, 40), (88, 40), 0.3, 1.2), ("a", "", (82, 52), (88, 52), 0.3, 1.2),
        ("a", "", (68, 30), (64, 33), 0.5, 0.8),
        ("a", "", (102, 34)),
        ("ren", "蓮", (60, 36)),
        ("ball", "", (61.5, 37.5)),
        ],
        arrows=[((82, 30), (88, 30), 0.2, "w"), ((76, 44), (86, 46), 0.6, "w"),
                ((46, 40), (52, 40), 0.8, "w")])
    "右に鷹野。後ろに{rb}三好{/rb}{rt}みよし{/rt}先輩。"
    "相手の最終ライン――いちばんうしろのDFの列が、じりじりと下がっていく。"
    $ learn("last_line")
    hide screen speedlines
    $ tactics_off()

    menu:
        "自分で撃つ":
            $ ch2_shot = "shoot"
            $ lean("野心型")
            $ up("技術", 3)
            "一人かわす。二人目が、肩から体を入れてくる。"
        "鷹野とワンツー":
            $ ch2_shot = "onetwo"
            $ lean("仲間型")
            $ bond_up("鷹野", 5)
            "鷹野に当てて、走る。戻ってきたボールは、ちょうど一歩先に転がってきた。"
            $ learn("onetwo")
        "三好先輩に下げて、裏に走る":
            $ ch2_shot = "back"
            $ lean("求道型")
            $ up("戦術眼", 3)
            $ bond_up("三好", 4)
            "三好先輩の、不格好なロングボール。それでも、走りこんだ場所にぴたりと落ちてきた。"

    scene bg pref_ground_day at cam_snap(1.25, 0.5, 0.35)
    with dissolve
    if ch2_shot == "shoot":
        ## 自分で撃つ：キーパーの指先
        "倒れながら、右足を振り抜いた。"
        $ se("ボールを蹴る音")
        "ゴールの右上。――入る。"
        with vpunch
        "キーパーの指先が、ほんの数センチ、ボールに触れた。"
        "ボールはバーの上を越えて、ゴールの裏に落ちた。"
        miyoshi "うあああ！　今の、指だけかよ！"
        "コーナーキックは、相手の頭にはね返された。"
    elif ch2_shot == "back":
        ## 三好先輩に下げて裏へ：ポスト
        "キーパーと、一対一。"
        $ se("ボールを蹴る音")
        "ゴールの左下に、流しこんだ。"
        $ se("ボールがポストに当たる音")
        with vpunch
        "――カン、と乾いた音。"
        "ボールは、ポストの内側をなめて、外に転がっていった。"
        miyoshi "あああ！　今の、俺のパスは完璧だったのに！"
        ren "……すみません"
    else:
        ## 鷹野とワンツー：入ったのに、オフサイド
        "キーパーと、一対一。"
        $ se("ボールを蹴る音")
        "ゴールの左下に、流しこんだ。"
        $ se("ネットが揺れる音")
        with vpunch
        "入った。"
        $ bgm("（止まる）")
        "両手を上げて振り返る。三好先輩が、こっちに走ってくる。"
        "その向こうで――"
        "副審の旗が、ゆっくりと上がっていた。"
        $ se("笛の音")
        shinpan "オフサイド"
        ren "……は？"
        miyoshi "うそだろ！？　今の出てなかったって！"
        "抗議しても、旗は下がらない。"
        "副審は、プレーが終わるまで旗を上げるのを待っていた。"
        "最初から、出ていたんだ。"
    "スコアボードは、1−1のまま動かなかった。"
    $ sb_set(mm=40)
    $ se("試合終了の笛")
    "1−1。PK戦。"

    ## PK戦
    hide screen scoreboard
    scene bg pref_ground_eve
    with Dissolve(1.0)
    $ bgm("緊迫した試合の曲")
    "この日、港北の試合は、会場の最後の第4試合だった。グラウンドの影が、もう長く伸びていた。"
    show kuroda normal
    with dissolve
    kuroda "蹴る順番を決める。鷹野、坂口、三好、{rb}小池{/rb}{rt}こいけ{/rt}、{rb}早瀬{/rb}{rt}はやせ{/rt}"
    show sakaguchi match at right
    with dissolve
    sakaguchi "……俺！？"
    kuroda "クロスを上げたやつが、いちばん足が振れてる"
    hide kuroda
    with dissolve
    if ch2_shot == "onetwo":
        sakaguchi "……てかさ、オフサイドって何？　ゲームだと、勝手に笛が鳴るからさ"
    else:
        sakaguchi "……てかさ、今日、向こうの旗が何回も上がってたじゃん。オフサイドって何？　ゲームだと、勝手に笛が鳴るからさ"
    show hinata serious at left
    with dissolve
    hinata "パスが出た瞬間に、相手のいちばん後ろのDFより、ゴールに近いところにいたら反則"
    if ch2_shot == "onetwo":
        hinata "{rb}蓮{/rb}{rt}れん{/rt}は、パスが出たとき、半歩だけ前にいたの"
        ren "……半歩か"
    else:
        hinata "{rb}野口{/rb}{rt}のぐち{/rt}くん、今日だけで4回取られてたよ"
        noguchi "……点取る係だからな。前にいるのが仕事なんだよ"
        hinata "前にいすぎるのが、反則なの"
    sakaguchi "むず。ゲームのほうが優しいじゃん"
    $ learn("offside")
    hide hinata
    hide sakaguchi
    with dissolve

    $ pk_reset("港北", "白浜工業")
    "コイントスで、港北が先に蹴ることになった。"
    $ learn("pk_shootout")
    call pk_shot("home", "港北　1人目　鷹野", "mid_hi", "goal")
    "港北の1人目、鷹野。ど真ん中に、思いきり。決める。"
    call pk_shot("away", "白浜工業　1人目", "bl", "goal")
    "白浜工業の1人目。決める。"
    call pk_shot("home", "港北　2人目　坂口", "br", "save")
    "港北の2人目、坂口。キーパーに止められる。"
    sakaguchi "……ごめん"
    "坂口は、しゃがみこんで顔を上げなかった。"
    call pk_shot("away", "白浜工業　2人目", "post_r", "post")
    "白浜工業の2人目。ポストに当たって外れる。"
    daimon "……あ、当たった"
    call pk_shot("home", "港北　3人目　三好", "bl", "goal")
    "港北の3人目、{rb}三好{/rb}{rt}みよし{/rt}先輩。左下へ、思いきり。決める。"
    call pk_shot("away", "白浜工業　3人目", "tr", "goal")
    "白浜工業の3人目。決める。"
    call pk_shot("home", "港北　4人目　小池", "tl", "goal")
    koike "……たぶん、入った"
    sakaguchi "入ってるって！　見ろよ！"
    call pk_shot("away", "白浜工業　4人目", "br", "goal")
    "白浜工業の4人目。決める。"
    "3−3。"
    scene bg pk_home_eve at cam_push(6.0, 1.08)
    with dissolve
    "港北の5人目。俺の番だった。"
    "ボールを、ペナルティマークに置く。"
    "キーパーが、両手を広げた。"

    ## コースを選ぶ。能力が足りないと外れる（外れたらサドンデスへ）
    menu:
        "思いきり、右上に":
            $ ch2_pk = "tr"
            $ lean("野心型")
            $ ch2_pk_ok = check("技術", 45)
        "キーパーが動くのを、最後まで見る":
            $ ch2_pk = "watch"
            $ lean("求道型")
            $ ch2_pk_ok = check("戦術眼", 50)
        "坂口のぶんまで、確実に左下へ":
            $ ch2_pk = "bl"
            $ lean("仲間型")
            $ bond_up("坂口", 4)
            $ ch2_pk_ok = check("メンタル", 41)

    if ch2_pk_ok:
        if ch2_pk == "tr":
            call pk_shot("home", "港北　5人目　早瀬", "tr", "goal")
            "右足を、思いきり振り抜いた。ボールは、右上の角に突き刺さった。"
        elif ch2_pk == "watch":
            call pk_shot("home", "港北　5人目　早瀬", "br", "goal")
            "キーパーが、先に左へ動いた。その逆へ、そっと流しこんだ。"
            $ up("戦術眼", 2)
        else:
            call pk_shot("home", "港北　5人目　早瀬", "bl", "goal")
            "坂口のぶんまで。確実に、左下へ。"
        "4−3。"
        "相手の5人目が決めれば、4−4。外せば、港北の勝ちだ。"
    else:
        if ch2_pk == "tr":
            call pk_shot("home", "港北　5人目　早瀬", "bar", "post")
            "強すぎた。ボールはクロスバーをたたいて、空へ消えた。"
        elif ch2_pk == "watch":
            call pk_shot("home", "港北　5人目　早瀬", "bl", "save")
            "キーパーは、最後まで動かなかった。……読まれていた。"
        else:
            call pk_shot("home", "港北　5人目　早瀬", "bl_center", "save")
            "置きにいったボールは、キーパーの正面だった。"
        "3−3のまま。"
        "相手の5人目が決めれば、終わりだ。"
        miyoshi "下向くな、蓮！　まだ終わってない！"
        call pk_shot("away", "白浜工業　5人目", "over", "post")
        "相手の5人目のボールは、大きく枠の上に外れた。"
        "3−3。サドンデス。"
        call pk_shot("home", "港北　6人目　江藤", "br", "goal")
        eto "……ドリブルしかしないって、言ったのに"
        "{rb}江藤{/rb}{rt}えとう{/rt}は、キーパーをぎりぎりまで見て、逆に流しこんだ。"
        "4−3。"
        "相手の6人目が決めれば、また並ぶ。外せば、港北の勝ちだ。"
        $ up("メンタル", 2)

    scene bg pk_away_eve at cam_push(8.0, 1.06)
    with dissolve
    "{rb}大門{/rb}{rt}だいもん{/rt}が、ゴールの前に立った。"
    "両腕が、遠くからでも分かるくらい震えている。"
    miyoshi "大門！　倒れるのは慣れてるんだろ！"
    voice "audio/voice/daimon_hai.mp3"
    daimon "は、はいっ！"

    ## 大門に、声をかける
    menu:
        "「左だ！」":
            $ ch2_shout = "left"
            ren "大門、左だ！"
            $ bond_up("大門", 4)
            if check("戦術眼", 48):
                "キッカーの軸足が、少し左に開いていた。間違いない。"
                $ up("戦術眼", 1)
        "「右だ！」":
            $ ch2_shout = "right"
            ren "大門、右だ！"
        "何も言わない。信じる":
            $ ch2_shout = "none"
            $ bond_up("大門", 4)
    "大門は、一度、目を閉じた。"
    "そして、開けた。"
    $ se("ボールを蹴る音")
    $ renpy.hide_screen("pk_board")
    scene cg daimon_pk at cam_snap(1.08, 0.6, 0.4)
    with flash
    "左。"
    if ch2_shout == "right":
        "大門は、俺の声とは逆に飛んだ。"
    "大門の大きな体が、倒れるように左へ飛んだ。"
    "受け身の、きれいな形だった。"
    $ learn("gk_dive")
    $ se("鈍い衝突音")
    "ボールが、大門の腕に当たって、外に転がっていった。"
    $ pk_kick("away", False, kick=False)
    $ se("試合終了の笛")
    $ win("港北", "PK 4−3")
    pause 1.0
    voice "audio/voice/daimon_tomatta.mp3"
    daimon "……と、止まった……？"
    $ bgm("明るい部活の曲")
    "次の瞬間、全員が大門の上に倒れこんでいた。"
    sakaguchi "大門ーーっ！！"
    voice "audio/voice/miyoshi_kattazo.mp3"
    miyoshi "勝ったぞ！！　勝ったぞおおお！！"
    daimon "く、苦しいです！　重いです！"
    "人の山のいちばん下で、大門は泣きながら笑っていた。"
    if ch2_shout == "left":
        daimon "……は、早瀬くんの『左』、ちゃんと聞こえました"
    elif ch2_shout == "right":
        daimon "す、すみません！　右って聞こえたのに、体が勝手に左に……"
        ren "……結果オーライだ"
    else:
        daimon "何も聞こえなかったので……じ、自分で、決めました"
    "県立{rb}港北{/rb}{rt}こうほく{/rt}高校サッカー部の、3年ぶりの、公式戦の勝利だった。"
    hide screen win_banner
    hide screen letterbox
    $ pk_off()

    scene bg pref_ground_eve
    with dissolve
    "{rb}黒田{/rb}{rt}くろだ{/rt}は、ベンチに座ったまま、拍手もしなかった。"
    "ただ、一度だけ、うなずいた。"
    "ベンチの前で、ひなたがストップウォッチを握ったまま泣いていた。"
    show hinata teary
    with dissolve
    hinata "……ずっと見てたよ。全部、ノートに書いた"
    ## 6月の夜のトークで「ストップウォッチとメモ」の話をしていた人だけ（nightcontact.rpy で立つ）
    if flags.get("ひなた_ストップウォッチ"):
        "ひなたのノートには、俺が走った時間と距離が、前半の最初の1分から、小さな字でびっしり並んでいた。"
        "6月の夜、トークで言っていたとおりだった。"
    ren "知ってる"
    if ch2_knee == "honest":
        hinata "{rb}蓮{/rb}{rt}れん{/rt}、今日、一回も足かばわなかったね"
    else:
        hinata "{rb}蓮{/rb}{rt}れん{/rt}、後半に一回だけ、右足かばったでしょ。……あとで冷やすからね"
    ren "……ひなた。おにぎりも、ノートも。ありがとな"
    show hinata stare
    hinata "…………今の、ほめた？"
    ren "ほめた"
    show hinata teary
    hinata "……もう一回"
    ren "言わない"
    hinata "ケチ"
    "ひなたは、泣きながら笑った。"
    $ heart_up("ひなた", "ときめき", 3)
    hide hinata
    with dissolve
    "――{rb}港北{/rb}{rt}こうほく{/rt}ーっ！"
    "土手の端から、一度だけ、女の子の声が飛んできた。"
    "振り返ると、日傘が、あわてたように深く傾いた。"
    "シャッターの音が一回。それきり、日傘は見えなくなった。"
    $ heart_up("千夏", "ときめき", 2)
    $ heart_up("ひなた", "信頼", 3)
    $ bond_up("大門", 8)
    $ bond_up("坂口", 4)
    $ up("メンタル", 4)
    $ set_flag("ch2_first_win")

    ## 試合のふり返り（選んだことが、どう効いたか）
    python:
        _rows = [("スコア", "1−1　PK 4−3")]
        _rows.append(("得点", "後半18分　坂口のクロス → 鷹野のヘディング"))
        _rows.append(("残り5分", {"shoot": "自分で撃った（キーパーの指先にはじかれた）",
                                 "onetwo": "鷹野とワンツー（決めたが、半歩出ていてオフサイド）",
                                 "back": "三好先輩に下げて裏へ（ポストに当たった）"}.get(ch2_shot, "―")))
        _course = {"tr": "右上", "watch": "キーパーを最後まで見る", "bl": "左下"}.get(ch2_pk, "―")
        _rows.append(("蓮のPK", _course + ("　→　決めた" if ch2_pk_ok else "　→　外した（江藤がサドンデスで決めた）")))
        _rows.append(("大門への声", {"left": "「左だ！」　→　当たり", "right": "「右だ！」　→　大門は逆に飛んで止めた",
                                   "none": "何も言わずに信じた"}.get(ch2_shout, "―")))
        _rows.append(("勝因", {"left": "蓮の「左だ！」と、大門の横っ飛び",
                               "right": "大門が自分の体を信じた、逆への横っ飛び",
                               "none": "蓮が信じて任せた、大門の横っ飛び"}.get(ch2_shout, "大門の横っ飛び")))
        if ch2_knee == "honest":
            _memo = "ひなた：テーピング、最後までもったね。ひざ、かばってなかったよ"
        else:
            _memo = "ひなた：言ってくれたら、ちゃんとテーピングしたのに"
    call screen match_report("インターハイ予選1回戦　港北 対 白浜工業", _rows, _memo)

    ############################################################################
    ## シーン5：2回戦（7月初め）
    ############################################################################
    scene black
    with Dissolve(1.0)
    $ set_cal("7月4日（土）", "インターハイ予選2回戦")
    $ bgm("（なし）")
    mono "2回戦。相手は、県で8番目に強い私立、{rb}西海{/rb}{rt}さいかい{/rt}学院だった。"
    mono "前半で、0−1。"
    scene bg pref_ground_day
    with dissolve
    $ bgm("試合の曲（劣勢）")
    show kuroda normal
    with dissolve
    "ハーフタイム。{rb}黒田{/rb}{rt}くろだ{/rt}は、マグネットのボードを俺の前に置いた。"
    kuroda "後半、どうする。……{rb}早瀬{/rb}{rt}はやせ{/rt}、お前が決めろ"
    menu:
        "「三好先輩も上げて、全員で点を取りに行きます」":
            $ ch2_2nd = "attack"
            $ lean("野心型")
            $ bond_up("三好", 3)
            kuroda "……わかった"
            hide kuroda
            with dissolve
            "後半、{rb}港北{/rb}{rt}こうほく{/rt}は初めて、相手のゴール前に何度も迫った。"
            "{rb}坂口{/rb}{rt}さかぐち{/rt}のクロスが、二度、ゴールの前を横切った。"
            "そして、空いた後ろを、二度突かれた。"
            ## 鷹野との絆が深ければ、1点返せる
            if check_bond("鷹野", 24):
                "後半40分。俺のスルーパスに、{rb}鷹野{/rb}{rt}たかの{/rt}が一歩だけ先に触った。"
                $ se("ネットが揺れる音")
                with vpunch
                "1点、返した。"
                "鷹野は、ボールを拾って、走ってセンターサークルに戻した。"
                $ ch2_2nd_score = "1−3"
            else:
                "最後のクロスは、誰の頭にも合わなかった。"
        "「0−1のまま耐えて、最後の10分に懸けます」":
            $ ch2_2nd = "hold"
            $ lean("求道型")
            $ up("戦術眼", 2)
            kuroda "……わかった"
            hide kuroda
            with dissolve
            "全員で下がって、耐えた。後半30分まで、0−1のまま。"
            ## 走りこみが足りていれば、最後の10分も足が止まらない
            if check("フィジカル", 28):
                "最後の10分。足は、まだ前に出た。"
                "{rb}三好{/rb}{rt}みよし{/rt}先輩が、最後まで相手のエースに食らいついていた。"
                "点は取れなかった。でも、もう1点も取らせなかった。"
                $ ch2_2nd_score = "0−1"
            else:
                "最後の10分。走ろうとした足が、もう前に出なかった。"
                "その10分で、2点を取られた。"
    scene black
    with dissolve
    $ bgm("（なし）")
    mono "[ch2_2nd_score]。"
    mono "走って、走って、それでも追いつけなかった。"
    scene bg pref_ground_eve
    with dissolve
    show kuroda normal
    with dissolve
    show miyoshi match at left
    with dissolve
    if ch2_2nd_score == "0−1":
        miyoshi "……1点か。0−9から、8点も縮まったな！"
    elif ch2_2nd_score == "1−3":
        miyoshi "……1点、取ったぞ！　県で8番目から、1点だ！"
    else:
        miyoshi "……3点か。0−9から、6点も縮まったな！"
    "泥だらけの顔で、{rb}三好{/rb}{rt}みよし{/rt}先輩はいちばんに笑った。"
    hide miyoshi
    with dissolve
    "試合のあと、{rb}黒田{/rb}{rt}くろだ{/rt}は一言だけ言った。"
    kuroda "夏で変わる。……体育館、借りといたぞ"
    miyoshi "体育館？"
    kuroda "合宿だ。27日から、泊まりこみで3日"
    show sakaguchi match at right
    with dissolve
    sakaguchi "は？？？"
    if flags.get("ch2_council"):
        "――6月に生徒会室へ出した、あの申請書。「宿泊」の欄の丸。"
        "黒田は、6月にはもう、決めていたのだ。"

    ## 帰りの駅で、紗希とすれちがう（楽譜をもう一度拾う。短い接点）
    scene bg kohoku_station_eve
    with dissolve
    $ bgm("（なし）")
    "今日は、あのマイクロバスが借りられなかった。会場からは、みんなで電車に乗って帰ってきた。"
    "電車を降りた、{rb}港北{/rb}{rt}こうほく{/rt}駅のホーム。"
    "ホームのいちばん端に、白い半袖のシャツの女の子が立っていた。桜嶺の夏服だ。"
    "色素の薄い、短い髪。腕に、楽譜の束を抱えている。"
    $ se("駅に着く音・ドアが開く音")
    "向かいのホームに、電車がすべりこんできた。"
    $ se("強い海風")
    "巻き上がった風で、束のいちばん上の一枚が、ホームを滑ってきた。"
    "スパイクの入ったバッグを下ろして、踏まれる前に拾った。"
    $ _sk_keep = saki_call
    ## 第1章の港で名前を聞いていなければ、楽譜の端に書いてあった名字で呼ぶ（8月15日の満員電車と同じ）
    $ saki_call = "紗希" if flags.get("紗希_名前を聞いた") else "鬼塚"
    show saki normal
    with dissolve
    voice "audio/voice/saki_mata.mp3"
    saki_v "……また、あなた"
    "楽譜を受け取ろうとした指が、俺のユニフォームの泥のところで止まった。"
    show saki frown
    voice "audio/voice/saki_maketano.mp3"
    saki_v "……負けたの"
    menu:
        "「ああ。……でも、点差は縮まった」":
            $ heart_up("紗希", "信頼", 2)
            voice "audio/voice/saki_tensa.mp3"
            saki_v "……点差なんて、聞いてない"
            "そう言いながら、あの子は、俺の顔をもう一度だけ見た。"
        "「楽譜、飛ばされすぎだろ」":
            $ heart_up("紗希", "ときめき", 2)
            voice "audio/voice/saki_kaze.mp3"
            saki_v "……風が悪いの。わたしじゃない"
            "楽譜を、胸の前でぎゅっと抱えなおした。"
    voice "audio/voice/saki_sou.mp3"
    saki_v "そう"
    hide saki
    with dissolve
    "それだけ言って、白いシャツの背中は、改札への階段を下りていった。"
    "負けた日に、あの子に会うのは、二度目だった。"
    $ saki_call = _sk_keep
    $ set_flag("紗希_駅")

    ############################################################################
    ## シーン5.5：雨の部室とアルバム（7月8日・水・雨）
    ############################################################################
label ch2_album_scene:      # テスト用の目印（コンソールで jump ch2_album_scene）
    scene black
    with dissolve
    $ set_cal("7月8日（水）", "放課後・雨")
    scene bg clubroom_rain
    with dissolve
    $ se("雨の音")
    $ bgm("あたたかいアコースティックギター")
    "梅雨の雨で、グラウンドは使えなかった。"
    "11人が、せまい部室にぎゅうぎゅうに座っている。"
    show sakaguchi normal at right
    with dissolve
    sakaguchi "{rb}黒田{/rb}{rt}くろだ{/rt}先生、雨の日は練習なしって、優しすぎじゃね"
    show miyoshi uniform at left
    with dissolve
    miyoshi "違う！　先生は『ロッカーを片づけろ』って言ったんだ！"
    sakaguchi "それ、もっとひどくない？"
    hide sakaguchi
    hide miyoshi
    with dissolve
    "{rb}大門{/rb}{rt}だいもん{/rt}が、ロッカーの上から古い段ボールを下ろした。"
    show daimon uniform_worried
    with dissolve
    daimon "あの……これ、何でしょう"
    hide daimon
    with dissolve
    "中から出てきたのは、表紙のはがれかけたアルバムだった。"
    miyoshi "うわ、なつかしい……って、俺も見たことないや"
    "ページをめくる。土のグラウンド。色あせた青のユニフォーム。"
    "4年前。{rb}港北{/rb}{rt}こうほく{/rt}が、県大会でベスト8まで行った年のものらしい。"
    "最後のページに、スタンドで中学生くらいの女の子が、手作りの旗を振っている写真があった。"
    "旗には、青と白の、港北サッカー部のマーク。"
    "その女の子の顔に、どこか見覚えがあった。"
    if persistent.trial_cleared:
        "女の子の首から、小さなフィルムカメラが下がっていた。"

    daimon "あ、あと、これも入ってました"
    "段ボールの底に、新しい封筒が一つ。宛名はない。"
    "中には、写真が十数枚入っていた。"
    scene cg album_photos
    with Dissolve(1.0)
    "雨の5月31日。泥だらけで走る{rb}三好{/rb}{rt}みよし{/rt}先輩。"
    "1回戦。人の山のいちばん下で、泣きながら笑っている大門。"
    daimon "ぼ、僕、こんな顔してたんですか……"
    sakaguchi "やべえ、俺のクロスの瞬間あるじゃん！"
    "{rb}鷹野{/rb}{rt}たかの{/rt}は、黙って一枚を手に取った。自分が頭から飛びこんだ、ゴールの瞬間だった。"
    if flags.get("531_初シュート"):
        "もう一枚。雨の中で、鷹野がキーパーの手にぶつけたシュートの写真。"
        "鷹野は、その一枚も黙ってポケットに入れた。"
    kiryu "誰が撮ったの、これ"
    "誰も、答えられなかった。"
    "1回戦の土手の端。日傘と、古いフィルムカメラ。"

    menu:
        "「……千夏先輩、かもしれない」":
            $ ch2_album = "guess"
            $ set_flag("千夏_アルバム")
            ren "……{rb}千夏{/rb}{rt}ちか{/rt}先輩、かもしれない"
            miyoshi "{rb}七瀬{/rb}{rt}ななせ{/rt}が？　まさか"
            sakaguchi "生徒会長、俺らのこと嫌いじゃん"
            ren "……そうかな"
        "（何も言わずに、11人の写真を一枚だけもらっておく）":
            $ ch2_album = "keep"
            $ set_flag("千夏_写真")
            $ up("メンタル", 2)
            "円陣を組んだ、雨の11人の写真。いちばん端で、俺だけがカメラのほうを見ていた。"
            "写真を、そっと生徒手帳にはさんだ。"

    scene bg clubroom_rain
    with dissolve
    show miyoshi uniform
    with dissolve
    "三好先輩が、自分の写真を一枚、指でなぞった。"
    miyoshi "……誰でもいいや。俺たちのこと、ちゃんと見てたやつがいるってことだろ"
    "三好先輩の目が、赤かった。"
    $ bond_up("三好", 5)
    hide miyoshi
    with dissolve
    "雨の音だけが、しばらく続いた。"
    $ amb_stop()

    ## 雨上がりの帰り道：6月に港の防波堤へ行かなかった人も、ピアノを一度だけ聞く
    ##   （防波堤へ行った人は、もう聞いているので出さない）
    if not flags.get("ch2_pier"):
        $ set_cal("7月8日（水）", "帰り道", quiet=True)
        scene bg harbor_sunset
        with Dissolve(1.0)
        $ se("波の音、カモメ")
        $ bgm("（なし）")
        "部室を出るころには、雨は上がっていた。"
        "雲の切れ間から、夕日が港に落ちている。"
        "防波堤の近くの家の窓から、ピアノの音が聞こえてきた。"
        $ bgm("静かなピアノの旋律")
        "弾きかけて、同じところで止まる。"
        "また最初から弾いて、また同じところで止まる。"
        scene cg saki_window at cam_push(10.0, 1.04)
        with Dissolve(0.8)
        "窓のカーテンのすき間で、色素の薄い短い髪が揺れた。"
        "5月には港で、この前は駅のホームで。二度、楽譜を拾ったあの子と、同じ髪の色だった。"
        "四度目も、曲は同じところで止まった。"
        "窓の向こうから、「……最悪」とつぶやく声が聞こえた。"
        "俺は、声をかけずに、その窓の前を通りすぎた。"
        $ set_flag("紗希_ピアノ_帰り道")
        $ amb_stop()

    ############################################################################
    ## シーン5.6：7月の自由行動（2日）→ ひざの警告
    ############################################################################
    call ch2_free_loop("jul")
    call ch2_knee_warn

    ############################################################################
    ## シーン6：夏合宿（7月下旬・学校の体育館に2泊3日）
    ############################################################################
    scene black
    with dissolve
    $ set_cal("7月27日（月）", "夏合宿")
    scene bg gym_day
    with dissolve
    $ bgm("明るい部活の曲")
    "体育館の隅に、11人ぶんの荷物が積み上がった。ここが、3日間の寝床になる。"
    "朝6時から、グラウンドを走る。昼は、炎天下でボールを使った練習。夕方、また走る。"
    "めしの時間だけは、体育館の日かげに逃げこんだ。ひなたの作った大量のおにぎりが、毎食ちゃんとなくなっていく。"
    "{rb}坂口{/rb}{rt}さかぐち{/rt}たちは初日の夜に3回「帰る」と言い、2日目の夜には一回も言わなかった。"
    show kuroda normal
    with dissolve
    kuroda "{rb}江藤{/rb}{rt}えとう{/rt}。ドリブルは3回まで。4回目はパスだ"
    eto "……3回はいいんだ"
    hide kuroda
    with dissolve

    ## 夜の体育館
    scene black
    with dissolve
    $ set_cal("7月27日（月）", "夜")
    "夕飯のあと、全員で、近くの銭湯まで歩いた。帰りは、校舎の外の水飲み場に一列に並んで、歯をみがいた。"
    "{rb}三好{/rb}{rt}みよし{/rt}先輩は、歯ブラシをくわえたまま、明日のメニューの話をしていた。"
    scene cg gym_futons at cam_push(16.0, 1.06)
    with Dissolve(1.2)
    $ bgm("静かな夜の曲")
    "夜10時。体育館にもどると、電気を消した床に、11枚の布団が二列に並んで待っていた。"
    "高い窓から、月の光が床に斜めに落ちている。"
    scene bg gym_night
    with dissolve
    ## 1日目の夜：恋バナ（扉の外で、見回りに来た千夏が聞いてしまう）
    sakaguchi "……なあ。こういう夜ってさ、やっぱ好きな子の話だよな"
    miyoshi "おっ、修学旅行の夜みたいなやつ！"
    sakaguchi "三好先輩は、聞かなくても分かるからいいっす。どうせ、サッカーボール"
    miyoshi "なんで分かった！？"
    eto "……江藤は、ドリブルが恋人"
    noguchi "野口は、ゲームのキャラ"
    sakaguchi "お前らに聞いてねえよ。……で、蓮は？"
    sakaguchi "マネージャーの篠宮と、生徒会長。……どっちがタイプ？"
    "布団の中で、10人ぶんの耳が、こっちを向いた気がした。"
    daimon "ぼ、僕も、ちょっと聞きたいです……"
    takano "……くだらね"
    "そう言いながら、{rb}鷹野{/rb}{rt}たかの{/rt}も寝返りを打たなかった。"
    menu:
        "「……ひなた、かな」":
            $ ch2_koibana = "hinata"
            sakaguchi "うわ、幼なじみ！　王道じゃん！"
            miyoshi "篠宮か！　毎朝おにぎりだもんな！"
            ren "……おにぎりで決めてない"
            $ bond_up("坂口", 2)
        "「……千夏先輩」":
            $ ch2_koibana = "chika"
            sakaguchi "マジ？　あの生徒会長？　怒られたい系？"
            miyoshi "{rb}七瀬{/rb}{rt}ななせ{/rt}か……！　七瀬は、ああ見えて、いいやつだぞ！"
            ren "……そういうのじゃない"
            $ bond_up("坂口", 2)
        "「……サッカー」とごまかす":
            $ ch2_koibana = "soccer"
            sakaguchi "逃げた！　ずりい！"
            takano "……いちばん、まともな答えだろ"
            $ bond_up("鷹野", 2)
            $ bond_up("坂口", 2)
    "そのとき、体育館の扉の向こうで、何かが床に落ちる、乾いた音がした。"
    "懐中電灯の丸い光が、扉のすき間を横切って、すぐに遠ざかっていった。"
    kiryu "……今、誰かいた？"
    miyoshi "見回りだろ。……え、見回り？"
    "全員が、急に寝たふりをした。"
    $ set_flag("ch2_恋バナ", ch2_koibana)

    ## 2日目の昼：紅白戦
    scene black
    with dissolve
    $ set_cal("7月28日（火）", "紅白戦")
    scene bg kohoku_ground_day
    with dissolve
    $ bgm("明るい部活の曲")
    "2日目の紅白戦。"
    "{rb}鷹野{/rb}{rt}たかの{/rt}のスルーパスが出る一歩前に、{rb}桐生{/rb}{rt}きりゅう{/rt}先輩はもうコースに立っていた。"
    takano "……なんで分かんだよ"
    kiryu "お前、出す前に一回、右を見る"
    "足は遅い。でも、桐生先輩は、走る前に答えを知っていた。"
    "その紅白戦で、{rb}野口{/rb}{rt}のぐち{/rt}が、生まれて初めてゴールを決めた。"
    noguchi "……取った。取ったぞ、俺"
    sakaguchi "ウケる。泣いてんじゃん"
    noguchi "泣いてねえ"
    $ up("フィジカル", 4)
    $ up("技術", 2)

    ## 2日目の夜：なんでサッカーをやっているか
    scene black
    with dissolve
    $ set_cal("7月28日（火）", "夜")
    scene bg gym_night
    with dissolve
    $ bgm("静かな夜の曲")
    "二日目の夜。電気を消した体育館で、今夜も、誰も寝ていなかった。"
    miyoshi "……なあ。起きてるやつ"
    sakaguchi "寝れるわけないじゃん、床かてえし"
    miyoshi "一人ずつさ。なんでサッカーやってるか、言わないか"
    sakaguchi "うわ、今日はまじめなやつ"
    miyoshi "いいだろ、昨日のより、まじめなやつ"
    "暗い中で、何人かが笑った。"

    miyoshi "じゃあ俺からな"
    scene cg gym_miyoshi at cam_push(14.0, 1.05)
    with Dissolve(0.8)
    miyoshi "俺、中学でもずっと補欠だった。3年間、一回も試合に出てない"
    miyoshi "でも、ベンチから見てたサッカーが、ずっと楽しそうでさ"
    miyoshi "だから、高校では絶対に出るって決めてたんだ。……そしたら、部員が3人になってた"
    $ memory("cg m531_huddle", "5月31日　雨の練習試合")
    miyoshi "最後の年に、11人で試合に出られた。だから俺、今、けっこう幸せなんだよ"
    $ memory_off()
    "暗がりのどこかで、誰かが鼻をすすった。"
    scene bg gym_night at lights(-0.06)
    with Dissolve(0.8)

    daimon "……僕は"
    "{rb}大門{/rb}{rt}だいもん{/rt}の声は、布団の中から聞こえた。"
    daimon "この顔で、ずっと怖がられてきたんです。何もしてないのに"
    daimon "だから、自分でも、自分は怖い人なんだって思うようになってて"
    $ memory("cg daimon_pk", "インターハイ予選1回戦")
    daimon "でも、PKを止めたとき、みんなが上に乗ってきて……誰も、僕のこと怖がってなかった"
    daimon "……それが、うれしかったです"
    $ memory_off()
    sakaguchi "重かったけどな、お前"
    daimon "重かったのは坂口くんです"
    $ memory("bg game_center", "駅前のゲームセンター")
    sakaguchi "……俺らさ、ゲーセンで、ずっと5人だけだったじゃん"
    sakaguchi "11人って、思ってたより、うるさくて悪くない"
    $ memory_off()
    kiryu "……俺らが幽霊部員になったのは、去年の先輩が怖かったから"
    kiryu "{rb}三好{/rb}{rt}みよし{/rt}先輩だけ、毎日来てた。一人で"
    miyashita "だから今年は、来ることにした"
    miyoshi "……お前ら、そういうの先に言えよ"

    "しばらく、静かだった。"
    scene bg gym_night at lights(-0.12)
    with Dissolve(1.0)
    "月が雲に入ったのか、窓の光が少し細くなった。"
    takano "……ユースに、上がれなかったんじゃない"
    scene cg gym_takano at cam_push(12.0, 1.05)
    with Dissolve(0.8)
    "{rb}鷹野{/rb}{rt}たかの{/rt}の声だった。腕で目を隠したまま、こっちを見なかった。"
    takano "上がれないって言われる前に、自分でやめた。言われるのが、怖かったから"
    takano "だから、{rb}桜嶺{/rb}{rt}おうりょう{/rt}のBに、ジュニアユースで一緒だったやつがいたとき、本当は、すげえ腹が立った"
    takano "あいつにじゃない。逃げた自分に"
    if flags.get("鷹野_わざと負け"):
        takano "……あと、屋上の。あのとき言ったよな、わざとだろって"
        takano "あれ、今でもむかついてる。次は本気で来い"
        $ bond_up("鷹野", 5)
    "鷹野は、それ以上言わなかった。"
    "誰も、それ以上聞かなかった。"
    scene bg gym_night at lights(-0.12)
    with Dissolve(0.8)

    miyoshi "……{rb}蓮{/rb}{rt}れん{/rt}は？"
    "暗い天井を見上げた。"
    scene cg item_knee_night at item_close
    with Dissolve(0.8)
    "布団の中で、右ひざに手を当てる。"
    "ひざが、もう完全には戻らないこと。それだけは、誰にも言っていない。"

    menu:
        "ひざのことを、全部話す":
            $ ch2_night = "knee"
            $ bond_up("三好", 4)
            $ bond_up("大門", 4)
            $ bond_up("鷹野", 4)
            $ bond_up("坂口", 4)
            $ bond_up("三好", 3)
            $ up("無理ゲージ", -5)
            ren "……右ひざ、まだ完全じゃない。たぶん、ずっと完全にはならない"
            ren "でも、やめたくない。だから、もし俺が無理してたら、止めてくれ"
            miyoshi "おう。止める"
            daimon "と、止めます"
            takano "……知ってたよ、そんなこと"
            scene cg gym_door_light at item_close
            with Dissolve(0.8)
            "体育館の扉のすき間に、細い光が一本だけ差していた。"
            "誰かが、廊下で立ち止まっていたらしい。"
            $ set_flag("ch2_knee_told")
        "桜嶺を、見返したい":
            $ ch2_night = "ouryo"
            scene bg gym_night at lights(-0.12)
            with dissolve
            $ lean("野心型")
            $ up("メンタル", 3)
            ren "俺が行くはずだった学校に、俺がいないチームで勝ちたい"
            sakaguchi "……かっけえじゃん"
            takano "勝つのは俺だけどな"
        "ただ、サッカーが好きだから":
            $ ch2_night = "love"
            scene bg gym_night at lights(-0.12)
            with dissolve
            $ lean("求道型")
            $ up("メンタル", 3)
            ren "……好きだからだ。それ以外、思いつかない"
            miyoshi "それがいちばんだよ"
            "{rb}三好{/rb}{rt}みよし{/rt}先輩の声が、鼻声になっていた。"

    scene bg gym_night at lights(-0.12)
    with dissolve
    $ se("体育館の扉が開く音")
    show chika normal
    with dissolve
    chika "……10時を過ぎています。消灯の確認に来ました"
    sakaguchi "うわっ、生徒会長！？"
    show chika narrow
    chika "申請書に、見回りは生徒会が行うと書いてあります。読んでいないんですか"
    "{rb}千夏{/rb}{rt}ちか{/rt}先輩は、懐中電灯で布団の列を一往復照らした。"
    chika "11人。確認しました"
    ## 1日目の夜の恋バナを、扉の外で聞いていた
    if ch2_koibana == "chika":
        "懐中電灯の光は、俺の布団のところだけ、なぜか素通りした。"
        chika "……昨日の夜の見回りでは、何も聞いていません"
        "誰も、何も聞いていなかった。"
        $ heart_up("千夏", "ときめき", 5)
    elif ch2_koibana == "hinata":
        chika "……篠宮さんに、毎朝のおにぎりのお礼を、ちゃんと言っておいてください"
        "なぜか、声が、昨日の見回りのときより一度低かった。"
        $ heart_up("千夏", "さみしさ", 3)
    elif ch2_koibana == "soccer":
        chika "……サッカー部の消灯は、サッカーより優先です"
        "昨日の夜の話を、聞いていたらしかった。"
        $ heart_up("千夏", "信頼", 2)
    if ch2_night == "knee":
        "懐中電灯の光が、俺の布団の前で止まった。"
        show chika normal
        chika "……{rb}早瀬{/rb}{rt}はやせ{/rt}くん。止めてくれる人がいるなら、止められるうちに、止めてもらってください"
        chika "今のは、見回りとは関係ありません"
        $ heart_up("千夏", "信頼", 3)
    hide chika
    with dissolve
    "千夏先輩は、体育館の入口に紙袋を一つ置いて、出ていった。"
    if flags.get("千夏_差し入れ_ドリンク"):
        "中には、凍らせたスポーツドリンクが11本入っていた。"
        "……覚えておきます、と言っていた。"
    else:
        "中には、冷えたおしぼりと、塩あめの袋が入っていた。"
    $ heart_up("千夏", "信頼", 5)

    ## 合宿の最後の日：ひなたと、水飲み場で片づけ（第2章で必ず通る、ひなたの場面）
    scene black
    with dissolve
    $ set_cal("7月29日（水）", "合宿の最後")
    scene bg kohoku_ground_eve
    with dissolve
    $ bgm("あたたかいアコースティックギター")
    "3日目の夕方。みんなが帰ったあと、校舎の外の水飲み場で、おにぎり用の大きなざるを洗った。"
    "となりで、ひなたが、からっぽの保冷バッグを逆さにして振っていた。"
    show hinata smile
    with dissolve
    hinata "3日で、おにぎり、198個。……全部なくなった"
    ren "数えてたのかよ"
    hinata "数えるよ。マネージャーだもん"
    "ひなたは、毎朝5時に、はやせ食堂から自転車でおにぎりを運んできていた。"
    ## 1日目の夜の恋バナ（坂口が、口をすべらせた）
    if ch2_koibana == "hinata":
        hinata "……坂口くんが言ってた。1日目の夜のこと"
        "ひなたは、ざるをこする手を止めなかった。耳だけが、真っ赤だった。"
        hinata "……おにぎりで決めたんじゃないなら、いいけど"
        $ heart_up("ひなた", "ときめき", 5)
    elif ch2_koibana == "chika":
        show hinata pout
        hinata "坂口くんから聞いた。……生徒会長、なんだ"
        hinata "べつに。蓮の好みとか、どうでもいいし"
        "ひなたは、ざるの水を、いつもより強く切っていた。"
        $ heart_up("ひなた", "さみしさ", 3)
    elif ch2_koibana == "soccer":
        hinata "坂口くんが言ってた。『サッカー』って答えたんでしょ"
        hinata "……蓮らしい。ちょっとだけ、つまんないけど"
        $ heart_up("ひなた", "信頼", 2)
    show hinata normal
    hinata "ねえ、{rb}蓮{/rb}{rt}れん{/rt}。……来年の夏も、ここで合宿するよね"
    "ひなたは、ざるの水を切りながら、こっちを見なかった。"
    menu:
        "「するに決まってるだろ」":
            $ heart_up("ひなた", "ときめき", 3)
            show hinata stare
            "ひなたは、そこで初めて、俺の顔を見た。"
            hinata "……眉毛、動かなかった"
            show hinata smile
            hinata "じゃあ、来年は200個にする"
        "「ひなたのおにぎりがあるならな」":
            $ heart_up("ひなた", "信頼", 3)
            show hinata pout
            hinata "それ、わたしじゃなくて、おにぎりが来てほしいだけじゃん"
            show hinata smile
            hinata "……いいけど。おにぎり作るの、わたしだから"
    "蛇口をしめると、セミの声だけが残った。"
    hinata "来年もね。わたし、ちゃんと数えてるから"
    hide hinata
    with dissolve

    ############################################################################
    ## シーン6.5：8月の自由行動（夏休み・2日）→ ひざの警告
    ############################################################################
    call ch2_free_loop("aug")
    call ch2_knee_warn

    ############################################################################
    ## シーン7：夏祭り（8月15日）
    ############################################################################
    scene black
    with dissolve
    $ set_cal("8月14日（金）", "夜")
    scene bg ren_room_night
    with dissolve
    $ bgm("静かな夜の曲")
    $ se("トークアプリの通知音（連続）")
    window auto hide
    $ talk_start("港北サッカー部（12）", "21:30")
    $ talk("三好", "明日の潮見港の花火大会、練習は休みな！")
    $ talk("三好", "黒田先生公認！！")
    $ talk("坂口", "先生、公認とか言うタイプじゃないでしょ")
    window auto hide
    $ talk_end()
    "{rb}潮見{/rb}{rt}しおみ{/rt}港の花火大会。電車で二駅先の、県でいちばん大きな港の祭りだ。"
    "{rb}港北{/rb}{rt}こうほく{/rt}の小さな漁港とはちがって、毎年、何万人も人が来る。"
    "誰と行こう。"
    "スマホを持ったまま、しばらく画面を見ていた。"

    menu:
        "ひなたを誘う":
            $ ch2_fest = "hinata"
        "千夏先輩を誘う" if heart["千夏"]["ときめき"] + heart["千夏"]["信頼"] >= CH2_CHIKA_INVITE:
            $ ch2_fest = "chika"
        "鷹野と大門を誘う":
            $ ch2_fest = "boys"
        "誰も誘わず、一人で行く":
            $ ch2_fest = "alone"
    ## 誘うやり取り（誘い文句で、相手の返事と気持ちの上がり方が変わる）
    if ch2_fest == "hinata":
        call ch2_invite_hinata
    elif ch2_fest == "chika":
        call ch2_invite_chika
    elif ch2_fest == "boys":
        call ch2_invite_boys
    else:
        "……一人で、ふらっと行けばいい。"
        "なぜか、人の多いところより、港の端のほうを見てみたかった。"
        $ set_flag("紗希_祭り")
    if ch2_fest != "alone":
        scene bg ren_room_night
        with dissolve
        "待ち合わせは、会場の最寄りの「{rb}潮見{/rb}{rt}しおみ{/rt}港駅」。"
        "俺は、店の手伝いで少し遅れて、一人で電車に乗ることになった。"
    else:
        "会場は、{rb}潮見{/rb}{rt}しおみ{/rt}港駅のすぐ前だ。"
        "店の手伝いを終えてから、一人で電車に乗った。"

    ## 満員電車
label ch2_train:      # テスト用の目印（コンソールで jump ch2_train）
    ## 第1章の港で名前を聞いていなければ、楽譜の端に書いてあった名字で呼ぶ
    $ saki_call = "紗希" if flags.get("紗希_名前を聞いた") else "鬼塚"
    scene black
    with dissolve
    $ set_cal("8月15日（土）", "夕方")
    $ bgm("（なし）")
    scene bg train_eve at cam_jog
    with Dissolve(1.0)
    $ se("電車の走る音")
    "花火の日の電車は、ぎゅうぎゅうだった。"
    "浴衣の人、家族連れ、部活帰りのジャージ。"
    "ドアの近くで、身動きがとれなくなった。"
    $ se("電車がカーブで揺れる音")
    scene bg train_eve at cam_snap(1.08)
    with hpunch
    "カーブで、車両がぐらりと揺れる。"
    "押されて、背中が誰かの背中にぶつかった。"
    "細い背中だった。"
    "相手も押されていて、離れようにも離れられない。"
    "背中同士が、ぴたりとくっついたまま止まる。"
    "「……っ」"
    "小さく、息をのむ音がした。"

    scene cg train_saki at cam_push(10.0, 1.05)
    with Dissolve(1.0)
    $ bgm("静かなピアノの旋律")
    "首だけで、そっと振り返る。"
    "俺の肩ごしに、色素の薄い短い髪。"
    "トートバッグからのぞく、見覚えのある楽譜。"
    "……あの時の。"
    "横目で、目が合った。"
    window hide
    pause
    scene bg train_eve
    with dissolve
    show saki casual
    with dissolve
    voice "audio/voice/saki_minaide.mp3"
    saki_v "……こっち、見ないで"
    "小さな声だった。耳が、少し赤い。"
    voice "audio/voice/saki_ugokanaide.mp3"
    saki_v "あと、動かないで。……動くと、もっとくっつくから"
    ren "……動いてない"
    voice "audio/voice/saki_kokyu.mp3"
    saki_v "動いてる。呼吸で"
    ren "呼吸は無理だろ"
    voice "audio/voice/saki_nn.mp3"
    saki_v "…………"
    "背中ごしに、相手の体温が伝わってくる。"
    "自分の心臓の音が、背中から聞こえていないか、気が気じゃなかった。"
    voice "audio/voice/saki_ichini.mp3"
    saki_v "……いち、に、さん、し。いち、に、さん、し"
    ren "……何、数えてるんだ"
    voice "audio/voice/saki_andante.mp3"
    saki_v "アンダンテ。……黙ってて"

    menu:
        "大丈夫か？　苦しくない？":
            $ ch2_saki_word = "ok"
            $ heart_up("紗希", "信頼", 4)
            voice "audio/voice/saki_kurushii.mp3"
            saki_v "……苦しいに決まってるでしょ。満員なんだから"
            voice "audio/voice/saki_osanaide.mp3"
            saki_v "…………押さなかったのは、ほめてあげる"
        "……久しぶり":
            $ ch2_saki_word = "long"
            $ heart_up("紗希", "ときめき", 4)
            voice "audio/voice/saki_oboeteta.mp3"
            saki_v "……覚えてたの"
            voice "audio/voice/saki_oboetenai.mp3"
            saki_v "別に、覚えててほしいなんて言ってない"
            "背中ごしの[saki_call]は、ずっと下を向いているようだった。"
        "何も言わずに、次の駅まで耐える":
            $ ch2_saki_word = "none"
            "次の駅まで、2分。"
            "人生で、いちばん長い2分だった。"

    ## 第1章の港で、何も言わずに見送っていた場合
    if flags.get("紗希_出会い遅れ"):
        voice "audio/voice/saki_kikanakatta.mp3"
        saki_v "……最初に港で会ったとき、何も聞かなかった人"
        voice "audio/voice/saki_miokutta.mp3"
        saki_v "楽譜だけ拾って、黙って見送った"
        "責めているのか、ほっとしているのか、分からない声だった。"

    ## 第1章の港で名前を聞かなかった人は、ここで名前が分かる
    if not flags.get("紗希_名前を聞いた"):
        ren "……{rb}鬼塚{/rb}{rt}おにづか{/rt}、さん？"
        "くっついた背中が、びくっと固まった。"
        voice "audio/voice/saki_nande.mp3"
        saki_v "……なんで、その名前"
        ren "港で拾った楽譜に、書いてあった"
        voice "audio/voice/saki_yobanaide.mp3"
        saki_v "その名前で、呼ばないで"
        "電車が揺れて、また背中が押しつけられた。"
        voice "audio/voice/saki_yobunara.mp3"
        saki_v "…………{rb}紗希{/rb}{rt}さき{/rt}。呼ぶなら、そっち"
        $ saki_call = "紗希"
        $ set_flag("紗希_名前を聞いた")
        $ meet("紗希")      # 第1章で名前を聞かなかった人は、ここで相関図に出る
        $ heart_up("紗希", "信頼", 3)

    ## 港の防波堤で、ピアノを最後まで聴いていた場合
    if flags.get("ch2_piano"):
        voice "audio/voice/saki_teibou.mp3"
        saki_v "……ねえ。この前、堤防でボール蹴ってたの、あなた？"
        voice "audio/voice/saki_tomaru.mp3"
        saki_v "同じところで止まるの、聴いてたでしょ。……最悪"

    $ amb_stop(1.0)
    $ se("駅に着く音・ドアが開く音")
    scene bg shiomi_station_eve
    with dissolve
    "ドアが開いた瞬間、人の波に押し出された。"
    "振り返ると、[saki_call]は少し離れたところで、乱れた前髪を直していた。"
    show saki casual
    with dissolve
    voice "audio/voice/saki_happyokai.mp3"
    saki_v "……発表会の帰り。花火を見に来たわけじゃないから"
    "誰も、何も聞いていない。"
    "それに、{rb}港北{/rb}{rt}こうほく{/rt}の駅で見かけた子が帰るなら、この電車は逆方向だ。"
    voice "audio/voice/saki_jiko.mp3"
    saki_v "それと、さっきのは、事故だから"
    voice "audio/voice/saki_wasurete.mp3"
    saki_v "忘れて"
    hide saki
    with dissolve
    "[saki_call]は、早足で人混みの中に消えていった。"
    $ set_flag("紗希_再会")

    ## 花火
    scene black
    with dissolve
    $ set_cal("8月15日（土）", "夜")
    scene bg festival_night
    with Dissolve(1.0)
    $ bgm("夏祭りの曲")
    $ se("花火の音")

    if ch2_fest == "hinata":
        show hinata yukata
        with dissolve
        hinata "遅い！　……って言おうと思ったけど、まあいいや"
        if ch2_invite == "yukata":
            hinata "……見たいって言ったの、{rb}蓮{/rb}{rt}れん{/rt}だからね"
        voice "audio/voice/hinata_yukata.mp3"
        hinata "浴衣、どう？"
        menu:
            "動きにくそう":
                $ heart_up("ひなた", "信頼", 4)
                voice "audio/voice/hinata_mou.mp3"
                hinata "もう！　そういうとこ！"
                "ひなたは笑いながら、俺の腕を軽くたたいた。"
            "似合ってる":
                $ heart_up("ひなた", "ときめき", 5)
                voice "audio/voice/hinata_ehehe.mp3"
                hinata "……えへへ。でしょ"
        hide hinata
        with dissolve
        $ se("花火の音")
        scene cg fw_hinata at cam_push(10.0, 1.04)
        with Dissolve(1.2)
        hinata "来年も、再来年も、ここで見られるといいね"
        "その「来年」が、どこで迎えるものになるのか、俺はまだ知らなかった。"

    elif ch2_fest == "chika":
        show chika yukata
        with dissolve
        chika "……4分の遅刻です。記録しておきます"
        chika "……生徒会として、地域の行事を視察するのも仕事ですから"
        if ch2_invite == "photo":
            "{rb}千夏{/rb}{rt}ちか{/rt}先輩は、本当に三脚を持ってきていた。"
        elif ch2_invite == "yukata":
            "浴衣のことには、最後まで一言も触れなかった。……耳だけが、ずっと赤かった。"
        "{rb}千夏{/rb}{rt}ちか{/rt}先輩は、花火ではなく、花火を見上げる人たちにカメラを向けていた。"
        menu:
            "先輩も写ってください":
                $ heart_up("千夏", "ときめき", 5)
                chika "……写るのは、苦手です。撮る側のほうが、性に合っています"
                hide chika
                with dissolve
                $ se("花火の音")
                scene cg fw_chika at cam_push(10.0, 1.04)
                with Dissolve(1.2)
                "そう言って、千夏先輩はレンズをこっちに向けた。"
            "何を撮ってるんですか":
                $ heart_up("千夏", "信頼", 4)
                chika "……この町の、夏です"
                hide chika
                with dissolve
                $ se("花火の音")
                scene cg fw_chika at cam_push(10.0, 1.04)
                with Dissolve(1.2)
                "気づいたら、レンズがこっちを向いていた。"
        voice "audio/voice/chika_ichimai.mp3"
        chika "……一枚だけですよ"
        "あなたを撮るのは、と、花火の音にまぎれて聞こえた。"

    elif ch2_fest == "boys":
        show takano casual at left
        show daimon jinbei at right
        with dissolve
        daimon "射的、全部外しました……"
        takano "キーパーのくせに、狙ったとこに一個も飛ばねえのかよ"
        daimon "止めるのと当てるのは、ちがうんです……"
        hide takano
        hide daimon
        with dissolve
        $ se("花火の音")
        scene cg fw_boys at cam_push(10.0, 1.04)
        with Dissolve(1.2)
        takano "……来年は、もっと勝つぞ"
        voice "audio/voice/daimon_hai.mp3"
        daimon "はいっ！"
        "{rb}鷹野{/rb}{rt}たかの{/rt}がそんなことを言うのを、初めて聞いた。"

    else:
        "人混みの外れの、防波堤の端。"
        "花火が上がるたびに、少し離れたところに、短い髪の影が浮かび上がる。"
        $ se("花火の音")
        scene cg fw_saki at cam_push(12.0, 1.05)
        with Dissolve(1.2)
        "[saki_call]は、花火を見ていなかった。"
        "海のほうを、ずっと見ていた。"
        scene bg breakwater_night
        with dissolve
        show saki casual
        with dissolve
        saki_v "……花火、見ないの"
        ren "そっちこそ"
        saki_v "毎年、ここで見てた。家族で"
        saki_v "今年は、父が合宿。……サッカーの"
        $ set_flag("ch3_紗希_父")     # 第3章の防波堤：父がサッカーの人だと、ここで先に聞いている
        ren "……じゃあ、一人同士だな"
        saki_v "一緒にしないで"
        "そう言いながら、[saki_call]は、最後の一発が消えるまで帰らなかった。"
        $ heart_up("紗希", "信頼", 5)
        hide saki
        with dissolve

    ## ひなたを誘わなかった夜（取り返せる程度の、さみしさ）
    if ch2_fest != "hinata":
        scene black
        with dissolve
        scene bg ren_room_night
        with dissolve
        $ bgm("静かな夜の曲")
        $ se("トークアプリの通知音")
        window auto hide
        $ talk_start("ひなた", "23:31")
        $ talk("ひなた", "花火、クラスの子と見てた")
        $ talk("ひなた", "蓮、どこにいた？")
        $ ch2_r = talk_choose([("ごめん。来年は一緒に行こう", "next"), ("人が多くて、分かんなかった", "excuse")])
        if ch2_r == "next":
            $ talk_me("ごめん。来年は一緒に行こう")
            $ talk("ひなた", "……約束ね。眉毛見えないけど、信じる")
            $ heart_up("ひなた", "さみしさ", -3)
            $ set_flag("ひなた_来年の花火")
        else:
            $ talk_me("人が多くて、分かんなかった")
            $ talk("ひなた", "そっか。おやすみ")
            $ heart_up("ひなた", "さみしさ", 4)
        window auto hide
        $ talk_end()

    ############################################################################
    ## シーン8：章の終わり（8月の終わり）
    ############################################################################
    scene black
    with Dissolve(1.0)
    $ set_cal("8月31日（月）", "夏休み最後の練習")
    scene bg kohoku_ground_eve
    with dissolve
    $ bgm("明るい部活の曲")
    "夏休みの最後の日。"
    "{rb}黒田{/rb}{rt}くろだ{/rt}が、全員を集めた。"
    show kuroda board
    with dissolve
    kuroda "10月から、選手権予選が始まる"
    kuroda "3年は、これが最後の大会だ"
    "誰も、{rb}三好{/rb}{rt}みよし{/rt}先輩のほうを見なかった。"
    "見たら、何かが決まってしまう気がした。"
    if ch2_2nd == "attack":
        kuroda "2回戦、全員で攻めたのは間違いじゃない。……最後までそれをやれる体を、この夏で作った。そうだな"
    elif ch2_2nd == "hold" and ch2_2nd_score == "0−1":
        kuroda "2回戦は、最後の10分まで走れた。足りなかったのは、点を取りに行く一歩だ。……この夏で、それは見えたか"
    elif ch2_2nd == "hold":
        kuroda "2回戦の耐え方は悪くなかった。足りなかったのは、最後に走る足だ。……この夏で、少しはついたか"
    hide kuroda
    show miyoshi smile
    with dissolve
    voice "audio/voice/miyoshi_hahha.mp3"
    miyoshi "よーし！　じゃあ、優勝するか！"
    sakaguchi "急にでかいこと言うじゃん"
    miyoshi "言うだけならタダだろ！"
    "みんなが笑った。三好先輩も、いちばん大きな声で笑っていた。"

    ## 三好の相談（第3章の選手権で、ポジションが変わる）
    "練習のあと、三好先輩に呼び止められた。"
    miyoshi "……なあ、{rb}蓮{/rb}{rt}れん{/rt}。正直に答えてくれ"
    miyoshi "選手権。……俺、センターバックから外れて、左に回ったほうがいいと思うか？"
    miyoshi "真ん中は、{rb}桐生{/rb}{rt}きりゅう{/rt}と宮下で組める。桐生は足は遅いけど、読みがいい。宮下は背がある"
    miyoshi "俺は、走るだけだ。走るなら、外のほうが活きるのかもしれない"
    "三好先輩は、笑っていなかった。"
    menu:
        "「先輩は、いちばん後ろにいてください」":
            $ ch2_miyoshi_cb = "stay"
            $ bond_up("三好", 5)
            $ up("メンタル", 2)
            miyoshi "……おう。じゃあ、抜かれても抜かれても、追いつく"
            "帰り道に振り返ると、暗いグラウンドの外周に、まだ一つ影が動いていた。"
        "「……真ん中は、桐生先輩と宮下先輩に任せていいと思います」":
            $ ch2_miyoshi_cb = "kiryu"
            $ lean("求道型")
            $ up("戦術眼", 3)
            miyoshi "……そっか。そうだよな"
            "三好先輩は、笑った。いつもより、少しだけ時間をかけて。"
            miyoshi "じゃあ俺は、左で走る。端から端まで。……ありがとな、言ってくれて"
    $ set_flag("ch2_miyoshi_cb", ch2_miyoshi_cb)
    "グラウンドの土は、夏のあいだに、すっかり硬くなっていた。"
    "俺たちの足も、少しだけ、そうなっていた。"

    scene black
    with Dissolve(1.5)
    mono "九月。10月から、選手権予選が始まる。"
    mono "三好先輩の、最後の大会。"
    mono "組み合わせが決まるのは、9月7日。"

    ## 神城からの、取り消されたトーク（第3章の秘密を、蓮の目線のまま少しだけにおわせる）
    $ set_cal("9月2日（水）", "夜")
    scene bg ren_room_night
    with dissolve
    $ bgm("静かな夜の曲")
    $ se("トークアプリの通知音")
    window auto hide
    $ talk_start("神城 凌", "23:52")
    $ talk("神城", "選手権、7日に組み合わせが出るな")
    $ talk("神城", "早瀬。決勝のことで、言わなきゃいけないことがある")
    $ talk_system("神城がメッセージの送信を取り消しました")
    $ talk("神城", "なんでもない。試合で会おう")
    window auto hide
    $ talk_end()
    "取り消される前の一行だけが、目に焼きついていた。"
    $ set_flag("神城_取り消し")
    "決勝のこと。"
    "あの冬の、あの一瞬のことを、あいつは何だと思っているんだろう。"

    ## 章の終わりのタイトル → 次章予告（第3章の台詞だけを、断片で並べる）
    scene black
    with Dissolve(1.0)
    call show_title("第2章　泥だらけの夏", "完")
    $ bgm("張りつめた静かな曲")
    mono "「{rb}港北{/rb}{rt}こうほく{/rt}は、なくなるかもしれません」"
    mono "「あなたも、あの人の駒なの？」"
    mono "「……決勝のこと、ずっと言えなかった」"
    mono "「残るか、移るか。――蓮が決めて」"
    mono "大晦日。俺は、選ばなければならない。"
    call show_title("次章予告", "第3章　冬の扉")
    jump chapter3


################################################################################
## 自由行動の行き先（6月の放課後）
################################################################################

## グラウンド：黒田のメニュー
##   まだ見ていない練習の場面から1つ選ぶ（全部見たら、また最初から）
default ch2_practice_seen = []
define CH2_PRACTICE = ["ch2_pr_run", "ch2_pr_side", "ch2_pr_kiryu", "ch2_pr_face"]

label ch2_practice:
    scene bg kohoku_ground_eve
    with dissolve
    python:
        _left = [x for x in CH2_PRACTICE if x not in ch2_practice_seen]
        if not _left:
            ch2_practice_seen = []
            _left = list(CH2_PRACTICE)
        ch2_pp = renpy.random.choice(_left)
        ch2_practice_seen = ch2_practice_seen + [ch2_pp]
    call expression ch2_pp
    $ up("フィジカル", 3)
    $ up("無理ゲージ", 3)
    call tuto_stats
    return

default ch2_pp = ""

label ch2_pr_run:
    "{rb}黒田{/rb}{rt}くろだ{/rt}のメニューは、半分がボールを使わない走りこみだった。"
    "{rb}坂口{/rb}{rt}さかぐち{/rt}たちは文句を言いながら、それでも最後まで走った。"
    show kuroda normal
    with dissolve
    kuroda "{rb}早瀬{/rb}{rt}はやせ{/rt}。真ん中は、ボールを持ってないときにどこにいるかで決まる"
    hide kuroda
    with dissolve
    return

label ch2_pr_side:
    "右サイドで、{rb}坂口{/rb}{rt}さかぐち{/rt}と{rb}森{/rb}{rt}もり{/rt}が言い合っていた。"
    show sakaguchi jersey
    with dissolve
    sakaguchi "森、もっと上がってこいって"
    mori "坂口が戻ってこないから、上がれないんだよ"
    sakaguchi "……ウケる。それ、俺のせいじゃん"
    "結局、二人は日が暮れるまで、上がる順番を決める練習をしていた。"
    hide sakaguchi
    with dissolve
    return

label ch2_pr_kiryu:
    "パス回しの練習。"
    "{rb}三好{/rb}{rt}みよし{/rt}先輩のパスが、また大きく外れた。"
    kiryu "……三好先輩。そのパス、どこに出したの"
    miyoshi "気持ちは、お前のとこに出した！"
    kiryu "気持ちは受け取れない"
    "{rb}宮下{/rb}{rt}みやした{/rt}先輩が、しゃがんで笑いをこらえていた。"
    return

label ch2_pr_face:
    "ボールを受ける瞬間、ベンチから声が飛んだ。"
    show kuroda normal
    with dissolve
    kuroda "顔、上げろ。足もとは見なくても、ボールはそこにある"
    hide kuroda
    with dissolve
    "顔を上げると、右に{rb}坂口{/rb}{rt}さかぐち{/rt}、前に{rb}鷹野{/rb}{rt}たかの{/rt}が見えた。"
    "さっきまで見えていなかったものが、全部そこにあった。"
    return

## 生徒会室：合宿の申請書
label ch2_council:
    $ set_flag("ch2_council")
    scene bg student_council
    with dissolve
    $ bgm("張りつめた静かな曲")
    "{rb}黒田{/rb}{rt}くろだ{/rt}に頼まれた、夏休みの体育館の使用申請書を、生徒会室に出しに行った。"
    "「宿泊」の欄に、なぜか丸がついている。"
    show chika normal
    with dissolve
    chika "学校の体育館に部活動で泊まる。……前例がありません"
    ## 5月20日に「出られます」と言い切ったか、正直に言ったか
    if flags.get("520_言い切った"):
        chika "……それと。{rb}桐生{/rb}{rt}きりゅう{/rt}くん、5月の練習試合の前半25分で、足をつったそうですね"
        ren "……見てたんですか"
        show chika narrow
        chika "報告を受けました。出られる状態だと、聞いていましたが"
        ren "……すみません"
        chika "次からは、正直に書いてください。書類も、口でも"
        show chika normal
    elif flags.get("520_正直"):
        chika "5月の練習試合。{rb}桐生{/rb}{rt}きりゅう{/rt}くんが途中で足をつったと聞きました。……あなたの報告どおりでしたね"
        chika "正直な書類は、直しがいがあります"
        $ heart_up("千夏", "信頼", 2)
    "そう言いながら、{rb}千夏{/rb}{rt}ちか{/rt}先輩は赤ペンを取った。"
    "日付の書き方。責任者の欄。夜間の見回りの欄。"
    "書き方の間違いを、全部直してくれた。"
    "机の上のフィルムカメラに、新しいフィルムが入っているのが見えた。"
    menu:
        "書類、ありがとうございます":
            $ heart_up("千夏", "信頼", 5)
            show chika soft
            voice "audio/voice/chika_nn.mp3"
            chika "仕事ですから。……合宿、けがのないように"
        "先輩も見に来てください":
            $ heart_up("千夏", "ときめき", 4)
            show chika narrow
            chika "……試合をですか。生徒会は、そんなに暇ではありません"
            "千夏先輩は、カメラのストラップを指に一回巻きつけた。"
    hide chika
    with dissolve
    return

## 部室：大門の居残り
label ch2_daimon:
    $ set_flag("ch2_daimon")
    scene bg clubroom
    with dissolve
    "部室の前で、{rb}大門{/rb}{rt}だいもん{/rt}が一人で残っていた。"
    "壁に当てたボールを、顔の前で受ける練習をしている。"
    show daimon jersey
    with dissolve
    daimon "あ……{rb}早瀬{/rb}{rt}はやせ{/rt}くん。……今の、内緒にしてください"
    daimon "目をつぶる回数、昨日より2回減りました"
    menu:
        "目を開けたまま、一本止めよう":
            $ bond_up("大門", 5)
            $ up("メンタル", 2)
            "俺が蹴ったボールを、大門は目を開けたまま、胸で止めた。"
            daimon "……と、止められました"
        "今日は終わろう。俺も付き合うから、明日":
            $ bond_up("大門", 4)
            $ up("無理ゲージ", -2)
            daimon "……はい。明日も、お願いします"
    hide daimon
    with dissolve
    return

## 屋上：鷹野と黒田の動画
label ch2_takano:
    $ set_flag("ch2_takano")
    scene bg rooftop
    with dissolve
    "屋上で、{rb}鷹野{/rb}{rt}たかの{/rt}がスマホを見ていた。"
    show takano narrow
    with dissolve
    "画面には、ぼやけた古い試合の動画。"
    "鷹野が見つけた、黒田先生の現役時代の動画だった。青いユニフォームの、背の高い選手。"
    takano "……この人、左足でも同じ球を蹴ってた"
    menu:
        "黒田に教わろう。二人で":
            $ bond_up("鷹野", 5)
            $ lean("仲間型")
            voice "audio/voice/takano_fun.mp3"
            takano "……ふーん。お前が頼むならな"
        "いつか、あれを超える":
            $ bond_up("鷹野", 3)
            $ lean("野心型")
            show takano surprised
            takano "……先に超えるのは、俺だ"
        "「……もう一回。左足のとこ、止めて見せて」":
            $ bond_up("鷹野", 4)
            $ up("戦術眼", 2)
            $ lean("求道型")
            "動画を、何度も止めて、戻して、また止めた。"
            "踏みこむ足の向きが、右と左で、まったく同じだった。"
            takano "……お前、気持ち悪いくらい見るな"
            ren "お前もだろ"
            takano "…………まあな"
    hide takano
    with dissolve
    return

## 港の防波堤：ピアノの音
label ch2_pier:
    $ set_flag("ch2_pier")
    scene bg harbor_sunset
    with dissolve
    $ se("波の音、カモメ")
    "港の防波堤で、一人でボールを蹴った。"
    "壁に当てて、止めて、また蹴る。"
    "近くの家の窓から、ピアノの音が聞こえてきた。"
    "弾きかけて、同じところで止まる。"
    "また最初から弾いて、また同じところで止まる。"
    menu:
        "最後まで聴いていく":
            $ set_flag("ch2_piano")
            $ up("メンタル", 2)
            "ボールを足もとに止めて、しばらく聴いていた。"
            "何度目かで、その曲は、やっと最後まで流れた。"
            "窓の向こうで、誰かがほっと息をついた。"
        "自主練を続ける":
            $ up("技術", 2)
            $ up("無理ゲージ", 2)
            "ピアノが止まるたびに、ボールを蹴った。"
    $ amb_stop()
    return


################################################################################
## 自由行動のしくみ（6月・7月・8月で共通）
##   行き先を選ぶ → その場所のラベル → 人に会った日の夜は、その人からトークが届く（日替わりの夜のトーク）
################################################################################

default ch2_dates = []
default ch2_time = ""
default ch2_banner = ""
default ch2_intro = ""

label ch2_free_loop(month):
    $ ch2_dates, ch2_time, ch2_banner, ch2_intro = CH2_FREE[month]
    $ recap_text = CH2_RECAP[month].replace("2回戦は、0−3で負けた。", "2回戦は、" + ch2_2nd_score + "で負けた。")
    scene black
    with dissolve
    window auto hide
    tuto "自由行動です。[ch2_intro]"
    if month == "jun":
        tuto "メニューの「相関図」から、「選手名鑑」が見られるようになりました。"
        tuto "「メンタル」の練習を選ぶと、練習のあと「港の防波堤」にも寄れます。"
    $ ch2_day = 1
    while ch2_day <= len(ch2_dates):
        $ amb_stop()
        $ set_cal(ch2_dates[ch2_day - 1], ch2_time)
        $ bgm("作戦会議っぽい軽快な曲")
        window auto hide
        ## まず練習メニュー（practice.rpy）。そのあと、行動マップで会いに行く人を選ぶ
        call practice_day(month)
        $ set_cal(ch2_dates[ch2_day - 1], ch2_time)
        $ bgm("作戦会議っぽい軽快な曲")
        window auto hide
        call screen action_map(ch2_spots(month), ch2_banner + "（残り" + str(len(ch2_dates) + 1 - ch2_day) + "日）")
        $ ch2_dest = ch2_spot_label(month, _return)
        $ ch2_res = ""
        if ch2_dest != "ch2_practice":
            $ set_flag(ch2_dest)
        call expression ch2_dest
        $ amb_stop()
        $ _met = ""
        if renpy.has_label("ch2_talk_" + ch2_dest[4:]):
            call ch2_night_talk(ch2_dest)
            $ _met = night_met_of(ch2_dest)
        ## 毎晩、自分からもう1人にトークを送れる（nightcontact.rpy）
        call night_send(ch2_dates[ch2_day - 1], month, met=_met)
        $ ch2_day += 1
    $ amb_stop()
    return

## その日の夜、会った人からトークが届く
label ch2_night_talk(lab):
    scene black
    with dissolve
    $ set_cal(ch2_dates[ch2_day - 1], "夜")
    scene bg ren_room_night
    with dissolve
    $ bgm("静かな夜の曲")
    $ se("トークアプリの通知音")
    window auto hide
    call expression "ch2_talk_" + lab[4:]
    window auto hide
    $ talk_end()
    return

## ひざの警告（無理ゲージが高いときだけ。痛むと、フィジカルが下がって無理ゲージが下がる）
label ch2_knee_warn:
    if hidden["無理ゲージ"] < CH2_KNEE_WARN:
        return
    scene black
    with dissolve
    $ set_cal(CH2_KNEE_WARN_DATE.get(ch2_dates[-1], ch2_dates[-1]), "夕方の練習")
    scene bg kohoku_ground_eve
    with dissolve
    $ bgm("静かなピアノ")
    "次の日の練習。最後のダッシュ。"
    $ se("鈍い衝突音")
    scene bg kohoku_ground_eve at cam_snap(1.1, 0.5, 0.7)
    with vpunch
    "右ひざが、がくんと抜けた。"
    "転びはしなかった。でも、しばらく立てなかった。"
    scene bg kohoku_ground_eve
    with dissolve
    if ch2_knee == "honest" or flags.get("ch2_knee_told"):
        show kuroda normal
        with dissolve
        if ch2_knee == "honest":
            kuroda "……{rb}篠宮{/rb}{rt}しのみや{/rt}から聞いてる。今日はもう上がれ。明日もだ"
        else:
            kuroda "……{rb}三好{/rb}{rt}みよし{/rt}から聞いてる。止めてくれと言ったのは、お前だろう。今日はもう上がれ"
        ren "……はい"
        hide kuroda
        with dissolve
    else:
        "誰にも見られていなかった。"
        "家に帰って、一人で冷やした。"
    $ up("フィジカル", -3)
    $ up("無理ゲージ", -15)
    if not flags.get("tuto_muri"):
        $ set_flag("tuto_muri")
        window auto hide
        tuto "無理ゲージが高いと、ひざが痛むことがあります。技術とフィジカルの練習を続けすぎないようにしましょう（メンタルの練習で、ひざを休められます）。"
    return


################################################################################
## 自由行動の行き先（7月の放課後）
################################################################################

## 生徒会室：千夏のキーホルダー
label ch2_chika_key:
    scene bg student_council
    with dissolve
    $ bgm("張りつめた静かな曲")
    "放課後の生徒会室。{rb}千夏{/rb}{rt}ちか{/rt}先輩は、一人で書類に判を押していた。"
    "机の端のフィルムカメラ。ストラップの先で、色あせたキーホルダーが揺れている。"
    "青と白の、あのマーク。"
    show chika normal
    with dissolve
    chika "……何か用ですか。合宿の申請なら、もう受理しています"
    ren "部室に、写真が届いてました。試合の写真"
    chika "そうですか"
    "千夏先輩は、判を押す手を止めなかった。"
    chika "よかったですね。記念になって"
    ## 規則にきびしい会長が、じつはサッカーにくわしい
    if ch2_shot == "onetwo":
        ren "1回戦、オフサイドで1点取り消されて"
        chika "あれは、副審が正しいです。きわどいときは、プレーが終わるまで旗を上げずに待つんです。パスが出た瞬間、{rb}早瀬{/rb}{rt}はやせ{/rt}くんの右足のかかとが、半歩――"
    else:
        ren "1回戦、{rb}野口{/rb}{rt}のぐち{/rt}がオフサイドばっかり取られて"
        chika "{rb}野口{/rb}{rt}のぐち{/rt}くんは、飛び出すのが早すぎます。パスを出す人の足もとを見ないで走るから、いつも半歩――"
    "判を押す手が、止まった。"
    show chika narrow
    chika "……と、生徒会の記録に書いてありました"
    ren "記録に、そんなことまで？"
    chika "用件は以上ですか"
    "千夏先輩は、また判を押しはじめた。"
    $ heart_up("千夏", "ときめき", 3)
    show chika normal
    if ch2_album == "guess":
        ren "先輩、1回戦、見に来てましたよね"
        "判を押す音が、一瞬止まった。"
        show chika narrow
        chika "……生徒会は、各部の活動を把握しておく必要がありますから"
    menu:
        "「写真、ありがとうございました」":
            $ ch2_res = "thanks"
            show chika narrow
            chika "……私は、何も渡していません"
            "千夏先輩は、カメラのストラップを指に巻きつけた。二回。"
            $ heart_up("千夏", "ときめき", 5)
        "「そのキーホルダー、サッカー部のですよね」":
            $ ch2_res = "key"
            show chika soft
            chika "……4年前の県大会のとき、スタンドで配っていたものです"
            chika "それ以上は、また今度"
            $ heart_up("千夏", "信頼", 5)
            $ set_flag("千夏_キーホルダー")
    hide chika
    with dissolve
    return

label ch2_talk_chika_key:
    $ talk_start("千夏", "21:48")
    $ talk("千夏", "明日の朝練、グラウンドの使用時間を守ってください")
    $ talk("千夏", "……合宿の差し入れは、何がいいですか")
    $ ch2_r = talk_choose([("凍らせたスポーツドリンク", "drink"), ("先輩が来てくれるだけで", "come")])
    if ch2_r == "drink":
        $ talk_me("凍らせたスポーツドリンク")
        $ talk("千夏", "……覚えておきます")
        $ set_flag("千夏_差し入れ_ドリンク")
    else:
        $ talk_me("先輩が来てくれるだけで")
        $ talk("千夏", "生徒会は、差し入れ係ではありません")
        $ heart_up("千夏", "ときめき", 2)
    return

## 職員室：黒田の問題（戦術眼で結果が変わる）
label ch2_kuroda_quiz:
    scene bg staffroom
    with dissolve
    $ bgm("とぼけた日常の曲")
    "職員室。{rb}黒田{/rb}{rt}くろだ{/rt}は、缶コーヒーを片手に古いノートを広げていた。"
    "ページいっぱいに、丸と矢印。"
    show kuroda normal
    with dissolve
    kuroda "……ちょうどいい。{rb}早瀬{/rb}{rt}はやせ{/rt}、問題だ"
    hide kuroda
    with dissolve
    $ tactics(caption="黒田の問題", dots=[
        ("h", "江藤", (60, 10), (84, 8), 0.8, 1.0),
        ("h", "鷹野", (72, 40)), ("h", "坂口", (64, 58)),
        ("a", "", (80, 14), (66, 14), 0.2, 0.8),
        ("a", "", (84, 28)), ("a", "", (84, 42)), ("a", "", (82, 54)),
        ("ren", "蓮", (50, 34)),
        ("ball", "", (51.5, 35.5)),
        ])
    kuroda "相手の右サイドバックが上がった。ボールは真ん中のお前。どこに出す"
    $ learn("ura")
    if check("戦術眼", 50):
        $ tactics(caption="黒田の問題", dots=[
            ("h", "江藤", (84, 8)),
            ("h", "鷹野", (72, 40)), ("h", "坂口", (64, 58)),
            ("a", "", (66, 14)),
            ("a", "", (84, 28)), ("a", "", (84, 42)), ("a", "", (82, 54)),
            ("ren", "蓮", (50, 34)),
            ("ball", "", (51.5, 35.5), (84, 9), 0.3, 0.7),
            ],
            arrows=[((52, 34), (83, 9), 0.2, "y")])
        ren "……鷹野じゃないです。上がったサイドバックの裏に、{rb}江藤{/rb}{rt}えとう{/rt}を走らせます"
        $ tactics_off()
        show kuroda normal
        with dissolve
        "黒田は、黙ってノートを一枚めくった。"
        kuroda "次"
        "三問続けて答えると、黒田はノートを閉じた。"
        kuroda "……お前、本当に見えてるんだな"
        kuroda "俺も昔は、見えてた。ひざが言うことを聞かなくなるまではな"
        $ up("戦術眼", 3)
        $ set_flag("黒田の過去", flags.get("黒田の過去", 0) + 1)
    else:
        ren "……{rb}鷹野{/rb}{rt}たかの{/rt}に、縦パス"
        $ tactics_off()
        show kuroda normal
        with dissolve
        kuroda "半分正解だ。それは止められる"
        kuroda "全員の位置を、もう一回見ろ。答えは、いつもボールのないところにある"
        $ up("戦術眼", 2)
    hide kuroda
    with dissolve
    return

## 駅前のゲーセン：坂口とゲームで勝負（戦術眼で結果が変わる）
label ch2_arcade:
    scene bg game_center
    with dissolve
    $ bgm("ゲームセンターの曲")
    show sakaguchi normal
    with dissolve
    sakaguchi "お、{rb}蓮{/rb}{rt}れん{/rt}じゃん。勝負しようぜ。サッカーゲーム"
    "画面の中でも、{rb}坂口{/rb}{rt}さかぐち{/rt}は右サイドだった。"
    if check("戦術眼", 45):
        $ ch2_res = "win"
        $ se("ゲームのゴール音")
        "坂口のチームは、本物と同じように右サイドを上がりっぱなしだった。"
        "その裏だけを狙った。2−1。"
        sakaguchi "……ウケる。俺の癖、ばれてんじゃん"
        sakaguchi "明日の練習で、それ直すわ"
        $ bond_up("坂口", 5)
        $ up("戦術眼", 1)
    else:
        $ ch2_res = "lose"
        "0−4。"
        sakaguchi "蓮、ゲーム下手すぎ"
        mori "本物のサッカーは、うまいのにね"
        $ bond_up("坂口", 4)
    hide sakaguchi
    with dissolve
    return

label ch2_talk_arcade:
    $ talk_start("坂口", "22:31")
    if ch2_res == "win":
        $ talk("坂口", "今日のリプレイ見たけど")
        $ talk("坂口", "蓮の真ん中、ゲームでもうぜえ")
        $ talk_me("ほめてる？")
        $ talk("坂口", "ほめてねえ（笑）")
    else:
        $ talk("坂口", "次は手加減してやるよ（笑）")
        $ talk_me("次は勝つ")
        $ talk("坂口", "0−4のやつが言うセリフじゃない")
    return

## 港への坂道：ひなたの夢
label ch2_hinata_dream:
    scene bg slope_eve
    with dissolve
    $ bgm("あたたかいアコースティックギター")
    "自販機の横のベンチで、ひなたが分厚い本を読んでいた。"
    "『スポーツ障害とテーピング』。"
    show hinata smile
    with dissolve
    hinata "あ、{rb}蓮{/rb}{rt}れん{/rt}。ちょうどいいところに。ひざ、貸して"
    "ひなたは、慣れた手つきでテープを巻き始めた。"
    show hinata normal
    hinata "……あのね。わたし、トレーナーになりたいの"
    hinata "高校を出たら、専門の学校に行こうかなって"
    hinata "蓮みたいに、ケガしても続けたい人を、続けられるようにする仕事"
    menu:
        "「俺のせいで、決めたのか？」":
            show hinata pout
            hinata "……もう。蓮のせいじゃなくて、蓮のおかげ"
            $ heart_up("ひなた", "信頼", 5)
        "「ひなたなら、なれる」":
            show hinata smile
            hinata "……うん。じゃあ、最初の患者は蓮ね"
            $ heart_up("ひなた", "ときめき", 5)
    $ set_flag("ひなた_トレーナー")
    $ up("無理ゲージ", -3)
    hide hinata
    with dissolve
    return

label ch2_talk_hinata_dream:
    $ talk_start("ひなた", "22:05")
    $ talk("ひなた", "テーピング、はがすとき痛くなかった？")
    $ ch2_r = talk_choose([("ちょっと痛かった", "ouch"), ("全然", "fine")])
    if ch2_r == "ouch":
        $ talk_me("ちょっと痛かった")
        $ talk("ひなた", "ごめん！　次はもっとうまくやる")
        $ heart_up("ひなた", "信頼", 2)
    else:
        $ talk_me("全然")
        $ talk("ひなた", "……テープ、明日も巻くからね")
    return

## 港の防波堤：自主練（6月にピアノを最後まで聴いていると、続きがある）
label ch2_pier_jul:
    scene bg harbor_sunset
    with dissolve
    $ se("波の音、カモメ")
    "港の防波堤で、一人でボールを蹴った。"
    if flags.get("ch2_piano"):
        "今日も、あのピアノが聞こえた。"
        "曲は、もう同じところで止まらなかった。"
        "弾き終わったあと、窓から色素の薄い髪がのぞいたように見えた。"
        "すぐに、カーテンが閉まった。"
        $ up("メンタル", 3)
        $ set_flag("紗希_ピアノ2")
    else:
        "壁に当てて、止めて、また蹴る。暗くなるまで続けた。"
        $ up("技術", 3)
        $ up("無理ゲージ", 3)
    $ amb_stop()
    return


################################################################################
## 自由行動の行き先（8月・夏休み）
################################################################################

## はやせ食堂：ひなたと母
label ch2_shokudo:
    $ set_cal(ch2_dates[ch2_day - 1], "昼")
    scene bg shokudo_day
    with dissolve
    $ bgm("あたたかいアコースティックギター")
    $ se("包丁がまな板を叩く音")
    "夏休みの昼。店は、汗だくの漁師さんたちでいっぱいだった。"
    "ひなたが、勝手にエプロンをつけて手伝いに来ていた。"
    show mother smile at left
    with dissolve
    haha "ひなたちゃん、もううちの子になっちゃう？"
    show hinata apron at right
    with dissolve
    hinata "えっ"
    ren "母さん！"
    haha "冗談だよ。……{rb}蓮{/rb}{rt}れん{/rt}、ひざは"
    ren "……大丈夫"
    show mother normal at left
    haha "そう。やりたいことやりな"
    "カウンターの奥から、妹のゆずが顔を出した。"
    yuzu "ひなちゃん、お兄ちゃんのお嫁さんになるの？"
    hinata "ならない！"
    ren "ならない"
    hinata "……そこは蓮が言わなくていいの"
    menu:
        "ひなたと並んで、皿を洗う":
            "肩がぶつかるたびに、ひなたは「せまい」と笑った。"
            $ heart_up("ひなた", "ときめき", 5)
        "厨房で、母さんを手伝う":
            show mother sadsmile at left
            haha "お父さんも、夏は真っ黒だったよ。ボールばっかり追いかけて"
            $ up("メンタル", 3)
    hide mother
    hide hinata
    with dissolve
    return

label ch2_talk_shokudo:
    $ talk_start("ひなた", "21:12")
    $ talk("ひなた", "まかない、おいしかった")
    $ talk("ひなた", "千鶴さんに、また来てって言われた")
    $ ch2_r = talk_choose([("いつでも来いよ", "come"), ("母さんの冗談、気にすんな", "joke")])
    if ch2_r == "come":
        $ talk_me("いつでも来いよ")
        $ talk("ひなた", "……うん")
        $ heart_up("ひなた", "ときめき", 2)
    else:
        $ talk_me("母さんの冗談、気にすんな")
        $ talk("ひなた", "気にしてないし！")
        $ heart_up("ひなた", "信頼", 2)
    return

## 部室：三好の夏
label ch2_miyoshi_summer:
    scene bg clubroom
    with dissolve
    $ bgm("日常の静かな曲")
    "夏休みの部室で、{rb}三好{/rb}{rt}みよし{/rt}先輩が一人でスパイクを磨いていた。"
    show miyoshi smile
    with dissolve
    miyoshi "俺さ。選手権が終わったら、引退なんだよな"
    miyoshi "受験しないで、親父の工務店で働く。だから俺のサッカーは、この冬で終わり"
    menu:
        "「終わらせません。勝ち続けます」":
            $ lean("野心型")
            miyoshi "……おう。じゃあ一日でも長く、俺を引退させないでくれ"
        "「先輩のサッカー、最後まで見てます」":
            $ lean("仲間型")
            miyoshi "見てるだけじゃなくて、一緒に走れよ！"
    $ bond_up("三好", 6)
    $ set_flag("三好_引退")
    $ set_flag("三好_工務店")
    hide miyoshi
    with dissolve
    return

label ch2_talk_miyoshi_summer:
    $ talk_start("三好", "23:02")
    $ talk("三好", "さっきの話、みんなには内緒な！！")
    $ talk("三好", "しんみりするの苦手なんだよ俺")
    $ talk_me("了解です")
    $ talk("三好", "明日も6時半な！！")
    return

## 柔道場：大門のあいさつ
label ch2_daimon_judo:
    scene bg judo_hall
    with dissolve
    $ bgm("明るい部活の曲")
    "{rb}大門{/rb}{rt}だいもん{/rt}は、柔道部の先輩たちに頼まれて、畳の上でキーパーの飛びこみを見せていた。"
    judo_senpai "PK止めたんだってな。受け身の大門が"
    show daimon worried
    with dissolve
    daimon "は、はい。受け身、役に立ちました"
    menu:
        "「大門の受け身は、港北の武器だ」":
            $ bond_up("大門", 5)
            show daimon normal
            daimon "……ぶ、武器"
            "大門は、うれしそうに自分の手のひらを見ていた。"
        "「今度、俺にも受け身を教えてくれ」":
            daimon "えっ、僕が教える側ですか！？"
            $ se("畳に人が落ちる音")
            "その日、畳の上で30回投げられた。"
            $ bond_up("大門", 4)
            $ up("フィジカル", 2)
    hide daimon
    with dissolve
    return

label ch2_talk_daimon_judo:
    $ talk_start("大門", "21:40")
    $ talk("大門", "柔道部の先輩たちが、選手権を見に来るって言ってました")
    $ talk("大門", "こ、怖いです")
    $ talk_me("大門が怖がられる側だろ")
    $ talk("大門", "それはそうなんですけど")
    return

## 夜のグラウンド：鷹野の左足（技術で結果が変わる）
label ch2_takano_night:
    $ set_cal(ch2_dates[ch2_day - 1], "夜")
    scene bg kohoku_ground_night
    with dissolve
    $ bgm("張りつめた静かな曲")
    "夜のグラウンドで、{rb}鷹野{/rb}{rt}たかの{/rt}が一人で左足のキックを繰り返していた。"
    "{rb}黒田{/rb}{rt}くろだ{/rt}が右足で蹴った、あのボール。それを、鷹野は左足でまねしていた。"
    show takano jersey_narrow
    with dissolve
    takano "……見てんじゃねえよ。どうせなら、相手しろ"
    "一対一。"
    hide takano
    with dissolve
    $ se("土を蹴る足音")
    scene bg kohoku_ground_night at cam_jog
    with dissolve
    if check("技術", 48):
        $ ch2_res = "win"
        $ se("ボールが抜けていく音")
        "一回だけ、鷹野を抜いた。"
        scene bg kohoku_ground_night
        show takano jersey_surprised
        with dissolve
        takano "……もう一本"
        "鷹野の口もとが、ゆるんでいた。"
        $ bond_up("鷹野", 5)
        $ up("技術", 2)
    else:
        $ ch2_res = "lose"
        $ se("ボールを奪われる音")
        "5回やって、5回とも止められた。"
        scene bg kohoku_ground_night
        show takano jersey
        with dissolve
        takano "真ん中のやつが、一人も抜けなくてどうすんだよ"
        $ bond_up("鷹野", 3)
        $ up("フィジカル", 2)
    hide takano
    with dissolve
    return

label ch2_talk_takano_night:
    $ talk_start("鷹野", "23:40")
    $ talk("鷹野", "左足")
    $ talk("鷹野", "明日も")
    $ talk_me("了解")
    return

## 生徒会室：夏休みの千夏
label ch2_chika_summer:
    scene bg student_council
    with dissolve
    $ bgm("張りつめた静かな曲")
    "夏休みの生徒会室。扇風機の音だけがしていた。"
    "合宿の報告書を、出しに来た。"
    "机の上に、一枚の書類が出しっぱなしになっていた。"
    "『県立高校の再編計画（案）』。{rb}港北{/rb}{rt}こうほく{/rt}の名前に、赤い線が引いてある。"
    show chika narrow
    with dissolve
    chika "……見ましたか"
    menu:
        "「見てません」":
            $ ch2_res = "no"
            $ set_flag("統廃合_見た")     # 気をつかって「見てません」と言ったが、本当は見ている（第3章で使う）
            show chika soft
            chika "……うそが下手ですね。ありがとうございます"
            $ heart_up("千夏", "信頼", 5)
        "「港北、どうなるんですか」":
            $ ch2_res = "ask"
            chika "まだ、決まっていません"
            chika "……決めさせません"
            $ heart_up("千夏", "ときめき", 4)
            $ set_flag("統廃合を知る")
    hide chika
    with dissolve
    return

label ch2_talk_chika_summer:
    $ talk_start("千夏", "22:20")
    $ talk("千夏", "今日のことは、誰にも言わないでください")
    $ talk("千夏", "……報告書、ありがとうございました")
    $ ch2_r = talk_choose([("言いません。約束します", "promise"), ("一人で抱えないでください", "alone")])
    if ch2_r == "promise":
        $ talk_me("言いません。約束します")
        $ talk("千夏", "……助かります")
        $ heart_up("千夏", "信頼", 2)
    else:
        $ talk_me("一人で抱えないでください")
        $ talk("千夏", "抱えていません。仕事ですから")
        $ talk("千夏", "……でも、覚えておきます")
        $ heart_up("千夏", "ときめき", 2)
    return


################################################################################
## 6月の行き先の夜のトーク
################################################################################

label ch2_talk_council:
    $ talk_start("千夏", "21:55")
    $ talk("千夏", "申請書の控えを、部室のポストに入れておきました")
    $ talk("千夏", "なくさないでください")
    $ ch2_r = talk_choose([("合宿の見回り、先輩が来るんですか", "patrol"), ("赤ペンの字、きれいでした", "hand")])
    if ch2_r == "patrol":
        $ talk_me("合宿の見回り、先輩が来るんですか")
        $ talk("千夏", "申請書に書いたとおりです")
        $ talk("千夏", "消灯は10時。守ってください")
        $ heart_up("千夏", "信頼", 2)
    else:
        $ talk_me("赤ペンの字、きれいでした")
        $ talk("千夏", "……字のことを言われたのは、初めてです")
        $ talk("千夏", "仕事ですから")
        $ heart_up("千夏", "ときめき", 2)
    return

label ch2_talk_daimon:
    $ talk_start("大門", "21:30")
    $ talk("大門", "今日はありがとうございました")
    $ talk("大門", "目をつぶった回数、ゼロでした")
    $ talk("大門", "……うそです。1回です")
    $ talk_me("明日はゼロな")
    $ talk("大門", "は、はい！")
    return

label ch2_talk_takano:
    $ talk_start("鷹野", "23:15")
    $ talk("鷹野", "さっきの動画")
    $ talk("鷹野", "23分のとこ、左足")
    $ talk_me("見た。えぐい")
    $ talk("鷹野", "だろ")
    return


################################################################################
## 夏祭りに誘う（8月14日の夜）
################################################################################

## ひなた：閉店後の店で、二人きり
label ch2_invite_hinata:
    scene bg shokudo_night
    with dissolve
    "階段を下りると、閉店したあとの店に、まだ明かりがついていた。"
    "ひなたが、エプロンをつけたまま、皿を拭いていた。"
    show hinata apron
    with dissolve
    hinata "あ、{rb}蓮{/rb}{rt}れん{/rt}。{rb}千鶴{/rb}{rt}ちづる{/rt}さん、ゆずちゃんと二階に上がったよ"
    hinata "明日、練習休みだって。{rb}三好{/rb}{rt}みよし{/rt}先輩、テンション高すぎ"
    "皿と布巾がこすれる音だけが、しばらく続いた。"
    "……言うなら、今だ。"
    menu:
        "「……明日の花火。一緒に行かないか」":
            $ ch2_invite = "plain"
            $ heart_up("ひなた", "ときめき", 5)
            "ひなたの手が、止まった。"
            hinata "…………二人で？"
            ren "二人で"
            hinata "……行く。行くに決まってるじゃん"
            "ひなたは、拭き終わった皿を、もう一回拭いていた。"
        "「どうせ暇だろ。付き合えよ」":
            $ ch2_invite = "tease"
            $ heart_up("ひなた", "信頼", 4)
            $ heart_up("ひなた", "ときめき", 1)
            hinata "暇じゃないし。宿題あるし"
            hinata "……でも、蓮が一人だとかわいそうだから、行ってあげる"
            ren "誰も一人だなんて言ってない"
            hinata "眉毛、上がってるよ"
        "「……ひなたの浴衣、見たいんだけど」":
            $ ch2_invite = "yukata"
            $ heart_up("ひなた", "ときめき", 7)
            "ひなたの手から、布巾が落ちた。"
            hinata "な、な、なにそれ"
            ren "……言ってみただけだ"
            hinata "言ってみただけで言わないでよ！"
            "ひなたは真っ赤な顔で、俺の背中をばしんと叩いた。"
            hinata "……楽しみにしててよね。もう"
    "店を出ていくひなたの足音は、いつもより速かった。"
    hide hinata
    with dissolve
    return

## 千夏：トークで
label ch2_invite_chika:
    "{rb}千夏{/rb}{rt}ちか{/rt}先輩とのトークを開いた。"
    "6月のあの夜から、何度かやりとりはした。でも、こっちから何かに誘ったことは、一度もない。"
    "送る言葉を、三回消して、三回打ち直した。"
    window auto hide
    $ talk_start("千夏", "21:52")
    $ ch2_r = talk_choose([("明日の花火大会、一緒に行きませんか", "plain"), ("花火、撮りに行きませんか。先輩のカメラで", "photo"), ("先輩の浴衣、見てみたいです", "yukata")])
    $ ch2_invite = ch2_r
    if ch2_r == "plain":
        $ talk_me("明日の花火大会、一緒に行きませんか")
        $ talk_system("既読がついてから、2分")
        $ talk("千夏", "……生徒会として、地域の行事を視察する予定はありました")
        $ talk("千夏", "19時。潮見港駅の改札。遅刻は認めません")
        $ heart_up("千夏", "信頼", 4)
    elif ch2_r == "photo":
        $ talk_me("花火、撮りに行きませんか。先輩のカメラで")
        $ talk("千夏", "フィルムの残りは、24枚です")
        $ talk("千夏", "花火は、写真に撮るのがいちばん難しい被写体の一つです。シャッターを開けておく時間が――")
        $ talk_system("千夏がメッセージの送信を取り消しました")
        $ talk("千夏", "19時。潮見港駅の改札。三脚は私が持っていきます")
        $ heart_up("千夏", "信頼", 3)
        $ heart_up("千夏", "ときめき", 2)
    else:
        $ talk_me("先輩の浴衣、見てみたいです")
        $ talk_system("既読がついてから、5分")
        $ talk("千夏", "生徒会長が、浴衣で祭りに行かなければならない規則はありません")
        $ talk("千夏", "……持っていない、とは言っていません")
        $ talk("千夏", "19時。潮見港駅の改札")
        $ heart_up("千夏", "ときめき", 6)
    window auto hide
    $ talk_end()
    "スマホを置いても、しばらく画面を見ていた。"
    return

## 鷹野と大門：3人のトーク
label ch2_invite_boys:
    window auto hide
    $ talk_start("花火（3）", "21:48")
    $ talk_me("明日、花火行かないか")
    $ talk("大門", "い、行きます！　甚平、あります！")
    $ talk("鷹野", "……人多いとこ、嫌いなんだけど")
    $ ch2_r = talk_choose([("射的で勝負な。負けたら焼きそば", "shoot"), ("来いよ。三人で行きたいんだ", "honest")])
    $ ch2_invite = ch2_r
    if ch2_r == "shoot":
        $ talk_me("射的で勝負な。負けたら焼きそば")
        $ talk("鷹野", "……乗った。大盛りな")
        $ talk("大門", "ぼ、僕、射的は得意じゃないです……")
        $ bond_up("鷹野", 4)
        $ bond_up("大門", 2)
    else:
        $ talk_me("来いよ。三人で行きたいんだ")
        $ talk("鷹野", "……は？　きも")
        $ talk("鷹野", "19時な")
        $ talk("大門", "鷹野くん、来るんですね！")
        $ talk("鷹野", "うるせえ")
        $ bond_up("鷹野", 3)
        $ bond_up("大門", 3)
    window auto hide
    $ talk_end()
    return


################################################################################
## 千夏：最初のトーク（6/1 の夜）
##   スマホに不慣れな千夏が、ビデオ通話を開いたまま、気づかずに文を打ち続ける。
##   黙って見ている／カメラのことを言う、で、見えるものが変わる。次の朝、校門で一言。
################################################################################

label ch2_chika_videocall:
    ## ――そのころの千夏（5月から何度か送っているのに、既読がつかない。蓮はメモのIDを追加し忘れていた）
    scene black
    with dissolve
    "――同じ日の、夕方。"
    $ cal_time = "夕方"
    scene bg student_council
    with dissolve
    $ bgm("とぼけた日常の曲")
    "生徒会室に、一人だけ残っている人がいた。"
    show chika normal
    with dissolve
    "{rb}七瀬{/rb}{rt}ななせ{/rt}{rb}千夏{/rb}{rt}ちか{/rt}は、判を押す手を止めて、机の端のスマホを見た。"
    "トークアプリを開く。サッカー部の届けの、連絡先の欄から追加した名前。"
    "5月に送った二通のメッセージには、どちらも、まだ「既読」がついていなかった。"
    voice "audio/voice/chika_kidoku.mp3"
    chika "……既読が、つきません"
    chika "見ていないだけです。サッカー部は、忙しいので"
    "判を、一つ押す。スマホを見る。既読は、ついていない。"
    "判を、もう一つ押す。スマホを見る。"
    "判を押すたびに、スマホを見た。届けの束は、いつもの倍の時間をかけて、少しずつ減っていった。"
    show chika narrow
    chika "……IDを書き間違えた可能性があります。確認するのは、生徒会の仕事です"
    "一文だけ打って、送信を押した。"
    "それから、画面をしばらく見つめた。"
    voice "audio/voice/chika_santsume.mp3"
    chika "……三通目は、規則違反だったかもしれません"
    "判を、一つ押す。スマホを見る。"
    "既読は、やっぱり、ついていなかった。"
    hide chika
    with dissolve
    scene black
    with dissolve
    "――その夜。"
    $ cal_time = "夜"
    scene bg ren_room_night
    with dissolve
    $ bgm("静かな夜の曲")
    "明日の時間割をそろえようとして、カバンの内ポケットに指が当たった。"
    "四つに折った、小さな紙。"
    "5月に、{rb}千夏{/rb}{rt}ちか{/rt}先輩から渡されたメモ。トークアプリのIDが、一行だけ書いてある。"
    "……追加するのを、忘れていた。"
    "部の申請や連絡は、これからはあなたに送ります。――そう言われたのに。"
    "IDを打ちこんで、追加を押した。"
    $ set_flag("千夏_友だち")
    window auto hide
    $ talk_start("千夏", "22:56")
    $ talk_day("5月21日（木）", "18:12")
    $ talk_old("千夏", "生徒会の七瀬です。サッカー部の登録、受理しました")
    $ talk_old("千夏", "部の連絡は、こちらに送ります。よろしくお願いします")
    $ talk_day("5月28日（木）", "19:40")
    $ talk_old("千夏", "練習試合の校外活動届は、前日までに提出してください")
    $ talk_day("6月1日（月）", "17:26")
    $ talk("千夏", "IDは、これで合っていますか")
    "メッセージが、三通。最初の一通は、もう10日以上も前だった。"
    "どれも、今、俺が開いたこの瞬間に、まとめて「既読」になったはずだ。"
    "……連絡することなら、今日、一つあった。"
    $ talk_minutes = 22 * 60 + 57
    $ talk_system("千夏を友だちに追加しました")
    $ talk_me("早瀬です。すみません、IDを追加するのを忘れていました。合っています")
    $ talk_me("今日から、黒田先生が練習を見てくれることになりました。部の届けに書くことがあれば、教えてください")
    $ talk_end()
    "既読は、すぐについた。"
    "返事は、来なかった。一分。三分。五分。"
    "寝る前に送るような話じゃなかったか、と思いはじめたころ。"
    window auto hide
    $ talk_start("千夏", "23:04")
    $ talk_system("千夏が入力しています")
    $ talk("千夏", "確認します。一つ、確かめたいことがあります")
    $ talk_system("千夏がビデオ通話を開始しました")
    $ talk_end()
    $ se("スマホの着信（ビデオ通話）")
    "画面いっぱいに、着信の表示が出た。"
    "……ビデオ？"
    "考えるより先に、親指が「応答」を押していた。"
    $ bgm("（なし）")
    scene cg chika_video at cam_push(10.0, 1.04)
    with Dissolve(1.0)
    "映ったのは、知らない女の人だった。"
    "――と、一瞬思った。"
    "いつもまっすぐおろしている長い黒髪が、濡れたまま、前髪ごと全部うしろへかき上げられていた。おでこが、全部見えている。"
    "首にはバスタオル。生徒会の腕章も、きっちり結んだリボンもない。首まわりのゆるい部屋着が、片方の肩から少しだけずり落ちていた。"
    "{rb}七瀬{/rb}{rt}ななせ{/rt}{rb}千夏{/rb}{rt}ちか{/rt}だった。たぶん。"
    "画面の中の千夏先輩は、こっちを見ていなかった。"
    "手元のスマホを両手で持って、眉を寄せて、親指だけを真剣に動かしている。"
    "ビデオは、机に立てたタブレットのほうから、つながっているらしかった。同じアカウントで、両方に入れてあるのかもしれない。"
    "カメラがついていることに、気づいていない。"
    "手の中で、トークの通知が光った。"
    "『監督の欄は、届けの二枚目です。顧問の欄とは別です。』"
    "画面の中の千夏先輩が、首をかしげる。何か打って、消して、また打つ。"
    "三好先輩が言っていた。千夏先輩のスマホには、トークアプリのほかは、最初から入っているアプリしかない、と。タブレットは、たぶん家族のだ。"
    $ bgm("とぼけた日常の曲")

    menu:
        "……黙って見ている":
            $ ch2_video = "watch"
            "声をかけるタイミングを、なくした。"
            "千夏先輩が、ふっと息をはいて、小さな声でつぶやいた。"
            voice "audio/voice/chika_katai.mp3"
            chika "……早瀬くん。……は、硬いですか"
            "誰もいない部屋で、自分にだけ聞かせる声だった。"
            voice "audio/voice/chika_renkun.mp3"
            chika "……{rb}蓮{/rb}{rt}れん{/rt}、くん"
            "言ってから、千夏先輩は、スマホを持ったまま、両手で顔を覆った。"
            "画面が、しばらく、指のすき間だけになった。"
            "通知が光る。"
            "『明日も、よろしくお願いします。早瀬くん』"
            "結局、そこに戻ったらしい。"
            $ bgm("（止まる）")
            scene cg chika_video_eyes
            with Dissolve(0.3)
            "――そのとき、千夏先輩が、顔を上げた。"
            "画面の中で、目が合った。"
            "…………"
            "三秒。"
            "画面が、真っ暗になった。"
            $ heart_up("千夏", "ときめき", 6)
            $ set_flag("千夏_名前の練習")
            scene bg ren_room_night
            with dissolve
            window auto hide
            $ talk_start("千夏", "23:04")
            $ talk_system("ビデオ通話が終了しました（5:12）")
            $ talk_system("既読がついてから、7分")
            $ talk("千夏", "通信の不具合です")
            $ talk("千夏", "おやすみなさい")
            $ talk_end()
            "5分12秒。"
            "そのうちの何秒を見られていたのか、千夏先輩は、たぶん計算している。"
        "「先輩。カメラ、ついてます」と言う":
            $ ch2_video = "tell"
            ren "……先輩。カメラ、ついてます"
            "千夏先輩の親指が、止まった。"
            $ bgm("（止まる）")
            scene cg chika_video_eyes
            with Dissolve(0.3)
            "ゆっくり、顔が上がる。画面の中で、目が合った。"
            voice "audio/voice/chika_e.mp3"
            chika "………………え"
            $ se("スマホが机に倒れる音")
            "千夏先輩の手が、カメラのほうへ伸びてきた。"
            scene cg chika_video_fall at cam_snap(1.08)
            with hpunch
            "画面がぐるりと回って、天井の照明が映った。タオルの端と、指先だけが、画面の下を横切っていく。"
            "照明の横の、カーテンレールに、ハンガーが一つ。干してあるのは、白いレースの……"
            "――見なかったことにした。"
            "その下の壁に、コルクボードが映った。新聞の切り抜きが一枚だけ、四すみをきっちりピンで留めてある。"
            "『県大会　潮見FC・早瀬　決勝へ導く2アシスト』。中2の秋の、地方紙の小さな記事だった。"
            "……俺の記事だった。"
            voice "audio/voice/chika_minaide.mp3"
            chika "見ないでください！ 今のは、見ていません！ 早瀬くんは、何も見ていません！"
            voice "audio/voice/chika_shiryou.mp3"
            chika "そ、それと、それは資料です！ 部の存続の審査のための、資料です！"
            "……一年半以上も前の記事が？"
            "聞き返す前に、通話が切れた。"
            $ set_flag("千夏_切り抜き")
            $ heart_up("千夏", "信頼", 5)
            $ heart_up("千夏", "ときめき", 3)
            scene bg ren_room_night
            with dissolve
            window auto hide
            $ talk_start("千夏", "23:04")
            $ talk_system("ビデオ通話が終了しました（1:48）")
            $ talk("千夏", "今のは、事故です")
            $ talk("千夏", "記録から、消去してください")
            $ ch2_r = talk_choose([("消去しました", "erase"), ("髪、上げてるの初めて見ました", "hair"), ("あの記事、なつかしかったです", "clip")])
            if ch2_r == "erase":
                $ talk_me("消去しました")
                $ talk("千夏", "……ご協力、感謝します")
                $ heart_up("千夏", "信頼", 2)
            elif ch2_r == "clip":
                $ talk_me("あの記事、なつかしかったです")
                $ talk_system("既読がついてから、6分")
                $ talk("千夏", "資料です")
                $ talk("千夏", "……記録から、消去してください。両方とも")
                $ heart_up("千夏", "ときめき", 2)
                $ heart_up("千夏", "信頼", 2)
            else:
                $ talk_me("髪、上げてるの初めて見ました")
                $ talk_system("既読がついてから、4分")
                $ talk("千夏", "消去してください、と言いました")
                $ talk("千夏", "……乾かしている途中でした")
                $ talk("千夏", "誰にも言わないでください")
                $ heart_up("千夏", "ときめき", 3)
            $ talk("千夏", "おやすみなさい")
            $ talk_end()
    $ set_flag("千夏_ビデオ", ch2_video)
    $ bgm("（なし）")

    ## 次の朝の校門（服装検査）
    scene black
    with dissolve
    $ set_cal("6月2日（火）", "朝")
    scene bg kohoku_gate_summer
    with dissolve
    $ bgm("のんびりした春の曲")
    "次の朝。校門の前で、生徒会が服装検査をしていた。"
    show chika normal
    with dissolve
    chika "おはようございます。シャツは、ズボンに入れてください"
    "いつもの声。いつもの腕章。まっすぐおろした、いつもの黒髪。"
    "目だけが、一度も合わなかった。"
    chika "……それから"
    voice "audio/voice/chika_tamatama.mp3"
    chika "昨夜、既読がすぐについたのは、たまたまトークの画面を開いていたからです。ずっと開いていたわけでは、ありません"
    ren "……何も言ってないです"
    chika "……今のも、記録にありません"
    chika "それと。IDは、次からは、もらったその日のうちに追加してください"
    if ch2_video == "watch":
        show chika narrow
        chika "……早瀬くん"
        "名前を呼ぶ前に、ひと呼吸ぶん、間があった。"
        voice "audio/voice/chika_fuguai.mp3"
        chika "昨夜は、通信の不具合がありました。それ以外は、何もありませんでした"
    else:
        show chika narrow
        chika "……早瀬くん。昨夜のことは、記録にありません"
    "そう言った千夏先輩の耳が、赤かった。"
    hide chika
    with dissolve
    return

