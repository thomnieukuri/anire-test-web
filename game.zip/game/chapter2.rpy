## chapter2.rpy ―― 第2章「泥だらけの夏」（高1・6〜8月）
##   台本：アンイレ 体験版台本（第2章「泥だらけの夏」のタブ）
##   黒田が初めて練習を見る → インターハイ予選で初勝利（PK戦） → 夏合宿 → 港の夏祭りで紗希と再会

## 自由行動の日付（6月の放課後・2日）
define CH2_FREE_DATES = ["6月9日（火）", "6月11日（木）"]

## 自由行動の前に読める「これまでのこと」
define CH2_RECAP = [
    "5月31日、桜嶺学園Bとの練習試合は0−9。\n最後まで足を止めなかったのは、三好先輩だけだった。\n\n6月。約束どおり、黒田先生が練習を見に来た。\n黒田先生は、元潮見ブルーマリンズの選手。J1で4年プレーして、28歳のとき、ひざのケガで引退した人だった。\n\n全員のポジションが決まった。俺は、真ん中。\nインターハイ予選の1回戦まで、あと少し。",
]

## 夏祭りに誘える条件（千夏の「ときめき＋信頼」がこれ以上のときだけ、千夏先輩を誘える）
##   第1章・第2章で一度も生徒会室に行かないと、だいたい10。どちらかで一度行けば届く
define CH2_CHIKA_INVITE = 14

default ch2_day = 1
default ch2_dest = ""
default ch2_pos = ""          # 作戦ボードで言ったこと（center / goal / takano）
default ch2_knee = ""         # ひざのことを、ひなたに正直に言ったか（honest / hide）。第3章・第5章に影響
default ch2_shot = ""         # 残り5分の判断（shoot / onetwo / back）
default ch2_night = ""        # 夜の体育館で話したこと（knee / ouryo / love）
default ch2_fest = ""         # 夏祭りに誘った相手（hinata / chika / boys / alone）
default ch2_saki_word = ""    # 満員電車で紗希に言ったこと（long / ok / none）

init python:
    ## 行動マップの行き先。学校の中と港の堤防があるので、町の地図に出す
    ##   タグは横に約270ピクセルあるので、重ならないように散らしている
    def ch2_spots():
        f = store.flags
        return [
            {"id": "ground", "name": "グラウンド", "x": 240, "y": 200,
             "event": "練習（能力アップ）", "enabled": True},
            {"id": "council", "name": "生徒会室", "x": 640, "y": 110, "face": "chika",
             "event": "" if f.get("ch2_council") else "千夏", "enabled": not f.get("ch2_council")},
            {"id": "clubroom", "name": "部室", "x": 520, "y": 250, "face": "daimon",
             "event": "" if f.get("ch2_daimon") else "大門", "enabled": not f.get("ch2_daimon")},
            {"id": "roof", "name": "屋上", "x": 330, "y": 45, "face": "takano",
             "event": "" if f.get("ch2_takano") else "鷹野", "enabled": not f.get("ch2_takano")},
            {"id": "pier", "name": "港の防波堤", "x": 330, "y": 560,
             "event": "" if f.get("ch2_pier") else "自主練", "enabled": not f.get("ch2_pier")},
        ]

    ## 作戦ボード：4−4−2 の11人（紺が港北。右へ攻める。画面の下側が右サイド）
    CH2_442 = [
        ("h", "大門", (5, 34)),
        ("h", "三好", (18, 41)), ("h", "桐生", (18, 27)), ("h", "宮下", (24, 11)),
        ("h", "森", (24, 57)), ("h", "坂口", (46, 59)), ("h", "小池", (36, 34)), ("h", "江藤", (46, 9)),
        ("h", "鷹野", (70, 42)), ("h", "野口", (70, 26)),
        ("ren", "蓮", (52, 34)),
    ]

    def ch2_board(n, caption="港北　4−4−2"):
        """作戦ボードに、CH2_442 の最初の n 人を並べる（黒田が一つずつ置いていく）"""
        tactics(dots=CH2_442[:n], caption=caption)


label chapter2:
    scene black
    with Dissolve(1.0)
    call show_title("第2章", "泥だらけの夏")

    ############################################################################
    ## シーン1：黒田の作戦ボード（6月1日・月曜）
    ############################################################################
    $ set_cal("6月1日（月）", "放課後")
    scene bg kohoku_ground_eve
    with dissolve
    $ bgm("とぼけた日常の曲")

    "月曜日。{rb}黒田{/rb}{rt}くろだ{/rt}は、本当に来た。"
    $ se("サンダルが土をこする音")
    "よれたジャージにサンダル。脇に、緑色の板を抱えている。"
    show kuroda board
    with dissolve
    kuroda "集まれ"
    show miyoshi smile at right
    with dissolve
    miyoshi "はいっ！　全員集合ー！"
    voice "audio/voice/kuroda_koe.mp3"
    kuroda "……{rb}三好{/rb}{rt}みよし{/rt}。声がでかい"
    hide miyoshi
    with dissolve
    "黒田がグラウンドの隅に立てかけたのは、マグネットの作戦ボードだった。"
    "緑の盤面に、白いチョークのライン。端が少しさびている。"
    kuroda "11人いる。だから、今日から11人の場所を決める"
    "黒田は、紺のマグネットを一つ、ゴールの前に置いた。"

    hide kuroda
    with dissolve
    $ ch2_board(1)
    kuroda "キーパー、{rb}大門{/rb}{rt}だいもん{/rt}"
    voice "audio/voice/daimon_hai.mp3"
    daimon "は、はいっ！"
    kuroda "受け身だけは柔道部でいちばんだったそうだな。倒れるのが怖くないやつは、キーパーに向いてる"
    daimon "……倒れるのは、慣れてます"
    kuroda "ボールが怖いのは、そのうち慣れる"

    "黒田は、ゴール前のすぐ上に、もう一つマグネットを置いた。"
    $ ch2_board(2)
    kuroda "センターバック、三好"
    miyoshi "俺がですか！？　俺、技術ないですよ！"
    kuroda "知ってる。0−9の試合、最後まで走ってたのはお前だけだ"
    kuroda "いちばん走るやつを、いちばん後ろに置く。抜かれても、追いつけるからな"
    show miyoshi smile at right
    with dissolve
    voice "audio/voice/miyoshi_yosha.mp3"
    miyoshi "……っしゃあ！"
    hide miyoshi
    with dissolve
    $ ch2_board(4)
    kuroda "その隣に{rb}桐生{/rb}{rt}きりゅう{/rt}。左のサイドバックに{rb}宮下{/rb}{rt}みやした{/rt}"
    kiryu "……名前だけの部員だったのに"
    miyashita "ちゃんと場所あるんだ"

    "黒田は、ゲーセンの5人組のほうを向いた。"
    kuroda "お前ら。ゲームでは、どこをやってる"
    sakaguchi "は？"
    kuroda "サッカーのゲームだ。毎日やってるんだろう"
    "5人が顔を見合わせた。"
    sakaguchi "……俺は右サイド。上がりっぱなしで、ずっとクロス上げてる"
    mori "{rb}森{/rb}{rt}もり{/rt}です。右のサイドバック。坂口が上がりっぱなしだから、俺がずっと尻ぬぐいしてます"
    eto "{rb}江藤{/rb}{rt}えとう{/rt}。左サイド。……ドリブルしかしない"
    koike "{rb}小池{/rb}{rt}こいけ{/rt}っす。真ん中の後ろのほう。パスを散らす係"
    noguchi "{rb}野口{/rb}{rt}のぐち{/rt}。前。点を取る係。取ったことないけど"
    kuroda "じゃあ、それでいい"
    voice "audio/voice/sakaguchi_maji.mp3"
    sakaguchi "……は？　マジで？"
    kuroda "ゲームでも、自分がどこにいると気持ちいいかは分かってる。それで十分だ"
    "5人のマグネットが、ボードの上に並んでいく。"
    $ ch2_board(8)
    voice "audio/voice/sakaguchi_ukeru.mp3"
    sakaguchi "……ウケる。ゲームと同じじゃん"

    "黒田の手が、最後の二つのマグネットで止まった。"
    $ ch2_board(10)
    kuroda "フォワード、{rb}鷹野{/rb}{rt}たかの{/rt}と野口"
    show takano normal at right
    with dissolve
    takano "……当然だろ"
    hide takano
    with dissolve
    kuroda "そして、{rb}早瀬{/rb}{rt}はやせ{/rt}"
    $ ch2_board(11)
    "赤い輪のついたマグネットが、ボードのど真ん中に置かれた。"
    kuroda "真ん中だ"
    ren "……トップ下じゃなくて、ですか"
    kuroda "お前は前を向いてボールを持つと、見る前に全部見えてる。そういうやつは、真ん中に置く。全員にボールを配れ"
    kuroda "それに、そのひざだ。前で削られるより、真ん中で受けて、はたけ"
    "4−4−2。11個のマグネットが、緑の盤面に並んだ。"
    $ tactics_off()

    show kuroda board
    with dissolve
    menu:
        "真ん中で、全員を動かします":
            $ ch2_pos = "center"
            $ lean("求道型")
            $ up("戦術眼", 3)
            kuroda "それでいい"
            "黒田は、それ以上何も言わなかった。でも、少しだけ満足そうに見えた。"
        "俺は、前で点を取りたいです":
            $ ch2_pos = "goal"
            $ lean("野心型")
            $ up("技術", 3)
            kuroda "取りたきゃ、真ん中から走って取れ。それくらいの体力はつけろ"
            kuroda "……前に出たがるやつは、嫌いじゃない"
        "鷹野に、全部つなぎます":
            $ ch2_pos = "takano"
            $ lean("仲間型")
            $ bond_up("鷹野", 5)
            show takano normal at right
            with dissolve
            voice "audio/voice/takano_chi.mp3"
            takano "……は？　勝手に決めんな"
            "鷹野は顔をそむけた。でも、そのマグネットを、少しだけ前にずらしていた。"
            hide takano
            with dissolve

    ## 一本だけのキック
    show sakaguchi normal at right
    with dissolve
    sakaguchi "てかさ、先生ってサッカーできんの？"
    "空気が止まった。"
    miyoshi "{rb}坂口{/rb}{rt}さかぐち{/rt}！"
    sakaguchi "だってさ、ずっと新聞かぶって寝てる人じゃん"
    hide sakaguchi
    with dissolve
    "黒田は、何も言わずにボールを一つ拾った。"
    "サンダルのまま。"
    show kuroda normal
    kuroda "早瀬、鷹野。あのゴールの、右上の角に立て"
    hide kuroda
    with dissolve
    "言われたとおりに走る。グラウンドの反対側。50メートル以上ある。"
    "黒田は助走もしなかった。"
    "左足を引きずったまま、右足を、ただ振った。"
    $ se("ボールを蹴る音")
    scene bg kohoku_ground_eve at cam_push(4.0, 1.12)
    with flash
    show screen speedlines
    "ボールは、低く、まっすぐ伸びてきた。"
    "途中で、ぐんと曲がる。"
    "俺と鷹野が同時に跳んだ。"
    hide screen speedlines
    $ se("ネットが揺れる音")
    scene bg kohoku_ground_eve
    with hpunch
    "どっちの頭にも当たらず、ボールはゴールの右上、ネットの角に突き刺さった。"
    "誰も、何も言わなかった。"
    show kuroda yawn
    with dissolve
    voice "audio/voice/kuroda_fuaa.mp3"
    kuroda "……今日は、走るだけだ。グラウンド20周"
    show sakaguchi normal at right
    with dissolve
    sakaguchi "うそだろ！？"
    $ set_flag("黒田_一本")

    ## その夜のトーク
    scene black
    with dissolve
    $ set_cal("6月1日（月）", "夜")
    scene bg ren_room_night
    with dissolve
    $ bgm("静かな夜の曲")
    $ se("トークアプリの通知音（連続）")
    window auto hide
    $ talk_start("港北サッカー部（12）", "22:07")
    $ talk("鷹野", "黒田修司")
    $ talk("鷹野", "元潮見ブルーマリンズ。J1で4年")
    $ talk("鷹野", "28で引退。ひざのケガ")
    $ talk("坂口", "は？？？？？？")
    $ talk("三好", "すげええええええ！！")
    $ talk("大門", "サ、サインもらったほうがいいですか")
    $ talk("桐生", "数学の先生じゃなかったの")
    "{rb}鷹野{/rb}{rt}たかの{/rt}が、グループに何かを書きこんだのは、これが初めてだった。"
    "既読の数が、また11になった。"
    window auto hide
    $ talk_end()
    "ひざのケガ。28歳。"
    "左足を引きずる黒田の背中を、思い出していた。"
    $ bond_up("鷹野", 3)
    $ set_flag("黒田の過去", flags.get("黒田の過去", 0) + 1)   # 第1章で職員室に行っていれば、もう1つ進んでいる

    ############################################################################
    ## シーン2：6月の自由行動（2日）
    ############################################################################
    $ recap_text = CH2_RECAP[0]
    window auto hide
    tuto "自由行動です。インターハイ予選の1回戦まで、放課後は2日。"

    $ ch2_day = 1
    while ch2_day <= 2:
        $ amb_stop()
        $ set_cal(CH2_FREE_DATES[ch2_day - 1], "放課後")
        $ bgm("作戦会議っぽい軽快な曲")
        window auto hide
        call screen action_map(ch2_spots(), "6月の放課後、どこへ行く？（残り" + str(3 - ch2_day) + "日）")
        $ ch2_dest = _return
        if ch2_dest == "council":
            call ch2_council
        elif ch2_dest == "clubroom":
            call ch2_daimon
        elif ch2_dest == "roof":
            call ch2_takano
        elif ch2_dest == "pier":
            call ch2_pier
        else:
            call ch2_practice
        $ ch2_day += 1
    $ amb_stop()

    ############################################################################
    ## シーン3：ひざ（6月中旬）
    ############################################################################
    scene black
    with dissolve
    $ set_cal("6月17日（水）", "放課後")
    scene bg kohoku_ground_eve
    with dissolve
    $ bgm("静かなピアノ")

    "練習の終わり。"
    "ダッシュの最後の一本で、右ひざの奥が、きしんだ。"
    "痛い、というほどじゃない。"
    "冬に、ぷつんと何かが切れた、あの場所の近くだ。"
    show hinata serious
    with dissolve
    hinata "……{rb}蓮{/rb}{rt}れん{/rt}。今、右足かばったでしょ"
    ren "かばってない"
    hinata "かばった。10年見てるんだから、分かるよ"
    "ひなたは、俺のひざの前にしゃがみこんだ。"

    menu:
        "……少し痛い。正直に言う":
            $ ch2_knee = "honest"
            $ heart_up("ひなた", "信頼", 8)
            $ up("無理ゲージ", -6)
            voice "audio/voice/hinata_un_soft.mp3"
            hinata "……うん"
            hinata "言ってくれて、ありがと"
            "ひなたは、カバンから湿布とテーピングを出した。いつのまにか、ちゃんとした巻き方を覚えている。"
            hinata "{rb}黒田{/rb}{rt}くろだ{/rt}先生にも、言っとくね。メニュー、少し変えてもらう"
            ren "……それは"
            show hinata stare
            hinata "言っとくね"
            "怒ると怖いのは、昔から変わらない。"
        "大丈夫だって。黙って練習を続ける":
            $ ch2_knee = "hide"
            $ up("技術", 3)
            $ up("無理ゲージ", 8)
            $ heart_up("ひなた", "さみしさ", 5)
            show hinata forcesmile
            hinata "……そっか"
            hide hinata
            with dissolve
            "ひなたは立ち上がって、何も言わずにストップウォッチを首にかけ直した。"
            "その夜、玄関に湿布が一箱だけ置いてあった。"
            "メモも何もなかった。"
    $ set_flag("ch2_knee", ch2_knee)

    ############################################################################
    ## シーン4：初勝利（6月下旬・インターハイ予選1回戦）
    ############################################################################
label ch2_match:      # 試合のテスト用の目印（コンソールで jump ch2_match）
    scene black
    with dissolve
    $ set_cal("6月27日（土）", "インターハイ予選1回戦　対 白浜工業")
    scene bg pref_ground_day
    with Dissolve(1.0)
    $ bgm("緊迫した試合の曲")

    "インターハイ予選、1回戦。相手は県立{rb}白浜{/rb}{rt}しらはま{/rt}工業。"
    "去年は2回戦まで進んだチームだ。"
    "{rb}港北{/rb}{rt}こうほく{/rt}が公式戦に出るのは、3年ぶりらしい。"
    "スタンドというほどのものはない。土手に、何人かの保護者が座っているだけだ。"
    "その端に、日傘をさした生徒が一人いた。"
    "首から、古いフィルムカメラを下げている。"
    "……{rb}千夏{/rb}{rt}ちか{/rt}先輩？"
    "目が合いそうになった瞬間、日傘が傾いて顔が隠れた。"

    ## キックオフ。黒帯とスコアボード（港北 紺／白浜工業 黄）
    $ se("キックオフの笛")
    $ sb_set("前半", 0, 0, 0, 0, "#2a3f8f", "#e8c43a")
    scene bg pref_ground_day at cam_jog
    with dissolve
    show screen letterbox
    show screen scoreboard

    "前半12分。"
    scene bg pref_ground_day at cam_snap(1.15)
    with hpunch
    $ goal("白浜工業", away=1, mm=12)
    "先制された。"
    voice "audio/voice/daimon_sumimasen.mp3"
    daimon "す、すみませんっ！"
    miyoshi "いい！　今のは俺が抜かれた！　次だ次！"
    "前半は、0−1のまま終わった。"

    $ se("前半終了の笛")
    $ sb_set("後半", 18)
    scene bg pref_ground_day at cam_pan_r(10.0)
    with dissolve
    "後半18分。"
    "{rb}坂口{/rb}{rt}さかぐち{/rt}が、右サイドを上がりっぱなしで走る。"
    "ゲームと同じだ。本当に、ずっと上がりっぱなしだ。"
    voice "audio/voice/sakaguchi_kocchi.mp3"
    sakaguchi "{rb}蓮{/rb}{rt}れん{/rt}！　こっち！"
    $ tactics(caption="後半18分　0−1", dots=[
        ("h", "大門", (5, 34)), ("h", "三好", (34, 40)), ("h", "", (34, 26)),
        ("h", "小池", (46, 34)), ("h", "江藤", (66, 12)),
        ("h", "坂口", (66, 58), (86, 60), 0.5, 1.0),
        ("h", "鷹野", (78, 40), (90, 36), 1.4, 0.7),
        ("a", "", (82, 30)), ("a", "", (84, 44)), ("a", "", (72, 52)),
        ("a", "", (62, 28)), ("a", "", (100, 34)),
        ("ren", "蓮", (58, 36)),
        ("ball", "", (59.5, 37.5), (86, 58), 0.3, 0.6),
        ],
        arrows=[((60, 38), (85, 58), 0.2, "y"), ((86, 60), (92, 36), 1.3, "y")])
    "真ん中で受けて、前を向く。見えている。"
    "右へ、はたく。"
    $ tactics_off()
    $ se("ボールを蹴る音")
    scene bg pref_ground_day at cam_snap(1.2, 0.6, 0.3)
    with flash
    "坂口のクロスに、{rb}鷹野{/rb}{rt}たかの{/rt}が頭から飛びこんだ。"
    $ goal("港北", home=1)
    with vpunch
    miyoshi "うおおおおおお！！"
    sakaguchi "入った！？　今の入った！？　俺のクロス！？"
    "鷹野は、何も言わずに自陣に戻っていく。"
    "でも、すれ違いざまに、俺の背中を一回だけたたいた。"
    "港北の、公式戦の初ゴールだった。"

    ## 残り5分
    $ bgm("試合の曲（終盤）")
    $ sb_set(mm=35)
    scene bg pref_ground_day at cam_push(6.0, 1.15)
    with dissolve
    "後半35分。1−1。"
    "相手の足も、こっちの足も止まりかけている。"
    $ se("ボールが転がる音")
    "ボールが、真ん中の俺に転がってきた。"
    show screen speedlines
    $ tactics(caption="後半35分　1−1", dots=[
        ("h", "大門", (5, 34)), ("h", "三好", (46, 40)), ("h", "坂口", (70, 60)),
        ("h", "小池", (50, 28)), ("h", "江藤", (68, 10)),
        ("h", "鷹野", (76, 44), (79, 45), 0.4, 0.8),
        ("a", "", (82, 20), (88, 21), 0.3, 1.2), ("a", "", (82, 30), (88, 30), 0.3, 1.2),
        ("a", "", (82, 40), (88, 40), 0.3, 1.2), ("a", "", (82, 52), (88, 52), 0.3, 1.2),
        ("a", "", (68, 30), (64, 33), 0.5, 0.8),
        ("a", "", (102, 34)),
        ("ren", "蓮", (60, 36)),
        ("ball", "", (61.5, 37.5)),
        ],
        arrows=[((82, 30), (88, 30), 0.2, "w"), ((76, 44), (86, 46), 0.6, "w"),
                ((46, 40), (52, 40), 0.8, "w")])
    "右に鷹野。後ろに{rb}三好{/rb}{rt}みよし{/rt}先輩。"
    "相手の最終ラインが、じりじりと下がっていく。"
    hide screen speedlines
    $ tactics_off()

    menu:
        "自分で撃つ":
            $ ch2_shot = "shoot"
            $ lean("野心型")
            $ up("技術", 3)
            "一人かわす。二人目が来る前に、右足を振り抜いた。"
        "鷹野とワンツー":
            $ ch2_shot = "onetwo"
            $ lean("仲間型")
            $ bond_up("鷹野", 5)
            "鷹野に当てて、走る。戻ってきたボールは、ちょうど一歩先に転がってきた。"
        "三好先輩に下げて、裏に走る":
            $ ch2_shot = "back"
            $ lean("求道型")
            $ up("戦術眼", 3)
            $ bond_up("三好", 4)
            "三好先輩の、不格好なロングボール。それでも、走りこんだ場所にぴたりと落ちてきた。"

    scene bg pref_ground_day at cam_snap(1.25, 0.5, 0.35)
    with dissolve
    "キーパーと、一対一。"
    $ se("ボールを蹴る音")
    "ゴールの左下に、流しこんだ。"
    $ se("ネットが揺れる音")
    with vpunch
    "入った。"
    $ bgm("（止まる）")
    "両手を上げて振り返る。三好先輩が、こっちに走ってくる。"
    "その向こうで――"
    "副審の旗が、ゆっくりと上がっていた。"
    $ se("笛の音")
    shinpan "オフサイド"
    ren "……は？"
    miyoshi "うそだろ！？　今の出てなかったって！"
    "抗議しても、旗は下がらない。"
    "副審は、プレーが終わるまで旗を上げるのを待っていた。"
    "最初から、出ていたんだ。"
    "スコアボードは、1−1のまま動かなかった。"
    $ sb_set(mm=40)
    $ se("試合終了の笛")
    "1−1。PK戦。"

    ## PK戦
    hide screen scoreboard
    scene bg pref_ground_eve
    with Dissolve(1.0)
    $ bgm("緊迫した試合の曲")
    show kuroda normal
    with dissolve
    kuroda "蹴る順番を決める。鷹野、坂口、三好、{rb}小池{/rb}{rt}こいけ{/rt}、{rb}早瀬{/rb}{rt}はやせ{/rt}"
    show sakaguchi normal at right
    with dissolve
    sakaguchi "……俺！？"
    kuroda "クロスを上げたやつが、いちばん足が振れてる"
    hide kuroda
    hide sakaguchi
    with dissolve

    $ pk_reset("港北", "白浜工業")
    "白浜工業の1人目。"
    $ pk_kick("away", True)
    "決める。"
    "港北の1人目、鷹野。ど真ん中に、思いきり。"
    $ pk_kick("home", True)
    "決める。"
    "白浜工業の2人目。"
    $ pk_kick("away", False)
    "ポストに当たって外れる。"
    daimon "……あ、当たった"
    "港北の2人目、坂口。"
    $ pk_kick("home", False)
    "キーパーに止められる。"
    sakaguchi "……ごめん"
    "坂口は、しゃがみこんで顔を上げなかった。"
    "白浜工業の3人目、4人目。"
    $ pk_kick("away", True)
    $ pk_kick("away", True)
    "決める。"
    "三好先輩、小池。"
    $ pk_kick("home", True)
    $ pk_kick("home", True)
    "決める。"
    "3−3。"
    "港北の5人目。俺の番だった。"

    menu:
        "思いきり、右上に":
            $ lean("野心型")
        "キーパーが動くのを、最後まで見る":
            $ lean("求道型")
            $ up("戦術眼", 2)
        "坂口のぶんまで、確実に左下へ":
            $ lean("仲間型")
            $ bond_up("坂口", 4)
    $ pk_kick("home", True)
    with vpunch
    "4−3。"
    "相手の5人目が決めれば、4−4。外せば、港北の勝ちだ。"

    "{rb}大門{/rb}{rt}だいもん{/rt}が、ゴールの前に立った。"
    "両腕が、遠くからでも分かるくらい震えている。"
    miyoshi "大門！　倒れるのは慣れてるんだろ！"
    voice "audio/voice/daimon_hai.mp3"
    daimon "は、はいっ！"
    "大門は、一回だけ目を閉じた。"
    "そして、開けた。"
    $ se("ボールを蹴る音")
    scene cg daimon_pk at cam_snap(1.08, 0.6, 0.4)
    with flash
    "左。"
    "大門の大きな体が、倒れるように左へ飛んだ。"
    "受け身の、きれいな形だった。"
    $ se("鈍い衝突音")
    "ボールが、大門の腕に当たって、外に転がっていった。"
    $ pk_kick("away", False, kick=False)
    $ se("試合終了の笛")
    $ win("港北", "PK 4−3")
    pause 1.0
    voice "audio/voice/daimon_tomatta.mp3"
    daimon "……と、止まった……？"
    $ bgm("明るい部活の曲")
    "次の瞬間、全員が大門の上に倒れこんでいた。"
    sakaguchi "大門ーーっ！！"
    voice "audio/voice/miyoshi_kattazo.mp3"
    miyoshi "勝ったぞ！！　勝ったぞおおお！！"
    daimon "く、苦しいです！　重いです！"
    "人の山のいちばん下で、大門は泣きながら笑っていた。"
    "県立{rb}港北{/rb}{rt}こうほく{/rt}高校サッカー部の、公式戦の初勝利だった。"
    hide screen win_banner
    hide screen letterbox
    $ pk_off()

    scene bg pref_ground_eve
    with dissolve
    "{rb}黒田{/rb}{rt}くろだ{/rt}は、土手に座ったまま、拍手もしなかった。"
    "ただ、一回だけ、小さくうなずいた。"
    "土手の端の日傘は、もういなかった。"
    "シャッターの音が、一回だけ聞こえた気がした。"
    $ bond_up("大門", 8)
    $ bond_up("坂口", 4)
    $ up("メンタル", 4)
    $ set_flag("ch2_first_win")

    ############################################################################
    ## シーン5：2回戦（7月初め）
    ############################################################################
    scene black
    with Dissolve(1.0)
    $ set_cal("7月4日（土）", "インターハイ予選2回戦")
    $ bgm("（なし）")
    mono "2回戦は、0−3で負けた。"
    mono "相手は、県で8番目に強い私立だった。"
    mono "走って、走って、それでも追いつけなかった。"
    scene bg pref_ground_eve
    with dissolve
    show kuroda normal
    with dissolve
    "試合のあと、{rb}黒田{/rb}{rt}くろだ{/rt}は一言だけ言った。"
    kuroda "夏で変わる。……体育館、借りといたぞ"
    miyoshi "体育館？"
    kuroda "合宿だ。泊まりこみで3日"
    show sakaguchi normal at right
    with dissolve
    sakaguchi "は？？？"

    ############################################################################
    ## シーン6：夏合宿（7月下旬・学校の体育館に2泊3日）
    ############################################################################
    scene black
    with dissolve
    $ set_cal("7月27日（月）", "夏合宿")
    scene bg gym_day
    with dissolve
    $ bgm("明るい部活の曲")
    "朝6時、グラウンド。昼は、炎天下でボールを使った練習。夕方、また走る。"
    "ひなたの作った大量のおにぎりが、毎食ちゃんとなくなっていく。"
    "{rb}坂口{/rb}{rt}さかぐち{/rt}たちは初日の夜に3回「帰る」と言い、2日目の夜には一回も言わなかった。"
    $ up("フィジカル", 4)
    $ up("技術", 2)

    ## 夜の体育館
    scene black
    with dissolve
    $ set_cal("7月28日（火）", "夜")
    scene bg gym_night
    with Dissolve(1.0)
    $ bgm("静かな夜の曲")
    "夜10時。電気を消した体育館に、11枚の布団が並んでいる。"
    "天井の高いところに、非常口の緑のランプだけが光っていた。"
    miyoshi "……なあ。起きてるやつ"
    sakaguchi "寝れるわけないじゃん、床かてえし"
    miyoshi "一人ずつさ。なんでサッカーやってるか、言わないか"
    sakaguchi "うわ、修学旅行の夜みたいなやつ"
    miyoshi "いいだろ、修学旅行の夜みたいなやつ"
    "暗い中で、何人かが笑った。"

    miyoshi "じゃあ俺からな"
    miyoshi "俺、中学でもずっと補欠だった。3年間、一回も試合に出てない"
    miyoshi "でも、ベンチから見てたサッカーが、ずっと楽しそうでさ"
    miyoshi "だから、高校では絶対に出るって決めてたんだ。……そしたら、部員が3人になってた"
    miyoshi "最後の年に、11人で試合に出られた。だから俺、今、けっこう幸せなんだよ"
    "誰も、何も言えなかった。"

    daimon "……僕は"
    "{rb}大門{/rb}{rt}だいもん{/rt}の声は、布団の中から聞こえた。"
    daimon "この顔で、ずっと怖がられてきたんです。何もしてないのに"
    daimon "だから、自分でも、自分は怖い人なんだって思うようになってて"
    daimon "でも、PKを止めたとき、みんなが上に乗ってきて……誰も、僕のこと怖がってなかった"
    daimon "……それが、うれしかったです"
    sakaguchi "重かったけどな、お前"
    daimon "重かったのは坂口くんです"

    "しばらく、静かだった。"
    takano "……ユースに、上がれなかったんじゃない"
    "{rb}鷹野{/rb}{rt}たかの{/rt}の声だった。"
    takano "上がれないって言われる前に、自分でやめた。言われるのが、怖かったから"
    takano "だから、{rb}桜嶺{/rb}{rt}おうりょう{/rt}のBにいたあいつらを見たとき、本当は、すげえ腹が立った"
    takano "あいつらにじゃない。逃げた自分に"
    "鷹野は、それ以上言わなかった。"
    "誰も、それ以上聞かなかった。"

    miyoshi "……{rb}蓮{/rb}{rt}れん{/rt}は？"
    "暗い天井を見上げた。"
    "ひざが、もう完全には戻らないこと。それだけは、誰にも言っていない。"

    menu:
        "ひざのことを、全部話す":
            $ ch2_night = "knee"
            $ bond_up("三好", 4)
            $ bond_up("大門", 4)
            $ bond_up("鷹野", 4)
            $ bond_up("坂口", 4)
            $ heart_up("ひなた", "信頼", 5)
            $ up("無理ゲージ", -5)
            ren "……右ひざ、まだ完全じゃない。たぶん、ずっと完全にはならない"
            ren "でも、やめたくない。だから、もし俺が無理してたら、止めてくれ"
            miyoshi "おう。止める"
            daimon "と、止めます"
            takano "……知ってたよ、そんなこと"
            "体育館の扉のすき間に、細い光が一本だけ差していた。"
            "誰かが、廊下で立ち止まっていたらしい。"
            $ set_flag("ch2_knee_told")
        "桜嶺を、見返したい":
            $ ch2_night = "ouryo"
            $ lean("野心型")
            $ up("メンタル", 3)
            ren "俺が行くはずだった学校に、俺がいないチームで勝ちたい"
            sakaguchi "……かっけえじゃん"
            takano "勝つのは俺だけどな"
        "ただ、サッカーが好きだから":
            $ ch2_night = "love"
            $ lean("求道型")
            $ up("メンタル", 3)
            ren "……好きだからだ。それ以外、思いつかない"
            miyoshi "それがいちばんだよ"
            "{rb}三好{/rb}{rt}みよし{/rt}先輩の声が、少しだけ鼻声になっていた。"

    $ se("体育館の扉が開く音")
    show chika normal
    with dissolve
    chika "……10時を過ぎています。消灯の確認に来ました"
    sakaguchi "うわっ、生徒会長！？"
    show chika narrow
    chika "申請書に、見回りは生徒会が行うと書いてあります。読んでいないんですか"
    "{rb}千夏{/rb}{rt}ちか{/rt}先輩は、懐中電灯で布団の列を一往復照らした。"
    chika "11人。確認しました"
    hide chika
    with dissolve
    "千夏先輩は、体育館の入口に紙袋を一つ置いて、出ていった。"
    "中には、凍らせたスポーツドリンクが11本入っていた。"
    $ heart_up("千夏", "信頼", 5)

    ############################################################################
    ## シーン7：夏祭り（8月15日）
    ############################################################################
    scene black
    with dissolve
    $ set_cal("8月14日（金）", "夜")
    scene bg ren_room_night
    with dissolve
    $ bgm("静かな夜の曲")
    $ se("トークアプリの通知音（連続）")
    window auto hide
    $ talk_start("港北サッカー部（12）", "21:30")
    $ talk("三好", "明日の港の夏祭り、練習は休みな！")
    $ talk("三好", "黒田先生公認！！")
    $ talk("坂口", "先生、公認とか言うタイプじゃないでしょ")
    window auto hide
    $ talk_end()
    "誰と行こう。"
    "スマホを持ったまま、しばらく画面を見ていた。"

    menu:
        "ひなたを誘う":
            $ ch2_fest = "hinata"
        "千夏先輩を誘う" if heart["千夏"]["ときめき"] + heart["千夏"]["信頼"] >= CH2_CHIKA_INVITE:
            $ ch2_fest = "chika"
        "鷹野と大門を誘う":
            $ ch2_fest = "boys"
        "誰も誘わず、一人で行く":
            $ ch2_fest = "alone"
    if ch2_fest == "hinata":
        $ heart_up("ひなた", "ときめき", 4)
    elif ch2_fest == "chika":
        $ heart_up("千夏", "ときめき", 4)
    elif ch2_fest == "boys":
        $ bond_up("鷹野", 3)
        $ bond_up("大門", 3)
    else:
        $ set_flag("紗希_祭り")
    if ch2_fest != "alone":
        "待ち合わせは、会場の最寄りの「{rb}潮見{/rb}{rt}しおみ{/rt}港駅」。"
        "俺は、家の手伝いで少し遅れて、一人で電車に乗ることになった。"
    else:
        "会場は、{rb}潮見{/rb}{rt}しおみ{/rt}港駅のすぐ前だ。"
        "家の手伝いを終えてから、一人で電車に乗った。"

    ## 満員電車
label ch2_train:      # テスト用の目印（コンソールで jump ch2_train）
    ## 第1章の港で名前を聞いていなければ、楽譜の端に書いてあった名字で呼ぶ
    $ saki_call = "紗希" if flags.get("紗希_名前を聞いた") else "鬼塚"
    scene black
    with dissolve
    $ set_cal("8月15日（土）", "夕方")
    $ bgm("（なし）")
    scene bg train_eve at cam_jog
    with Dissolve(1.0)
    $ se("電車の走る音")
    "花火の日の電車は、ぎゅうぎゅうだった。"
    "浴衣の人、家族連れ、部活帰りのジャージ。"
    "ドアの近くで、身動きがとれなくなった。"
    $ se("電車がカーブで揺れる音")
    scene bg train_eve at cam_snap(1.08)
    with hpunch
    "カーブで、車両がぐらりと揺れる。"
    "押されて、背中が誰かの背中にぶつかった。"
    "細い背中だった。"
    "相手も押されていて、離れようにも離れられない。"
    "背中同士が、ぴたりとくっついたまま止まる。"
    "「……っ」"
    "小さく、息をのむ音がした。"

    scene cg train_saki at cam_push(10.0, 1.05)
    with Dissolve(1.0)
    $ bgm("静かなピアノの旋律")
    "暗くなりかけた窓ガラスに、車内が映っている。"
    "俺の肩ごしに、色素の薄い短い髪。"
    "トートバッグからのぞく、見覚えのある楽譜。"
    "……あの時の。"
    "窓の中で、目が合った。"
    window hide
    pause
    scene bg train_eve
    with dissolve
    show saki casual
    with dissolve
    voice "audio/voice/saki_minaide.mp3"
    saki_v "……こっち、見ないで"
    "小さな声だった。耳が、少し赤い。"
    voice "audio/voice/saki_ugokanaide.mp3"
    saki_v "あと、動かないで。……動くと、もっとくっつくから"
    ren "……動いてない"
    voice "audio/voice/saki_kokyu.mp3"
    saki_v "動いてる。呼吸で"
    ren "呼吸は無理だろ"
    voice "audio/voice/saki_nn.mp3"
    saki_v "…………"
    "背中ごしに、相手の体温が伝わってくる。"
    "自分の心臓の音が、背中から聞こえていないか、気が気じゃなかった。"

    menu:
        "……久しぶり":
            $ ch2_saki_word = "long"
            $ heart_up("紗希", "ときめき", 4)
            voice "audio/voice/saki_oboeteta.mp3"
            saki_v "……覚えてたの"
            voice "audio/voice/saki_oboetenai.mp3"
            saki_v "別に、覚えててほしいなんて言ってない"
            "窓に映る[saki_call]は、ずっと下を向いていた。"
        "大丈夫か？　苦しくない？":
            $ ch2_saki_word = "ok"
            $ heart_up("紗希", "信頼", 4)
            voice "audio/voice/saki_kurushii.mp3"
            saki_v "……苦しいに決まってるでしょ。満員なんだから"
            voice "audio/voice/saki_osanaide.mp3"
            saki_v "…………でも、ありがと。押さないでくれて"
        "何も言わずに、次の駅まで耐える":
            $ ch2_saki_word = "none"
            "次の駅まで、2分。"
            "人生で、いちばん長い2分だった。"

    ## 港の堤防で、ピアノを最後まで聴いていた場合
    if flags.get("ch2_piano"):
        voice "audio/voice/saki_teibou.mp3"
        saki_v "……ねえ。この前、堤防でボール蹴ってたの、あなた？"
        voice "audio/voice/saki_tomaru.mp3"
        saki_v "同じところで止まるの、聴いてたでしょ。……最悪"

    $ amb_stop(1.0)
    $ se("駅に着く音・ドアが開く音")
    scene bg shiomi_station_eve
    with dissolve
    "ドアが開いた瞬間、人の波に押し出された。"
    "振り返ると、[saki_call]は少し離れたところで、乱れた前髪を直していた。"
    show saki casual
    with dissolve
    voice "audio/voice/saki_happyokai.mp3"
    saki_v "……発表会の帰り。花火を見に来たわけじゃないから"
    "誰も、何も聞いていない。"
    voice "audio/voice/saki_jiko.mp3"
    saki_v "それと、さっきのは、事故だから"
    voice "audio/voice/saki_wasurete.mp3"
    saki_v "忘れて"
    hide saki
    with dissolve
    "[saki_call]は、早足で人混みの中に消えていった。"
    $ meet("紗希")
    $ set_flag("紗希_再会")
    tuto "[saki_call]と再会しました。第3章から、[saki_call]のイベントが行動マップに出るようになります。"

    ## 花火
    scene black
    with dissolve
    $ set_cal("8月15日（土）", "夜")
    scene bg festival_night
    with Dissolve(1.0)
    $ bgm("夏祭りの曲")
    $ se("花火の音")

    if ch2_fest == "hinata":
        show hinata yukata
        with dissolve
        hinata "遅い！　……って言おうと思ったけど、まあいいや"
        voice "audio/voice/hinata_yukata.mp3"
        hinata "浴衣、どう？"
        menu:
            "似合ってる":
                $ heart_up("ひなた", "ときめき", 5)
                voice "audio/voice/hinata_ehehe.mp3"
                hinata "……えへへ。でしょ"
            "動きにくそう":
                $ heart_up("ひなた", "信頼", 4)
                voice "audio/voice/hinata_mou.mp3"
                hinata "もう！　そういうとこ！"
                "ひなたは笑いながら、俺の腕を軽くたたいた。"
        hide hinata
        with dissolve
        $ se("花火の音")
        scene cg fw_hinata at cam_push(10.0, 1.04)
        with Dissolve(1.2)
        hinata "来年も、再来年も、ここで見られるといいね"
        "その「来年」が、どこで迎えるものになるのか、俺はまだ知らなかった。"

    elif ch2_fest == "chika":
        show chika yukata
        with dissolve
        chika "……生徒会として、地域の行事を視察するのも仕事ですから"
        "{rb}千夏{/rb}{rt}ちか{/rt}先輩は、花火ではなく、花火を見上げる人たちにカメラを向けていた。"
        menu:
            "先輩も写ってください":
                $ heart_up("千夏", "ときめき", 5)
                show chika narrow
                chika "……写るのは、苦手です。撮る側のほうが、性に合っています"
                hide chika
                with dissolve
                $ se("花火の音")
                scene cg fw_chika at cam_push(10.0, 1.04)
                with Dissolve(1.2)
                "そう言って、千夏先輩はレンズをこっちに向けた。"
            "何を撮ってるんですか":
                $ heart_up("千夏", "信頼", 4)
                chika "……この町の、夏です"
                hide chika
                with dissolve
                $ se("花火の音")
                scene cg fw_chika at cam_push(10.0, 1.04)
                with Dissolve(1.2)
                "気づいたら、レンズがこっちを向いていた。"
        voice "audio/voice/chika_ichimai.mp3"
        chika "……一枚だけですよ"

    elif ch2_fest == "boys":
        show takano casual at left
        show daimon jinbei at right
        with dissolve
        daimon "射的、全部外しました……"
        takano "お前、ゴールキーパーなのに的に当てる側やってどうすんだよ"
        hide takano
        hide daimon
        with dissolve
        $ se("花火の音")
        scene cg fw_boys at cam_push(10.0, 1.04)
        with Dissolve(1.2)
        takano "……来年は、もっと勝つぞ"
        voice "audio/voice/daimon_hai.mp3"
        daimon "はいっ！"
        "{rb}鷹野{/rb}{rt}たかの{/rt}がそんなことを言うのを、初めて聞いた。"

    else:
        "人混みの外れの、堤防の端。"
        "花火が上がるたびに、少し離れたところに、短い髪の影が浮かび上がる。"
        $ se("花火の音")
        scene cg fw_saki at cam_push(12.0, 1.05)
        with Dissolve(1.2)
        "[saki_call]は、花火を見ていなかった。"
        "海のほうを、ずっと見ていた。"
        "声は、かけなかった。かけられなかった。"

    ############################################################################
    ## シーン8：章の終わり（8月の終わり）
    ############################################################################
    scene black
    with Dissolve(1.0)
    $ set_cal("8月31日（月）", "放課後")
    scene bg kohoku_ground_eve
    with dissolve
    $ bgm("明るい部活の曲")
    "夏休みの最後の日。"
    "{rb}黒田{/rb}{rt}くろだ{/rt}が、作戦ボードの前に全員を集めた。"
    show kuroda board
    with dissolve
    kuroda "9月から、選手権予選が始まる"
    kuroda "3年は、これが最後の大会だ"
    "誰も、{rb}三好{/rb}{rt}みよし{/rt}先輩のほうを見なかった。"
    "見たら、何かが決まってしまう気がした。"
    hide kuroda
    show miyoshi smile
    with dissolve
    voice "audio/voice/miyoshi_hahha.mp3"
    miyoshi "よーし！　じゃあ、優勝するか！"
    sakaguchi "急にでかいこと言うじゃん"
    miyoshi "言うだけならタダだろ！"
    "みんなが笑った。三好先輩も、いちばん大きな声で笑っていた。"
    "グラウンドの土は、夏のあいだに、すっかり硬くなっていた。"
    "俺たちの足も、少しだけ、そうなっていた。"

    scene black
    with Dissolve(1.5)
    call show_title("第2章　泥だらけの夏", "完")
    call show_title("次章予告", "第3章　冬の扉")
    jump trial_end


################################################################################
## 自由行動の行き先（6月の放課後）
################################################################################

## グラウンド：黒田のメニュー
label ch2_practice:
    scene bg kohoku_ground_eve
    with dissolve
    "{rb}黒田{/rb}{rt}くろだ{/rt}のメニューは、半分がボールを使わない走りこみだった。"
    "{rb}坂口{/rb}{rt}さかぐち{/rt}たちは文句を言いながら、それでも最後まで走った。"
    show kuroda normal
    with dissolve
    kuroda "{rb}早瀬{/rb}{rt}はやせ{/rt}。真ん中は、ボールを持ってないときにどこにいるかで決まる"
    hide kuroda
    with dissolve
    $ up("フィジカル", 3)
    $ up("無理ゲージ", 3)
    return

## 生徒会室：合宿の申請書
label ch2_council:
    $ set_flag("ch2_council")
    scene bg student_council
    with dissolve
    $ bgm("張りつめた静かな曲")
    "{rb}黒田{/rb}{rt}くろだ{/rt}に頼まれた、夏休みの体育館の使用申請書を、生徒会室に出しに行った。"
    "「宿泊」の欄に、なぜか丸がついている。"
    show chika normal
    with dissolve
    chika "学校の体育館に部活動で泊まる。……前例がありません"
    "そう言いながら、{rb}千夏{/rb}{rt}ちか{/rt}先輩は赤ペンを取った。"
    "日付の書き方。責任者の欄。夜間の見回りの欄。"
    "書き方の間違いを、全部直してくれた。"
    "机の上のフィルムカメラに、新しいフィルムが入っているのが見えた。"
    menu:
        "先輩も見に来てください":
            $ heart_up("千夏", "ときめき", 4)
            show chika narrow
            chika "……試合をですか。生徒会は、そんなに暇ではありません"
            "千夏先輩は、カメラを引き出しにしまった。少しだけ、あわてて。"
        "書類、ありがとうございます":
            $ heart_up("千夏", "信頼", 5)
            show chika soft
            voice "audio/voice/chika_nn.mp3"
            chika "仕事ですから。……合宿、けがのないように"
    hide chika
    with dissolve
    return

## 部室：大門の居残り
label ch2_daimon:
    $ set_flag("ch2_daimon")
    scene bg clubroom
    with dissolve
    "部室の前で、{rb}大門{/rb}{rt}だいもん{/rt}が一人で残っていた。"
    "壁に当てたボールを、顔の前で受ける練習をしている。"
    show daimon worried
    with dissolve
    daimon "あ……{rb}早瀬{/rb}{rt}はやせ{/rt}くん。……見てた？"
    daimon "目をつぶる回数、昨日より2回減ったんだ"
    menu:
        "目を開けたまま、一本止めよう":
            $ bond_up("大門", 5)
            $ up("メンタル", 2)
            "俺が蹴ったボールを、大門は目を開けたまま、胸で止めた。"
            daimon "……と、止められた"
        "今日は終わろう。俺も付き合うから、明日":
            $ bond_up("大門", 4)
            $ up("無理ゲージ", -2)
            daimon "……うん。明日も、お願い"
    hide daimon
    with dissolve
    return

## 屋上：鷹野と黒田の動画
label ch2_takano:
    $ set_flag("ch2_takano")
    scene bg rooftop
    with dissolve
    "屋上で、{rb}鷹野{/rb}{rt}たかの{/rt}がスマホを見ていた。"
    show takano narrow
    with dissolve
    "画面には、ぼやけた古い試合の動画。青いユニフォームの、背の高い選手。"
    takano "……この人、左足でも同じ球を蹴ってた"
    menu:
        "黒田に教わろう。二人で":
            $ bond_up("鷹野", 5)
            $ lean("仲間型")
            voice "audio/voice/takano_fun.mp3"
            takano "……ふーん。お前が頼むならな"
        "いつか、あれを超える":
            $ bond_up("鷹野", 3)
            $ lean("野心型")
            show takano surprised
            takano "……先に超えるのは、俺だ"
    hide takano
    with dissolve
    return

## 港の堤防：ピアノの音
label ch2_pier:
    $ set_flag("ch2_pier")
    scene bg harbor_sunset
    with dissolve
    $ se("波の音、カモメ")
    "港の防波堤で、一人でボールを蹴った。"
    "壁に当てて、止めて、また蹴る。"
    "近くの家の窓から、ピアノの音が聞こえてきた。"
    "弾きかけて、同じところで止まる。"
    "また最初から弾いて、また同じところで止まる。"
    menu:
        "最後まで聴いていく":
            $ set_flag("ch2_piano")
            $ up("メンタル", 2)
            "ボールを足もとに止めて、しばらく聴いていた。"
            "何度目かで、その曲は、やっと最後まで流れた。"
            "窓の向こうで、小さく息をつく音がした気がした。"
        "自主練を続ける":
            $ up("技術", 2)
            $ up("無理ゲージ", 2)
            "ピアノが止まるたびに、ボールを蹴った。"
    $ amb_stop()
    return
