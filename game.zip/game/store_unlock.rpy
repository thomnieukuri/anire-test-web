################################################################################
## 製品版の続きを解放する（課金）  v0.30.0
##   ・無料は第3章まで。「残るか、移るか」を選んだあとの続き（第4〜6章とすべての結末）を、1回の購入（1,500円）で解放する
##   ・Ren'Py の iap（アンロック型の課金）を使う。Google Play と App Store に対応。商品IDは両方とも "anire_full"
##     （ストア側に、同じIDで「1回だけ買える商品（消費しない）」を登録する。IDは一度使ったら変えない）
##   ・PC と Web には課金の仕組みがない（iap.get_store_name() が None）。テストページは今までどおり体験版の終わりで止まる
##   ・作者の確認用（Web の dev/。AUTHOR_BUILD）と、開発中の PC（config.developer）は、テスト用に「買ったことにする」ことができる
################################################################################

define IAP_PRODUCT = "full"
define IAP_PRICE_FALLBACK = "1,500円"     # ストアから値段を取れないとき（PC のテストなど）に出す値段

## 有料の章に入ったしるし（play_marks のキー）。このしるしがあるセーブは、買っていないと読めない
define PAID_MARKS = ("chapter4a", "chapter4b")

## 有料の章の、章えらびの一覧（買ったあと、または作者の確認用のときに出す）
define CHAPTER_LIST_PAID = [
    ("第4章「最後の世代」", "cs_chapter4a", "ルートA・高2。港北に残った続き"),
    ("第5章「ひざ」", "cs_chapter5a", "ルートA・高2の秋〜冬。ひざの手術を決める"),
    ("第6章「潮風の決勝」", "cs_chapter6a", "ルートA・高3。最後の世代の最後の一年"),
]

default persistent.debug_unlocked = False   # テスト用：「買ったことにする」（AUTHOR_BUILD / config.developer のときだけ効く）

init python:
    iap.register(IAP_PRODUCT, identifier="anire_full", google="anire_full", ios="anire_full")

    def iap_testable():
        """テスト用の「買ったことにする」が使えるか（作者の確認用と、開発中の PC だけ）"""
        return bool(AUTHOR_BUILD or config.developer)

    def store_available():
        """ストアで買える端末か（Android の Google Play / iPhone の App Store）"""
        return iap.get_store_name() is not None

    def full_unlocked():
        """製品版の続きが解放されているか"""
        if iap_testable() and persistent.debug_unlocked:
            return True
        return iap.has_purchased(IAP_PRODUCT)

    def full_price():
        return iap.get_price(IAP_PRODUCT) or IAP_PRICE_FALLBACK

    def in_paid_part():
        """いま有料の章にいるか（セーブを読んだときの確認用）"""
        marks = getattr(store, "play_marks", None) or {}
        return any(k in marks for k in PAID_MARKS)

    def route_ready(route):
        """選んだルートの続きが、この版に入っているか"""
        if route == "stay":
            return renpy.has_label("chapter4a")
        if route == "move":
            return renpy.has_label("chapter4b")
        return False

    ## 有料の章のセーブを、買っていない状態で読んだとき：購入画面を出し、買わなければタイトルに戻す
    def _paid_after_load():
        if in_paid_part() and not full_unlocked():
            renpy.call_in_new_context("paid_save_locked")
            if not full_unlocked():
                renpy.full_restart()
    config.after_load_callbacks.append(_paid_after_load)


################################################################################
## 体験版の終わり（第3章の最後の選択のあと）から、続きへ
##   script.rpy の trial_end から呼ぶ。買っていれば、そのまま続きの章へ進む
################################################################################
label to_paid_part:
    ## ルートB（chapter4b）は製品版のファイル。Web のテスト版には入れないので、名前で飛ぶ（lint で「ない」と言われないように）
    $ renpy.jump("chapter4a" if ch3_route == "stay" else "chapter4b")

## 購入画面を出す。買えたら True を返す（_return）
label ask_unlock:
    $ _unlock_res = renpy.call_screen("unlock_screen")
    if _unlock_res == "restore":
        if full_unlocked():
            tuto "購入を確認しました。続きを遊べます。"
        else:
            tuto "このアカウントでの購入は、見つかりませんでした。"
            jump ask_unlock
    return full_unlocked()

## 章えらびから、有料の章を選んだとき（まだ買っていない）
label unlock_from_menu:
    $ quick_menu = False
    scene black
    call ask_unlock
    if _return:
        tuto "ありがとうございます！　章えらびから、続きの章を選べるようになりました。"
    return

## 有料の章のセーブを、買っていない状態で読んだとき
label paid_save_locked:
    scene black
    tuto "このセーブは、製品版の続きの章のものです。"
    call ask_unlock
    return


################################################################################
## 購入画面
################################################################################
screen unlock_screen():
    modal True
    zorder 120
    add Solid("#0b0f16f2")
    frame:
        style "unlock_frame"
        vbox:
            spacing 18
            xalign 0.5
            text "この先は、製品版です" style "unlock_title"
            text "第4章からの続き（ルートA・ルートBの第4〜6章と、すべての結末）を、1回の購入で遊べます。\nここまでの選択や、ヒロインとの関係は、そのまま続きに引き継がれます。" style "unlock_body"
            null height 6
            textbutton ("続きを買う（%s）" % full_price()):
                style "unlock_buy"
                text_style "unlock_buy_text"
                action iap.Purchase(IAP_PRODUCT, success=Return("bought"))
            if not store_available():
                text "（この端末では買えません。スマホのアプリ版で買えます）" style "unlock_note"
            hbox:
                spacing 18
                xalign 0.5
                textbutton "購入を復元する":
                    style "unlock_sub"
                    text_style "unlock_sub_text"
                    action [iap.Restore(), Return("restore")]
                    sensitive store_available()
                textbutton "あとで":
                    style "unlock_sub"
                    text_style "unlock_sub_text"
                    action Return("later")
            text "前に買ったことがあるときや、機種を変えたときは「購入を復元する」を押してください（同じアカウントなら、追加のお金はかかりません）。" style "unlock_note"
            if iap_testable():
                textbutton "（テスト用）買ったことにする":
                    style "unlock_sub"
                    text_style "unlock_test_text"
                    xalign 0.5
                    action [SetField(persistent, "debug_unlocked", True), Return("bought")]

style unlock_frame:
    background Frame("gui/note_small.png", 14, 14)
    xalign 0.5
    yalign 0.5
    xsize 900
    padding (56, 44, 56, 40)

style unlock_title:
    font FONT_JP_B
    size 36
    color PEN_RED
    xalign 0.5

style unlock_body:
    size 22
    color INK
    line_spacing 6
    text_align 0.5
    xalign 0.5

style unlock_note:
    size 17
    color INK_SOFT
    text_align 0.5
    xalign 0.5

style unlock_buy:
    xalign 0.5
    xsize 560
    ysize 84
    background Solid(PEN_RED)
    hover_background Solid("#e05a5a")
    insensitive_background Solid("#c9b8a8")

style unlock_buy_text:
    font FONT_JP_B
    size 30
    color "#ffffff"
    xalign 0.5
    yalign 0.5

style unlock_sub:
    xsize 260
    ysize 60
    background Solid("#ffffff00")
    hover_background Solid("#00000014")

style unlock_sub_text:
    size 22
    color PEN_TEAL
    insensitive_color "#b9ab9b"
    xalign 0.5
    yalign 0.5

style unlock_test_text:
    size 18
    color INK_SOFT
    xalign 0.5
    yalign 0.5

style unlock_title:
    variant "small"
    size 44
style unlock_body:
    variant "small"
    size 28
style unlock_note:
    variant "small"
    size 22
style unlock_sub_text:
    variant "small"
    size 28
style unlock_frame:
    variant "small"
    xsize 1100
