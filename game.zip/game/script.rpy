## script.rpy ―― ゲームの入口と共通の小道具

## 「はじめから」でここに来る
label start:
    $ quick_menu = True
    $ music_stop(1.5)       # タイトル画面の曲を消す
    $ mark_update_seen()    # はじめから遊ぶ人には、この版の「更新しました」は出さない
    ## 選択肢のヒントを出すか、最初に一度だけ聞く（あとから設定でいつでも変えられる）
    if persistent.choice_hints is None:
        call choice_hint_ask
    jump prologue

label choice_hint_ask:
    scene black
    window auto hide
    tuto "このゲームでは、選んだことで能力やヒロインの気持ちが変わり、物語の行き先も変わります。"
    tuto "選択肢の下に「何が上がるか」と「試合で判定に使う能力」の小さなヒントを出すこともできます。"
    menu:
        "出さない（おすすめ。まずは直感で選んでみてください）":
            $ persistent.choice_hints = False
        "出す":
            $ persistent.choice_hints = True
    tuto "あとから、設定画面の「選択肢のヒント」で、いつでも切りかえられます。"
    return

## 古い版のセーブを読んだとき、続きの場所（台本の行）が見つからなかったら、ここに来る。
##   何もしないと、Ren'Py は「戻る先がない」としてタイトル画面に戻してしまうので、
##   いちばん新しく来た章のはじめから続ける（選択や気持ちの数値は、そのまま残る）。
##   ※ 版をまたいでセーブを使えるように、.rpyc ファイルは消さずに残しておくこと（README の「セーブの互換」）
init python:
    config.return_not_found_label = "save_lost"
    config.load_failed_label = "save_lost"

label save_lost:
    python:
        _lost_to = "start"
        for _n in ("chapter4a", "chapter3", "chapter2", "chapter1", "prologue"):
            if _n in play_marks:
                _lost_to = _n
                break
    $ quick_menu = True
    window auto hide
    tuto "古い版のセーブデータだったため、続きの場所が見つかりませんでした。今の章のはじめから続けます（ここまでの選択や気持ちの数値は、そのまま残っています）。"
    $ renpy.jump(_lost_to)

## 章タイトルを出す。例：call show_title("プロローグ", "止まった冬")
label show_title(main, sub=""):
    window auto hide
    $ quick_menu = False
    $ cal_quiet = True      # 章タイトルの間は日付を隠す（日付そのものは残す）
    $ music_stop(1.5)       # 章の区切りは、いったん静かにする
    show screen title_card(main, sub)
    with Dissolve(0.8)
    pause 2.5
    hide screen title_card
    with Dissolve(0.8)
    $ quick_menu = True
    return

## 最初の選択肢の前に出す、セーブとロードの案内（1回目のプレイだけ）
label save_guide:
    if persistent.save_guide_seen:
        return
    window auto hide
    tuto "ここで最初の「選択肢」です。選んだ答えで、このあとの話やヒロインとの関係が変わっていきます。"
    tuto "「1つ戻る」で読み返すことはできますが、選んだ答えは変えられません。別の答えを試したいときは、選ぶ前に「セーブ」しておきましょう。"
    tuto "セーブは、画面の右上のメニューボタン（≡）を押して「セーブ」から。右クリック（スマホは画面を長押し）で開くメニューからもできます。"
    tuto "続きから遊ぶときは、タイトル画面の「ロード」か、右上のメニューボタンの「ロード」から、セーブした場所を選びます。"
    call screen save_prompt
    $ persistent.save_guide_seen = True
    return

## 体験版の終わり
label trial_end:
    window auto hide
    scene black
    with Dissolve(1.0)
    ## 開発中だけ：ルートA 第4章（製品版・chapter4a.rpy）に進める。Web 版・配布版（config.developer が False）では出ない
    if config.developer and ch3_route == "stay":
        menu:
            "（開発用）ルートA 第4章「最後の世代」へ進む":
                jump chapter4a
            "体験版の終わりへ":
                pass
    call show_title("無料で遊べるのはここまで", "遊んでくれてありがとう！　第4章からの続きは、製品版で。")
    $ persistent.trial_cleared = True
    ## 製品版の予告（続きの量と中身。テスターの声：何章あるかで値段の印象が変わる）
    call screen product_preview with Dissolve(0.6)
    ## 遊んだ時間と、アンケートの案内（testplay.rpy）
    call screen trial_result with Dissolve(0.6)
    return


## 製品版の予告（体験版の最後に出す）
##   v0.29.7：買いたくなる画面に作り直した。2つの道を「扉」として並べ、選んだ道を大きく、もう一つの道も遊べることを見せる。
##   ボリュームは「続きのプレイ時間 8時間以上（予定）」だけを数字で出す（作者の決定。章の数・結末の数・値段はまだ出さない）。
##   この先の中身（ルート名、運命の選択の中身や回数、恋愛の結末の種類）は書かない（ネタバレになるため）。
screen pp_door(route, name, line, img, accent):
    $ _chosen = (ch3_route == route)
    $ _other = bool(ch3_route) and not _chosen
    fixed:
        xysize (560, 236)
        if _other:
            add Transform(img, crop=(0, 90, 1280, 540), size=(560, 236), matrixcolor=SaturationMatrix(0.35) * BrightnessMatrix(-0.18))
        else:
            add Transform(img, crop=(0, 90, 1280, 540), size=(560, 236))
        add Solid("#0b0f1680" if _chosen else "#0b0f16b8") xysize (560, 236)
        add Solid(accent) xysize (560, 6) yalign 1.0
        vbox:
            xpos 26
            yalign 0.5
            spacing 6
            if _chosen:
                text "あなたが選んだ道" style "pp_badge" color accent
            elif _other:
                text "もう一つの道も、遊べる" style "pp_badge" color "#c9d2de"
            text name style "pp_door_name"
            text line style "pp_door_line"

screen product_preview():
    modal True
    zorder 100
    add Solid("#0f141c")
    vbox:
        xalign 0.5
        yalign 0.5
        xsize 1180
        spacing 18
        vbox:
            xalign 0.5
            spacing 2
            text "製品版でつづく物語" xalign 0.5 style "pp_kicker"
            text "物語は、ここから二つに分かれる。" xalign 0.5 style "pp_title"
        hbox:
            xalign 0.5
            spacing 24
            use pp_door("stay", "港北に残る", "弱いまま、上を目指す。この仲間と。", "images/bg/kohoku_ground_eve.jpg", "#4f8fe0")
            use pp_door("move", "桜嶺へ移る", "いちばん強い場所で、いちばん上を目指す。", "images/bg/ouryo_ground_rain.jpg", "#d7a73c")
        hbox:
            xalign 0.5
            spacing 48
            vbox:
                yalign 0.5
                spacing 0
                text "8時間以上" style "pp_big"
                text "続きのプレイ時間（予定）" style "pp_small" xalign 0.5
            vbox:
                yalign 0.5
                spacing 6
                text "・体験版で選んだ答えは、すべて続きに引き継がれる" style "pp_point"
                text "・「残るか、移るか」のような、取り消せない大きな選択が、この先にも待っている" style "pp_point"
                text "・結末は、サッカーと恋愛の両方が、選んだ答えで変わる" style "pp_point"
                text "・1回の購入で、2つの道と、すべての結末が遊べる" style "pp_point"
        vbox:
            xalign 0.5
            spacing 2
            text "「春になったら、全部話す」――神城は、約束を守るのか。" xalign 0.5 style "pp_hook"
            text "港北は、残るのか。右ひざは、最後までもつのか。" xalign 0.5 style "pp_hook"
        hbox:
            xalign 0.5
            spacing 30
            text "※開発中のため、内容は変わることがあります" yalign 0.5 size 16 color "#7d8794"
            textbutton "つぎへ" action Return() yalign 0.5 text_size 28 text_color "#ff8a7a" text_hover_color "#ffffff" text_font FONT_JP_B

style pp_kicker:
    font FONT_JP_B
    size 20
    color "#9fb0c4"
    kerning 2

style pp_title:
    font FONT_JP_B
    size 36
    color "#ffffff"

style pp_badge:
    font FONT_JP_B
    size 17
    kerning 1

style pp_door_name:
    font FONT_JP_B
    size 38
    color "#ffffff"
    outlines [(2, "#0b0f16aa", 0, 0)]

style pp_door_line:
    size 20
    color "#e7ecf2"
    outlines [(2, "#0b0f16aa", 0, 0)]

style pp_big:
    font FONT_JP_B
    size 52
    color "#ffd27a"

style pp_small:
    size 16
    color "#c9d2de"

style pp_point:
    size 19
    color "#e7ecf2"

style pp_hook:
    size 21
    color "#8fd3cf"
    font FONT_JP_B
