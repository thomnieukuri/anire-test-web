## script.rpy ―― ゲームの入口と共通の小道具

## 「はじめから」でここに来る
label start:
    $ quick_menu = True
    $ music_stop(1.5)       # タイトル画面の曲を消す
    $ mark_update_seen()    # はじめから遊ぶ人には、この版の「更新しました」は出さない
    ## 選択肢のヒントを出すか、最初に一度だけ聞く（あとから設定でいつでも変えられる）
    if persistent.choice_hints is None:
        call choice_hint_ask
    jump prologue

label choice_hint_ask:
    scene black
    window auto hide
    tuto "このゲームでは、選んだことで能力やヒロインの気持ちが変わり、物語の行き先も変わります。"
    tuto "選択肢の下に「何が上がるか」と「試合で判定に使う能力」の小さなヒントを出すこともできます。"
    menu:
        "出さない（おすすめ。まずは直感で選んでみてください）":
            $ persistent.choice_hints = False
        "出す":
            $ persistent.choice_hints = True
    tuto "あとから、設定画面の「選択肢のヒント」で、いつでも切りかえられます。"
    return

## 古い版のセーブを読んだとき、続きの場所（台本の行）が見つからなかったら、ここに来る。
##   何もしないと、Ren'Py は「戻る先がない」としてタイトル画面に戻してしまうので、
##   いちばん新しく来た章のはじめから続ける（選択や気持ちの数値は、そのまま残る）。
##   ※ 版をまたいでセーブを使えるように、.rpyc ファイルは消さずに残しておくこと（README の「セーブの互換」）
init python:
    config.return_not_found_label = "save_lost"
    config.load_failed_label = "save_lost"

label save_lost:
    python:
        _lost_to = "start"
        for _n in ("chapter4a", "chapter3", "chapter2", "chapter1", "prologue"):
            if _n in play_marks:
                _lost_to = _n
                break
    $ quick_menu = True
    window auto hide
    tuto "古い版のセーブデータだったため、続きの場所が見つかりませんでした。今の章のはじめから続けます（ここまでの選択や気持ちの数値は、そのまま残っています）。"
    $ renpy.jump(_lost_to)

## 章タイトルを出す。例：call show_title("プロローグ", "止まった冬")
label show_title(main, sub=""):
    window auto hide
    $ quick_menu = False
    $ cal_quiet = True      # 章タイトルの間は日付を隠す（日付そのものは残す）
    $ music_stop(1.5)       # 章の区切りは、いったん静かにする
    show screen title_card(main, sub)
    with Dissolve(0.8)
    pause 2.5
    hide screen title_card
    with Dissolve(0.8)
    $ quick_menu = True
    return

## 最初の選択肢の前に出す、セーブとロードの案内（1回目のプレイだけ）
label save_guide:
    if persistent.save_guide_seen:
        return
    window auto hide
    tuto "ここで最初の「選択肢」です。選んだ答えで、このあとの話やヒロインとの関係が変わっていきます。"
    tuto "「1つ戻る」で読み返すことはできますが、選んだ答えは変えられません。別の答えを試したいときは、選ぶ前に「セーブ」しておきましょう。"
    tuto "セーブは、画面の右上のメニューボタン（≡）を押して「セーブ」から。右クリック（スマホは画面を長押し）で開くメニューからもできます。"
    tuto "続きから遊ぶときは、タイトル画面の「ロード」か、右上のメニューボタンの「ロード」から、セーブした場所を選びます。"
    call screen save_prompt
    $ persistent.save_guide_seen = True
    return

## 体験版の終わり
label trial_end:
    window auto hide
    scene black
    with Dissolve(1.0)
    ## 開発中だけ：ルートA 第4章（製品版・chapter4a.rpy）に進める。Web 版・配布版（config.developer が False）では出ない
    if config.developer and ch3_route == "stay":
        menu:
            "（開発用）ルートA 第4章「最後の世代」へ進む":
                jump chapter4a
            "体験版の終わりへ":
                pass
    call show_title("無料で遊べるのはここまで", "遊んでくれてありがとう！　第4章からの続きは、製品版で。")
    $ persistent.trial_cleared = True
    ## 製品版の予告（続きの量と中身。テスターの声：何章あるかで値段の印象が変わる）
    call screen product_preview with Dissolve(0.6)
    ## 遊んだ時間と、アンケートの案内（testplay.rpy）
    call screen trial_result with Dissolve(0.6)
    return


## 製品版の予告（体験版の最後に出す）
screen product_preview():
    modal True
    zorder 100
    add Solid("#000000")
    fixed:
        xysize (1180, 700)
        xalign 0.5
        yalign 0.5
        add "gui/note_big.png" xysize (1180, 700)
        vbox:
            xalign 0.5
            yalign 0.5
            xsize 1020
            spacing 8
            text "製品版でつづく物語" xalign 0.5 style "pp_title"
            if ch3_route == "move":
                text "あなたが選んだ道：桜嶺へ移る" xalign 0.5 size 22 color PEN_RED
            elif ch3_route == "stay":
                text "あなたが選んだ道：港北に残る" xalign 0.5 size 22 color PEN_RED
            vbox:
                spacing 8
                text "・第4〜6章（高2・高3）。港北に残った道と、桜嶺へ移った道で、物語が分かれる。仲間もライバルも、ヒロインとの距離も変わる" style "pp_text"
                text "・「残るか、移るか」のような、取り消せない大きな選択（運命の選択）が、この先にも待っている" style "pp_text"
                text "・結末は、サッカーと恋愛の両方が、選んだ答えで変わる" style "pp_text"
                text "・1回の購入で、2つのルートと、すべての結末が遊べる" style "pp_text"
            vbox:
                xalign 0.5
                spacing 2
                text "「春になったら、全部話す」――神城は、約束を守るのか。" xalign 0.5 style "pp_hook"
                text "港北は、残るのか。右ひざは、最後までもつのか。" xalign 0.5 style "pp_hook"
            text "※開発中のため、内容は変わることがあります" xalign 0.5 size 17 color INK_SOFT
            textbutton "つぎへ" action Return() xalign 0.5 text_size 28 text_color PEN_RED text_hover_color INK

style pp_title:
    font FONT_JP_B
    size 34
    color INK

style pp_text:
    size 21
    color INK
    line_spacing 4

style pp_hook:
    size 22
    color PEN_TEAL
    font FONT_JP_B

style pp_title:
    variant "small"
    size 28

style pp_text:
    variant "small"
    size 21
    line_spacing 0

style pp_hook:
    variant "small"
    size 21
