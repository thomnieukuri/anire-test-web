## script.rpy ―― ゲームの入口と共通の小道具

## 「はじめから」でここに来る
label start:
    $ quick_menu = True
    $ music_stop(1.5)       # タイトル画面の曲を消す
    jump prologue

## 古い版のセーブを読んだとき、続きの場所（台本の行）が見つからなかったら、ここに来る。
##   何もしないと、Ren'Py は「戻る先がない」としてタイトル画面に戻してしまうので、
##   いちばん新しく来た章のはじめから続ける（選択や気持ちの数値は、そのまま残る）。
##   ※ 版をまたいでセーブを使えるように、.rpyc ファイルは消さずに残しておくこと（README の「セーブの互換」）
init python:
    config.return_not_found_label = "save_lost"
    config.load_failed_label = "save_lost"

label save_lost:
    python:
        _lost_to = "start"
        for _n in ("chapter3", "chapter2", "chapter1", "prologue"):
            if _n in play_marks:
                _lost_to = _n
                break
    $ quick_menu = True
    window auto hide
    tuto "古い版のセーブデータだったため、続きの場所が見つかりませんでした。今の章のはじめから続けます（ここまでの選択や気持ちの数値は、そのまま残っています）。"
    $ renpy.jump(_lost_to)

## 章タイトルを出す。例：call show_title("プロローグ", "止まった冬")
label show_title(main, sub=""):
    window auto hide
    $ quick_menu = False
    $ cal_quiet = True      # 章タイトルの間は日付を隠す（日付そのものは残す）
    $ music_stop(1.5)       # 章の区切りは、いったん静かにする
    show screen title_card(main, sub)
    with Dissolve(0.8)
    pause 2.5
    hide screen title_card
    with Dissolve(0.8)
    $ quick_menu = True
    return

## 最初の選択肢の前に出す、セーブとロードの案内（1回目のプレイだけ）
label save_guide:
    if persistent.save_guide_seen:
        return
    window auto hide
    tuto "ここで最初の「選択肢」です。選んだ答えで、このあとの話やヒロインとの関係が変わっていきます。"
    tuto "「1つ戻る」で読み返すことはできますが、選んだ答えは変えられません。別の答えを試したいときは、選ぶ前に「セーブ」しておきましょう。"
    tuto "セーブは、画面の右上のメニューボタン（≡）を押して「セーブ」から。右クリック（スマホは画面を長押し）で開くメニューからもできます。"
    tuto "続きから遊ぶときは、タイトル画面の「ロード」か、右上のメニューボタンの「ロード」から、セーブした場所を選びます。"
    call screen save_prompt
    $ persistent.save_guide_seen = True
    return

## 体験版の終わり
label trial_end:
    window auto hide
    scene black
    with Dissolve(1.0)
    call show_title("無料で遊べるのはここまで", "遊んでくれてありがとう！　第4章からの続きは、製品版で。")
    $ persistent.trial_cleared = True
    ## 遊んだ時間と、アンケートの案内（testplay.rpy）
    call screen trial_result with Dissolve(0.6)
    return
