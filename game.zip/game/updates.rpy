## 遊ぶ人に見せる更新情報
##   タイトル画面の右下「更新情報」から開ける。新しい版を初めて開いたときは、タイトル画面で一度だけお知らせを出す。
##   版を出すたびに、いちばん上に足す（遊ぶ人に関係があって、知らせてよいことだけ。開発の中のことは書かない）

define UPDATE_NOTES = [
    ("0.26.2", "2026年10月27日", [
        "プロローグ（中3の2月）に、自由行動を追加しました。リハビリ帰りのひなた、店を手伝う母、一人の防波堤のどこで過ごすかを選べます（はじめから遊ぶと見られます）",
    ]),
    ("0.26.1", "2026年10月27日", [
        "体験版の最後に「製品版でつづく物語」を追加しました。続きの章とルート、結末のしくみを紹介しています",
        "ヒロインの「ときめき」と「信頼」の意味が分かるようにしました。はじめて気持ちが動いたときと、相関図に出ます",
        "選択肢のヒントを追加しました。設定画面の「選択肢のヒント」で、出す／出さないを選べます（おすすめは、まずは直感で）",
        "テストの期間を、11月13日までにのばしました",
    ]),
]

## この版の更新情報を、もう見たか
default persistent.notes_seen_version = None

init python:

    def update_notes_for(ver):
        for v, d, items in UPDATE_NOTES:
            if v == ver:
                return d, items
        return None

    def update_notice_due():
        """前の版を遊んだことがある人が、この版で初めてタイトルを開いたとき True"""
        if persistent.notes_seen_version == config.version:
            return False
        if not update_notes_for(config.version):
            return False
        return bool(persistent.save_guide_seen or persistent.trial_cleared or persistent.play_report)

    def mark_update_seen():
        persistent.notes_seen_version = config.version

## 新しい版を初めて開いたときのお知らせ（タイトル画面の上に一度だけ）
screen update_notice():
    modal True
    zorder 120
    add Solid("#00000088")
    $ _n = update_notes_for(config.version)
    frame:
        style "update_frame"
        vbox:
            spacing 10
            text "ver.[config.version] に更新しました" style "update_title"
            if _n:
                for _it in _n[1]:
                    text "・" + _it style "update_item"
            null height 4
            hbox:
                xalign 0.5
                spacing 50
                textbutton "更新情報をすべて見る" action [Function(mark_update_seen), Hide("update_notice"), ShowMenu("updates")] text_size 24
                textbutton "閉じる" action [Function(mark_update_seen), Hide("update_notice")] text_size 24 text_color PEN_RED

## 更新情報の一覧（タイトル画面とメニューから）
screen updates():
    tag menu
    use game_menu("更新情報", scroll="viewport"):
        vbox:
            spacing 22
            for _v, _d, _items in UPDATE_NOTES:
                vbox:
                    spacing 6
                    hbox:
                        spacing 16
                        text "ver." + _v style "update_ver"
                        text _d style "update_date" yalign 1.0
                    for _it in _items:
                        text "・" + _it style "update_item"

style update_frame:
    background Frame("gui/note_big.png", 40, 40)
    xalign 0.5
    yalign 0.5
    xmaximum 1000
    padding (60, 46, 60, 46)

style update_title:
    font FONT_JP_B
    size 30
    color INK
    xalign 0.5

style update_ver:
    font FONT_JP_B
    size 26
    color PEN_RED

style update_date:
    size 18
    color INK_SOFT

style update_item:
    size 21
    color INK
    line_spacing 4

style update_title:
    variant "small"
    size 30

style update_item:
    variant "small"
    size 24

style mm_link_button:
    padding (6, 2, 6, 2)

style mm_link_button_text:
    size 20
    color "#ffffff"
    hover_color "#ffe38a"
    outlines [(2, "#00000088", 0, 0)]

style mm_link_button_text:
    variant "small"
    size 24
