## 遊ぶ人に見せる更新情報
##   タイトル画面の右下「更新情報」から開ける。新しい版を初めて開いたときは、タイトル画面で一度だけお知らせを出す。
##   版を出すたびに、いちばん上に足す（遊ぶ人に関係があって、知らせてよいことだけ。開発の中のことは書かない）
##   書き方：やったことを全部並べず、遊ぶ人から見て分かること・必要なことだけを、短く、ふつうの言い方で（1版に3〜5行まで）
##   版の番号は push まで分けない（push までの作業は、同じ番号の1項目に足していく）

define UPDATE_NOTES = [
    ("0.29.1", "2026年10月27日", [
        "三好の声を、見た目に合う低めの声に変えました",
        "選手名鑑の小池の紹介を、絵に合わせて直しました",
        "練習の場面の、細かな食い違いを直しました",
    ]),
    ("0.29.0", "2026年10月27日", [
        "自由行動の流れが変わりました。6月からは、まず練習メニュー（技術・フィジカル・戦術眼・メンタル）を選び、そのあと会いに行く人を選べます",
        "練習では、毎回だれかとちょっとした出来事があります",
        "第1章の自由行動は、部員集めと人に会うことだけになりました",
        "試合の判定の一部を、新しい流れに合わせて調整しました",
    ]),
    ("0.28.0", "2026年10月27日", [
        "スマホのセーブ・ロード画面を、押しまちがえにくくしました（枠を大きくし、セーブは赤・ロードは青で見分けられます。枠ごとに「消す」ボタンもあります）",
        "セーブした枠に、物語の中の日付が出るようになりました",
        "坂口の仲間（森・小池・江藤・野口）と、2年の桐生・宮下に絵がつきました。話すときは、セリフ枠の左上に顔の写真が出ます",
        "試合の一枚絵のユニフォームに、背番号を入れました",
    ]),
    ("0.27.3", "2026年10月27日", [
        "紗希の台詞の一部に、声がつきました",
        "一部の場面の背景と立ち絵を直しました",
        "物語の細かなつながりを直しました",
    ]),
    ("0.27.2", "2026年10月27日", [
        "12月21日の夜のビデオ通話の場面に、一枚絵を入れました",
    ]),
    ("0.27.0", "2026年10月27日", [
        "夜のトークで、同じ相手に何度送っても、毎回ちがう話が読めるようになりました。坂口と神城にも送れます（6月から）",
        "12月21日の夜に、ひなたとのビデオ通話の場面を追加しました",
        "「残るか、移るか」を選ぶ前に、セーブの案内が出るようになりました",
        "試合の判定の一部を、少しやさしくしました",
        "物語の細かな食い違いや、合宿の夜の曲などを直しました",
    ]),
    ("0.26.2", "2026年10月27日", [
        "プロローグ（中3の2月）に、自由行動を追加しました。リハビリの帰り道に会うひなた、店に立つ母、一人きりの防波堤のどこで過ごすかを選べます（はじめから遊ぶと見られます）",
    ]),
    ("0.26.1", "2026年10月27日", [
        "体験版の最後に「製品版でつづく物語」を追加しました。続きの章とルート、結末のしくみを紹介しています",
        "ヒロインの「ときめき」と「信頼」の意味が分かるようにしました。はじめて気持ちが動いたときと、相関図に出ます",
        "選択肢のヒントを追加しました。設定画面の「選択肢のヒント」で、出す／出さないを選べます（おすすめは、まずは直感で）",
        "テストの期間を、11月13日までにのばしました",
    ]),
]

## この版の更新情報を、もう見たか
default persistent.notes_seen_version = None

init python:

    def update_notes_for(ver):
        for v, d, items in UPDATE_NOTES:
            if v == ver:
                return d, items
        return None

    def update_notice_due():
        """前の版を遊んだことがある人が、この版で初めてタイトルを開いたとき True"""
        if persistent.notes_seen_version == config.version:
            return False
        if not update_notes_for(config.version):
            return False
        return bool(persistent.save_guide_seen or persistent.trial_cleared or persistent.play_report)

    def mark_update_seen():
        persistent.notes_seen_version = config.version

## 新しい版を初めて開いたときのお知らせ（タイトル画面の上に一度だけ）
screen update_notice():
    modal True
    zorder 120
    add Solid("#00000088")
    $ _n = update_notes_for(config.version)
    frame:
        style "update_frame"
        vbox:
            spacing 10
            text "ver.[config.version] に更新しました" style "update_title"
            if _n:
                for _it in _n[1]:
                    text "・" + _it style "update_item"
            null height 4
            hbox:
                xalign 0.5
                spacing 50
                textbutton "更新情報をすべて見る" action [Function(mark_update_seen), Hide("update_notice"), ShowMenu("updates")] text_size 24
                textbutton "閉じる" action [Function(mark_update_seen), Hide("update_notice")] text_size 24 text_color PEN_RED

## 更新情報の一覧（タイトル画面とメニューから）
screen updates():
    tag menu
    use game_menu("更新情報", scroll="viewport"):
        vbox:
            spacing 22
            for _v, _d, _items in UPDATE_NOTES:
                vbox:
                    spacing 6
                    hbox:
                        spacing 16
                        text "ver." + _v style "update_ver"
                        text _d style "update_date" yalign 1.0
                    for _it in _items:
                        text "・" + _it style "update_item"

style update_frame:
    background Frame("gui/note_big.png", 40, 40)
    xalign 0.5
    yalign 0.5
    xmaximum 1000
    padding (60, 46, 60, 46)

style update_title:
    font FONT_JP_B
    size 30
    color INK
    xalign 0.5

style update_ver:
    font FONT_JP_B
    size 26
    color PEN_RED

style update_date:
    size 18
    color INK_SOFT

style update_item:
    size 21
    color INK
    line_spacing 4

style update_title:
    variant "small"
    size 30

style update_item:
    variant "small"
    size 24

style mm_link_button:
    padding (6, 2, 6, 2)

style mm_link_button_text:
    size 20
    color "#ffffff"
    hover_color "#ffe38a"
    outlines [(2, "#00000088", 0, 0)]

style mm_link_button_text:
    variant "small"
    size 24
