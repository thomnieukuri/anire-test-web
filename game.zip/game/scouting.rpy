## scouting.rpy ―― 試合のための「つかんだ情報」と、作戦会議・ハーフタイムの読み（v0.37.0・試作：体験版の準決勝 桜嶺戦）
##   作者の相談（11/17）「試合に、選択肢以外のゲーム性や、専門的な内容を足したい。黒田がまさかの戦術をとるとか」
##   1. スカウティング：11月の自由行動で会いに行った人から、桜嶺の情報を1つずつもらう（鷹野・千夏・紗希。ひなたのノートの1つは全員がもらえる）
##   2. 作戦会議（11/12）：黒田の「まさかの作戦」（前半は5人で引いて守る。点を取りに行くのは1回だけ）。
##      その1回を、つかんだ情報のどれで狙うかを、蓮が決める
##   3. ハーフタイムの読み：前半に見えたこと（作戦ボード）から、後半に1つだけ変えるところを、蓮が言う
##   準決勝は物語の上で負けが決まっている。変わるのは、点差・見せ場・ふり返りまで（作者 11/17「負け確でいい」）

default scout_cards = []        # つかんだ情報（id の並び）
default ch3_plan = ""           # 作戦会議で決めた狙い（look / makabe / ck / sub / kuroda）
default ch3_half = ""           # ハーフタイムで変えたところ（ck / mark / makabe / sub）

## (id, 名前, 中身, だれから)
define SCOUT = [
    ("look", "神城のくせ",
     "ボールを持つ前に、一回だけ桜嶺のベンチを見る。その一瞬、足が止まる。",
     "ひなたのノート"),
    ("makabe", "14番の裏",
     "14番は、抜かれたあと、守りに戻らない。14番のうしろ、左の奥があく。",
     "鷹野"),
    ("ck", "桜嶺のコーナーキック",
     "ニアに走りこむ二人は、おとり。本命は、ファーにふくらむ9番の頭。",
     "千夏先輩の記録"),
    ("sub", "鬼塚監督の交代",
     "後半20分に、前の二人を必ず代える。代わった直後は、守りの声がそろわない。",
     "紗希"),
]

init python:
    def scout_name(cid):
        for k, name, body, who in SCOUT:
            if k == cid:
                return name
        return cid

    def learn_scout(cid):
        """つかんだ情報を1つ増やす。右上に出す"""
        if cid in store.scout_cards:
            return
        store.scout_cards = store.scout_cards + [cid]
        toast("つかんだ情報：「%s」" % scout_name(cid))
        telop_sound()

    def has_scout(cid):
        return cid in store.scout_cards

    def scout_rows():
        out = []
        for k, name, body, who in SCOUT:
            if k in store.scout_cards:
                out.append((name, body + "（" + who + "）"))
        return out

    def ch3_ck_held():
        """後半17分のコーナーキックを止められるか（作戦かハーフタイムで、ファーを読んでいた）"""
        return store.ch3_plan == "ck" or store.ch3_half == "ck"

    def ch3_last_bonus():
        """最後の5分の判定を、どれだけ下げるか（鬼塚の交代を待っていた・14番の裏を言っていた）"""
        b = 0
        if store.ch3_plan == "sub":
            b += 6
        elif store.ch3_plan in ("look", "makabe"):
            b += 3
        if store.ch3_half == "sub":
            b += 4
        elif store.ch3_half == "makabe":
            b += 3
        return b

################################################################################
## 情報の一覧（試合のふり返りと同じ、ひなたのルーズリーフ）
################################################################################
screen scout_report(title, rows, memo=""):
    modal True
    zorder 150
    add "#00000088"
    fixed at report_in:
        xysize (956, 656)
        xalign 0.5
        yalign 0.5
        add "gui/report_note.png"
        frame:
            style "report_tape"
            text "桜嶺戦のために　つかんだ情報" style "report_head"
        vbox:
            xpos 112
            ypos 100 - 42 - 4
            spacing 0
            text title style "report_title"
            for k, v in rows:
                hbox:
                    spacing 14
                    text k style "report_key"
                    text v style "report_val"
            if memo:
                text memo style "report_memo"
        text "タップで閉じる" style "report_hint"
    key "dismiss" action Return()
    button:
        xysize (1280, 720)
        background None
        action Return()


################################################################################
## 作戦会議（11月12日・木）：黒田の「まさかの作戦」と、狙いを決める
################################################################################
label ch3_semi_plan:
    scene black
    with dissolve
    $ set_cal("11月12日（木）", "放課後")
    scene bg clubroom
    with dissolve
    $ bgm("作戦会議っぽい軽快な曲")
    "準決勝の二日前。練習のあと、{rb}黒田{/rb}{rt}くろだ{/rt}が部室に全員を集めた。"
    show kuroda board
    with dissolve
    "ホワイトボードの代わりの、古い作戦ボード。黒田は、マグネットを一つずつ、自分たちのゴールの前に並べていった。"
    $ tactics(caption="桜嶺戦　前半の並び（5-4-1）", dots=[
        ("h", "大門", (3, 34)),
        ("h", "", (16, 8), (13, 8), 0.0, 0.5), ("h", "", (16, 21), (13, 21), 0.1, 0.5),
        ("h", "三好", (16, 34), (13, 34), 0.2, 0.5), ("h", "", (16, 47), (13, 47), 0.3, 0.5),
        ("h", "", (16, 60), (13, 60), 0.4, 0.5),
        ("ren", "蓮", (36, 34), (25, 30), 0.6, 0.6), ("h", "", (36, 14), (25, 14), 0.7, 0.6),
        ("h", "", (36, 50), (25, 42), 0.8, 0.6), ("h", "", (36, 58), (25, 56), 0.9, 0.6),
        ("h", "鷹野", (60, 20), (44, 22), 1.0, 0.6),
        ])
    kuroda "前半は、5人で守る。前に残すのは、{rb}鷹野{/rb}{rt}たかの{/rt}一人だ"
    show miyoshi smile at left
    with dissolve
    miyoshi "……は！？　先生、5バックって、引きこもれってことですか！"
    kuroda "そうだ"
    "黒田は、あっさり言った。"
    kuroda "ボールは、いらない。前半の45分、シュートは0本でいい"
    kuroda "5月に、[m531_sc]だった相手だ。同じ顔で前に出れば、同じ数字になる"
    hide miyoshi
    show takano jersey_narrow at left
    with dissolve
    takano "……で、点はどうやって取るんだよ"
    kuroda "90分のうち、取りに行くのは、一回だけだ"
    kuroda "その一回を、どこで使うか。……それは、まだ決めてない"
    hide takano
    with dissolve
    $ tactics_off()
    "黒田が、こっちを見た。"
    kuroda "{rb}早瀬{/rb}{rt}はやせ{/rt}。この10日で、お前らが拾ってきたものを、全部出せ"

    ## ひなたのノート（全員がもらえる情報）
    show hinata serious at right
    with dissolve
    hinata "……はい。これ"
    "ひなたが、ノートを机に置いた。付せんが、何枚も飛び出している。"
    hinata "桜嶺の準々決勝のビデオ。千夏先輩が、生徒会のつてで借りてくれたの。5回、見た"
    hinata "神城くん、ボールを持つ前に、一回だけ、桜嶺のベンチを見る。毎回。……そのとき、足が止まってる"
    $ learn_scout("look")
    hide hinata
    with dissolve

    ## 11月に会いに行った人から聞いたこと
    if has_scout("makabe"):
        "鷹野が言っていたこと。14番は、抜かれたあと、守りに戻らない。"
    if has_scout("ck"):
        "千夏先輩の記録。桜嶺の点の3分の1は、コーナーキック。全部、ファーサイド。"
    if has_scout("sub"):
        "[saki_call]が言っていたこと。あの人は、後半20分に、前の二人を必ず代える。"
    $ _n = len(scout_cards)
    if _n == 1:
        "俺が出せるのは、ひなたのノートだけだった。"
    window auto hide
    call screen scout_report("つかんだ情報　%d／%d" % (len(scout_cards), len(SCOUT)), scout_rows(), "黒田：一回だけ、取りに行く。どこで使う")

    show kuroda board
    kuroda "どれで行く"
    menu:
        "「神城がベンチを見る、その一瞬で、前を向きます」" if has_scout("look"):
            $ ch3_plan = "look"
            $ up("戦術眼", 2)
            kuroda "……あいつの目が、ベンチに行ってるあいだだけ、お前はあいつより速い"
            kuroda "前を向いたら、迷うな。撃て"
        "「14番の裏です。鷹野を、外に走らせます」" if has_scout("makabe"):
            $ ch3_plan = "makabe"
            $ bond_up("鷹野", 3)
            show takano jersey at left
            with dissolve
            takano "……あいつの裏なら、目つぶってても走れる"
            hide takano
            with dissolve
            kuroda "前半30分までに、一回だけ見せろ。あとは、向こうが勝手に気にする"
        "「コーナーキックです。ニアは捨てて、ファーに大門さんを寄せます」" if has_scout("ck"):
            $ ch3_plan = "ck"
            $ bond_up("大門", 3)
            show daimon jersey at left
            with dissolve
            daimon "ぼ、僕が、ファーに……？"
            kuroda "ニアに二人走ってきても、ついていくな。本命は、いつもファーの9番だ"
            hide daimon
            with dissolve
            kuroda "取られなかった1点も、取った1点と同じだ"
        "「後半20分です。鬼塚監督が前を代えた瞬間に、全員で前に出ます」" if has_scout("sub"):
            $ ch3_plan = "sub"
            $ up("メンタル", 2)
            kuroda "……あの男は、そういう男だ。決めたとおりにしか動かない"
            "黒田は、それ以上、鬼塚監督のことを言わなかった。"
            kuroda "三好。代わった合図は、お前が右手を上げろ。それで、全員が一歩前だ"
        "「……先生に、任せます」":
            $ ch3_plan = "kuroda"
            kuroda "……そうか"
            "黒田は、マグネットを一つだけ動かして、作戦ボードをしまった。"
    $ set_flag("ch3_plan", ch3_plan)
    hide kuroda
    with dissolve
    "部室を出ると、外はもう暗かった。"
    "あさって。[m531_sc]の相手と、もう一度。"
    $ amb_stop()
    return


################################################################################
## ハーフタイム：前半に見えたことから、後半に1つだけ変える
################################################################################
label ch3_semi_half:
    show kuroda board
    with dissolve
    "ハーフタイム。{rb}黒田{/rb}{rt}くろだ{/rt}は、作戦ボードを、ベンチの前の芝の上に置いた。"
    kuroda "……いい試合だ。お前らが、試合をしてる"
    kuroda "[m531_sc]のときは、試合になってなかった"
    "誰も、笑わなかった。でも、全員がうなずいていた。"
    ## 前半22分のコーナーキックを、ボードで見せる（読みの手がかり）
    $ tactics(caption="前半22分　桜嶺のコーナーキック", dots=[
        ("h", "大門", (2, 34)),
        ("h", "", (8, 32), (7, 24), 0.6, 0.6), ("h", "", (11, 36), (11, 26), 0.6, 0.6), ("h", "", (13, 40), (14, 29), 0.7, 0.6),
        ("a", "", (20, 12), (6, 22), 0.3, 0.7), ("a", "", (24, 16), (10, 25), 0.4, 0.7),
        ("a", "9", (22, 58), (8, 45), 0.9, 0.8),
        ("ball", "", (0.5, 0.5), (8, 45), 1.5, 0.6),
        ],
        arrows=[((20, 12), (6, 22), 0.3, "w"), ((24, 16), (10, 25), 0.4, "w"), ((22, 58), (8, 45), 0.9, "r"), ((0.5, 0.5), (8, 45), 1.5, "r")])
    if ch3_plan == "ck":
        kuroda "コーナーは、決めたとおりでいい。大門、よく見てた"
    kuroda "{rb}早瀬{/rb}{rt}はやせ{/rt}。前半、何が見えた。……後半、一つだけ変える"
    $ tactics_off()
    if ch3_knee_plan == "half":
        kuroda "それと、もう下がってなくていい。45分、全部使え"
        "ひざは、まだ軽い。前半、ほとんど走らなかった分だけ。"
    menu:
        "「コーナーキックです。ニアの二人はおとりで、本命はファーの9番」" if ch3_plan != "ck":
            $ ch3_half = "ck"
            $ up("戦術眼", 2)
            kuroda "……見てたか"
            kuroda "大門。後半のコーナーは、ニアを捨てろ。ファーに一歩寄れ"
        "「神城です。あいつを、自由にさせすぎてます」":
            $ ch3_half = "mark"
            kuroda "三好と坂口で、挟め。神城には、前を向かせるな"
        "「14番です。あいつ、抜かれたら戻ってこない」" if has_scout("makabe") and ch3_plan != "makabe":
            $ ch3_half = "makabe"
            $ bond_up("鷹野", 2)
            kuroda "鷹野。最後の10分、14番の裏だけを見てろ"
        "「後半20分です。鬼塚監督が、前の二人を代えます」" if has_scout("sub") and ch3_plan != "sub":
            $ ch3_half = "sub"
            kuroda "……そうか。じゃあ、代わったら、全員で一歩前だ"
    $ set_flag("ch3_half", ch3_half)
    "ベンチの前で、ひなたが何も言わずに、背中を一回押した。"
    hide kuroda
    with dissolve
    return


################################################################################
## 後半のアディショナルタイム：同点のまま終わらせない（準決勝は負けで決まっている）
##   ファーを読んで止めた人だけが、ここまで来る。最後は、鬼塚がニアに変えてくる
################################################################################
label ch3_semi_stoppage:
    $ sb_set(mm=83)
    scene bg stadium_semi_eve at cam_push(6.0, 1.12)
    with dissolve
    $ bgm("試合の曲（終盤）")
    "後半アディショナルタイム。スコアボードの横に、+3。"
    "同点のまま、時間だけが過ぎていく。スタンドの声が、ひとつの音みたいに聞こえた。"
    "最後のコーナーキック。桜嶺のベンチで、鬼塚監督が、指を一本だけ立てた。"
    "ニアに走る白が、一人だけだった。"
    "{rb}大門{/rb}{rt}だいもん{/rt}が、ファーへ一歩寄る。今日、ずっとそうしてきたとおりに。"
    ## v0.43.0：鬼塚の指一本 → ニアの神城、を一枚絵で続けて見せる
    scene cg ch3s_stoppage_sign at cam_push(4.0, 1.05)
    with dissolve
    $ cg_look()
    "鬼塚監督の指が、一本。それだけで、白の並びが変わった。"
    scene cg ch3s_stoppage_goal
    with goal_flash
    "ボールは、ニアに来た。"
    "走りこんだのは、{rb}神城{/rb}{rt}かみしろ{/rt}だった。"
    $ goal("桜嶺", home=sb_home, away=sb_away + 1, mm=83, by="神城")
    $ cg_look()
    "大門の、反対側。ネットが、小さく揺れた。"
    "読まれていたのは、こっちの読みのほうだった。"
    $ set_flag("ch3_semi_stoppage")
    return


################################################################################
## 前半22分：桜嶺のコーナーキック（ハーフタイムの読みの手がかり）
################################################################################
label ch3_semi_ck_hint:
    $ sb_set(mm=22)
    if ch3_plan == "ck":
        "前半22分、桜嶺のコーナーキック。ニアに、白が二人走りこむ。……誰も、ついていかなかった。"
        scene cg ch3s_daimon_catch22
        with vpunch
        $ cg_look()
        "ファーにふくらんだ9番の前に、{rb}大門{/rb}{rt}だいもん{/rt}が先に飛び出して、両手でつかんだ。"
        "ベンチで、黒田が、小さくうなずいた。"
        $ bond_up("大門", 2)
    else:
        "前半22分、桜嶺のコーナーキック。ニアに、白が二人走りこんだ。港北の三人が、そっちへつられる。"
        "がら空きのファーで、背の高い9番が、頭を合わせた。"
        scene cg ch3s_post22
        with vpunch
        $ se("鈍い衝突音")
        $ cg_look()
        "ボールは、ポストに当たって、外に出た。"
        "{rb}大門{/rb}{rt}だいもん{/rt}が、ゴールの中で、ニアとファーを、何度も見くらべていた。"
    return
