## nightcontact.rpy ―― 自由行動の夜に、自分から誰かにトークを送る（LINE風）
##   v0.29.5 から：自分から送れるのは、その月の最後の自由行動の夜だけ（★つきで、まだ話していないことがある人だけ、最大3人）。
##   ほかの夜は、昼に会った人からのトークがあればそれだけ。なければ2晩に1晩、相手から先に届く（NIGHT_INCOMING_OPEN の一言のあと、いつもの話）。
##   送れる相手：ひなた（いつでも）、千夏（6/1 にIDを追加してから）、三好、大門・鷹野（仲間になってから）、
##   坂口・神城（6月から。5/31 に部のグループができ、神城に初めて返事をしたあと）。
##   紗希は連絡先を知らないので、有料パートで flags["紗希_連絡先"] を立てたら、ここに自動で並ぶ。
##   同じ人に何度でも送れる。話はその人の「時期」ごとに用意している：
##     1回目 nc_<id>_<時期>、2回目 nc_<id>_<時期>_2、3回目からは nc_<id>_extra1, 2, …（時期を問わない話。まだ見ていないものから）
##   （「おやすみ」だけの短いやりとりは使わない。v0.27.0）
##   新しい相手を足すときは NIGHT_IDS と night_can_send と、送る相手の選択肢に足す。
##
##   呼び方：call night_send("7月15日（水）", "jul", met="ひなた")
##     met ＝ その夜、すでにトークをした相手（同じ夜にもう一度は選べない）

default night_sent = {}          # (相手, 時期) → 送った回数
default night_extra_seen = []    # 見た「時期を問わない話」のラベル
default night_month = ""         # 今夜の月（"apr" など）。トークの中で分けたいときに読む
default night_date = ""          # 今夜の日付（"7月15日（水）" など）
default night_quiet = 0          # 送れる夜でも、昼に会った人のトークがある夜でもない夜の数（2晩に1晩、相手から届く）
default night_incoming = ""      # 相手から届く夜の相手（talk_start のあと、相手の一言を先に出す）
default night_boost = False      # 夜のトーク中だけ True（気持ち・絆の上がり方を2倍に）
default night_count = 0          # 夜のトークをした回数
default night_last = {}          # 相手 → 最後に夜のトークをしたときの night_count（久しぶりの人を先に）
default night_tuto_done = False

## 相手から届く夜の、相手の最初の一言（そのあとに、いつもの話が続く）。神城からは来ない
##   このあとの話は、蓮が先に送る形で書いてある（talk_me から始まる）。届いた一言のあとに続けても
##   おかしくならない言葉にしておく（「起きてる？」に蓮が「起きてる？」と返す、などにならないように）
##   三好は、5/31 より前（4・5月）は「早瀬」と呼ぶ（nt2_miyoshi_ren。第4章の夜は「蓮」のまま）
init -1 python:
    class NightIncomingOpen(dict):
        def get(self, who, default=None):
            text = dict.get(self, who, default)
            if who == "三好" and text and not getattr(store, "a4_night_date", ""):
                text = text.replace("蓮", nt2_miyoshi_ren(), 1)
            return text

define NIGHT_INCOMING_OPEN = NightIncomingOpen({
    "ひなた": "ねえ", "千夏": "……起きていますか", "紗希": "……起きてる？",
    "三好": "蓮！！　起きてるか！！", "大門": "早瀬くん、起きてますか", "鷹野": "おい", "坂口": "ひま？",
    "小早川": "先輩、今いいですか", "あげは": "パイセン起きてる？？",
})
define NIGHT_BOOST = 2
define NIGHT_HEROINES = ("ひなた", "千夏", "紗希", "あげは")
define NIGHT_ORDER = ("ひなた", "千夏", "紗希", "三好", "大門", "鷹野", "坂口", "神城")

init python:
    ## 相手の名前 → ラベルに使う名前
    NIGHT_IDS = {"ひなた": "hinata", "千夏": "chika", "紗希": "saki", "三好": "miyoshi", "大門": "daimon",
                 "鷹野": "takano", "坂口": "sakaguchi", "神城": "kamishiro"}

    def night_slot(who, month, date):
        """その夜の話のかたまりの名前。ヒロインは月ごと（5月だけ、21日の前とあとで分ける）。
        仲間は時期ごと：4月 ch1／5月 ch1b／6・7月 ch2a／8月 ch2b／9月 ch3a／10月 ch3b／11月 nov／12月 dec"""
        if who in ("ひなた", "千夏", "紗希"):
            if month == "may":
                try:
                    day = int(date.split("月")[1].split("日")[0])
                except Exception:
                    day = 1
                return "may1" if day < 21 else "may2"
            return month
        return {"apr": "ch1", "may": "ch1b", "jun": "ch2a", "jul": "ch2a", "aug": "ch2b",
                "sep": "ch3a", "oct": "ch3b", "nov": "nov", "dec": "dec"}.get(month, month)

    def night_can_send(who, month=""):
        if who == "千夏":
            return bool(store.flags.get("千夏_友だち"))
        if who in ("大門", "鷹野"):
            return who in store.ch1_join        # 誘って仲間になってから（4/17 にはみんな入っている）
        if who in ("坂口", "神城"):
            return month not in ("apr", "may")  # 5/31 のあと（部のグループ・神城への初めての返事）
        if who == "紗希":
            return bool(store.flags.get("紗希_連絡先"))
        return True

    def night_met_of(lab):
        """その夜にトークをした相手（行き先のラベルから）"""
        for key, who in (("hinata", "ひなた"), ("shokudo", "ひなた"), ("chika", "千夏"), ("council", "千夏"),
                         ("miyoshi", "三好"), ("daimon", "大門"), ("takano", "鷹野"), ("arcade", "坂口")):
            if key in lab:
                return who
        return "ほか"

    def night_label(who, month, date):
        """送った回数で、出す話を決める。1回目→その時期の話、2回目→その時期の2本目、3回目から→時期を問わない話"""
        slot = night_slot(who, month, date)
        n = store.night_sent.get((who, slot), 0)
        nid = NIGHT_IDS[who]
        first = "nc_%s_%s" % (nid, slot)
        if n == 0 and renpy.has_label(first):
            return first, slot
        if n <= 1 and renpy.has_label(first + "_2"):
            return first + "_2", slot
        extras = []
        k = 1
        while renpy.has_label("nc_%s_extra%d" % (nid, k)):
            extras.append("nc_%s_extra%d" % (nid, k))
            k += 1
        for lab in extras:
            if lab not in store.night_extra_seen:
                store.night_extra_seen.append(lab)
                return lab, slot
        if extras:
            ## 全部見たら、いちばん前から（ここまで来るのはまれ）
            lab = extras[n % len(extras)]
            return lab, slot
        return "nc_%s_short" % nid, slot

init python:

    def night_is_send_night(date, month):
        """その月の最後の自由行動の夜か（自分から送れる夜）"""
        last = {"apr": CH1_FREE_DATES[-1], "may": CH1_FREE3_DATE}
        for k, v in CH2_FREE.items():
            last[k] = v[0][-1]
        for k, v in CH3_FREE.items():
            last[k] = v[0][-1]
        return last.get(month) == date

    def night_has_new(who, month, date):
        """その時期の話（1本目・2本目）を、まだ読んでいないか"""
        slot = night_slot(who, month, date)
        n = store.night_sent.get((who, slot), 0)
        first = "nc_%s_%s" % (NIGHT_IDS[who], slot)
        return (n == 0 and renpy.has_label(first)) or (n <= 1 and renpy.has_label(first + "_2"))

    def night_send_list(month, date, met):
        """送れる夜の一覧：まだ話していないことがある人だけ。ヒロインを先に、仲間は久しぶりの人から。最大3人"""
        ok = [w for w in NIGHT_ORDER if w != met and night_can_send(w, month) and night_has_new(w, month, date)]
        her = [w for w in ok if w in NIGHT_HEROINES]
        mates = sorted([w for w in ok if w not in NIGHT_HEROINES],
                       key=lambda w: (store.night_last.get(w, 0), NIGHT_ORDER.index(w)))
        return (her + mates)[:3]

    def night_incoming_pick(month, date):
        """相手から届く夜：まだ話していないことがある人のうち、いちばん久しぶりの人（神城は除く）"""
        ok = [w for w in NIGHT_ORDER if w in NIGHT_INCOMING_OPEN and night_can_send(w, month) and night_has_new(w, month, date)]
        if not ok:
            return ""
        ok.sort(key=lambda w: (store.night_last.get(w, 0), NIGHT_ORDER.index(w)))
        return ok[0]

label night_send(date, month, met=""):
    ## v0.29.5：毎晩送れるとマンネリになるので、
    ##   ・自分から送れるのは、その月の最後の自由行動の夜だけ（体験版で9晩）。一覧は「まだ話していないことがある人」だけ、★つきで最大3人
    ##   ・昼に会った人のトークがあった夜は、それで終わり（送れる夜を除く）
    ##   ・どちらでもない夜は、2晩に1晩、まだ話していないことがある人から先に届く。ほかの夜は1行で終わる
    ##   ・回数が減ったぶん、夜のトークで上がる気持ち・絆は2倍（NIGHT_BOOST）
    python:
        night_month = month
        night_date = date
        _ns_send = night_is_send_night(date, month)
        _ns_who = night_send_list(month, date, met) if _ns_send else []
    if not _ns_send:
        if met:
            return
        $ night_quiet += 1
        $ _ns_in = night_incoming_pick(month, date) if night_quiet % 2 == 0 else ""
        scene black
        with dissolve
        $ set_cal(date, "夜")
        scene bg ren_room_night
        with dissolve
        $ bgm("静かな夜の曲")
        if not _ns_in:
            $ _ns_close = ("今日は、スマホを見ないまま眠った。", "布団に入ったとたん、意識が落ちた。", "ノートを少しだけ見返して、電気を消した。")[night_quiet // 2 % 3]
            "[_ns_close]"
            return
        $ se("トークアプリの通知音")
        $ _ns_in_name = {"千夏": "千夏先輩", "三好": "三好先輩", "紗希": saki_call}.get(_ns_in, _ns_in)
        "スマホが鳴った。[_ns_in_name]からだった。"
        $ _ns_to = _ns_in
        $ night_incoming = _ns_in
        jump night_send_open
    if not _ns_who:
        return
    if not met:
        scene black
        with dissolve
        $ set_cal(date, "夜")
        scene bg ren_room_night
        with dissolve
        $ bgm("静かな夜の曲")
        ## 毎晩同じ文にならないように、日付で3つから選ぶ
        $ _ns_open = ("風呂から上がって、スマホを手に取った。", "宿題を片づけて、スマホを手に取った。", "布団に入る前に、スマホを手に取った。")[sum(ord(c) for c in date) % 3]
        "[_ns_open]"
    if not night_tuto_done:
        $ night_tuto_done = True
        window auto hide
        tuto "月に一度、その月の最後の夜に、自分から誰かにトークを送れます。並ぶのは、まだ話していないことがある人だけです。"
        tuto "ほかの夜にも、ときどき相手からトークが届きます。"
    "……誰かに、送ってみようか。"
    ## 毎晩同じ選択肢なので、「済」の印は付けない（nochosen）
    menu:
        "★ ひなたに送る" (nochosen=True) if "ひなた" in _ns_who:
            $ _ns_to = "ひなた"
        "★ 千夏先輩に送る" (nochosen=True) if "千夏" in _ns_who:
            $ _ns_to = "千夏"
        "★ 紗希に送る" (nochosen=True) if "紗希" in _ns_who:
            $ _ns_to = "紗希"
        "★ 三好先輩に送る" (nochosen=True) if "三好" in _ns_who:
            $ _ns_to = "三好"
        "★ 大門に送る" (nochosen=True) if "大門" in _ns_who:
            $ _ns_to = "大門"
        "★ 鷹野に送る" (nochosen=True) if "鷹野" in _ns_who:
            $ _ns_to = "鷹野"
        "★ 坂口に送る" (nochosen=True) if "坂口" in _ns_who:
            $ _ns_to = "坂口"
        "★ 神城に送る" (nochosen=True) if "神城" in _ns_who:
            $ _ns_to = "神城"
        "今日は、やめておく" (nochosen=True):
            $ _ns_to = ""
    if not _ns_to:
        "スマホを伏せて、目を閉じた。"
        return
label night_send_open:
    $ _ns_lab, _ns_slot = night_label(_ns_to, night_month, night_date)
    $ night_sent[(_ns_to, _ns_slot)] = night_sent.get((_ns_to, _ns_slot), 0) + 1
    $ night_count += 1
    $ night_last[_ns_to] = night_count
    window auto hide
    $ night_boost = True
    call expression _ns_lab
    $ night_boost = False
    $ night_incoming = ""
    window auto hide
    $ talk_end()
    $ set_flag("夜の連絡_" + _ns_slot, _ns_to)
    return

## 前の版の呼び方（古いセーブのために残す）
label night_contact(key, date):
    $ _nc_month = key.split("_")[1]
    call night_send(date, _nc_month)
    return


## ===========================================================================
## 同じ時期の2回目から：短いやりとり
## ===========================================================================
label nc_hinata_short:
    $ talk_start("ひなた", "22:31")
    $ talk_me("起きてる？")
    $ talk("ひなた", "起きてる。どうしたの")
    $ talk_me("いや、なんでもない")
    $ talk("ひなた", "なにそれ。……でも、ちょっとうれしいから許す")
    $ talk("ひなた", "おやすみ")
    $ heart_up("ひなた", "ときめき", 1)
    return

label nc_chika_short:
    $ talk_start("千夏", "21:40")
    $ talk_me("おやすみなさい")
    $ talk_system("既読")
    $ talk("千夏", "おやすみなさい。……早瀬くん")
    $ heart_up("千夏", "信頼", 1)
    return

label nc_miyoshi_short:
    $ talk_start("三好", "21:15")
    $ talk_me("明日もよろしくお願いします")
    $ talk("三好", "おう！！！！")
    $ talk("三好", "朝練、7時な！！！")
    $ bond_up("三好", 1)
    return

label nc_daimon_short:
    $ talk_start("大門", "21:50")
    $ talk_me("おつかれ")
    $ talk("大門", "お、おつかれさまです！")
    $ talk("大門", "……早瀬くんから来ると、ちょっとびっくりします。うれしいほうの")
    $ bond_up("大門", 1)
    return

label nc_takano_short:
    $ talk_start("鷹野", "23:02")
    $ talk_me("おつかれ")
    $ talk_system("既読")
    $ talk("鷹野", "……寝ろ")
    $ bond_up("鷹野", 1)
    return


## ===========================================================================
## ひなた（月ごと）
## ===========================================================================
label nc_hinata_apr:
    $ talk_start("ひなた", "21:36")
    $ talk_me("今日、ちょっと疲れた")
    $ talk("ひなた", "知ってる。一緒に回ったもん")
    $ talk("ひなた", "部員、集まりそう？")
    $ _r = talk_choose([("まだ全然。でも、やめない", "a"), ("ひなたも、誰か知らない？", "b")])
    if _r == "a":
        $ talk_me("まだ全然。でも、やめない")
        $ talk("ひなた", "うん。そういうとこは、昔から変わんないね")
        $ talk("ひなた", "明日のおにぎり、一個多くしとく")
        $ heart_up("ひなた", "信頼", 3)
    else:
        $ talk_me("ひなたも、誰か知らない？")
        $ talk("ひなた", "知ってたら、とっくに連れてってる")
        $ talk("ひなた", "明日、1年の教室、もう一回まわってみる")
        $ heart_up("ひなた", "ときめき", 3)
    return

label nc_hinata_may1:
    $ talk_start("ひなた", "22:12")
    $ talk_me("中間テストの範囲、どこまでだっけ")
    $ talk("ひなた", "数学は、教科書の58ページまで")
    $ talk("ひなた", "……練習ばっかりで、聞いてなかったでしょ")
    $ _r = talk_choose([("ひなたがいて助かった", "a"), ("ノート、写させて", "b")])
    if _r == "a":
        $ talk_me("ひなたがいて助かった")
        $ talk("ひなた", "でしょ。もっと助かっていいよ")
        $ heart_up("ひなた", "ときめき", 3)
    else:
        $ talk_me("ノート、写させて")
        $ talk("ひなた", "お店のカウンターでならいい。宿題は、ちゃんと自分でやること")
        $ talk("ひなた", "……あと、ひざのテーピングの本、買った。それも見ていいよ")
        $ heart_up("ひなた", "信頼", 3)
    return

label nc_hinata_jun:
    $ talk_start("ひなた", "21:48")
    $ talk_me("梅雨入りしたって")
    $ talk("ひなた", "知ってる。グラウンド、ぐちゃぐちゃだった")
    $ talk("ひなた", "ねえ、ストップウォッチ、新しいの買った。前のは、ボタンが戻らなくなってた。予選の日、蓮が何分走ったか、ベンチで全部メモする")
    $ talk("ひなた", "ひざのためだからね。ストーカーじゃないからね")
    $ set_flag("ひなた_ストップウォッチ")
    $ _r = talk_choose([("頼む。数字で見たほうが分かる", "a"), ("試合中まで見張らなくていい", "b")])
    if _r == "a":
        $ talk_me("頼む。数字で見たほうが分かる")
        $ talk("ひなた", "でしょ。黒田先生にも見せていい？")
        $ talk("ひなた", "……あと、ゴール決めたら、時間も書いとく")
        $ heart_up("ひなた", "信頼", 3)
    else:
        $ talk_me("試合中まで見張らなくていい")
        $ talk("ひなた", "見張ってない。見てるだけ")
        $ talk("ひなた", "……ずっと見てるの、昔からだし")
        $ heart_up("ひなた", "ときめき", 3)
    return

label nc_hinata_sep:
    $ talk_start("ひなた", "22:05")
    $ talk_me("ノートの、桜嶺のページ、増えた？")
    $ talk("ひなた", "増えた。組み合わせ、桜嶺と同じ山だったから")
    $ _r = talk_choose([("ひなたのノートがあれば、勝てる気がする", "a"), ("ノート、どこまで書いてあるの", "b")])
    if _r == "a":
        $ talk_me("ひなたのノートがあれば、勝てる気がする")
        $ talk("ひなた", "勝つのは蓮たちでしょ")
        $ talk("ひなた", "……でも、そう言われるのは、ちょっといい")
        $ heart_up("ひなた", "ときめき", 3)
    else:
        $ talk_me("ノート、どこまで書いてあるの")
        $ talk("ひなた", "中学の決勝から、全部")
        $ talk("ひなた", "蓮のひざの日記も、別のノートにある。……見せないけど")
        $ heart_up("ひなた", "信頼", 3)
    return

label nc_hinata_nov:
    $ talk_start("ひなた", "22:40")
    $ talk_me("ノート、まだ書いてる？")
    $ talk("ひなた", "書いてる。ちょうど聞きたかったの")
    $ talk("ひなた", "今日、ひざ、何回さすった？")
    $ talk("ひなた", "練習のとき、数えてた")
    $ _r = talk_choose([("……8回", "a"), ("さすってない", "b")])
    if _r == "a":
        $ talk_me("……8回")
        $ talk("ひなた", "11回だよ。……でも、言ってくれた")
        $ talk("ひなた", "明日の朝、氷のう持ってく")
        $ heart_up("ひなた", "信頼", 4)
        $ up("無理ゲージ", -2)
    else:
        $ talk_me("さすってない")
        $ talk("ひなた", "11回")
        $ talk("ひなた", "……トークだと眉毛が見えないから、わたしの数え間違いってことにしとく")
        $ heart_up("ひなた", "さみしさ", 2)
    return


## ===========================================================================
## 千夏（月ごと。6月1日にIDを追加してから）
## ===========================================================================
label nc_chika_jun:
    $ talk_start("千夏", "21:20")
    $ talk_me("黒田先生の届け、ありがとうございました")
    $ talk_system("既読")
    $ talk("千夏", "受理しました。監督の欄も、問題ありません")
    $ talk("千夏", "……それから。あの夜のことは、記録にありません")
    $ _r = talk_choose([("はい。何もありませんでした", "a"), ("髪、似合ってました", "b")])
    if _r == "a":
        $ talk_me("はい。何もありませんでした")
        $ talk("千夏", "協力に、感謝します")
        $ heart_up("千夏", "信頼", 3)
    else:
        $ talk_me("髪、似合ってました")
        $ talk_system("既読がついてから、4分")
        $ talk("千夏", "記録にありません、と言いました")
        $ talk("千夏", "……おやすみなさい")
        $ heart_up("千夏", "ときめき", 3)
    return

label nc_chika_sep:
    $ talk_start("千夏", "21:12")
    $ talk_me("選手権の組み合わせ、出ました")
    $ talk_system("既読")
    $ talk("千夏", "知っています。……ちょうど、聞こうと思っていました")
    $ talk("千夏", "選手権の組み合わせ表を、生徒会の掲示板に貼ってもいいですか")
    $ talk("千夏", "サッカー部の試合を、校内に知らせるのは初めてです")
    $ _r = talk_choose([("お願いします", "a"), ("先輩の字で書いてくれるなら", "b")])
    if _r == "a":
        $ talk_me("お願いします")
        $ talk("千夏", "明日の朝、貼っておきます。勝ち上がったら、線を赤で引きます")
        $ heart_up("千夏", "信頼", 3)
    else:
        $ talk_me("先輩の字で書いてくれるなら")
        $ talk_system("既読がついてから、3分")
        $ talk("千夏", "……生徒会の掲示物は、すべてわたしが書いています")
        $ talk("千夏", "サッカー部のところだけ、少し大きく書きます。規則の範囲で")
        $ heart_up("千夏", "ときめき", 3)
    return

label nc_chika_nov:
    $ talk_start("千夏", "21:58")
    $ talk_me("生徒会、まだ仕事ですか")
    $ talk("千夏", "今、帰りました。……ひとつ、聞いてもいいですか")
    $ talk("千夏", "保健室の利用記録に、早瀬くんの名前が、この一週間で、三回ありました")
    $ talk("千夏", "生徒会は、利用記録を確認する係ではありません。たまたま、見えただけです")
    $ _r = talk_choose([("ひざ、少し腫れてます。でも、準決勝は出ます", "a"), ("湿布をもらってただけです", "b")])
    if _r == "a":
        $ talk_me("ひざ、少し腫れてます。でも、準決勝は出ます")
        $ talk("千夏", "……知っています。止めても、出るのでしょう")
        $ talk("千夏", "なら、ちゃんと帰ってきてください。それだけです")
        $ heart_up("千夏", "信頼", 4)
    else:
        $ talk_me("湿布をもらってただけです")
        $ talk("千夏", "三回とも、ですか")
        $ talk("千夏", "……分かりました。そういうことに、しておきます")
        $ heart_up("千夏", "さみしさ", 2)
    return


## ===========================================================================
## 三好（時期ごと）
## ===========================================================================
label nc_miyoshi_ch1:
    $ talk_start("三好", "21:03")
    if ch1_dest == "arcade":
        $ talk_me("今日、ゲーセンの1年の5人が、話を聞いてくれました")
    elif ch1_dest == "judo":
        $ talk_me("今日、柔道部の大門が、話を聞いてくれました")
    elif ch1_dest == "roof":
        $ talk_me("今日、屋上で鷹野と話しました")
    else:
        $ talk_me("今日、一人、話を聞いてくれました")
    $ talk("三好", "早瀬！！！　今日もおつかれ！！！")
    $ talk("三好", "あと何人だ！？　俺、数えるの苦手でさ！！")
    $ _r = talk_choose([("全員そろうまで、毎日誘います", "a"), ("先輩、数えるのは俺がやります", "b")])
    if _r == "a":
        $ talk_me("全員そろうまで、毎日誘います")
        $ talk("三好", "それだ！！！　俺も明日、3年の教室まわってくる！！")
        $ bond_up("三好", 3)
    else:
        $ talk_me("先輩、数えるのは俺がやります")
        $ talk("三好", "助かる！！　お前、戦術眼ってやつがあるもんな！！")
        $ bond_up("三好", 2)
        $ up("戦術眼", 1)
    return

label nc_miyoshi_ch2a:
    $ talk_start("三好", "21:30")
    $ talk_me("明日の朝練、何時でしたっけ")
    $ talk("三好", "明日の朝練、7時な！！　桐生のインターホンも鳴らしてくる！！")
    $ talk("三好", "なあ蓮。黒田先生のメニュー、きついけど、楽しいよな！！")
    $ _r = talk_choose([("楽しいです", "a"), ("先輩、桐生先輩の家族に怒られますよ", "b")])
    if _r == "a":
        $ talk_me("楽しいです")
        $ talk("三好", "だよな！！！　2年間、ずっとこれがやりたかったんだ！！")
        $ bond_up("三好", 3)
    else:
        $ talk_me("先輩、桐生先輩の家族に怒られますよ")
        $ talk("三好", "大丈夫だ！！　朝ごはんまで出してくれる！！")
        $ talk("三好", "……え、怒ってるのか、あれ？")
        $ bond_up("三好", 2)
        $ up("メンタル", 1)
    return

label nc_miyoshi_ch2b:
    $ talk_start("三好", "20:45")
    $ talk_me("合宿、おつかれさまでした")
    $ talk("三好", "おう！！　合宿の写真、待ち受けにしたぞ！！")
    $ talk_system("三好が写真を送信しました")
    $ talk("三好", "大門がまばたきしてるけど、それもいい！！")
    $ _r = talk_choose([("いい写真ですね", "a"), ("俺だけ半目なんですけど", "b")])
    if _r == "a":
        $ talk_me("いい写真ですね")
        $ talk("三好", "だろ！！　卒業アルバムにも入れてもらう！！")
        $ bond_up("三好", 3)
    else:
        $ talk_me("俺だけ半目なんですけど")
        $ talk("三好", "ほんとだ！！！　あははは！！！")
        $ talk("三好", "……でもこれ、夏の顔だな。いい顔だ")
        $ bond_up("三好", 2)
        $ up("メンタル", 1)
    return

label nc_miyoshi_ch3a:
    $ talk_start("三好", "22:10")
    $ talk_me("組み合わせ、見ました")
    $ talk("三好", "蓮。選手権、俺の最後の大会だ")
    $ talk("三好", "……って、毎日言うのやめたほうがいいか？　坂口に「重い」って言われた")
    $ _r = talk_choose([("毎日言ってください", "a"), ("最後にしなければいいんです", "b")])
    if _r == "a":
        $ talk_me("毎日言ってください")
        $ talk("三好", "……おう。じゃあ、毎日言う")
        $ talk("三好", "お前が来てくれて、ほんとによかった")
        $ bond_up("三好", 3)
    else:
        $ talk_me("最後にしなければいいんです。勝てば、まだ続きます")
        $ talk("三好", "……それだ！！！")
        $ talk("三好", "やっぱりお前は、キャプテンより先のことを考えてるな！！")
        $ bond_up("三好", 2)
        $ lean("野心型")
    return

label nc_miyoshi_nov:
    $ talk_start("三好", "21:44")
    $ talk_me("先輩、明日も朝練7時ですか")
    $ talk("三好", "7時だ！！　……ちょうどいい。ひざ、どうだ")
    if ch2_night == "knee" or flags.get("ch2_knee_told"):
        $ talk("三好", "合宿で、止めてくれって言ったのは、お前だからな。……俺、ちゃんと見てるぞ")
    else:
        $ talk("三好", "最近、ずっと右をかばってるだろ。……俺、ちゃんと見てるぞ")
    $ _r = talk_choose([("正直、少し痛いです", "a"), ("大丈夫です。桜嶺まで、もちます", "b")])
    if _r == "a":
        $ talk_me("正直、少し痛いです")
        $ talk("三好", "言ってくれてありがとな。明日は、俺がお前の分まで走る")
        $ bond_up("三好", 3)
        $ up("無理ゲージ", -2)
    else:
        $ talk_me("大丈夫です。桜嶺まで、もちます")
        $ talk("三好", "……おう。信じる")
        $ talk("三好", "でも、走れなくなったら、絶対に言えよ。キャプテン命令だ")
        $ bond_up("三好", 2)
        $ up("メンタル", 1)
    return

label nc_miyoshi_dec:
    $ talk_start("三好", "20:58")
    $ talk_me("先輩、冬休みはどうするんですか")
    $ talk("三好", "引退しても、朝練は行くからな！！　OBとして！！")
    $ talk("三好", "……親父の工務店、春から手伝うんだ。だから、行けるのは冬のあいだだけだ")
    $ _r = talk_choose([("毎朝、待ってます", "a"), ("先輩のぶんまで、勝ちます", "b")])
    if _r == "a":
        $ talk_me("毎朝、待ってます")
        $ talk("三好", "おう！！　7時な！！　……泣いてないぞ、俺は")
        $ bond_up("三好", 3)
    else:
        $ talk_me("先輩のぶんまで、勝ちます")
        if flags.get("ch3_armband") == "takano":
            $ talk("三好", "……おう。鷹野のこと、頼んだぞ。あいつ、キャプテンのくせに口が悪いからな")
        else:
            $ talk("三好", "……おう。頼んだ、キャプテン")
        $ bond_up("三好", 2)
        $ lean("仲間型")
    return


## ===========================================================================
## 大門（時期ごと。仲間になってから）
## ===========================================================================
label nc_daimon_ch1:
    $ talk_start("大門", "21:25")
    $ talk_me("大門、柔道部のほうは、大丈夫だったか")
    $ talk("大門", "あ、あの、はい。トーク、返し方これで合ってますか")
    $ talk("大門", "柔道部の先輩たちに、サッカー部に入るって言いました。……怒られませんでした")
    $ _r = talk_choose([("よかった。明日から、よろしくな", "a"), ("ゴールの前、任せた", "b")])
    if _r == "a":
        $ talk_me("よかった。明日から、よろしくな")
        $ talk("大門", "は、はい！　よろしくお願いします！")
        $ bond_up("大門", 3)
    else:
        $ talk_me("ゴールの前、任せた")
        $ talk("大門", "ま、任されます……！　たぶん……！")
        $ bond_up("大門", 2)
        $ up("メンタル", 1)
    return

label nc_daimon_ch2a:
    $ talk_start("大門", "22:00")
    $ talk_me("今日のキーパー練、どうだった")
    if night_month == "jul":
        $ talk("大門", "あの……1回戦のPK、ほんとは、目をつぶってたんです")
        $ talk("大門", "止まったのは、たまたまです。次は、怖くて、またつぶってしまいそうで")
    else:
        $ talk("大門", "あの……PKって、目をつぶったら、だめですか")
        $ talk("大門", "怖くて、つい、つぶってしまうんです")
    $ _r = talk_choose([("つぶってもいい。でも、最後まで動くな", "a"), ("明日、目を開ける練習を付き合う", "b")])
    if _r == "a":
        $ talk_me("つぶってもいい。でも、最後まで動くな")
        $ talk("大門", "さ、最後まで、動かない……！　メモしました")
        $ bond_up("大門", 2)
        $ up("戦術眼", 1)
    else:
        $ talk_me("明日、目を開ける練習を付き合う")
        $ talk("大門", "……ありがとうございます。早瀬くんのボールなら、開けていられる気がします")
        $ bond_up("大門", 3)
    return

label nc_daimon_ch2b:
    $ talk_start("大門", "21:10")
    $ talk_me("夏休み、何してる")
    $ talk("大門", "夏休みの宿題、全部終わりました")
    $ talk("大門", "……やることがなくて、柔道場で受け身をしてました")
    $ _r = talk_choose([("今度、一緒に宿題やらせて", "a"), ("その受け身、キーパーに使える", "b")])
    if _r == "a":
        $ talk_me("今度、一緒に宿題やらせて。俺、半分も終わってない")
        $ talk("大門", "は、はい！　図書館、毎朝開いてます！")
        $ bond_up("大門", 3)
    else:
        $ talk_me("その受け身、キーパーに使える。横に飛んだあと、すぐ立てる")
        $ talk("大門", "……そうか。転ぶのは、得意です")
        $ bond_up("大門", 2)
        $ up("フィジカル", 1)
    return

label nc_daimon_ch3a:
    $ talk_start("大門", "22:20")
    $ talk_me("選手権の会場、観客席があるらしいな")
    $ talk("大門", "そ、そうなんです。……さっき、聞きました")
    $ talk("大門", "人に見られると、手が震えるんです……")
    $ _r = talk_choose([("震えたまま止めればいい", "a"), ("観客じゃなくて、俺の背中を見てろ", "b")])
    if _r == "a":
        $ talk_me("震えたまま止めればいい。インターハイのPKも、震えてただろ")
        $ talk("大門", "……そうでした。震えてたのに、止まりました")
        $ bond_up("大門", 2)
        $ up("メンタル", 1)
    else:
        $ talk_me("観客じゃなくて、俺の背中を見てろ")
        $ talk("大門", "は、はい。……早瀬くんの背中、大きくないので、見やすいです")
        $ talk("大門", "あっ、悪い意味じゃないです！")
        $ bond_up("大門", 3)
    return

label nc_daimon_nov:
    $ talk_start("大門", "21:35")
    $ talk_me("まだ動画見てるのか")
    $ talk("大門", "見てます。神城くんのシュート、動画で100回見ました")
    $ talk("大門", "……100回とも、止められませんでした。動画なのに")
    $ _r = talk_choose([("101回目に止めればいい", "a"), ("一人で止めなくていい。前で俺たちが削る", "b")])
    if _r == "a":
        $ talk_me("101回目に止めればいい")
        $ talk("大門", "……101回目。それが、試合の日ですね")
        $ bond_up("大門", 2)
        $ up("メンタル", 1)
    else:
        $ talk_me("一人で止めなくていい。前で俺たちが削る")
        $ talk("大門", "……はい。うしろで、待ってます")
        $ bond_up("大門", 3)
    return

label nc_daimon_dec:
    $ talk_start("大門", "21:05")
    $ talk_me("今日の練習、どうだった")
    if ch3_fight in ("undecided", "maybe"):
        $ talk("大門", "あの……桜嶺のこと、坂口くんたちと話しました")
        $ talk("大門", "どっちに決めても、僕は、早瀬くんのボールを止める練習を続けます")
    else:
        $ talk("大門", "あの……三好先輩がいなくなった練習、まだ慣れません")
        $ talk("大門", "声が、一人ぶん足りないんです")
    $ _r = talk_choose([("ありがとう、大門", "a"), ("来年は、大門が声を出せ", "b")])
    if _r == "a":
        $ talk_me("ありがとう、大門")
        $ talk("大門", "……こちらこそ、です")
        $ bond_up("大門", 3)
    else:
        $ talk_me("来年は、大門が声を出せ。キーパーは、いちばんうしろから全部見えるだろ")
        $ talk("大門", "ぼ、僕がですか……！？　……練習、します")
        $ bond_up("大門", 2)
        $ up("メンタル", 1)
    return


## ===========================================================================
## 鷹野（時期ごと。仲間になってから）
## ===========================================================================
label nc_takano_ch1:
    $ talk_start("鷹野", "23:10")
    $ talk_me("明日の練習、来るよな")
    $ talk_system("既読")
    $ talk("鷹野", "……行く")
    $ talk("鷹野", "お前のパス、遅えから、明日は速いの出せ")
    $ _r = talk_choose([("お前が走れば、速いの出す", "a"), ("分かった。明日、合わせよう", "b")])
    if _r == "a":
        $ talk_me("お前が走れば、速いの出す")
        $ talk("鷹野", "……言ったな")
        $ bond_up("鷹野", 2)
        $ up("技術", 1)
    else:
        $ talk_me("分かった。明日、合わせよう")
        $ talk("鷹野", "……おう")
        $ bond_up("鷹野", 3)
    return

label nc_takano_ch2a:
    $ talk_start("鷹野", "22:48")
    $ talk_me("今、何してる")
    $ talk_system("既読")
    ## 「また」は、6月の屋上で一緒に動画を見たときだけ
    if flags.get("ch2_takano"):
        $ talk("鷹野", "黒田の動画、また見てた")
    else:
        $ talk("鷹野", "動画。黒田の、現役のころの")
    $ talk("鷹野", "左足のボレー。……あれ、どうやって当ててんだ")
    $ _r = talk_choose([("明日、黒田先生に聞きに行こう", "a"), ("見るより、蹴ったほうが早い", "b")])
    if _r == "a":
        $ talk_me("明日、黒田先生に聞きに行こう")
        $ talk("鷹野", "……お前が聞け。俺は横で見てる")
        $ bond_up("鷹野", 3)
    else:
        $ talk_me("見るより、蹴ったほうが早い。明日、100本付き合う")
        $ talk("鷹野", "……100本で足りるかよ")
        $ bond_up("鷹野", 2)
        $ up("技術", 1)
    return

label nc_takano_ch2b:
    $ talk_start("鷹野", "23:30")
    $ talk_me("暑くて寝れない")
    $ talk("鷹野", "こっちもだ。暑くて寝れねえ")
    $ talk("鷹野", "……夜のグラウンド、照明つけてもいいか、三好先輩に聞いといて")
    $ _r = talk_choose([("俺も行く", "a"), ("夜は寝ろ。ひざに悪い", "b")])
    if _r == "a":
        $ talk_me("俺も行く")
        $ talk("鷹野", "……勝手にしろ")
        $ talk("鷹野", "ボール、二個持ってこい")
        $ bond_up("鷹野", 3)
        $ up("無理ゲージ", 2)
    else:
        $ talk_me("夜は寝ろ。俺もお前も、ひざに悪い")
        $ talk("鷹野", "俺のひざは悪くねえ")
        $ talk("鷹野", "……でも、お前のは悪いな。寝ろ")
        $ bond_up("鷹野", 2)
        $ up("無理ゲージ", -2)
    return

label nc_takano_ch3a:
    $ talk_start("鷹野", "22:55")
    $ talk_me("組み合わせ、見たか。桜嶺と当たるとしたら、準決勝だ")
    if flags.get("真壁"):
        $ talk("鷹野", "見た。……真壁のやつ、今日もAで点取ってた")
    else:
        $ talk("鷹野", "見た。……桜嶺の14番、知ってるか。ジュニアユースで一緒だったやつ。この秋、Aに上がった")
    $ talk("鷹野", "……別に、気にしてねえけど")
    $ _r = talk_choose([("準決勝で、お前が取り返せ", "a"), ("気にしていい。俺も神城を気にしてる", "b")])
    if _r == "a":
        $ talk_me("準決勝で、お前が取り返せ")
        $ talk("鷹野", "……当たり前だ")
        $ bond_up("鷹野", 2)
        $ lean("野心型")
    else:
        $ talk_me("気にしていい。俺も、神城をずっと気にしてる")
        $ talk_system("既読がついてから、6分")
        $ talk("鷹野", "……そうかよ")
        $ talk("鷹野", "じゃあ、二人とも気にしてりゃいい")
        $ bond_up("鷹野", 3)
    return

label nc_takano_nov:
    $ talk_start("鷹野", "23:20")
    $ talk_me("明日、何時に行く")
    $ talk_system("既読がついてから、4分")
    $ talk("鷹野", "いつもどおり。……それより、ひざ")
    $ talk("鷹野", "……それだけ聞いた。答えなくていい")
    $ _r = talk_choose([("痛い。でも、出る", "a"), ("お前に心配されるほどじゃない", "b")])
    if _r == "a":
        $ talk_me("痛い。でも、出る")
        $ talk("鷹野", "……なら、俺が前で全部取る。お前は真ん中にいろ")
        $ bond_up("鷹野", 3)
    else:
        $ talk_me("お前に心配されるほどじゃない")
        $ talk("鷹野", "心配してねえ。……試合で歩かれたら困るだけだ")
        $ bond_up("鷹野", 2)
        $ up("メンタル", 1)
    return

label nc_takano_dec:
    $ talk_start("鷹野", "23:40")
    if ch3_fight in ("undecided", "maybe"):
        $ talk_me("この前は、悪かった")
        $ talk_system("既読がついてから、12分")
        $ talk("鷹野", "……用件は")
        $ _r = talk_choose([("冬休みも、グラウンドに行く", "a"), ("それだけ言いたかった", "b")])
        if _r == "a":
            $ talk_me("冬休みも、グラウンドに行く。お前に出す")
            $ talk("鷹野", "……勝手にしろ")
            $ bond_up("鷹野", 4)
        else:
            $ talk_me("それだけ言いたかった")
            $ talk("鷹野", "……知ってる")
            $ bond_up("鷹野", 3)
    else:
        $ talk_me("冬休みの練習、どうする")
        $ talk("鷹野", "……グラウンドの鍵、どうすんだ")
        $ talk("鷹野", "三好先輩がいねえと、誰が開けんのか分かんねえ")
        if flags.get("ch3_armband") == "takano":
            $ _r = talk_choose([("俺が開ける。お前はキャプテンらしく、最後に来い", "a"), ("キャプテンが開けろよ", "b")])
            if _r == "a":
                $ talk_me("俺が開ける。お前はキャプテンらしく、最後に来い")
                $ talk("鷹野", "……ふざけんな。一番に来るのは俺だ")
                $ bond_up("鷹野", 3)
            else:
                $ talk_me("キャプテンが開けろよ")
                $ talk("鷹野", "……めんどくせえ。押しつけやがって")
                $ talk("鷹野", "鍵、明日取りに行く")
                $ bond_up("鷹野", 2)
                $ lean("仲間型")
        else:
            $ _r = talk_choose([("俺が開ける", "a"), ("一番に来たやつが開けよう", "b")])
            if _r == "a":
                $ talk_me("俺が開ける。キャプテンだし")
                $ talk("鷹野", "……なら、俺は二番目に来る")
                $ bond_up("鷹野", 3)
            else:
                $ talk_me("一番に来たやつが開けよう")
                $ talk("鷹野", "……めんどくせえ。でも、一番に来るのは俺だ")
                $ bond_up("鷹野", 2)
                $ lean("仲間型")
    return

## ---------------------------------------------------------------------------
## 5月の後半（練習試合の前）
## ---------------------------------------------------------------------------
label nc_hinata_may2:
    $ talk_start("ひなた", "21:47")
    $ talk_me("日曜、雨っぽい")
    $ talk("ひなた", "知ってる。天気予報、10回見た")
    $ talk("ひなた", "てるてる坊主、3つ作った")
    $ _r = talk_choose([("雨でもやる。晴れなくていい", "a"), ("てるてる坊主、写真送って", "b")])
    if _r == "a":
        $ talk_me("雨でもやる。晴れなくていい")
        $ talk("ひなた", "……うん。そう言うと思った")
        $ talk("ひなた", "じゃあ、タオル11枚持ってく")
        $ heart_up("ひなた", "信頼", 3)
    else:
        $ talk_me("てるてる坊主、写真送って")
        $ talk("ひなた", "やだ。顔、蓮に似せたから")
        $ talk("ひなた", "……1つだけね")
        $ talk_system("ひなたが写真を送信しました")
        $ talk("ひなた", "眉毛、上がってるでしょ")
        $ heart_up("ひなた", "ときめき", 3)
    $ talk("ひなた", "おやすみ。ひざ、冷やして寝てね")
    return


## ---------------------------------------------------------------------------
## 7月（夏合宿の前）
## ---------------------------------------------------------------------------
label nc_hinata_jul:
    $ talk_start("ひなた", "22:05")
    $ talk_me("合宿の持ち物、なにがいる？")
    $ talk("ひなた", "リスト作ったよ。部のグループに貼っとく")
    $ talk("ひなた", "あと、蓮は枕。自分のじゃないと寝れないでしょ")
    $ _r = talk_choose([("ひなたがいて助かる", "a"), ("なんで知ってるんだよ", "b")])
    if _r == "a":
        $ talk_me("ひなたがいて助かる")
        $ talk("ひなた", "でしょ。マネージャーだもん")
        $ talk("ひなた", "……もっと言っていいよ")
        $ heart_up("ひなた", "信頼", 3)
    else:
        $ talk_me("なんで知ってるんだよ")
        $ talk("ひなた", "小3の林間学校。夜中に泣いてた")
        $ talk("ひなた", "わたし、となりの布団だったもん")
        $ heart_up("ひなた", "ときめき", 3)
    return

label nc_chika_jul:
    $ talk_start("千夏", "21:30")
    $ talk_me("夏合宿の体育館の件、どうなりましたか")
    $ talk_system("既読")
    $ talk("千夏", "使用許可は、今日の夕方に下りました")
    $ talk("千夏", "消灯は22時です。守ってください")
    $ _r = talk_choose([("ありがとうございます。助かりました", "a"), ("先輩も来ますか", "b")])
    if _r == "a":
        $ talk_me("ありがとうございます。助かりました")
        $ talk("千夏", "仕事ですから")
        $ talk("千夏", "……体育館の鍵は、三好先輩に預けません。早瀬くんに預けます")
        $ heart_up("千夏", "信頼", 3)
    else:
        $ talk_me("先輩も来ますか")
        $ talk_system("既読がついてから、3分")
        $ talk("千夏", "生徒会長は、部活動の合宿に参加しません")
        $ talk("千夏", "……差し入れは、検討します")
        $ heart_up("千夏", "ときめき", 3)
    return


## ---------------------------------------------------------------------------
## 8月（夏祭りの前）
## ---------------------------------------------------------------------------
label nc_hinata_aug:
    $ talk_start("ひなた", "21:12")
    $ talk_me("暑くて寝れない")
    $ talk("ひなた", "わかる。こっちも扇風機の前から動けない")
    $ talk("ひなた", "ねえ、浴衣って、ひまわりのと紺のと、どっちがいいと思う？")
    $ _r = talk_choose([("ひまわり", "a"), ("どっちでも似合う", "b")])
    if _r == "a":
        $ talk_me("ひまわり")
        $ talk("ひなた", "即答じゃん")
        $ talk("ひなた", "……じゃあ、ひまわりにする")
        $ heart_up("ひなた", "ときめき", 3)
    else:
        $ talk_me("どっちでも似合う")
        $ talk("ひなた", "それ、いちばん困るやつ")
        $ talk("ひなた", "でも、ちょっとうれしいから許す")
        $ heart_up("ひなた", "信頼", 3)
    return

label nc_chika_aug:
    $ talk_start("千夏", "20:48")
    if flags.get("千夏_差し入れ_ドリンク"):
        $ talk_me("合宿の差し入れ、ありがとうございました。凍ったスポーツドリンク")
        $ talk("千夏", "あれは、生徒会の備品の余りです。差し入れではありません")
        $ talk("千夏", "……11本では、足りませんでしたか")
    else:
        $ talk_me("合宿の差し入れ、ありがとうございました。塩あめ、まだ残ってます")
        $ talk("千夏", "あれは、生徒会の備品の余りです。差し入れではありません")
        $ talk("千夏", "……塩あめは、熱中症の予防です。残さず食べてください")
    $ _r = talk_choose([("足りました。三好先輩がいちばん喜んでました", "a"), ("先輩が持ってきてくれたのが、うれしかったです", "b")])
    if _r == "a":
        $ talk_me("足りました。三好先輩がいちばん喜んでました")
        $ talk("千夏", "三好先輩は、備品の規則を読むべきです")
        $ talk("千夏", "……次も、余りが出れば、持っていきます")
        $ heart_up("千夏", "信頼", 3)
    else:
        $ talk_me("先輩が持ってきてくれたのが、うれしかったです")
        $ talk_system("既読がついてから、5分")
        $ talk("千夏", "備品の、余りです")
        $ talk("千夏", "……そういうことを書くときは、先に言ってください。心の準備がいります")
        $ heart_up("千夏", "ときめき", 3)
    return


## ---------------------------------------------------------------------------
## 10月（準々決勝の前）
## ---------------------------------------------------------------------------
label nc_hinata_oct:
    $ talk_start("ひなた", "22:20")
    $ talk_me("準々決勝まで、あと少しだな")
    $ talk("ひなた", "うん。……ひざ、今日どうだった？")
    $ _r = talk_choose([("大丈夫", "a"), ("……ちょっと痛い", "b")])
    if _r == "a":
        $ talk_me("大丈夫")
        $ talk("ひなた", "ほんとに？　……トークだと眉毛が見えないの、ずるい")
        $ talk("ひなた", "明日、顔見て確かめるから")
        $ heart_up("ひなた", "さみしさ", 1)
    else:
        $ talk_me("……ちょっと痛い")
        $ talk("ひなた", "言ってくれた")
        $ talk("ひなた", "明日の朝、湿布持ってく。玄関で待ってて")
        $ heart_up("ひなた", "信頼", 4)
        $ up("無理ゲージ", -2)
    return

label nc_chika_oct:
    $ talk_start("千夏", "21:05")
    $ talk_me("準々決勝の会場、駅から遠いですね")
    $ talk("千夏", "バスで12分、徒歩で31分です。調べました")
    $ talk("千夏", "生徒会で、応援の生徒の集合時間を決めています")
    $ _r = talk_choose([("応援、来てくれるんですか", "a"), ("いつも、ありがとうございます", "b")])
    if _r == "a":
        $ talk_me("応援、来てくれるんですか")
        $ talk("千夏", "生徒会は、当日は学校で、ほかの部の試合の連絡を受ける係です")
        $ talk("千夏", "……結果は、いちばん先に、わたしに送ってください")
        $ heart_up("千夏", "ときめき", 3)
    else:
        $ talk_me("いつも、ありがとうございます")
        $ talk("千夏", "お礼は、勝ってからにしてください")
        $ heart_up("千夏", "信頼", 3)
    return


## ---------------------------------------------------------------------------
## 12月（冬休みの前）
## ---------------------------------------------------------------------------
label nc_hinata_dec:
    $ talk_start("ひなた", "21:58")
    $ talk_me("期末、どうだった")
    $ talk("ひなた", "数学以外は、勝った")
    $ talk("ひなた", "蓮は？")
    $ _r = talk_choose([("全部、負けた", "a"), ("今度、勉強教えて", "b")])
    if _r == "a":
        $ talk_me("全部、負けた")
        $ talk("ひなた", "あっはは。正直でよろしい")
        $ talk("ひなた", "冬休み、毎日お店で宿題見てあげる")
        $ heart_up("ひなた", "信頼", 3)
    else:
        $ talk_me("今度、勉強教えて")
        $ talk("ひなた", "……いいけど。お店じゃなくて、蓮の部屋ね")
        $ talk("ひなた", "べ、べつに深い意味はないから")
        $ heart_up("ひなた", "ときめき", 3)
    return

label nc_chika_dec:
    $ talk_start("千夏", "20:31")
    $ talk_me("生徒会室、まだ電気ついてましたね")
    $ talk("千夏", "署名の数を数えていました")
    $ talk("千夏", "……見ていたんですか")
    $ _r = talk_choose([("早く帰ってください。寒いので", "a"), ("手伝いに行けばよかった", "b")])
    if _r == "a":
        $ talk_me("早く帰ってください。寒いので")
        $ talk("千夏", "電気ストーブがあります")
        $ talk("千夏", "……でも、今日はもう帰ります。言われたので")
        $ heart_up("千夏", "ときめき", 3)
    else:
        $ talk_me("手伝いに行けばよかった")
        $ talk("千夏", "次は、お願いします。数えるのは、一人だと遅いので")
        $ heart_up("千夏", "信頼", 3)
    return
