## effects.rpy ―― 試合シーンなどの演出
##   ・カメラの動き（寄る・流す・揺らす）
##   ・映画のような黒帯
##   ・スコアボード（時計が1秒ずつ進む）
##   ・集中線
##   ・カットイン（名前の帯）
##   ・スローモーション（色が抜けて、ゆっくり寄る）

################################################################################
## カメラの動き（一枚絵や背景に at で付ける）
################################################################################

## ゆっくり寄っていく
transform cam_push(t=10.0, z=1.08):
    subpixel True
    align (0.5, 0.5)
    zoom 1.0
    linear t zoom z

## 決めた場所（顔など）に向かって、ゆっくり寄る。x, y は 0.0〜1.0（左上が 0, 0）
transform cam_push_at(t=10.0, z=1.08, x=0.5, y=0.5):
    subpixel True
    align (x, y)
    zoom 1.0
    linear t zoom z

## 寄った状態から、ゆっくり引く
transform cam_pull(t=8.0, z=1.12):
    subpixel True
    align (0.5, 0.5)
    zoom z
    easeout t zoom 1.0

## 左から右へゆっくり流す（少し拡大して、はみ出した分を動かす）
transform cam_pan_r(t=10.0):
    subpixel True
    zoom 1.1
    yalign 0.5
    xalign 0.0
    linear t xalign 1.0

## 下から上へ見上げていく
transform cam_tilt_up(t=6.0):
    subpixel True
    zoom 1.15
    xalign 0.5
    yalign 1.0
    easein t yalign 0.0

## ぐっと寄る（一瞬で）
transform cam_snap(z=1.25, x=0.5, y=0.5):
    subpixel True
    align (x, y)
    zoom 1.0
    easeout 0.18 zoom z

## 小さく揺れ続ける（走っている、息が上がっている）
transform cam_jog:
    subpixel True
    align (0.5, 0.5)
    zoom 1.04
    block:
        ease 0.22 yoffset -5
        ease 0.22 yoffset 3
        repeat

## スローモーション：色が抜けて、ゆっくり寄る
transform slowmo(t=4.0):
    subpixel True
    align (0.5, 0.5)
    matrixcolor SaturationMatrix(1.0)
    zoom 1.0
    linear 0.6 matrixcolor SaturationMatrix(0.15)
    linear t zoom 1.1

## 一瞬だけ赤く
transform red_hit:
    matrixcolor TintMatrix("#ffffff")
    linear 0.05 matrixcolor TintMatrix("#ff7060")
    linear 0.5 matrixcolor TintMatrix("#ffffff")

## 強い揺れ（ぶつかった瞬間）
define hard_punch = Move((0, 14), (0, -14), .06, bounce=True, repeat=True, delay=.42)

################################################################################
## 黒帯（映画のような上下の黒い帯）
################################################################################

screen letterbox():
    zorder -10      # セリフ枠より下に出す
    add Solid("#000") xysize (1280, 64) at lb_top
    add Solid("#000") xysize (1280, 64) at lb_bottom

transform lb_top:
    ypos -64
    on show:
        easein 0.5 ypos 0
    on hide:
        easeout 0.5 ypos -64

transform lb_bottom:
    ypos 720
    on show:
        easein 0.5 ypos 656
    on hide:
        easeout 0.5 ypos 720

################################################################################
## スコアボード（画面の上の真ん中。時計は本当に1秒ずつ進む）
##   出す前に $ sb_set(...) で前半／後半、時間、点数、チームの色を決める。
##   例：$ sb_set("後半", 40, 12, 0, 1, "#7fc4e8", "#f2f2ee")
##       show screen scoreboard
##   試合の途中で点数や時間を変えるときも、$ sb_set(...) だけでよい（表示はそのまま変わる）
################################################################################

default sb_half = "前半"
default sb_sec = 0
default sb_home = 0
default sb_away = 0
default sb_home_color = "#7fc4e8"
default sb_away_color = "#f2f2ee"

init python:
    def sb_set(half=None, mm=None, ss=0, home=None, away=None, home_color=None, away_color=None):
        if half is not None:
            store.sb_half = half
        if mm is not None:
            store.sb_sec = mm * 60 + ss
        if home is not None:
            store.sb_home = home
        if away is not None:
            store.sb_away = away
        if home_color is not None:
            store.sb_home_color = home_color
        if away_color is not None:
            store.sb_away_color = away_color

screen scoreboard():
    zorder 45
    timer 1.0 repeat True action SetVariable("sb_sec", sb_sec + 1)
    fixed at sb_in:
        xysize (300, 92)
        xalign 0.5
        ypos 10
        add "gui/fx_scoreboard.png"
        text "[sb_half]  {:02d}:{:02d}".format(sb_sec // 60, sb_sec % 60) style "sb_time"
        hbox:
            xalign 0.5
            ypos 44
            spacing 18
            add Solid(sb_home_color) xysize (22, 22) yalign 0.5
            text "[sb_home] - [sb_away]" style "sb_score"
            add Solid(sb_away_color) xysize (22, 22) yalign 0.5

transform sb_in:
    on show:
        alpha 0.0 yoffset -20
        easein 0.4 alpha 1.0 yoffset 0
    on hide:
        easeout 0.4 alpha 0.0 yoffset -20

################################################################################
## 集中線（2枚を交互に出して、ちらつかせる）
################################################################################

image fx_speed:
    "gui/fx_speed_a.png"
    pause 0.08
    "gui/fx_speed_b.png"
    pause 0.08
    repeat

screen speedlines():
    zorder -5       # セリフ枠より下に出す（文字が読みにくくならないように）
    add "fx_speed" at speed_in

transform speed_in:
    on show:
        alpha 0.0 zoom 1.15 align (0.5, 0.5)
        easein 0.2 alpha 0.85 zoom 1.0
    on hide:
        easeout 0.3 alpha 0.0

################################################################################
## カットイン（斜めの帯に名前）
##   例：show screen cutin("神城 凌", "U-15 日本代表")
################################################################################

screen cutin(name, sub=""):
    zorder 46
    on "show" action Function(telop_sound)      # テロップが出たときの小さな音
    fixed at cutin_band:
        xysize (1500, 150)
        add "gui/fx_cutin.png"
        hbox:
            xpos 420
            yalign 0.5
            spacing 26
            text name style "cutin_name"
            if sub:
                text sub style "cutin_sub"

transform cutin_band:
    rotate -6
    rotate_pad False
    xpos 1280 ypos 345
    on show:
        easein 0.25 xpos -110
        linear 3.0 xpos -150
    on hide:
        easeout 0.25 xpos -1600

################################################################################
## 画面の真ん中に出す独白（黒い画面の上などで使う）
################################################################################

define mono = Character(None, what_style="mono_text", window_background=None,
                        window_yalign=0.5, window_xalign=0.5, ctc="ctc_blink", ctc_position="nestled",
                        callback=telop_cb)


################################################################################
## 文字のスタイル
##   フォントや色（FONT_JP_B・INK など）は screens.rpy で決めている。
##   ファイルは名前順に読み込まれ、このファイルは screens.rpy より先に読まれるので、
##   init 1 にして screens.rpy のあとで作る。
################################################################################

init 1:
    style sb_time:
        xalign 0.5
        ypos 9
        font FONT_JP_B
        size 22
        color "#f2c84b"

    style sb_score:
        yalign 0.5
        font FONT_JP_B
        size 30
        color "#ffffff"

    style cutin_rt:
        font FONT_JP_B
        size 18
        color PEN_RED
        yoffset -50

    style cutin_name:
        yalign 0.5
        font FONT_JP_B
        size 54
        color INK
        ruby_style style.cutin_rt
        line_leading 18

    style cutin_sub:
        yalign 0.5
        yoffset 6
        size 24
        color PEN_RED

    style mono_text:
        font FONT_JP_B
        size 34
        color "#f4f1e8"
        xalign 0.5
        text_align 0.5
        outlines [(2, "#00000080", 0, 0)]
        ruby_line_leading 14
        ruby_style style.ruby_text
