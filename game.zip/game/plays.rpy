## plays.rpy ―― 覚えたプレー（v0.35.1）
##   テスターの声（11/6 T3）「試合の中で、主人公が成長する部分が見えると、より愛着がわく」
##   試合の中で、蓮が相手や仲間から一つ気づくと「覚えたプレー」になる（右上に出る・サッカーノートのいちばん上に残る）。
##   覚えたプレーは、そのあとの試合の選択肢に、新しく出る。使えたら、ノートに「使えた」が増える。
##   体験版：首振り（5/31 桜嶺B）→ 6月の1回戦で使える／軸足を見る（1回戦のPKで「左だ！」が当たったとき）→ 準決勝の最後で使える／
##           背負う（7/4 西海学院）→ 準決勝の前半で使える

default plays_learned = []      # 覚えた順
default plays_used = {}         # id → 使えた回数

## (id, 名前, 中身, どこで覚えたか)
define PLAYS = [
    ("kubifuri", "首振り",
     "ボールをもらう前に、首を振って、まわりを見ておく。もらってから考えると、一歩遅れる。",
     "5月31日　桜嶺学園B（0−9）。桜嶺の10番は、ボールが来る前に、必ず首を二回振っていた"),
    ("jikuashi", "軸足を見る",
     "蹴る人の、踏みこむほうの足（軸足）のつま先は、ボールの行く向きを向きやすい。キッカーの向きも、キーパーの重心も、足もとに出る。",
     "インターハイ予選1回戦のPK。大門に「左だ！」と言ったとき"),
    ("seoi", "背負う",
     "背中で相手を押さえて、ボールを体の向こうに置いたまま、前を向く。体の大きさより、体を入れる順番と角度。",
     "7月4日　インターハイ予選2回戦　西海学院。何度も背中で押さえられて、前を向かれた"),
]

init python:
    def play_name(pid):
        for k, name, body, where in PLAYS:
            if k == pid:
                return name
        return pid

    def learn_play(pid):
        """覚えたプレーを1つ増やす。初めてのときだけ、右上に出す"""
        if pid in store.plays_learned:
            return
        store.plays_learned = store.plays_learned + [pid]
        toast("覚えたプレー：「%s」" % play_name(pid))
        telop_sound()

    def play_known(pid):
        return pid in store.plays_learned

    def play_use(pid):
        """覚えたプレーが、試合で使えた"""
        store.plays_used = dict(store.plays_used)
        store.plays_used[pid] = store.plays_used.get(pid, 0) + 1
        toast("覚えたプレーが使えた：「%s」" % play_name(pid))
        telop_sound()
