## testplay.rpy ―― テストプレイのための道具
##   ・章ごとのプレイ時間を記録する（章のラベルに来た時の「遊んだ時間」を覚えておき、差を出す）
##   ・体験版の最後に「遊んだ時間」と「アンケートに答える」の画面を出す
##   ・アンケートの入力画面は、Web 版のページ（index.html）の側にある（tools/web_testgate.py で足す）。
##     ここからは、自動でつける情報（時間・進んだところ・好感度）を渡して開くだけ
##   ・遊んだ時間は renpy.get_game_runtime()（タイトル画面やメニューを開いている時間は入らない。
##     画面の前を離れていた時間は入る）

default play_marks = {}
default persistent.play_report = None

init python:
    import json as _tp_json

    PLAY_CHAPTERS = [("prologue", "プロローグ"), ("chapter1", "第1章"), ("chapter2", "第2章"), ("chapter3", "第3章")]
    PLAY_END = "trial_end"
    _PLAY_NAMES = [n for n, _ in PLAY_CHAPTERS] + [PLAY_END]

    def play_fmt(sec):
        m = int(sec // 60)
        if m < 1:
            return "1分未満"
        if m < 60:
            return "%d分" % m
        return "%d時間%d分" % (m // 60, m % 60)

    def play_times():
        """[(章の名前, 秒, 読み終わったか)]。とちゅうの章は、今までの時間"""
        m = store.play_marks
        now = renpy.get_game_runtime()
        out = []
        for i, (n, title) in enumerate(PLAY_CHAPTERS):
            if n not in m:
                continue
            end = m.get(_PLAY_NAMES[i + 1])
            done = end is not None
            if end is None:
                end = now
            out.append((title, max(0.0, end - m[n]), done))
        return out

    def play_save_report():
        times = play_times()
        reached = [n for n in _PLAY_NAMES if n in store.play_marks]
        persistent.play_report = {
            "reached": reached[-1] if reached else "",
            "times": [[t, int(s), d] for t, s, d in times],
            "heart": dict(store.heart),
            "belief": dict(store.belief),
            "version": config.version,
        }

    def play_mark(name, abnormal):
        if name not in _PLAY_NAMES:
            return
        if name == "prologue":
            store.play_marks = {}
        if name not in store.play_marks:
            store.play_marks[name] = renpy.get_game_runtime()
        play_save_report()

    ## とちゅうでやめた人がタイトル画面から答えるときのために、30秒ごとに今までの時間を覚えておく
    _play_last = [0.0]

    def play_tick(event, interact=True, **kwargs):
        if event != "begin" or not store.play_marks:
            return
        rt = renpy.get_game_runtime()
        if rt - _play_last[0] >= 30 or rt < _play_last[0]:
            _play_last[0] = rt
            play_save_report()

    config.label_callbacks.append(play_mark)
    config.all_character_callbacks.append(play_tick)

    ## アンケート（Web 版のときだけ）
    def survey_available():
        return bool(renpy.emscripten)

    def survey_sent():
        if not renpy.emscripten:
            return False
        try:
            import emscripten
            return emscripten.run_script_string("(function(){try{return localStorage.getItem('anire_survey_sent')||''}catch(e){return ''}})()") != ""
        except Exception:
            return False

    def survey_open(final=False):
        if not renpy.emscripten:
            return
        ## ゲームの中から開いたときは、今の時間で記録しなおす（タイトル画面からは、前に覚えた記録を使う）
        if store.play_marks:
            play_save_report()
        r = persistent.play_report or {}
        payload = {
            "final": bool(final),
            "reached": r.get("reached", ""),
            "times": r.get("times", []),
            "heart": r.get("heart", {}),
            "belief": r.get("belief", {}),
            "version": config.version,
        }
        import emscripten
        emscripten.run_script("window.anireSurvey && window.anireSurvey(%s)" % _tp_json.dumps(payload))


## 体験版の最後の画面：遊んだ時間と、アンケートへの案内
screen trial_result():
    modal True
    zorder 100

    add Solid("#000000")

    fixed:
        xysize (760, 560)
        xalign 0.5
        yalign 0.5
        add "gui/note_big.png" xysize (760, 560)
        vbox:
            xalign 0.5
            yalign 0.5
            xsize 620
            spacing 18
            text "遊んでくれてありがとう！" xalign 0.5 font FONT_JP_B size 34 color INK
            text "あなたが遊んだ時間" xalign 0.5 size 22 color INK_SOFT
            vbox:
                xalign 0.5
                spacing 6
                $ _tt = play_times()
                for _t, _s, _d in _tt:
                    hbox:
                        xsize 360
                        text _t size 26 color INK
                        text play_fmt(_s) size 26 color INK xalign 1.0
                if _tt:
                    hbox:
                        xsize 360
                        text "合計" size 26 font FONT_JP_B color INK
                        text play_fmt(sum(_s for _t, _s, _d in _tt)) size 26 font FONT_JP_B color INK xalign 1.0
            null height 6
            if survey_available():
                if survey_sent():
                    text "アンケートは送信ずみです。ありがとうございました！" xalign 0.5 size 22 color PEN_TEAL
                else:
                    text "よければ、感想を聞かせてください（3分くらい）" xalign 0.5 size 22 color INK
                hbox:
                    xalign 0.5
                    spacing 60
                    textbutton "アンケートに答える" action Function(survey_open, True) text_size 28 text_color PEN_RED text_hover_color INK
                    textbutton "タイトルへ" action Return() text_size 28
            else:
                hbox:
                    xalign 0.5
                    textbutton "タイトルへ" action Return() text_size 28


## Web 版（ブラウザ）：スマホのブラウザは、別の画面にしているあいだにページを消して、戻ったときに読み込み直すことがある。
##   そのときに続きから遊べるように、こまめにオートセーブして、タイトル画面に「前回のつづき」を出す
init python:
    if renpy.emscripten:
        config.autosave_frequency = 8       # 8回クリックごと（ふつうは200回）
        config.autosave_on_choice = True
        ## スマホのブラウザは、ページが使うメモリが多すぎると、ページを消して読み込み直す（タイトルに戻される）。
        ##   絵をためておく量を、ふつうの 400MB から 64MB に減らす（1280×720 の絵で15枚ほど）
        config.image_cache_size_mb = 64

    def last_autosave():
        try:
            return renpy.newest_slot(r"auto-")
        except Exception:
            return None
