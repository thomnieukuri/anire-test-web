## systems.rpy ―― ゲームの仕組み（能力値・絆・恋愛パラメータ・カレンダー・トーク画面・行動マップ・ステータス）

################################################################################
## 「1つ戻る」：読み返しはできるが、選んだ答えは変えられない
##   新しい場面が始まるたびに、それまでの場面を「固定」にする（Ren'Py の fixed rollback）。
##   選択肢の場面まで戻ると、選んだ答えだけが押せる。行動マップ・トークの返事も、前と同じ答えで進む。
##   別の答えを試したいときは、セーブ／ロードを使う。
################################################################################
define config.fix_rollback_without_choice = False     # 戻ったとき、選んだ答えだけは押せる（ほかは押せない）

init python:
    def _fix_past_choices():
        ## renpy.fix_rollback() と同じだが、毎回チェックポイントを増やさない
        ## （増やすと、「1つ戻る」が画面の切り替えのたびに止まってしまう）
        for rb in renpy.game.log.log:
            rb.fixed = True
    config.start_interact_callbacks.append(_fix_past_choices)

################################################################################
## パラメータ
################################################################################

define STAT_KEYS = ["技術", "フィジカル", "戦術眼", "メンタル"]
define HIDDEN_KEYS = ["無理ゲージ", "注目度"]
define BOND_KEYS = ["鷹野", "大門", "三好", "坂口", "神城"]   # 坂口は「坂口たち」（ゲーセンの5人組）
define HEROINES = ["ひなた", "千夏", "紗希"]
define HEART_KEYS = ["ときめき", "信頼", "さみしさ"]
define BELIEF_KEYS = ["仲間型", "野心型", "求道型"]

## 能力値（0〜100）
default stats = {"技術": 35, "フィジカル": 25, "戦術眼": 40, "メンタル": 30}

## 隠しパラメータ（0〜100）
default hidden = {"無理ゲージ": 15, "注目度": 5}

## 仲間・ライバルとの絆（0〜100）
default bond = {"鷹野": 0, "大門": 0, "三好": 0, "坂口": 0, "神城": 10}

## ヒロインごとの気持ち（ときめき→恋人ルート／信頼→親友ルート／さみしさ→会わないと溜まる）
default heart = {
    "ひなた": {"ときめき": 10, "信頼": 30, "さみしさ": 0},
    "千夏": {"ときめき": 0, "信頼": 0, "さみしさ": 0},
    "紗希": {"ときめき": 0, "信頼": 0, "さみしさ": 0},
}

## 信念タイプ（選択の傾向。エンディング判定に使う）
default belief = {"仲間型": 0, "野心型": 0, "求道型": 0}

## 物語のフラグ（例：flags["鷹野_わざと負け"] = True）
default flags = {}

init python:

    def _clamp(v):
        return max(0, min(100, v))

    def _signed(d):
        return ("＋" if d >= 0 else "−") + str(abs(d))

    def up(key, d):
        """能力値か隠しパラメータを増減する。例：$ up("メンタル", 5)"""
        if key in store.stats:
            store.stats[key] = _clamp(store.stats[key] + d)
        elif key in store.hidden:
            store.hidden[key] = _clamp(store.hidden[key] + d)
        else:
            raise Exception("知らないパラメータです: " + key)
        param_toast(key + " " + _signed(d))

    def bond_up(who, d):
        """仲間・ライバルとの絆を増減する。例：$ bond_up("鷹野", 5)"""
        ## 古いセーブには、あとから足した人（坂口）がいないので 0 から数える
        store.bond[who] = _clamp(store.bond.get(who, 0) + d)
        param_toast(("坂口たち" if who == "坂口" else who) + "の絆 " + _signed(d))

    def heart_up(who, kind, d):
        """ヒロインの気持ちを増減する。例：$ heart_up("ひなた", "信頼", 5)"""
        store.heart[who][kind] = _clamp(store.heart[who][kind] + d)
        param_toast(who + "の" + kind + " " + _signed(d))

    def lean(kind, d=1):
        """信念タイプの傾向を加算する。例：$ lean("仲間型")"""
        store.belief[kind] += d
        param_toast(kind + "の傾向 " + _signed(d))

    def set_flag(name, value=True):
        store.flags[name] = value

    def check_bond(who, need):
        """仲間との絆の判定。右上に「鷹野の絆 22／必要 20　成功」と出す"""
        v = store.bond.get(who, 0)
        ok = v >= need
        toast("%sの絆 %d／必要 %d　%s" % (who, v, need, "成功" if ok else "失敗"))
        telop_sound()
        return ok

    def check(key, need):
        """能力の判定。能力値が need 以上なら成功（True）。右上に「技術 47／必要 45　成功」と出す。
        例：if check("戦術眼", 50): …"""
        v = store.stats.get(key, store.hidden.get(key, 0))
        ok = v >= need
        toast("%s %d／必要 %d　%s" % (key, v, need, "成功" if ok else "失敗"))
        telop_sound()
        return ok


################################################################################
## 画面右上の小さな通知（能力値の変化・仮の演出メモ）
################################################################################

default toast_list = []

init python:

    def toast(msg):
        lst = list(store.toast_list) + [msg]
        store.toast_list = lst[-6:]
        ## 一度消してから出し直して、表示時間のカウントをやり直す
        renpy.hide_screen("toasts")
        renpy.show_screen("toasts")

    def clear_toasts():
        store.toast_list = []

    def param_toast(msg):
        if persistent.show_param_notify:
            toast(msg)
            telop_sound()

    ## BGM と効果音の bgm() / se() は audio.rpy にある

screen toasts():
    zorder 150
    vbox:
        xalign 1.0
        xoffset -12
        ypos 100    # 右上のメニューボタンの下に出す
        spacing 0
        for t in toast_list:
            frame:
                style "toast_frame"
                text t style "toast_text"
    timer 3.2 action [Function(clear_toasts), Hide("toasts")]

## 小さな付箋
style toast_frame:
    background Frame("gui/note_small.png", 14, 14)
    padding (22, 12, 26, 18)
    xalign 1.0

style toast_text:
    size 17
    color INK


################################################################################
## カレンダー表示（画面左上）
################################################################################

default cal_date = ""
default cal_time = ""

init python:

    def set_cal(date, time="", quiet=False):
        """日付の表示を変える。例：$ set_cal("4月14日（火）", "放課後")
          ・日付が変わったときは、画面のまん中に大きく出してから、左上に小さく残す
          ・同じ日のうちに時間だけ変わったときは、左上の小さい表示だけ変える
          ・quiet=True のときは何も出さない（真面目な場面・大事な場面は雰囲気を優先）"""
        changed = bool(date) and date != store.cal_date
        store.cal_date = date
        store.cal_time = time
        store.cal_quiet = quiet
        if changed and not quiet:
            ## 区切りとして、セリフ枠を消して、いったん画面を暗くしてから日付を出す
            _window_hide(None, auto=True)      # 「window auto hide」と同じ（自動でセリフ枠を出す設定は残す）
            renpy.scene()
            renpy.show("black")
            renpy.with_statement(Dissolve(0.4))
            store.cal_card = True
            renpy.show_screen("date_card", date, time)
            telop_sound()
            renpy.pause(2.0, hard=False)
            renpy.hide_screen("date_card")
            store.cal_card = False

default cal_quiet = False
default cal_card = False

## 日付が変わったとき：まん中に大きな付箋を貼って、少ししたらはがす
screen date_card(date, time=""):
    zorder 55
    fixed at date_card_in:
        xysize (560, 270)
        xalign 0.5
        yalign 0.42
        add "gui/note_calendar.png" zoom 2.06
        text date style "card_date"
        if time:
            text time style "card_time"

transform date_card_in:
    on show:
        alpha 0.0 rotate -6 zoom 1.08
        easeout 0.35 alpha 1.0 rotate -3 zoom 1.0
    on hide:
        easein 0.4 alpha 0.0 zoom 0.96

style card_date:
    xalign 0.5
    xoffset -6
    ypos 78
    font FONT_JP_B
    size 54
    color INK

style card_time:
    xalign 0.5
    xoffset -6
    ypos 164
    size 30
    color "#6e5a3c"

## ふだんは、画面の左上に小さく、うすく出しておく
screen calendar_hud():
    zorder 50
    if cal_date and not cal_quiet and not cal_card:
        frame at hud_fade:
            style "hud_tape"
            hbox:
                spacing 12
                text cal_date style "hud_date"
                if cal_time:
                    text cal_time style "hud_time"

style hud_tape is frame:
    xpos 14
    ypos 12
    background Frame("gui/banner_tape.png", 20, 10)
    padding (18, 4, 20, 7)

transform hud_fade:
    alpha 0.82

style hud_date:
    font FONT_JP_B
    size 19
    color INK
    yalign 0.5

style hud_time:
    size 17
    color "#6e5a3c"
    yalign 0.5


################################################################################
## 章タイトル（ノートの1ページに書く）
################################################################################

screen title_card(main, sub=""):
    zorder 60
    add "gui/page.png"
    vbox:
        xalign 0.5
        yalign 0.46
        spacing 22
        text main font FONT_JP_B size 54 xalign 0.5 color INK
        if sub:
            text sub size 32 xalign 0.5 color PEN_RED

define flash = Fade(0.08, 0.0, 0.6, color="#ffffff")


################################################################################
## トークアプリ（LINE風）
##   アプリ名は架空。製品版ではロゴ・色もオリジナルにする。
################################################################################

define TALK_APP_NAME = "TALQ"

## アイコン（gui/talk/avatar/ の画像名）。立ち絵がない人は、汎用のアイコンにする
define TALK_AVATAR = {
    "ひなた": "hinata", "千夏": "chika", "紗希": "saki", "三好": "miyoshi", "大門": "daimon",
    "鷹野": "takano", "坂口": "sakaguchi", "黒田": "kuroda", "母": "mother", "神城": "kamishiro",
    "桐生": "ball", "宮下": "pad",
}

default talk_title = ""
default talk_log = []
default talk_group = False
default talk_avatar = "gui/talk/avatar/flower.png"
default talk_date = ""
default talk_minutes = 0

init python:

    def talk_icon(name):
        """名前からアイコンの画像を決める（「神城 凌」のような書き方でも見つける）。"""
        for k, v in TALK_AVATAR.items():
            if name.startswith(k):
                return "gui/talk/avatar/%s.png" % v
        return "gui/talk/avatar/flower.png"

    def _talk_clock():
        m = store.talk_minutes
        return "%d:%02d" % ((m // 60) % 24, m % 60)

    def _talk_add(entry):
        log = store.talk_log
        prev = log[-1] if log else None
        ## 同じ人が続けて送ったときは、アイコンと名前を省く
        entry["cont"] = bool(prev and prev["kind"] == entry["kind"] and prev.get("who") == entry.get("who"))
        entry["time"] = _talk_clock()
        store.talk_minutes += 1 if len(log) % 2 else 0
        store.talk_log = log + [entry]
        ## ログ（バックログ）にも残す。トークの文は「トーク」の印を付ける
        if entry["kind"] in ("them", "me"):
            try:
                narrator.add_history("adv", ("蓮" if entry["kind"] == "me" else entry["who"]) + "（トーク）", entry["text"])
            except Exception:
                pass
        _talk_refresh()

    def _talk_refresh():
        ## 一度消してから出し直すことで、いちばん下の新しいメッセージまでスクロールさせる
        renpy.hide_screen("talk_view")
        renpy.show_screen("talk_view")

    def talk_start(title, clock="21:00"):
        """トーク画面を開く。例：$ talk_start("港北サッカー部（12）", "20:41")
        「（人数）」が付いている名前はグループのトークとして、名前を出す。"""
        store.talk_title = title
        store.talk_log = []
        store.talk_group = "（" in title
        store.talk_avatar = "gui/talk/avatar/group.png" if store.talk_group else talk_icon(title)
        store.talk_date = store.cal_date
        h, m = clock.split(":")
        store.talk_minutes = int(h) * 60 + int(m)
        _talk_refresh()
        renpy.with_statement(dissolve)

    def talk(who, text):
        """相手からのメッセージ（クリックで次へ）。例：$ talk("ひなた", "ひざ、大丈夫？")"""
        _talk_add({"kind": "them", "who": who, "text": text})
        renpy.pause()

    def talk_me(text, read="既読"):
        """自分（蓮）のメッセージ。"""
        _talk_add({"kind": "me", "who": "", "text": text, "read": read})
        renpy.pause()

    def talk_system(text):
        """画面の真ん中に出る小さな案内（既読がついた、など）。"""
        _talk_add({"kind": "system", "who": "", "text": text})
        renpy.pause()

    def talk_choose(items):
        """返信を選ぶ。items は (表示する文, 返す値) のリスト。選んだ値を返す。"""
        return renpy.call_screen("talk_choice", items=items)

    def talk_end():
        """トーク画面を閉じる。"""
        renpy.hide_screen("talk_view")
        renpy.with_statement(dissolve)

## スマホ本体（gui/talk/phone.png）の位置。画面部分は (436, 24) から 408×672
define PHONE_X = 420
define PHONE_Y = 8

screen talk_view():
    zorder 40

    ## うしろの背景を少し暗くして、スマホを目立たせる
    add Solid("#0000004d")

    ## 画面の中身
    fixed:
        pos (PHONE_X + 16, PHONE_Y + 16)
        xysize (408, 672)

        add Solid("#e4eaf1")

        ## 上のステータスバー
        fixed:
            ysize 34
            add Solid("#ffffff")
            text _talk_title_clock() style "talk_status" xpos 26
            hbox:
                xalign 1.0
                xoffset -24
                yalign 0.6
                spacing 6
                text "4G" style "talk_status"
                add Solid("#2b3440") xysize (22, 11) yalign 0.5

        ## ヘッダー（戻る、アイコン、トークの名前）
        fixed:
            ypos 34
            ysize 56
            add Solid("#ffffff")
            add Solid("#dfe3e8") ysize 1 yalign 1.0
            text "＜" style "talk_back"
            add talk_avatar zoom 0.4 xpos 36 yalign 0.5
            text talk_title style "talk_title"

        ## メッセージ
        viewport:
            ypos 90
            xysize (408, 524)
            yinitial 1.0
            mousewheel True
            vbox:
                xsize 408
                spacing 8
                null height 12
                if talk_date:
                    frame:
                        style "talk_pill"
                        text talk_date style "talk_pill_text"
                for m in talk_log:
                    if m["kind"] == "system":
                        frame:
                            style "talk_pill"
                            text m["text"] style "talk_pill_text"
                    elif m["kind"] == "me":
                        hbox:
                            xalign 1.0
                            xoffset -12
                            spacing 6
                            vbox:
                                yalign 1.0
                                spacing 0
                                if m.get("read"):
                                    text m.get("read") style "talk_meta" xalign 1.0
                                text m.get("time", "") style "talk_meta" xalign 1.0
                            frame:
                                style ("bubble_me_cont" if m.get("cont") else "bubble_me")
                                text m["text"] style "bubble_text"
                    else:
                        hbox:
                            xpos 10
                            spacing 6
                            if m.get("cont"):
                                null width 38
                            else:
                                add talk_icon(m["who"]) zoom 0.4
                            vbox:
                                spacing 3
                                if talk_group and not m.get("cont"):
                                    text m["who"] style "talk_sender"
                                hbox:
                                    spacing 6
                                    frame:
                                        style ("bubble_them_cont" if m.get("cont") else "bubble_them")
                                        text m["text"] style "bubble_text"
                                    text m.get("time", "") style "talk_meta" yalign 1.0
                null height 12

        ## 下の入力欄（飾り）
        fixed:
            ypos 614
            ysize 58
            add Solid("#ffffff")
            add Solid("#dfe3e8") ysize 1
            text "＋" style "talk_plus"
            frame:
                style "talk_field"
                text "メッセージを入力" style "talk_field_text"
            text "▶" style "talk_send"

    ## スマホの枠（画面の角を丸く見せるため、中身の上に重ねる）
    add "gui/talk/phone.png" pos (PHONE_X - 20, PHONE_Y - 20)

init python:
    ## ステータスバーの時計（最後のメッセージの時刻）
    def _talk_title_clock():
        return store.talk_log[-1]["time"] if store.talk_log else _talk_clock()


style talk_status:
    font FONT_JP_B
    size 14
    color "#2b3440"
    yalign 0.6

style talk_back:
    font FONT_JP_B
    size 22
    color "#2b3440"
    xpos 8
    yalign 0.5

style talk_title:
    font FONT_JP_B
    size 19
    color "#1e2733"
    xpos 82
    yalign 0.5

style talk_pill is frame:
    xalign 0.5
    background Frame("gui/talk/pill.png", 13, 13)
    padding (14, 4, 14, 5)

style talk_pill_text:
    size 13
    color "#ffffff"

style talk_sender:
    size 13
    color "#5b6878"

style talk_meta:
    size 11
    color "#7b8794"

style bubble_them is frame:
    background Frame("gui/talk/bubble_them.png", 24, 18)
    padding (22, 9, 14, 10)
    xmaximum 268

## 同じ人が続けて送った2つ目からは、しっぽのない吹き出し
style bubble_them_cont is bubble_them:
    background Frame("gui/talk/bubble_them_cont.png", 24, 18)

style bubble_me is frame:
    background Frame("gui/talk/bubble_me.png", 24, 18)
    padding (14, 9, 22, 10)
    xmaximum 268

style bubble_me_cont is bubble_me:
    background Frame("gui/talk/bubble_me_cont.png", 24, 18)

style bubble_text:
    size 18
    color "#1a1f26"
    line_spacing 2

style talk_plus:
    size 26
    color "#5b6878"
    xpos 16
    yalign 0.5

style talk_field is frame:
    xpos 50
    yalign 0.5
    xsize 300
    ysize 36
    background Frame("gui/talk/field.png", 17, 17)
    padding (16, 0, 16, 0)

style talk_field_text:
    size 15
    color "#a0a9b4"
    yalign 0.5

style talk_send:
    size 22
    color "#2f8f86"
    xpos 366
    yalign 0.5

## 返信の選択肢は、スマホの右側に付箋で並べる
screen talk_choice(items):
    zorder 110
    modal True
    vbox:
        xpos 884
        yalign 0.42
        spacing 0
        text "返信を選ぶ" style "talk_choice_head"
        null height 4
        for label_text, value in items:
            textbutton label_text action Return(value) style "talk_choice_button" text_style "talk_choice_text"

style talk_choice_head:
    font FONT_JP_B
    size 20
    color "#ffffff"
    outlines [(2, "#00000088", 0, 0)]
    xpos 16

style talk_choice_button is button:
    xsize 380
    background Frame("gui/note_small.png", 14, 14)
    hover_background Frame("gui/note_calendar.png", 14, 14)
    padding (24, 14, 26, 22)

style talk_choice_text:
    size 20
    color INK
    hover_color INK
    hover_font FONT_JP_B


################################################################################
## 行動マップ（放課後の行き先を選ぶ）
##   spots は {"id", "name", "x", "y", "event", "enabled"} の辞書のリスト
################################################################################

screen action_map(spots, banner, area="town"):
    modal True
    ## area="school" のときは、学校を大きくした地図
    add ("bg map_school" if area == "school" else "bg map")

    ## 行き先は、画びょうで留めた紙のタグ。(x, y) に画びょうが刺さる
    for s in spots:
        button:
            style "map_spot"
            pos (s["x"], s["y"])
            anchor (135, 18)
            sensitive s["enabled"]
            action Return(s["id"])
            hbox:
                xalign 0.5
                yalign 0.5
                spacing 8
                ## 人に会えるイベントは、顔の丸アイコンを名前の横に出す
                if s.get("face") and s["event"]:
                    add "gui/talk/avatar/%s.png" % s["face"] zoom 0.56 yalign 0.5
                vbox:
                    yalign 0.5
                    spacing 0
                    text s["name"] style "map_spot_name"
                    if s["event"]:
                        text "！ " + s["event"] style "map_spot_event"
                    elif not s["enabled"]:
                        text "（済み）" style "map_spot_done"

    ## 下の案内はマスキングテープ
    frame:
        style "map_banner"
        text banner style "map_banner_text"

    ## 右上：ここまでの話のふり返りと、相関図
    hbox:
        xalign 1.0
        xoffset -110    # 右上のメニューボタンをよける
        ypos 12
        spacing 10
        if recap_text:
            textbutton "これまでのこと" style "map_side" text_style "map_side_text" action Show("recap_note")
        textbutton "相関図" style "map_side" text_style "map_side_text" action ShowMenu("relations")

## 自由行動の前に、ここまでの話をまとめておく（行動マップの「これまでのこと」で読める）
default recap_text = ""

screen recap_note():
    modal True
    zorder 120
    button:
        xysize (1280, 720)
        background "#00000088"
        action Hide("recap_note")
    frame:
        xalign 0.5
        yalign 0.45
        xysize (760, 470)
        background Frame("gui/note_big.png", 30, 30)
        padding (56, 50, 56, 40)
        vbox:
            spacing 14
            text "これまでのこと" font FONT_JP_B size 30 color PEN_RED
            text recap_text size 23 color INK line_spacing 6
    textbutton "閉じる" style "map_side" text_style "map_side_text" xalign 0.5 ypos 610 action Hide("recap_note")

style map_side:
    background Frame("gui/note_small.png", 14, 14)
    padding (22, 12, 24, 16)

style map_side_text:
    font FONT_JP_B
    size 21
    color INK
    hover_color PEN_RED

style map_spot:
    xysize (270, 106)
    background "gui/spot_idle.png"
    hover_background "gui/spot_hover.png"
    insensitive_background "gui/spot_insensitive.png"
    padding (12, 24, 16, 18)

style map_spot_name:
    xalign 0.5
    font FONT_JP_B
    size 24
    color INK
    insensitive_color INK_SOFT

style map_spot_event:
    xalign 0.5
    size 17
    color PEN_RED

style map_spot_done:
    xalign 0.5
    size 17
    color INK_SOFT

style map_banner:
    xalign 0.5
    ypos 640
    xysize (780, 58)
    background "gui/banner_tape.png"
    padding (0, 0, 0, 0)

style map_banner_text:
    xalign 0.5
    yalign 0.5
    yoffset -2
    font FONT_JP_B
    size 24
    color INK


################################################################################
## ステータス画面（クイックメニューの「ステータス」から開く）
##   テスト用に隠しパラメータも表示している。製品版では隠す。
################################################################################

screen status():
    tag menu
    use game_menu("ステータス", scroll="viewport"):
        vbox:
            spacing 8

            null height 10
            text "能力値" style "status_head"
            for k in STAT_KEYS:
                use status_bar(k, stats[k])

            null height 10
            text "隠しパラメータ（テスト用に表示）" style "status_head"
            for k in HIDDEN_KEYS:
                use status_bar(k, hidden[k])

            null height 10
            text "仲間・ライバルとの絆" style "status_head"
            for k in BOND_KEYS:
                use status_bar(("坂口たち" if k == "坂口" else k), bond.get(k, 0))

            null height 10
            text "ヒロイン" style "status_head"
            for h in HEROINES:
                text h style "status_sub"
                for k in HEART_KEYS:
                    use status_bar("　" + k, heart[h][k])

            null height 10
            text "信念タイプの傾向" style "status_head"
            for k in BELIEF_KEYS:
                hbox:
                    spacing 20
                    text k style "status_label"
                    text str(belief[k]) style "status_value"

screen status_bar(name, value):
    hbox:
        spacing 20
        text name style "status_label"
        bar value StaticValue(value, 100) xsize 460 yalign 0.5
        text str(value) style "status_value"

style status_head:
    font FONT_JP_B
    size 24
    color PEN_RED

style status_sub:
    font FONT_JP_B
    size 22
    color PEN_TEAL

style status_label:
    size 22
    xsize 200

style status_value:
    size 22
    xsize 60
