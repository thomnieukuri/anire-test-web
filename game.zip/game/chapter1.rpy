## chapter1.rpy ―― 第1章「はじまりの十一人」（高1・4〜5月）
##   台本：アンイレ 体験版台本（第1章のタブ）

## 自由行動の日付
##   第1章の自由行動は3回：①部員集め（3日） ②5月の放課後（2日） ③試合の前（1日）
define CH1_FREE_DATES = ["4月14日（火）", "4月15日（水）", "4月16日（木）"]
define CH1_FREE2_DATES = ["5月12日（火）", "5月15日（金）"]
define CH1_FREE3_DATE = "5月28日（木）"

## 自由行動の前に読める「これまでのこと」
define CH1_RECAP = [
    "中3の冬、県大会の決勝で右ひざをケガした。\nぶつかった相手は神城。桜嶺の推薦は取り消された。\n\n春。近所の県立港北高校に入ると、サッカー部は部員3人。\n生徒会長の千夏先輩に「5月20日までに11人そろわなければ廃部」と言われた。\n顧問の黒田先生は「11人そろったら見てやる」とだけ。\n\nひなたが、部員の候補を調べてくれた。",
    "柔道部の大門、屋上の鷹野、ゲーセンの坂口たち5人。\n名前だけなら、11人分そろった。\n\nでも、ボールを怖がるキーパー、すぐサボるエース、ジャージすら持っていない5人。\n5月20日の締め切りまでに、本当に試合に出られるチームにしなければならない。",
    "5月20日。千夏先輩が、サッカー部の存続を認めてくれた。\n11人が、初めてグラウンドにそろった。\n\n黒田先生が組んだ練習試合の相手は、桜嶺学園のBチーム。\n俺が行くはずだった学校。神城がいる学校。\n試合は、5月31日の日曜日。",
]

## 自由行動②：5月の放課後の行き先
init python:
    def ch1_spots2():
        f = store.flags
        return [
            {"id": "ground", "name": "グラウンド", "x": 270, "y": 190,
             "event": "自主練（能力アップ）", "enabled": True},
            {"id": "council", "name": "生徒会室", "x": 500, "y": 80, "face": "chika",
             "event": "" if f.get("ch1_council") else "千夏", "enabled": not f.get("ch1_council")},
            {"id": "judo", "name": "柔道場", "x": 545, "y": 215, "face": "daimon",
             "event": "" if f.get("ch1_daimon2") else "大門", "enabled": not f.get("ch1_daimon2")},
            {"id": "walk", "name": "港への坂道", "x": 870, "y": 330, "face": "hinata",
             "event": "" if f.get("ch1_walk") else "ひなた", "enabled": not f.get("ch1_walk")},
        ]

    ## 自由行動③：試合の前の行き先（1日だけ）。行き先が学校の中だけなので、学校を大きくした地図（area="school"）で出す
    def ch1_spots3():
        return [
            {"id": "ground", "name": "グラウンド", "x": 455, "y": 320,
             "event": "自主練（能力アップ）", "enabled": True},
            {"id": "roof", "name": "屋上", "x": 556, "y": 67, "face": "takano", "event": "鷹野", "enabled": True},
            {"id": "clubroom", "name": "部室", "x": 850, "y": 270, "face": "miyoshi", "event": "三好", "enabled": True},
            {"id": "staff", "name": "職員室", "x": 1061, "y": 160, "face": "kuroda", "event": "黒田", "enabled": True},
        ]

## 誰を何日目に誘ったか（4 は誘いに行かず、あとで加入）。第2章の6月1日、早く誘った相手ほど絆が少し深くなる（chapter2.rpy）
default ch1_join = {}
default ch1_day = 1
default ch1_dest = ""
default ch1_reply = ""

init python:

    ## 行き先の位置（x, y）は、タグの赤い画びょうを刺す場所。地図の絵の建物の上に合わせてある
    ##   ・町の地図（images/bg/map.jpg）……ふだん
    ##   ・学校を大きくした地図（images/bg/map_school.jpg）……行き先が学校の中だけのとき
    ##   "face" に人物の id を入れると、タグに顔の丸アイコンが出る
    def ch1_spots():
        """第1章の自由行動で、行動マップに出す行き先。"""
        j = store.ch1_join
        return [
            {"id": "judo", "name": "柔道場", "x": 545, "y": 215, "face": "daimon",
             "event": "" if "大門" in j else "大門剛", "enabled": "大門" not in j},
            {"id": "roof", "name": "屋上", "x": 330, "y": 45, "face": "takano",
             "event": "" if "鷹野" in j else "鷹野迅", "enabled": "鷹野" not in j},
            {"id": "ground", "name": "グラウンド", "x": 270, "y": 190,
             "event": "自主練（能力アップ）", "enabled": True},
            {"id": "arcade", "name": "駅前のゲーセン", "x": 1050, "y": 120, "face": "sakaguchi",
             "event": "" if "5人組" in j else "1年の5人組", "enabled": "5人組" not in j},
        ]


label chapter1:
    scene black
    with Dissolve(1.0)
    call show_title("第1章", "はじまりの十一人")

    ############################################################################
    ## シーン1：土のグラウンド（4月・入学式の日）
    ############################################################################
    $ set_cal("4月8日（水）", "放課後")
    scene bg kohoku_ground_eve
    with dissolve
    $ bgm("のんびりした春の曲")

    "{rb}港北{/rb}{rt}こうほく{/rt}高校のグラウンドは、土だった。"
    "野球部と陸上部とソフトボール部が、ひとつの土を分け合って使っている。"
    "サッカーゴールは端のほうに一つだけ。ネットには、拳が通るくらいの穴が開いていた。"

    show hinata normal
    with dissolve
    voice "audio/voice/hinata_hee.mp3"
    hinata "……思ってたより、すごいね"
    ren "思ってたより、ひどいな"
    voice "audio/voice/hinata_iikata.mp3"
    hinata "言い方"

    $ se("遠くで土を蹴って走る足音")
    "グラウンドの外周を、一人で走っている人がいた。"
    "泥だらけのジャージ。日焼けした顔。"
    "息を切らしながら、こっちに向かって手を振ってくる。"

    show hinata normal at left
    show miyoshi smile at right
    with dissolve
    $ meet("三好")
    voice "audio/voice/miyoshi_oi.mp3"
    miyoshi "おーい！　もしかして、入部希望！？"
    ren "いや、まだ見に来ただけで――"
    miyoshi "入部希望だな！？　な！？"
    "両肩をつかまれた。力が強い。"
    miyoshi "3年の{rb}三好大地{/rb}{rt}みよしだいち{/rt}！　サッカー部のキャプテン！"
    miyoshi "ついでに言うと、ちゃんと練習に来てるのは俺一人！"
    voice "audio/voice/hinata_akire.mp3"
    hinata "ついでで言うことじゃないと思います"
    miyoshi "部員は3人いるんだけどな。2年の二人は、名前だけ置いてる幽霊部員なんだ"
    "三好先輩は、少しも悲しそうじゃない顔で笑った。"
    hinata_s "……この先輩、毎日一人でグラウンドを走ってるんだって。雨の日も"
    "ジャージの泥は、昨日今日ついたものじゃなかった。"
    miyoshi "でも今年は違う。お前が来たからな！"
    ren "……なんで俺のこと"
    miyoshi "知ってるよ。{rb}潮見{/rb}{rt}しおみ{/rt}FCの10番だろ。県大会の決勝、スタンドで見てた"
    miyoshi "あのターン、すごかった"
    "それは、俺がケガをする直前のプレーだった。"
    "三好先輩は、ケガのことは何も言わなかった。"
    miyoshi "なあ。俺、今年で最後なんだ"
    miyoshi "最後に一回でいい。11人で、公式戦に出たいんだよ"
    "夕方の風が、グラウンドの土を巻き上げる。"
    "三好先輩の目は、本気だった。"
    $ bond_up("三好", 5)
    "その夜、気づいたら、入部届を書いていた。"

    scene black
    with dissolve

    ############################################################################
    ## シーン2：生徒会室（翌日の放課後）
    ############################################################################
    $ set_cal("4月9日（木）", "放課後")
    scene bg student_council
    with dissolve
    $ bgm("張りつめた静かな曲")

    miyoshi "――というわけで、入部届です！"
    "{rb}三好{/rb}{rt}みよし{/rt}先輩が、俺の入部届を机に叩きつけた。"
    "机の向こうに座っていたのは、黒髪の長い女子生徒だった。"

    show chika normal
    with dissolve
    "細いメガネの奥の目が、届けと俺の顔を一往復する。"
    hinata_s "……生徒会長の、{rb}七瀬千夏{/rb}{rt}ななせちか{/rt}先輩。2年生で会長って、すごいよね"
    voice "audio/voice/chika_nyubu.mp3"
    chika "入部届は顧問の先生に出すものです。生徒会に持ってくるものではありません"
    miyoshi "いや、でもさ、会長に見せたほうが話が早いと思って"
    chika "話というのは、サッカー部の存続の件ですね"
    "千夏先輩は、引き出しから一枚の紙を出した。"
    chika "部員数が規定に満たない部は、今年度で廃部。先月の生徒総会で決まったことです"
    chika "サッカー部が残る条件は、5月20日の夏の大会のエントリー締め切りまでに、選手を11人そろえること"
    chika "そろわなければ廃部。部室も明け渡してもらいます"
    ren "……あと一か月ちょっとで、8人集めろってことですか"
    chika "7人です。あなたが入ったので"
    ren "……あっ"
    "自分を数えるのを、忘れていた。"
    if flags.get("母_八人"):
        "……母さんの「八人」も、俺を数え忘れていたらしい。"

    show chika narrow
    chika "それと、幽霊部員の二人を数に入れるなら、ちゃんと試合に出られる状態にしておいてください"
    chika "名前だけの部員で数を合わせるのは、認めません"
    miyoshi "……厳しいなあ、七瀬は"
    $ meet("千夏")
    voice "audio/voice/chika_kisoku.mp3"
    chika "規則ですから"
    "冷たい人だ、と思った。"
    "でも、ひとつだけ引っかかった。"
    "机の端に置かれた古いフィルムカメラ。"
    "そのストラップに、{rb}港北{/rb}{rt}こうほく{/rt}サッカー部の色あせたキーホルダーがついていた。"
    voice "audio/voice/chika_madananika.mp3"
    chika "まだ何か？"
    ren "……いえ"

    show chika window
    voice "audio/voice/chika_fu.mp3"
    chika "11人、そろうといいですね"
    "部屋を出る直前、背中越しにそう聞こえた気がした。"
    "振り返った時には、千夏先輩はもう書類に目を落としていた。"
    $ heart_up("千夏", "信頼", 3)

    ############################################################################
    ## シーン3：職員室（同じ日）
    ############################################################################
    scene bg staffroom
    with dissolve
    $ bgm("とぼけた日常の曲")

    "職員室のいちばん奥の机で、男が新聞を顔にかぶせて寝ていた。"
    "よれたジャージに、サンダル。机の上には、冷めた缶コーヒー。"
    miyoshi "{rb}黒田{/rb}{rt}くろだ{/rt}先生！　新入部員です！"

    show kuroda peek
    with dissolve
    $ meet("黒田")
    voice "audio/voice/kuroda_koe.mp3"
    kuroda "……{rb}三好{/rb}{rt}みよし{/rt}。声がでかい"
    voice "audio/voice/hinata_ee.mp3"
    hinata_s "この人が、顧問？"
    miyoshi_s "数学の黒田先生。顧問なんだけど、練習には一回も来たことない"
    "黒田は、俺の入部届をつまみ上げて、ちらりと見た。"
    voice "audio/voice/kuroda_hoo.mp3"
    kuroda "{rb}早瀬蓮{/rb}{rt}はやせれん{/rt}。……{rb}潮見{/rb}{rt}しおみ{/rt}FCか"
    kuroda "ひざは"
    ren "……え"
    kuroda "右ひざ。県大会の決勝で痛めたんだろ"
    "なんで知ってるんだ。"
    voice "audio/voice/kuroda_maa.mp3"
    kuroda "……まあ、好きにしろ。届けは預かる"
    miyoshi "先生！　今年こそ、練習見てくださいよ！"

    show kuroda yawn
    voice "audio/voice/kuroda_fuaa.mp3"
    kuroda "11人そろったら見てやる"
    miyoshi "ほんとですか！？"
    kuroda "そろったらな"
    "黒田は、また新聞を顔にかぶせた。"
    "これ以上話すことはない、という合図らしい。"

    hide kuroda
    with dissolve
    "職員室を出る時、黒田が席を立つのが見えた。"
    "左足を、わずかに引きずっていた。"

    scene black
    with dissolve

    ############################################################################
    ## シーン4：部員集め（4月中旬・自由行動）
    ############################################################################
    $ set_cal("4月13日（月）", "放課後")
    scene bg clubroom
    with dissolve
    $ bgm("作戦会議っぽい軽快な曲")

    "ほこりっぽい部室で、ひなたがノートを広げた。"

    show hinata proud
    with dissolve
    voice "audio/voice/hinata_fufun.mp3"
    hinata "候補、調べといたよ"
    hinata "一人目。1年3組、{rb}大門剛{/rb}{rt}だいもんつよし{/rt}くん。柔道部。身長190センチ"
    ren "190？"
    hinata "しかもリーゼントで、眉毛に剃り込み。廊下ですれ違うと、上級生が道をあけるんだって"
    miyoshi "完全に番長じゃないか！"
    hinata "でも、柔道部では毎日投げられてばっかりなんだって。優しすぎて、相手を投げられないらしいよ"
    hinata "見た目が怖すぎて、本人がいちばん困ってるみたい"
    hinata "二人目。1年1組、{rb}鷹野迅{/rb}{rt}たかのじん{/rt}くん。元Jクラブのジュニアユース。だいたい屋上でサボってる"
    $ learn("junior_youth")
    ren "ジュニアユース……"
    hinata "ユースに上がれなかったんだって。それからサッカーやってないみたい"
    hinata "三人目。……っていうか三人目から七人目。駅前のゲーセンにいつもいる1年の5人組"
    voice "audio/voice/miyoshi_uo.mp3"
    miyoshi "5人まとめて！？　最高じゃないか！"
    hinata "全員、帰宅部。サッカーゲームだけはすごく強いらしいです"
    miyoshi "ゲームか……。まあ、ゲームでも足は動く！"
    voice "audio/voice/hinata_ugokimasen.mp3"
    hinata "動きません"

    show hinata serious
    voice "audio/voice/hinata_nn.mp3"
    hinata "全員誘えたら、ちょうど11人。でも、毎日練習もしなきゃでしょ。{rb}蓮{/rb}{rt}れん{/rt}のひざのリハビリもあるし"
    voice "audio/voice/hinata_un.mp3"
    hinata "だから、どこから行くか、ちゃんと決めよ"

    window auto hide
    hide hinata
    with dissolve
    $ recap_text = CH1_RECAP[0]
    tuto "ここからは「自由行動」です。放課後に行く場所を、行動マップから1か所選びます。"
    tuto "人を誘いに行くと仲間が増えます。「グラウンド」を選ぶと練習になって、能力が上がります。"
    tuto "期間は3日。早く誘った相手ほど、強い状態でチームに入ります（誘わなかった相手も、あとで{rb}三好{/rb}{rt}みよし{/rt}とひなたが誘ってくれます）。"

    $ ch1_day = 1
    while ch1_day <= 3:
        $ amb_stop()                            # ゲームセンターの音などを止める
        $ set_cal(CH1_FREE_DATES[ch1_day - 1], "放課後")
        $ bgm("作戦会議っぽい軽快な曲")          # 行き先で曲が変わっても、マップに戻ったら元の曲に
        window auto hide
        call screen action_map(ch1_spots(), "放課後、どこへ行く？（残り" + str(4 - ch1_day) + "日）")
        $ ch1_dest = _return
        if ch1_dest == "judo":
            call ch1_daimon
        elif ch1_dest == "roof":
            call ch1_takano
        elif ch1_dest == "arcade":
            call ch1_arcade
        else:
            call ch1_practice
        ## その夜：自分から誰かにトークを送れる（nightcontact.rpy）
        $ amb_stop()
        call night_send(CH1_FREE_DATES[ch1_day - 1], "apr")
        $ ch1_day += 1

    ## 最後の日の行き先の音（ゲームセンター・屋上の曲）を、部室の場面に持ちこまない
    $ amb_stop()
    $ bgm("作戦会議っぽい軽快な曲")
    jump ch1_free_after


################################################################################
## 4−2 自主練
##   選ぶたびに、まだ見ていないパターンからランダムで1つ出る（全部見たら最初から）
################################################################################
define CH1_PRACTICE_PATTERNS = ["solo", "miyoshi", "hinata_time", "chika", "kuroda"]
default ch1_practice_seen = []
default ch1_pp = ""
## 自由行動①（4月）は 1、11人そろったあとの自由行動②③は 2。七瀬先輩のカメラは「今年の一枚目」の話なので、4月だけ出す
default ch1_phase = 1
default ch1_arcade_pick = ""     # ゲーセンの最後の10秒で選んだこと（shoot / pass）
default m531_play = ""          # 5/31の前半終了間際に選んだこと（dribble / pass / back）

label ch1_practice:
    scene bg kohoku_ground_eve
    with dissolve
    python:
        ## 七瀬先輩のカメラは4月だけ。ひなたの50メートル走は5月から（4月は、医者にジョギングだけと言われている）
        _all = [p for p in CH1_PRACTICE_PATTERNS
                if not (p == "chika" and ch1_phase >= 2)
                and not (p == "hinata_time" and ch1_phase < 2)]
        _pool = [p for p in _all if p not in ch1_practice_seen]
        if not _pool:
            ch1_practice_seen = []
            _pool = list(_all)
        ch1_pp = renpy.random.choice(_pool)
        ch1_practice_seen.append(ch1_pp)
    call expression "ch1_practice_" + ch1_pp
    call tuto_stats
    return

## 能力・絆・ひざの説明は、はじめて練習したあとに1回だけ出す（第1章で練習しなかった人には、第2章の最初の練習のあとに出す）
default tuto_stats_done = False
label tuto_stats:
    if tuto_stats_done:
        return
    $ tuto_stats_done = True
    window auto hide
    tuto "{rb}蓮{/rb}{rt}れん{/rt}の能力は「技術」「フィジカル」「戦術眼」「メンタル」の4つ。練習や選択肢で上がり、試合の結果や、能力の判定がある場面に関わります。"
    tuto "仲間との「絆」と、ヒロインの「ときめき」「信頼」もあります。右上のメニューの「ステータス」「相関図」で確かめられます。"
    tuto "ひざに無理をさせると、見えないところで負担がたまっていきます。練習のしすぎには気をつけましょう。"
    return

## 一人で黙々と
label ch1_practice_solo:
    "放課後のグラウンドで、一人でボールを蹴った。"
    if ch1_phase == 1:
        "冬からまともに走っていなかった体は、思っていたよりずっと重い。"
    else:
        "4月よりは、体が少し軽い。それでも、思った場所に足が届くのが、まだ半歩遅い。"
    "それでも、ボールが足に吸いつく感覚だけは、まだ残っていた。"
    $ up("技術", 3)
    $ up("フィジカル", 2)
    $ up("無理ゲージ", 3)
    "ひざの奥が、少し熱い。"
    return

## 三好先輩とパス交換
label ch1_practice_miyoshi:
    "グラウンドに出ると、{rb}三好{/rb}{rt}みよし{/rt}先輩がもうボールを蹴っていた。"
    show miyoshi smile
    with dissolve
    miyoshi "おっ、{rb}早瀬{/rb}{rt}はやせ{/rt}！　ちょうどいい、パス交換しようぜ！"
    "先輩のパスは、とにかく強い。そして、とにかくずれる。"
    "右に来ると思えば左。足もとかと思えば頭の上。"
    ren "先輩、もうちょっと……こう、相手の足もとに"
    miyoshi "分かってる！　分かってるけど、気持ちが先に行っちゃうんだよな！"
    "笑いながら、先輩は自分で蹴ったボールを自分で追いかけていった。"
    "ずれたボールを追ううちに、いつの間にか、足がよく動くようになっていた。"
    $ up("フィジカル", 3)
    $ up("技術", 1)
    $ up("無理ゲージ", 2)
    $ bond_up("三好", 3)
    miyoshi "明日もやろうな！　な！"
    hide miyoshi
    with dissolve
    return

## ひなたがタイムを計る（5月の自由行動②③だけ。ch1_practice で4月には選ばれないようにしてある）
label ch1_practice_hinata_time:
    "ゴールの横で、ひなたがストップウォッチを構えていた。"
    show hinata proud
    with dissolve
    hinata "はい、50メートル。ひざ、無理しないでよ"
    "笛の代わりに、ひなたの「よーい、どん」。"
    $ se("土を蹴る足音")
    show hinata stare
    hinata "……6秒9"
    ren "前は6秒3だった"
    voice "audio/voice/hinata_fufun.mp3"
    hinata "知ってる。ノートに書いてあるもん"
    "ひなたのノートには、中学の3年間の俺の記録が、全部残っているらしい。"
    $ up("フィジカル", 2)

    menu:
        "「もう一本」":
            show hinata serious
            voice "audio/voice/hinata_ippon.mp3"
            hinata "……一本だけだからね"
            "二本目は、6秒8。"
            show hinata smile
            voice "audio/voice/hinata_fufu.mp3"
            hinata "その負けず嫌いな顔、昔から変わんないね"
            $ up("フィジカル", 2)
            $ up("無理ゲージ", 5)
            $ heart_up("ひなた", "ときめき", 2)
            $ lean("求道型")
        "「今日はここまでにする」":
            show hinata smile
            voice "audio/voice/hinata_un_soft.mp3"
            hinata "えらい。……そういうとこは、ちゃんと大人になったじゃん"
            "ひなたが、ノートに何か書き足した。"
            $ up("メンタル", 1)
            $ heart_up("ひなた", "信頼", 3)

    hide hinata
    with dissolve
    return

## 七瀬先輩のカメラ
label ch1_practice_chika:
    "転がったボールを拾いに行くと、フェンスの向こうに人影があった。"
    show chika normal
    with dissolve
    "{rb}千夏{/rb}{rt}ちか{/rt}先輩だった。首から下げた古いフィルムカメラを、グラウンドに向けている。"
    ren "……何、撮ってるんですか"
    voice "audio/voice/chika_ee.mp3"
    chika "生徒会の記録です。部活動の写真を、年に一度まとめるので"
    chika "生徒会の記録には、去年のサッカー部は一枚もありません"
    show chika narrow
    chika "一人で練習している写真では、部活動に見えませんから"
    "カシャ、と小さな音がした。"
    ren "今のは？"
    show chika soft
    voice "audio/voice/chika_ichimaime.mp3"
    chika "……今年の一枚目です"
    "それだけ言って、先輩は校舎のほうへ戻っていった。"
    hide chika
    with dissolve
    "一人で蹴るボールが、さっきより軽く感じた。"
    $ up("技術", 2)
    $ up("メンタル", 2)
    $ up("無理ゲージ", 2)
    $ heart_up("千夏", "ときめき", 2)
    return

## 職員室の窓
label ch1_practice_kuroda:
    "一人でシュート練習をしていると、ふと、視線を感じた。"
    "顔を上げる。校舎の二階、職員室の窓。"
    "{rb}黒田{/rb}{rt}くろだ{/rt}が、缶コーヒーを片手にこっちを見ていた。"
    "……ような気がした。"
    "もう一度見たときには、窓のブラインドが下りていた。"
    "気のせいか。"
    "ゴールの枠に当たって跳ね返ったボールを、もう一度、蹴る。"
    "どこに蹴れば入るのか。どう体を向ければ、キーパーが動けないのか。"
    "考えながら蹴ると、一本一本が、少しずつ変わっていくように思えた。"
    $ up("技術", 2)
    $ up("戦術眼", 3)
    $ up("無理ゲージ", 2)
    return


################################################################################
## 4−3 柔道場：大門剛
################################################################################
label ch1_daimon:
    scene bg judo_hall
    with dissolve
    $ se("畳に人が落ちる音")

    show daimon worried
    with dissolve
    "でかい。"
    "畳の上で投げられて、天井を見上げているのに、それでもでかい。"
    "前に突き出したリーゼントに、剃り込みの入った眉。目が合っただけで、こっちが謝りそうになる顔だ。"
    $ meet("大門")
    voice "audio/voice/daimon_nanika.mp3"
    daimon "あ……あの、何か用ですか"
    "……声が、思ったよりずっと小さい。"
    ren "サッカー部に入ってくれないか。キーパーで"
    voice "audio/voice/daimon_hii.mp3"
    daimon "む、無理です！　ボールが飛んでくるんですよね！？　怖いです！"
    hinata "でも{rb}大門{/rb}{rt}だいもん{/rt}くん、今、思いっきり投げられてたよね"
    daimon "人に投げられるのは慣れてるので……"
    "慣れちゃだめだろ、それは。"
    ren "……その髪型で、怖いものがあるのか"
    voice "audio/voice/daimon_sumimasen.mp3"
    daimon "こ、これは、うちが床屋で……父が毎朝、勝手にセットするんです……"
    daimon "眉も、父が『男は眉だ』って……。僕は、本当はもっと普通にしたいんですけど……"
    "見た目と中身が、ここまで逆の人間を初めて見た。"

    menu:
        "「ボールは、人より痛くないぞ」":
            $ bond_up("大門", 6)
            daimon "……人より、痛くない"
            daimon "それなら、僕にもできるかもしれません"
            "大門は、正座をして深々と頭を下げた。"
            daimon "よろしくお願いします。……先輩たちに、柔道部をやめるって言ってきます"

        "「その体、もったいない」":
            $ bond_up("大門", 3)
            $ up("戦術眼", 1)
            daimon "……よく言われます。もったいないって"
            daimon "でも、ゴールの前に立つだけなら……誰も投げなくていいんですよね"
            "大門は、少しさみしそうに笑ってうなずいた。"

    $ ch1_join["大門"] = ch1_day
    tuto "大門が加入しました（GK）。"
    return


################################################################################
## 4−4 屋上：鷹野迅
################################################################################
label ch1_takano:
    scene bg rooftop
    with dissolve
    $ bgm("少しとがった曲")

    show takano lying
    with dissolve
    "屋上のフェンスにもたれて、そいつはイヤホンをしていた。"
    $ meet("鷹野")
    voice "audio/voice/takano_nani.mp3"
    takano "……なに"
    ren "サッカー部に――"
    takano "やらない"
    "即答だった。"
    voice "audio/voice/takano_chi.mp3"
    takano "弱小校の部活ごっこに付き合う気はない。帰れ"
    voice "audio/voice/hinata_gokko.mp3"
    hinata "ごっこって……！"
    ren "じゃあ、勝負しよう"
    "屋上の隅に、誰かが置きっぱなしにしたバレーボールが転がっていた。"
    ren "1対1。俺を抜けたら、もう二度と来ない。俺が止めたら、一回だけ練習に来い"

    show takano normal
    takano "……ひざ、壊れてんだろ。知ってるぞ、県大会の"
    takano "後悔すんなよ"

    $ se("ボールを蹴る音")
    "速い。"
    "ジュニアユースにいたのは、本当だった。"
    "ボールが足に吸いつく感じ。重心の低さ。左右どっちにも抜ける体の向き。"
    "――でも、俺には見えている。"
    "こいつが次に、どっちに行きたがっているか。"

    menu:
        "本気で止めに行く":
            $ up("技術", 2)
            $ bond_up("鷹野", 6)
            "右。"
            "{rb}鷹野{/rb}{rt}たかの{/rt}が切り返した瞬間、俺の足がボールに触れた。"
            $ se("ボールが転がる音")
            takano "……は？"
            show takano surprised
            takano "今の、読んでたのか"
            ren "見えてただけだ"
            "鷹野は舌打ちして、ボールを拾い上げた。"
            takano "……一回だけだぞ。一回だけ、練習行ってやる"
            "その「一回」が、いつまで続くのかは、まだ誰も知らない。"

        "わざと抜かせて、入部させる":
            $ bond_up("鷹野", -3)
            $ set_flag("鷹野_わざと負け")
            "右。読めていた。"
            "でも、足を出さなかった。"
            $ se("ボールが抜けていく音")
            takano "……ほらな"
            ren "すごいな。お前がいれば、{rb}港北{/rb}{rt}こうほく{/rt}は勝てる。……約束だから、もう来ないけど"
            show takano narrow
            "鷹野は、足の裏でボールを止めたまま、動かなかった。"
            takano "……今の、わざとだろ。勝ちをゆずられたままじゃ、気分わりい"
            "ボールが、俺の足もとに蹴り返されてきた。"
            voice "audio/voice/takano_darui.mp3"
            takano "まあいい。暇つぶしに行ってやるよ"
            "鷹野は、最後まで俺の顔を見なかった。"

    $ ch1_join["鷹野"] = ch1_day
    tuto "鷹野が加入しました（FW）。"
    return


################################################################################
## 4−5 駅前のゲームセンター：5人組
################################################################################
label ch1_arcade:
    scene bg game_center
    with dissolve
    $ bgm("ゲームセンターの曲")              # 効果音（にぎやかな音）はうるさいので使わず、曲だけにする

    "サッカーゲームの筐体の前に、同じ学年の5人がたむろしていた。"
    show sakaguchi normal
    with dissolve
    "リーダー格の{rb}坂口{/rb}{rt}さかぐち{/rt}が、こっちを見てにやりと笑う。"
    $ meet("坂口")
    voice "audio/voice/sakaguchi_soccer.mp3"
    sakaguchi "サッカー部？　俺ら、走るのとか無理なんだけど"
    voice "audio/voice/sakaguchi_ukeru.mp3"
    sakaguchi "あっはは！　ウケるんだけど。部員、足りなさすぎでしょ"
    sakaguchi "でもさ。このゲームで俺に勝てたら、5人まとめて入ってやってもいいよ"
    ren "ゲームか……"
    voice "audio/voice/hinata_ee.mp3"
    hinata "{rb}蓮{/rb}{rt}れん{/rt}、ゲーム下手じゃなかった？"
    ren "うるさい"
    "3本勝負。"
    "1勝1敗で迎えた、3本目。"
    "残り10秒、俺が操作する選手がゴール前でパスを受けた。"
    "コントローラーを握る手に、汗がにじむ。"

    menu:
        "自分でシュート":
            $ lean("野心型")
            $ ch1_arcade_pick = "shoot"
        "横の味方にパス":
            $ lean("仲間型")
            $ bond_up("坂口", 2)
            $ ch1_arcade_pick = "pass"

    $ se("ゲームのゴール音")
    voice "audio/voice/sakaguchi_maji.mp3"
    sakaguchi "……マジかよ"
    if ch1_arcade_pick == "shoot":
        sakaguchi "うわ。ゲームでも自分で行くタイプかよ。……ガチじゃん"
    else:
        sakaguchi "そこで横に出す？　ゲームで味方にパスするやつ、初めて見た。ウケる"
    voice "audio/voice/sakaguchi_shanee.mp3"
    sakaguchi "しょうがねえな。人数合わせくらいなら、やってやるよ"
    "5人がゲラゲラ笑いながら、こっちに手を差し出した。"
    "不安しかない。"
    "でも、これで――"

    $ ch1_join["5人組"] = ch1_day
    tuto "坂口たち5人が加入しました。"
    return


################################################################################
## 自由行動のあと：誘いに行かなかった相手
################################################################################
label ch1_free_after:
    $ set_cal("4月17日（金）", "放課後")
    scene bg clubroom
    with dissolve

    if "大門" not in ch1_join:
        "{rb}大門{/rb}{rt}だいもん{/rt}は、{rb}三好{/rb}{rt}みよし{/rt}先輩が3日続けて柔道場に通いつめて、ようやくうなずかせたらしい。"
        $ meet("大門")
        $ ch1_join["大門"] = 4
    if "鷹野" not in ch1_join:
        "{rb}鷹野{/rb}{rt}たかの{/rt}は、ひなたが毎日屋上に通って、「一回だけなら」と言わせたらしい。"
        $ meet("鷹野")
        $ ch1_join["鷹野"] = 4
    if "5人組" not in ch1_join:
        "ゲーセンの5人組は、三好先輩がゲームで完敗したあと、頭を下げて入ってもらったらしい。"
        $ meet("坂口")
        $ ch1_join["5人組"] = 4

    "これで、名前だけなら11人分そろった。"
    "あとは、5月20日の締め切りまでに、本当に11人が試合に出られる状態にするだけだ。"

    ############################################################################
    ## 自由行動②：5月の放課後（2日）
    ############################################################################
    "それから、3週間。"
    "{rb}坂口{/rb}{rt}さかぐち{/rt}たちは、ジャージを持っていなかった。パーカーとジーンズのまま、グラウンドの外周を走った。2周目で、5人とも歩いた。"
    "{rb}大門{/rb}{rt}だいもん{/rt}は、ゴールの前で両手を広げて、ボールが来るたびに目をつぶった。"
    "{rb}鷹野{/rb}{rt}たかの{/rt}は、パスを受けても、誰にも返さなかった。"
    "{rb}三好{/rb}{rt}みよし{/rt}先輩は、毎朝、2年の幽霊部員の家のインターホンを鳴らしに行っていた。"
    "ひなたのノートには、毎日、グラウンドに来た人数が書きこまれていった。5人。7人。4人。8人。"
    "9人が一度にそろった日は、まだ一日もなかった。"
    $ recap_text = CH1_RECAP[1]
    $ ch1_phase = 2
    window auto hide
    tuto "自由行動です。今回は2日間。"
    tuto "行動マップの右上の「これまでのこと」で、ここまでの話をふり返れます。"
    tuto "「相関図」では、出会った人との関係を確かめられます。"

    $ ch1_day = 1
    while ch1_day <= 2:
        $ amb_stop()
        $ set_cal(CH1_FREE2_DATES[ch1_day - 1], "放課後")
        $ bgm("作戦会議っぽい軽快な曲")
        window auto hide
        call screen action_map(ch1_spots2(), "5月の放課後、どこへ行く？（残り" + str(3 - ch1_day) + "日）")
        $ ch1_dest = _return
        if ch1_dest == "council":
            call ch1_council
        elif ch1_dest == "judo":
            call ch1_daimon2
        elif ch1_dest == "walk":
            call ch1_walk_hinata
        else:
            call ch1_practice
        $ amb_stop()
        call night_send(CH1_FREE2_DATES[ch1_day - 1], "may")
        $ ch1_day += 1
    $ amb_stop()

    ############################################################################
    ## シーン5：11人（5月20日）
    ############################################################################
    scene black
    with dissolve
    $ set_cal("5月20日（水）", "エントリー締め切り日")
    scene bg student_council
    with dissolve
    $ bgm("静かな緊張感のある曲")

    "エントリーの締め切り当日。"
    "生徒会室の机の上に、11人分の名前が書かれた用紙が置かれていた。"
    "{rb}三好{/rb}{rt}みよし{/rt}先輩、俺、{rb}大門{/rb}{rt}だいもん{/rt}、{rb}鷹野{/rb}{rt}たかの{/rt}、{rb}坂口{/rb}{rt}さかぐち{/rt}たち5人。"
    "そして、2年の幽霊部員だった{rb}桐生{/rb}{rt}きりゅう{/rt}先輩と{rb}宮下{/rb}{rt}みやした{/rt}先輩。"
    "二人は、三好先輩が毎朝家まで迎えに行って、ついに根負けしたらしい。"

    show chika normal
    with dissolve
    "{rb}千夏{/rb}{rt}ちか{/rt}先輩は、用紙を一行ずつ指でたどった。"
    "長い沈黙。"
    "三好先輩が、ごくりとつばを飲む音が聞こえた。"
    chika "一つ、確認させてください。{rb}桐生{/rb}{rt}きりゅう{/rt}くんと{rb}宮下{/rb}{rt}みやした{/rt}くんは、試合に出られる状態ですか"
    "二人が練習に来はじめて、まだ一週間だ。"
    "三好先輩が、すがるように俺を見た。"
    menu:
        "「正直、まだです。試合までに間に合わせます」":
            $ set_flag("520_正直")
            $ heart_up("千夏", "信頼", 4)
            miyoshi "は、{rb}早瀬{/rb}{rt}はやせ{/rt}！？"
            chika "……正直な報告は、助かります"
            chika "……試合までに、という言葉を記録しておきます"
        "「出られます」":
            $ set_flag("520_言い切った")
            $ heart_up("千夏", "ときめき", 2)
            chika "……言い切りましたね"
    voice "audio/voice/chika_kakunin.mp3"
    chika "……確認しました"
    chika "サッカー部の存続を認めます"
    voice "audio/voice/miyoshi_yosha.mp3"
    miyoshi "――っしゃあああ！！"
    voice "audio/voice/chika_shizukani.mp3"
    chika "生徒会室では静かに"
    miyoshi "ごめん！　でもありがとう{rb}七瀬{/rb}{rt}ななせ{/rt}！"

    show chika soft
    "一瞬だけ、千夏先輩の口元がゆるんだ。"
    "――気がした。"
    voice "audio/voice/chika_nn.mp3"
    chika "お礼を言われることはしていません。集めたのは、あなたたちです"
    "千夏先輩はもう、何事もなかったように次の書類をめくっていた。"
    $ heart_up("千夏", "ときめき", 2)
    chika "……それと、{rb}早瀬{/rb}{rt}はやせ{/rt}くん"
    chika "部の申請や連絡は、これからはあなたに送ります。三好くんは、読まないので"
    miyoshi "読むよ！？　たまに！"
    "差し出されたメモには、きれいな字で、トークアプリのIDが一行だけ書いてあった。"
    "あとで追加しよう、と思って、メモを四つに折って、カバンの内ポケットに入れた。"

    scene bg kohoku_ground_eve
    with dissolve
    $ bgm("明るい部活の曲")

    "11人が、初めてグラウンドにそろった。"
    scene cg practice_chaos at cam_pan_r(14.0)
    with Dissolve(1.0)
    "ユニフォームはばらばら。坂口たちはジャージですらない。"
    mori "{rb}森{/rb}{rt}もり{/rt}。……坂口が上がったら、俺が下がる係"
    eto "{rb}江藤{/rb}{rt}えとう{/rt}。ドリブルしかしない"
    koike "{rb}小池{/rb}{rt}こいけ{/rt}っす。パス係。たぶん"
    noguchi "{rb}野口{/rb}{rt}のぐち{/rt}。点取る係。ゲームではな"
    "2年の{rb}桐生{/rb}{rt}きりゅう{/rt}先輩と{rb}宮下{/rb}{rt}みやした{/rt}先輩は、ベンチに並んでスパイクのひもを結んでいた。"
    kiryu "……三好先輩、毎朝7時にインターホン鳴らすの、やめて"
    miyashita "うちの母さん、もう三好先輩の分の朝ごはん出してるからね"
    miyoshi "じゃあ明日から朝練な！"
    kiryu "……そういう意味じゃない"
    sakaguchi "てかさ、三好先輩のジャージ、なんでいつもそんな泥なの？　洗濯機ないの？"
    miyoshi "洗ってるわ！　毎日洗ってる！"
    miyoshi "朝、学校に来る前に、河川敷を一人で走ってんの。雨でも"
    sakaguchi "……なんで？　試合、なかったんでしょ"
    miyoshi "なかったから、だよ"
    miyoshi "2年間、一回も試合がなかった。走るのやめたら、サッカー部が本当になくなる気がしてさ"
    "三好先輩は、何でもないことみたいに笑った。"
    "初めて会った日の、あの泥だらけのジャージを思い出した。昨日今日の汚れじゃなかった理由が、やっと分かった。"
    sakaguchi "……ウケる。ガチじゃん"
    "坂口は笑ったけど、それ以上は何も言わなかった。"
    "大門はゴールの前で、ボールが来るたびに目をつぶっている。"
    "鷹野は、少し離れたところで一人でリフティングをしている。"
    "ひどいチームだ。"
    "でも、11人いる。"
    scene bg kohoku_ground_eve
    with dissolve

    $ se("サンダルが土をこする音")
    show kuroda normal
    with dissolve
    miyoshi "――{rb}黒田{/rb}{rt}くろだ{/rt}先生！"
    "本当に来た。"
    "黒田は、グラウンドを一周ぐるりと見回して、大きなため息をついた。"
    kuroda "……ひどいな"
    miyoshi "でも、11人です！"
    kuroda "約束は約束だ。……まずは、試合で見てやる"
    "黒田は、ポケットから折りたたんだ紙を出した。"
    kuroda "31日の日曜。練習試合を組んだ"
    kuroda "相手は、{rb}桜嶺{/rb}{rt}おうりょう{/rt}学園のBチームだ"
    $ bgm("（止まる）")
    "空気が、凍った。"
    "桜嶺。"
    "俺が行くはずだった学校。{rb}神城{/rb}{rt}かみしろ{/rt}がいる学校。"
    $ bgm("張りつめた静かな曲")
    kuroda "Bチームと言っても、県内のほとんどの高校より強い"
    $ learn("b_team")
    kuroda "自分たちがどこにいるのか、一回ちゃんと知っておけ"
    "黒田は、俺のほうをちらりと見た。"
    kuroda "{rb}早瀬{/rb}{rt}はやせ{/rt}。ひざが痛むなら、端で立ってるだけでいい。11人いれば、試合にはなる"
    ren "出ます"
    "考えるより先に、口が動いていた。"

    ############################################################################
    ## 自由行動③：試合の前（1日）
    ############################################################################
    scene black
    with Dissolve(1.0)
    "それから、一週間。"
    $ recap_text = CH1_RECAP[2]
    $ set_cal(CH1_FREE3_DATE, "放課後")       # 日付を先に変えてから、説明を出す
    $ bgm("作戦会議っぽい軽快な曲")
    window auto hide
    tuto "自由行動です。今回は1日だけ。試合の前に、誰と話しておくかを選びます。"
    tuto "それと、「サッカーノート」に言葉が書きこまれました。話の中でサッカーの言葉が出てくると、ひなたのノートに増えていきます。メニューの「相関図」の右上から読めます。"
    window auto hide
    call screen action_map(ch1_spots3(), "試合まで、あと3日。どこへ行く？", area="school")
    $ ch1_dest = _return
    if ch1_dest == "roof":
        call ch1_takano2
    elif ch1_dest == "clubroom":
        call ch1_miyoshi2
    elif ch1_dest == "staff":
        call ch1_kuroda2
    else:
        call ch1_practice
    ## その夜：自分から誰かにトークを送れる（nightcontact.rpy）
    call night_send(CH1_FREE3_DATE, "may")

    scene black
    with dissolve

    ############################################################################
    ## シーン6の前：桜嶺へ（5月31日・雨の朝）
    ##   マイクロバスで移動。車内のにぎやかさ → となりの席のひなた → 桜嶺の正門
    ############################################################################
label ch1_m531_bus:  # テスト用の目印（コンソールで jump ch1_m531_bus）
    $ set_cal("5月31日（日）", "練習試合　対 桜嶺学園B")
    scene bg kohoku_gate_rain
    with Dissolve(1.0)
    $ se("雨の音")
    $ bgm("日常の静かな曲")

    "朝7時。校門の前に、傘が12本並んでいた。"
    "11人と、ひなた。"
    show sakaguchi normal
    with dissolve
    sakaguchi "……雨じゃん。中止じゃないの、これ"
    show sakaguchi normal at right
    show miyoshi smile at left
    with dissolve
    miyoshi "サッカーは雨でもやる！　むしろ燃える！"
    sakaguchi "燃えるのは先輩だけっす"
    hide sakaguchi
    hide miyoshi
    with dissolve
    "古いエンジンの音がして、校門の前に、白いマイクロバスが止まった。"
    "車体の横に、かすれた文字。「{rb}潮見{/rb}{rt}しおみ{/rt}市　老人福祉センター」。"
    "運転席の窓が下がる。"
    show kuroda normal
    with dissolve
    kuroda "乗れ"
    miyoshi "先生、これどこから……"
    kuroda "借りた。……シートベルトはしろ。俺の運転は、あまり信用するな"
    sakaguchi "降りていいっすか"
    hide kuroda
    with dissolve

    scene bg bus_rain at cam_jog
    with dissolve
    $ bgm("とぼけた日常の曲")
    "ワイパーが、ぎこぎこと鳴っている。"
    "後ろの席では、{rb}坂口{/rb}{rt}さかぐち{/rt}たちが持ちこんだ携帯ゲーム機で大騒ぎしていた。"
    sakaguchi "おい！　今のパス、俺によこせって！"
    "いちばん前の席では、{rb}大門{/rb}{rt}だいもん{/rt}がひざの上に両手をそろえて、真っ青な顔をしていた。"
    voice "audio/voice/daimon_hii.mp3"
    daimon "一回も、止められる気がしません……"
    "{rb}三好{/rb}{rt}みよし{/rt}先輩が、突然歌い出した。校歌だった。"
    "誰も、ついてこなかった。"
    miyoshi "なんで誰も歌えないんだよ！"
    "{rb}鷹野{/rb}{rt}たかの{/rt}は、いちばん後ろの窓際で、イヤホンをしたまま外を見ていた。"
    "雨粒の向こうを、「{rb}桜嶺{/rb}{rt}おうりょう{/rt}」と書かれた国道の看板が流れていった。"

    ## となりの席：ひなた
    show hinata proud
    with dissolve
    "となりの席には、ひなたが座っていた。"
    "ひざの上に、大きな保冷バッグ。中身は、全員ぶんのおにぎりらしい。"
    hinata "4時起き。ほめていいよ"
    ren "……すごいな"
    hinata "もっと"
    ren "すごいすごい"
    show hinata pout
    hinata "心がこもってない"
    hide hinata
    with dissolve

    "バスが国道に出て、揺れが一定になったころ。"
    "こつん、と。右の肩に、重みがかかった。"
    scene cg bus_hinata at cam_push(10.0, 1.05)
    with Dissolve(1.0)
    $ bgm("あたたかいアコースティックギター")
    "ひなたが、寝ていた。"
    "4時起きは、本当だったらしい。"
    "シャンプーの匂いがした。"
    "10年以上見てきた顔なのに、近すぎて、知らない人みたいだった。"
    sakaguchi "うわ、見て見て。あそこ、いい感じじゃね？"
    miyoshi "やめてやれ！　寝かせてやれ！"
    "三好先輩の声がいちばん大きかった。"

    scene bg bus_rain
    with dissolve
    show hinata stare
    with dissolve
    "ひなたが、ぱちっと目を開けた。"
    hinata "…………"
    hinata "……寝てない"
    ren "寝てた"
    show hinata pout
    hinata "寝てない。目を閉じて、作戦を考えてただけ"
    "耳まで真っ赤だった。"

    menu:
        "「よだれ、ついてる」":
            hinata "ついてない！"
            "……念のため袖で口をぬぐうのを、俺は見なかったことにした。"
            $ heart_up("ひなた", "信頼", 3)
        "「……もう少し寝てていいぞ」":
            show hinata teary
            hinata "……ずるいよ、それ"
            "ひなたは、窓のほうを向いた。"
            "窓ガラスに映ったひなたの口もとが、笑っていた。"
            $ heart_up("ひなた", "ときめき", 4)
        "「おにぎり、ありがとな」":
            show hinata smile
            hinata "……どういたしまして"
            hinata "梅と、おかかと、ツナマヨ。ツナマヨは、{rb}蓮{/rb}{rt}れん{/rt}のぶんだけだから。みんなには内緒"
            $ heart_up("ひなた", "信頼", 3)

    show hinata serious
    "ひなたは、少し声を落とした。"
    hinata "……ねえ。ひざ、今日はどう？"
    hinata "雨の日、ケガしてからちょっと痛むって言ってたでしょ"
    "こいつには、何も隠せない。"

    menu:
        "「平気だ」":
            show hinata normal
            hinata "……そっか"
            "ひなたは、それ以上聞かなかった。"
            "保冷バッグのすき間から、湿布の箱がのぞいていた。"
            $ up("無理ゲージ", 3)
            $ heart_up("ひなた", "さみしさ", 3)
        "「少し重い。でも、出る」":
            show hinata smile
            hinata "うん。言ってくれてよかった"
            hinata "無理だと思ったら、ベンチ見て。わたし、ずっと見てるから"
            $ heart_up("ひなた", "信頼", 4)
            $ up("無理ゲージ", -2)
        "「……桜嶺を見たら、たぶん忘れる」":
            show hinata forcesmile
            hinata "……それが心配なんだってば"
            "ひなたは、ため息をついて笑った。"
            $ lean("野心型")
    hide hinata
    with dissolve

    ## 桜嶺学園の正門
    scene bg ouryo_gate_rain at cam_tilt_up(6.0)
    with Dissolve(1.2)
    $ bgm("張りつめた静かな曲")
    "バスが止まった。"
    "窓の外に、それが見えた。"
    "正門だけで、{rb}港北{/rb}{rt}こうほく{/rt}の校舎くらいの幅がある。"
    "奥には、ガラス張りの校舎。屋根のついた通路の先に、何棟もの寮。"
    "傘をさした白いジャージの列が、門の内側を走っていく。"
    "一列、二列……数えるのをやめた。"
    sakaguchi "……え、ここ、大学？"
    daimon "ひ、人が、多いです……"
    miyoshi "サッカー部だけで、120人いるらしい"
    "誰かが、ごくりとつばを飲んだ。"
    "ここに、来るはずだった。"
    "推薦が決まった日。母さんが、店を閉めて赤飯を炊いた日。"
    "あの冬がなければ、俺は今、あの白い列の中にいた。"
    show takano normal
    with dissolve
    takano "……ぼけっとしてんな。行くぞ"
    "鷹野が、いちばん最初にバスを降りた。"
    "傘も、ささずに。"
    hide takano
    with dissolve

    scene black
    with dissolve

    ############################################################################
    ## シーン6：0−9（5月末・日曜日）
    ############################################################################
label ch1_m531:      # 試合のテスト用の目印（コンソールで jump ch1_m531 とすると、ここから始められる）
    $ set_cal("5月31日（日）", "練習試合　対 桜嶺学園B")
    scene cg m531_warmup at cam_pan_r(16.0)
    with Dissolve(1.0)
    $ se("雨の音")
    $ bgm("重く静かな曲")

    "{rb}桜嶺{/rb}{rt}おうりょう{/rt}学園のグラウンドは、聞いていたとおり天然芝だった。"
    "雨に濡れた緑が、どこまでも平らに広がっている。"
    "土のグラウンドしか知らない{rb}坂口{/rb}{rt}さかぐち{/rt}たちは、口を開けたまま固まっていた。"
    sakaguchi "……ここ、ほんとに高校？"
    "向こうのベンチ前で、白いジャージの集団がアップを始めている。"
    "掛け声。ボール回し。誰一人、無駄な動きをしていない。"
    "これが、Bチーム。"
    "ベンチの奥で、腕を組んだ大人が一人、こっちを見ていた。"
    "桜嶺の監督、{rb}鬼塚{/rb}{rt}おにづか{/rt}。推薦の面談で、一度だけ会った人だ。"

    scene cg m531_kamishiro at cam_push_at(12.0, 1.08, 0.4, 0.0)
    with dissolve
    "スタンドの屋根の下に、白と金のジャージが一人だけ立っていた。"
    "{rb}神城{/rb}{rt}かみしろ{/rt}だ。"
    "1年でもうAチームにいるあいつが、なぜかこの試合を見に来ている。"
    show cg m531_kamishiro at cam_snap(1.2, 0.4, 0.0)
    "目が合った。"
    "神城の口が、何か言いかけて、閉じた。"
    "それだけで、あいつは視線をそらした。"
    "そらした先には、桜嶺のベンチがあった。"
    "腕を組んだ鬼塚監督が、神城のほうを見もせずに、何か一言だけ言った。"
    "神城の肩が、ほんの少しこわばった。"
    if persistent.trial_cleared:
        "――中3の決勝のスタンド。最前列で腕を組んでいたのも、この人だった。"

    ## キックオフの前の円陣
    scene cg m531_huddle at cam_push(10.0, 1.05)
    with dissolve
    "キックオフの前。{rb}三好{/rb}{rt}みよし{/rt}先輩が、全員の肩を引き寄せた。"
    miyoshi "いいか！　相手が誰だろうと関係ない！"
    miyoshi "この11人で、最初の試合だ！　楽しんでいくぞ！"
    voice "audio/voice/daimon_hai.mp3"
    daimon "は、はいっ！！"
    "声が裏返ったのは、うちのキーパーだけだった。"
    "雨の中で、11人の肩がぶつかり合った。"
    "ななめ向かいの{rb}大門{/rb}{rt}だいもん{/rt}は、顔がこわばっていた。"
    "こめかみを伝っているのが雨なのか汗なのか、たぶん本人にも分かっていない。"
    "スタンドの隅で、紺色の傘が一本だけ、こっちを向いていた。"
    "誰の傘かは、雨でよく見えなかった。"

    ## キックオフ。ここから試合の演出（黒帯とスコアボード）
    $ se("キックオフの笛")
    $ bgm("試合の曲（劣勢）")
    $ sb_set("前半", 3, 0, 0, 0, "#2a5bd7", "#f2f2ee")     # 港北（青）対 桜嶺B（白）
    scene bg ouryo_ground_rain at cam_jog
    with dissolve
    show screen letterbox
    show screen scoreboard

    "前半3分。"

    scene cg m531_keeper at cam_snap(1.1, 0.5, 0.4)
    with hpunch
    $ goal("桜嶺B", away=1)
    "1点目。"
    "大門が飛んだ。でも、ボールはその指先の、ずっと先を抜けていった。"

    $ sb_set(mm=11)
    scene bg ouryo_ground_rain at cam_pan_r(10.0)
    with flash
    $ goal("桜嶺B", away=2)
    "前半11分。2点目。"
    voice "audio/voice/sakaguchi_ball.mp3"
    sakaguchi "ちょ、ボールどこ！？"
    "坂口たちは、ボールがどこにあるのかすら分かっていない。"

    $ sb_set(mm=19)
    scene cg m531_tackle at cam_snap(1.1, 0.5, 0.3)
    with hpunch
    $ se("スパイクが芝をえぐる音")
    "前半19分。一度だけ、ボールが来た。"
    "仕掛けた瞬間、白い影が泥をはね上げて滑りこんできた。"
    show cg m531_tackle at slowmo(4.0)
    $ se("ボールを奪われる音")
    "ボールだけを、きれいに刈り取られた。"
    "刈り取ったのは、白の14番だった。"
    "14番は、{rb}鷹野{/rb}{rt}たかの{/rt}の横を走り抜けながら、何か言って笑った。"
    "鷹野は、何も言い返さなかった。"
    if flags.get("ch1_takano2"):
        "……あいつだ。屋上の動画の、鷹野とジュニアユースで一緒だったやつ。"

    $ sb_set(mm=25)
    scene bg ouryo_ground_rain at cam_snap(1.15)
    with hpunch
    "前半25分。左サイドバックの{rb}宮下{/rb}{rt}みやした{/rt}先輩が、足をつって倒れた。"
    "空いた左から、低いボールがゴール前へ。"
    voice "audio/voice/daimon_muri.mp3"
    daimon "む、無理ですーっ！"
    $ goal("桜嶺B", away=3)
    with vpunch
    "3点目。"
    "雨で重くなったボールが、俺の足もとにだけ来ない。"
    "来ないように、されている。"

    ## 前半終了間際。ここで選んだことで、前半の終わり方が変わる
    $ sb_set(mm=44, ss=10)
    scene bg ouryo_ground_rain at cam_push(6.0, 1.15)
    with dissolve
    "前半終了間際。"
    $ se("ボールが転がる音")
    "もう一度、俺のところにボールが転がってきた。"
    voice "audio/voice/miyoshi_ren.mp3"
    miyoshi "{rb}蓮{/rb}{rt}れん{/rt}っ！"
    "……三好先輩に名前で呼ばれたのは、初めてだった。"

    ## 職員室で黒田と話していれば、ベンチから一言だけ聞こえる
    if flags.get("ch1_kuroda2"):
        "雨の音にまぎれて、ベンチから低い声がした。"
        voice "audio/voice/kuroda_kao.mp3"
        kuroda "……顔、上げろ"
        show screen speedlines
        "顔を上げる。全員の位置が、一枚の絵みたいに見えた。"
    else:
        show screen speedlines
        "前を向く。"

    ## 作戦ボード：蓮がボールを持った瞬間（紺が港北。右へ攻める）
    $ tactics(caption="前半44分　0−3", dots=[
        ("h", "大門", (4, 34)), ("h", "", (28, 24)), ("h", "", (27, 46)),
        ("h", "三好", (42, 40)), ("h", "坂口", (58, 13)), ("h", "", (46, 18)),
        ("h", "鷹野", (68, 55), (72, 54), 0.4, 0.8),
        ("a", "", (40, 30)), ("a", "", (49, 25)), ("a", "", (48, 51)),
        ("a", "", (76, 24)),
        ("a", "", (68, 29)),
        ("a", "", (60, 51)),
        ("a", "", (100, 34)),
        ("ren", "蓮", (56, 38)),
        ("ball", "", (57.5, 39.5)),
        ],
        arrows=[((68, 55), (82, 52), 0.6, "w"),
                ((68, 29), (59, 35), 0.5, "r"), ((60, 51), (57.5, 43), 0.8, "r")])
    "右に{rb}鷹野{/rb}{rt}たかの{/rt}。ゴール前に、誰もいない。"
    voice "audio/voice/takano_kocchi.mp3"
    takano "こっちだ！　よこせっ！"
    "あの鷹野が、声を張り上げてボールを呼んでいる。"
    "白が二人、両側から寄せてくる。後ろには、三好先輩。"
    hide screen speedlines
    $ tactics_off()

    menu:
        "自分でドリブルで行く":
            $ m531_play = "dribble"
            $ lean("野心型")
            $ up("技術", 2)
            $ up("無理ゲージ", 5)
        "鷹野にパスを出す":
            $ m531_play = "pass"
            $ lean("仲間型")
            $ bond_up("鷹野", 5)
        "一度下げて、落ち着かせる":
            $ m531_play = "back"
            $ lean("求道型")
            $ up("戦術眼", 3)

    if m531_play == "dribble":
        ## 自分で行く → 囲まれて、カウンターで4点目
        $ se("ボールを蹴る音")
        $ tactics(caption="前半44分　0−3", dots=[
            ("h", "大門", (4, 34)), ("h", "", (28, 24)), ("h", "", (27, 46)),
            ("h", "三好", (42, 40)), ("h", "坂口", (58, 13)), ("h", "", (46, 18)),
            ("h", "鷹野", (72, 54)),
            ("a", "", (40, 30)), ("a", "", (49, 25)), ("a", "", (48, 51)),
            ("a", "", (76, 24)),
            ("a", "", (68, 29), (63, 35), 0.2, 0.7),
            ("a", "", (60, 51), (62, 42.5), 0.3, 0.7),
            ("a", "", (100, 34)),
            ("ren", "蓮", (56, 38), (61, 38.5), 0.1, 0.7),
            ("ball", "", (57.5, 39.5), (62.5, 39.5), 0.1, 0.7),
            ],
            arrows=[((56, 38), (64, 38.5), 0.0, "w")])
        "前に持ち出す。一人目の白が、もう目の前にいた。"
        $ tactics_off()

        scene cg m531_surrounded at cam_snap(1.12, 0.5, 0.35)
        with hpunch
        "顔を上げた瞬間には、もう二人に囲まれていた。"
        "読めていた。読めていたのに、体がついていかない。"
        show cg m531_surrounded at slowmo(4.0)
        "冬から止まっていた足は、まだ自分が思っているよりずっと重かった。"
        $ se("ボールを奪われる音")
        scene bg ouryo_ground_rain at cam_jog
        with flash

    elif m531_play == "pass":
        ## 鷹野へ → 港北のこの日初めてのシュート。止められて、カウンターで4点目
        $ se("ボールを蹴る音")
        $ tactics(caption="前半44分　0−3", dots=[
            ("h", "大門", (4, 34)), ("h", "", (28, 24)), ("h", "", (27, 46)),
            ("h", "三好", (42, 40)), ("h", "坂口", (58, 13)), ("h", "", (46, 18)),
            ("h", "鷹野", (72, 54)),
            ("a", "", (40, 30)), ("a", "", (49, 25)), ("a", "", (48, 51)),
            ("a", "", (76, 24), (84, 36), 0.6, 1.0),
            ("a", "", (68, 29), (61, 35), 0.1, 0.6),
            ("a", "", (60, 51), (58, 43.5), 0.4, 0.6),
            ("a", "", (100, 34)),
            ("ren", "蓮", (56, 38)),
            ("ball", "", (57.5, 39.5), (73.5, 55), 0.15, 0.45),
            ],
            arrows=[((56, 38), (72, 54), 0.0, "y")])
        "右へ。雨で重いボールを、思いきり押し出した。"
        "鷹野が、走りながら止める。トラップは、少しも乱れなかった。"

        $ tactics(caption="前半44分　0−3", dots=[
            ("h", "大門", (4, 34)), ("h", "", (28, 24)), ("h", "", (27, 46)),
            ("h", "三好", (42, 40)), ("h", "坂口", (58, 13)), ("h", "", (46, 18)),
            ("h", "鷹野", (72, 54), (89, 53), 0.0, 0.9),
            ("a", "", (40, 30)), ("a", "", (49, 25)), ("a", "", (48, 51)),
            ("a", "", (84, 36), (88, 47), 0.3, 0.7),
            ("a", "", (61, 35)),
            ("a", "", (58, 43.5)),
            ("a", "", (100, 34), (101, 37), 1.2, 0.3),
            ("ren", "蓮", (56, 38), (66, 40), 0.3, 1.2),
            ("ball", "", (73.5, 55), (90.5, 54), 0.0, 0.9),
            ],
            arrows=[((72, 54), (89, 53), 0.0, "w"), ((89, 53), (104, 36.5), 1.0, "y")])
        "一人かわして、ペナルティエリアの角。"
        $ se("ボールを蹴る音")
        "振り抜いた。"
        $ tactics_off()

        scene bg ouryo_ground_rain at cam_snap(1.35, 0.6, 0.62)      # ゴールに寄る
        with hpunch
        $ se("鈍い衝突音")
        "――キーパーの手に当たって、ボールは高く跳ね上がった。"
        "{rb}港北{/rb}{rt}こうほく{/rt}の、この日初めてのシュートだった。"
        voice "audio/voice/miyoshi_nice.mp3"
        miyoshi "ナイスシュートだ、鷹野ぉ！"
        voice "audio/voice/takano_chi.mp3"
        takano "……ちっ"
        "返事のかわりの舌打ちだった。でも、鷹野は口のはしを、かすかに上げていた。"
        "こぼれ球は、白いユニフォームが先に拾っていた。"
        $ set_flag("531_初シュート")

    else:
        ## 一度下げる → ボールを回して、0−3のまま前半を終える
        $ se("ボールを蹴る音")
        $ tactics(caption="前半44分　0−3", dots=[
            ("h", "大門", (4, 34)), ("h", "", (28, 24), (24, 18), 0.6, 0.9), ("h", "", (27, 46), (24, 52), 0.6, 0.9),
            ("h", "三好", (42, 40)), ("h", "坂口", (58, 13), (52, 10), 0.5, 0.9), ("h", "", (46, 18), (40, 22), 0.5, 0.9),
            ("h", "鷹野", (72, 54)),
            ("a", "", (40, 30), (44, 34), 0.6, 0.8), ("a", "", (49, 25)), ("a", "", (48, 51)),
            ("a", "", (76, 24)),
            ("a", "", (68, 29), (60, 31), 0.3, 0.7),
            ("a", "", (60, 51), (59, 45), 0.3, 0.7),
            ("a", "", (100, 34)),
            ("ren", "蓮", (56, 38), (56, 28), 0.4, 0.9),
            ("ball", "", (57.5, 39.5), (43.5, 41.5), 0.1, 0.45),
            ],
            arrows=[((56, 38), (43, 40), 0.0, "y"), ((56, 37), (56, 28), 0.5, "w")])
        "一度、後ろの三好先輩に下げた。"
        "寄せてきた白い二人が、獲物を見失ったみたいに足を止める。"
        $ tactics_off()

        scene bg ouryo_ground_rain at cam_pan_r(8.0)
        with dissolve
        miyoshi "いいぞ！　つなげ、つなげ！"
        "ボールを回す。つなぐ。取られない。それだけを考えた。"
        "大門まで戻して、また三好先輩へ。不格好でも、ボールは港北の足もとにあった。"

    if m531_play != "back":
        ## カウンター：白いボールが、一気に港北のゴールへ（奪われた場所から）
        $ m531_lost = (62, 38) if m531_play == "dribble" else (86, 43)
        $ tactics(caption="前半44分　0−3", dots=[
            ("h", "大門", (4, 34), (5, 37), 1.0, 0.3), ("h", "", (28, 24), (22, 30), 0.3, 1.0), ("h", "", (27, 46), (21, 41), 0.3, 1.0),
            ("h", "三好", (42, 40), (24, 38), 0.2, 1.3),
            ("a", "", (40, 30), (14, 32), 0.3, 1.0), ("a", "", (48, 51), (16, 44), 0.4, 1.0),
            ("ball", "", m531_lost, (13, 33), 0.1, 0.8),
            ],
            arrows=[(m531_lost, (14, 33), 0.0, "r"), ((42, 40), (25, 38), 0.2, "w")])
        voice "audio/voice/miyoshi_modore.mp3"
        miyoshi "戻れ！　戻れーっ！"
        $ tactics_off()
        scene bg ouryo_ground_rain at cam_jog
        with flash
        $ goal("桜嶺B", away=4)
        "カウンター。4点目。"
        if m531_play == "pass":
            "それでも、さっきのシュートの音だけは、まだ耳に残っていた。"

    hide screen goal_banner         # 早くクリックしても、GOAL の帯が次の場面に残らないように
    $ se("前半終了の笛")
    if m531_play == "back":
        "前半は、0−3のまま終わった。"
        "たったそれだけのことが、ベンチに戻るとき、妙に誇らしかった。"

    hide screen scoreboard
    hide screen letterbox
    scene black
    with Dissolve(0.8)

    ## 後半は、色が抜けたまま、ぼんやりと
    scene bg ouryo_ground_rain at slowmo(10.0)
    with Dissolve(0.8)

    "後半のことは、あまり覚えていない。"
    if m531_play == "back":
        "4点目。5点目。6点目。"
    else:
        "5点目。6点目。7点目。"
    "数えるのをやめたころ、気づいた。"
    "一人だけ、ずっと走っている人がいる。"

    scene cg miyoshi_rain at cam_push(12.0, 1.06)
    with Dissolve(1.0)
    $ bgm("静かなピアノ（試合の音が遠のく）")

    "{rb}三好{/rb}{rt}みよし{/rt}先輩だった。"
    "技術なんて、ないに等しい。何度もかわされて、何度も転んで、そのたびに泥だらけで起き上がる。"
    "ボールを持った相手に、また走っていく。"
    "0−8になっても。0−9になっても。"
    miyoshi "まだだ！　まだ終わってないぞ！"
    miyoshi "声出せ！　{rb}港北{/rb}{rt}こうほく{/rt}！"
    "誰も、何も言わなかった。"
    "でも、坂口が顔を上げた。"
    "大門が、ゴールの前で両手を広げた。"
    "鷹野が、舌打ちしながらもう一度だけ走り出した。"

    $ se("試合終了の笛")
    scene cg m531_final at cam_pull(10.0, 1.08)
    with Dissolve(1.0)
    "0−9。"
    "この11人の、最初の試合だった。"
    $ bond_up("三好", 5)
    $ up("メンタル", 3)

    scene bg ouryo_side_rain
    with dissolve
    show kuroda umbrella
    with dissolve
    kuroda "どうだった"
    "誰も答えない。答えられない。"
    kuroda "これが今のお前らだ。……まあ、一個だけ収穫はあった"
    kuroda "三好。最後まで足を止めなかったのは、お前だけだ"
    "三好先輩は、泥だらけの顔で笑った。"
    miyoshi "だって、楽しかったから"
    "強がりには聞こえなかった。"
    kuroda "……来週から、練習見てやる。毎日だ"
    hide kuroda
    with dissolve
    "{rb}黒田{/rb}{rt}くろだ{/rt}は、それだけ言って先に歩き出した。"
    "左足を少し引きずりながら。"

    ## 試合のふり返り
    python:
        _rows = [("スコア", "0−9")]
        _rows.append(("前半44分", {"dribble": "自分で持ち出した　→　二人に囲まれて、カウンターで4点目",
                                  "pass": "鷹野にパス　→　港北の初シュート（キーパーに止められた）",
                                  "back": "一度下げた　→　0−3のまま前半を終えた"}.get(m531_play, "―")))
        _rows.append(("シュート", "1本（鷹野）" if m531_play == "pass" else "0本"))
        _rows.append(("最後まで走った人", "三好先輩"))
    call screen match_report("練習試合　港北 対 桜嶺学園B", _rows, "ひなた：0−9。でも、11人全員が、最後までピッチにいた")

    ############################################################################
    ## シーン7：港の楽譜（同じ日の夕方）
    ############################################################################
    $ set_cal("5月31日（日）", "夕方", quiet=True)
    scene bg harbor_sunset
    with Dissolve(1.0)
    $ se("波の音、カモメ")
    $ bgm("（なし）")

    "学校の前でバスを降りたころには、雨はやんでいた。"
    "みんなと別れて、一人で港沿いを歩く。"
    "まっすぐ家に帰る気には、なれなかった。"
    "雲の切れ間から、夕日が海に落ちていく。"
    $ memory("cg m531_surrounded", "5月31日　桜嶺学園B")
    "0−9。"
    "分かっていた。分かっていたはずだった。"
    "それでも、あの芝の上で、俺は一度もあいつらに通用しなかった。"
    $ memory_off()

    $ se("強い海風")
    "風が吹いた。"
    "白い紙が何枚も、俺の顔の前を舞っていった。"
    voice "audio/voice/saki_a.mp3"
    saki_q "――あっ"
    "防波堤の上で、女の子が手を伸ばしていた。"
    "紙のうちの一枚が、俺の足もとに落ちる。"
    "拾い上げると、それは楽譜だった。"
    "細かい音符が、びっしりと並んでいる。"

    scene cg saki_meet
    with dissolve
    $ bgm("静かなピアノの旋律")
    pause           # 一枚絵は、クリック（タップ）するまで見せたままにする

    scene bg harbor_sunset
    show saki normal
    with dissolve
    "色素の薄い、短い髪。"
    "白いブレザー。――{rb}桜嶺{/rb}{rt}おうりょう{/rt}の制服だ。"
    voice "audio/voice/saki_arigato.mp3"
    saki_q "……ありがと"
    "楽譜を受け取ろうとした手が、途中で止まった。"
    "彼女の視線が、俺の肩にかかった泥だらけのスポーツバッグに落ちる。"
    "バッグから、スパイクのひもがはみ出していた。"

    show saki frown
    voice "audio/voice/saki_soccerbu.mp3"
    saki_q "……サッカー部？"
    ren "ああ。今日、桜嶺と練習試合で……0−9で負けた"
    voice "audio/voice/saki_sou.mp3"
    saki_q "そう"
    voice "audio/voice/saki_saiaku.mp3"
    saki_q "最悪"
    ren "……は？"
    voice "audio/voice/saki_fun.mp3"
    saki_q "サッカーなんて、なくなればいいのに"
    "彼女は、楽譜をひったくるように受け取った。"

    menu:
        "「……名前、聞いてもいいか」":
            $ heart_up("紗希", "ときめき", 5)
            $ set_flag("紗希_名前を聞いた")
            voice "audio/voice/saki_haa.mp3"
            saki_q "教える理由、ある？"
            ren "楽譜、拾った"
            voice "audio/voice/saki_nn.mp3"
            saki_q "……"
            voice "audio/voice/saki_name.mp3"
            saki_q "…………{rb}紗希{/rb}{rt}さき{/rt}"
            "小さな声だった。名字は、言わなかった。"
            $ meet("紗希")      # 名前を聞いたときだけ、相関図に出す（聞かなかった人は、第2章の満員電車で）

        "「何かあったのか？」":
            $ heart_up("紗希", "信頼", 5)
            voice "audio/voice/saki_betsuni.mp3"
            saki_q "……別に。あなたには関係ない"
            "彼女は、海のほうへ目をそらした。"
            voice "audio/voice/saki_sigh.mp3"
            saki_q "……嫌いなだけ。ボールしか見えない人たち"

        "何も言わずに見送る":
            $ set_flag("紗希_出会い遅れ")

    hide saki
    with dissolve
    "彼女は背を向けて、防波堤を歩いていった。"
    "夕日の中で、白いブレザーが遠ざかっていく。"
    "桜嶺の生徒が、なんでこんな港にいるんだろう。"
    "それに、サッカーが嫌いな桜嶺の生徒なんて、いるんだろうか。"
    "足もとに、もう一枚だけ楽譜が残っていた。"
    "端に、小さく名字が書いてある。"
    "「{rb}鬼塚{/rb}{rt}おにづか{/rt}」"
    "……鬼塚？"
    "桜嶺の監督と、同じ名字だった。"

    ############################################################################
    ## シーン8：トークグループ（同じ日の夜）
    ############################################################################
    scene black
    with dissolve
    $ amb_stop()            # 港の波の音を止める
    $ set_cal("5月31日（日）", "夜")
    scene bg ren_room_night
    with dissolve
    $ bgm("静かな夜の曲")

    "ベッドに倒れこんだ瞬間、全身が悲鳴を上げた。"
    "ひざは――大丈夫だ。少し熱を持っているだけ。"

    $ se("トークアプリの通知音（連続）")
    "ひなたが、やっと部のグループを作ったらしい。"
    "これまでの連絡は、ひなたが一人ずつ送ってくれていた。"
    window auto hide
    $ talk_start("港北サッカー部（12）", "20:41")
    $ talk("ひなた", "グループ作りました！　港北サッカー部です")
    $ talk("ひなた", "今日はおつかれさまでした。明日からもよろしくお願いします")
    $ talk("三好", "おつかれ！！！！！！")
    $ talk("三好", "最高の試合だった！！！！")
    $ talk("坂口", "0−9のどこが最高なんすか")
    $ talk("坂口", "てか明日、筋肉痛で死ぬ")
    $ talk("大門", "僕、ボールに9回さわれました。全部、ゴールの中からでしたけど")
    $ talk("桐生", "それはさわったって言わない")
    $ talk("宮下", "わろた")
    $ talk("三好", "明日の朝練、6時半な！")
    $ talk("坂口", "は？")
    $ talk("大門", "は、はい！")

    "{rb}鷹野{/rb}{rt}たかの{/rt}だけは、何も書きこんでいなかった。"
    "でも既読の数は、どのメッセージにも、一人も欠けずに11ついていた。"

    window auto hide
    $ talk_end()
    $ talk_start("ひなた", "23:12")
    $ talk("ひなた", "ひざ、大丈夫？")
    $ talk("ひなた", "ちゃんと冷やしてね")

    $ ch1_reply = talk_choose([("大丈夫。ちゃんと冷やしてる", "ok"), ("ちょっと痛い。でも、明日も行く", "honest"), ("（既読のまま寝る）", "ignore")])

    if ch1_reply == "ok":
        $ talk_me("大丈夫。ちゃんと冷やしてる")
        $ heart_up("ひなた", "信頼", 3)
        $ talk("ひなた", "ほんとかなあ")
        $ talk("ひなた", "眉毛、上がってない？")
    elif ch1_reply == "honest":
        $ talk_me("ちょっと痛い。でも、明日も行く")
        $ heart_up("ひなた", "信頼", 6)
        $ up("無理ゲージ", -5)
        $ talk("ひなた", "正直でよろしい")
        $ talk("ひなた", "明日、湿布持ってくね")
    else:
        $ heart_up("ひなた", "さみしさ", 5)
        $ talk_system("――そのまま眠ってしまった。翌朝、通知が残っていた")
        $ talk("ひなた", "おやすみ")

    window auto hide
    $ talk_end()

    ## 神城から、あの冬以来のトーク（プロローグでは返事を送れなかった）
    $ talk_start("神城 凌", "23:40")
    if ch1_reply == "ignore":
        $ talk_system("昨夜 23:40")      # 既読のまま寝た道は、翌朝に読む
    $ talk("神城", "今日、見てた")
    $ talk("神城", "最後まで走ってたキャプテン、いいな")
    $ talk("神城", "……監督が、お前のこと聞いてきた")
    $ talk_me("次は、試合で会う")
    window auto hide
    $ talk_end()
    "決勝の日以来、初めて返事を送った。"

    if ch1_reply != "ignore":
        "スマホを置いて、天井を見上げた。"
    else:
        "布団の中で、もう一度天井を見上げた。"
    "0−9。{rb}三好{/rb}{rt}みよし{/rt}先輩の泥だらけの笑顔。{rb}千夏{/rb}{rt}ちか{/rt}先輩の、気のせいかもしれない微笑み。{rb}黒田{/rb}{rt}くろだ{/rt}の引きずる左足。"
    "それから、港で会った、サッカーが嫌いな女の子。"
    "部員3人だったサッカー部は、あの試合でやっと、チームになりかけていた。"
    "最悪のスタートだ。"
    "でも、なぜか――"
    if ch1_reply != "ignore":
        "明日の朝練が、少しだけ楽しみだった。"
    else:
        "今日の朝練が、少しだけ楽しみだった。"

    scene black
    with Dissolve(1.5)
    call show_title("第1章　はじまりの十一人", "完")
    jump chapter2


################################################################################
## 自由行動②の行き先：5月の放課後
################################################################################

## 生徒会室：千夏のカメラ
label ch1_council:
    $ set_flag("ch1_council")
    scene bg student_council
    with dissolve
    "生徒会室のドアをノックすると、中から「どうぞ」と短い声がした。"
    show chika normal
    with dissolve
    voice "audio/voice/chika_fu.mp3"
    chika "……{rb}早瀬{/rb}{rt}はやせ{/rt}くん。締め切りは20日です。まだ日にちはありますが"
    ren "途中経過を出しに来ました。{rb}三好{/rb}{rt}みよし{/rt}先輩に頼まれて"
    "{rb}千夏{/rb}{rt}ちか{/rt}先輩は名簿を受け取ると、黙って目を通した。"
    "机の端に、古いフィルムカメラが置いてあった。"
    ren "そのカメラ……"
    chika "生徒会の記録用です。仕事の一つです"
    "千夏先輩は、カメラをさりげなく引き出しにしまった。"

    menu:
        "「グラウンドも撮ってください。いつか、ちゃんとしたチームになるので」":
            chika "……撮る価値があるチームになったら、考えます"
            "千夏先輩は顔を上げなかった。"
            "でも、名簿の「サッカー部」の欄に、丸をつけていた。"
            $ heart_up("千夏", "信頼", 4)
        "「写真、好きなんですか」":
            voice "audio/voice/chika_haa.mp3"
            chika "仕事だと言いました"
            "それ以上は聞くな、という顔だった。"
            "でも、引き出しを閉める指先は、いつもより丁寧だった。"
            $ heart_up("千夏", "ときめき", 3)

    voice "audio/voice/chika_nn.mp3"
    chika "用件は以上ですか"
    ren "はい。失礼しました"
    "ドアを閉める直前、カシャ、と小さな音が聞こえた。"
    "――シャッターの音、だったのかもしれない。"
    hide chika
    with dissolve
    return

## 柔道場：大門の受け身
label ch1_daimon2:
    $ set_flag("ch1_daimon2")
    scene bg judo_hall
    with dissolve
    "柔道場をのぞくと、畳の上に大きな背中が正座していた。"
    "{rb}大門{/rb}{rt}だいもん{/rt}だ。部から借りていた道着を、柔道部の部長に返しに来たらしい。"
    "部長が出ていっても、大門は畳に手をついたまま、しばらく動かなかった。"
    ren "……大門"
    show daimon normal
    with dissolve
    daimon "あ、{rb}早瀬{/rb}{rt}はやせ{/rt}くん。……見てましたか"
    daimon "やめるって言ったら、「お前は投げるのは下手だったけど、受け身だけは部でいちばんだった」って"
    ren "受け身？"
    daimon "倒れても、ケガしない倒れ方。……それしか、うまくならなかったんです"
    "大門は、自分の大きな手を見つめていた。"

    menu:
        "「それ、キーパーにいちばん大事なやつだ」":
            daimon "え？"
            ren "キーパーは、何回も飛んで、何回も倒れる。ケガしない倒れ方ができるなら、それだけで才能だよ"
            "大門の目が、まるくなった。"
            daimon "……そ、そうでしょうか"
            $ bond_up("大門", 6)
            $ up("戦術眼", 2)
        "「明日から、ボールが怖くなくなるまで付き合うよ」":
            daimon "ほ、ほんとですか？　……目、つぶっちゃいますけど、いいですか？"
            ren "最初はな"
            $ bond_up("大門", 4)
            $ up("フィジカル", 1)

    "柔道場を出るとき、大門は畳に向かって、もう一度深く頭を下げた。"
    hide daimon
    with dissolve
    return

## 港への坂道：ひなたのリハビリの本
label ch1_walk_hinata:
    $ set_flag("ch1_walk")
    scene bg slope_eve
    with dissolve
    "練習のあと、ひなたと並んで帰った。"
    "港へ下りる坂道。商店街のシャッターが、半分くらい閉まっている。"
    show hinata normal
    with dissolve
    voice "audio/voice/hinata_nee.mp3"
    hinata "ねえ、{rb}蓮{/rb}{rt}れん{/rt}。ちょっとそこ座って"
    "ひなたが、バス停のベンチを指さした。"
    ren "なんだよ"
    voice "audio/voice/hinata_hora.mp3"
    hinata "いいから。右ひざ、出して"
    "ひなたは、カバンから分厚い本を取り出した。『スポーツ障害のリハビリテーション』。"
    ren "……それ、どうしたんだよ"
    hinata "図書館で借りた。トレーナーの勉強、ちょっとずつしてるの"
    "ひなたの指が、ひざのお皿のまわりを、確かめるように押していく。"
    voice "audio/voice/hinata_nn.mp3"
    hinata "……ここ、痛い？"

    menu:
        "「痛くない」":
            show hinata stare
            voice "audio/voice/hinata_hee.mp3"
            hinata "ふーん。眉毛"
            ren "上がってない"
            hinata "上がってる"
            "ひなたは本を閉じて、かわりにノートを出した。いちばん後ろのページ。"
            "『蓮のうそ　一覧』。"
            "小3、給食のピーマン「食べた」。中1、テスト「見せるほどじゃない」。中3、12月14日「春には走れる」。"
            ren "……なんだよ、それ"
            hinata "記録。……今日のぶん、足しとくね"
            $ heart_up("ひなた", "さみしさ", 3)
            $ up("無理ゲージ", 2)
        "「……少しだけ、痛い」":
            show hinata smile
            voice "audio/voice/hinata_fufu.mp3"
            hinata "……よし。その顔なら、嘘じゃない"
            hinata "じゃあ、練習のあとのアイシング、明日からわたしが見るから"
            ren "マネージャーみたいだな"
            hinata "マネージャーだよ？　入部届、とっくに出してるもん"
            $ heart_up("ひなた", "信頼", 5)
            $ up("無理ゲージ", -3)

    "商店街のスピーカーから、夕方6時のチャイムが流れ始めた。"
    show hinata smile
    voice "audio/voice/hinata_ehehe.mp3"
    hinata "……帰ろ。{rb}千鶴{/rb}{rt}ちづる{/rt}さんのお店、今日コロッケの日だよ"
    hide hinata
    with dissolve
    return


################################################################################
## 自由行動③の行き先：試合の前
################################################################################

## 屋上：鷹野と、昔のチームメイト
label ch1_takano2:
    $ set_flag("ch1_takano2")       # 5/31の試合で、白の14番が鷹野の元チームメイトだと分かる
    scene bg rooftop
    with dissolve
    "屋上のフェンスにもたれて、{rb}鷹野{/rb}{rt}たかの{/rt}がスマホの画面を見ていた。"
    show takano normal
    with dissolve
    "映っているのは、{rb}桜嶺{/rb}{rt}おうりょう{/rt}学園の試合の動画だった。"
    voice "audio/voice/takano_nani.mp3"
    takano "……なに"
    ren "研究してるのか"
    voice "audio/voice/takano_fun.mp3"
    takano "別に。見てただけ"
    "画面の中で、白いユニフォームの選手が、3人を抜いてゴールを決めた。"
    takano "こいつ、ジュニアユースのとき、同じチームだった"
    ren "え？"
    takano "俺は上に上がれなくて、こいつは上がれる話を蹴って、桜嶺に引き抜かれた。今はB。日曜、たぶん出てくる"
    "鷹野は、スマホをポケットにしまった。"

    menu:
        "「じゃあ、日曜は抜き返してやれよ」":
            takano "……簡単に言うな"
            "鷹野は舌打ちして、ポケットに手を突っこんだ。でも、フェンスの向こうを見る目は笑っていた。"
            $ bond_up("鷹野", 5)
            $ lean("野心型")
        "「一人で抜かなくていい。俺に出せ」":
            takano "お前に？"
            ren "見る前に、見えてるから"
            takano "……なんだそれ"
            "鷹野は鼻で笑った。でも、言い返してはこなかった。"
            $ bond_up("鷹野", 4)
            $ set_flag("鷹野_俺に出せ")
            $ lean("仲間型")

    hide takano
    with dissolve
    return

## 部室：三好先輩とボールの空気
label ch1_miyoshi2:
    scene bg clubroom
    with dissolve
    "部室の電気がついていた。"
    show miyoshi smile
    with dissolve
    "{rb}三好{/rb}{rt}みよし{/rt}先輩が、一人でボールに空気を入れていた。"
    miyoshi "おう、{rb}早瀬{/rb}{rt}はやせ{/rt}。ちょうどいい、そっち持ってくれ"
    "10個のボールに、一つずつ空気を入れていく。"
    miyoshi "……なあ、早瀬。正直に言ってくれ"
    miyoshi "日曜、俺たち、何点取られると思う？"

    menu:
        "「……5点以上は、取られると思います」":
            miyoshi "だよな"
            "先輩は笑った。いつもより、小さな声で。"
            miyoshi "でもな。俺、ここ2年、試合ができなかったんだよ。11人いなくて"
            miyoshi "だから、何点取られてもいい。最後の一秒まで走れたら、それでいい"
            $ bond_up("三好", 6)
            $ up("メンタル", 2)
            $ lean("求道型")
        "「取られません。俺が止めます」":
            voice "audio/voice/miyoshi_hahha.mp3"
            miyoshi "おっ、言ったな！"
            "先輩は、大きな手で俺の背中をばしんと叩いた。"
            miyoshi "それ、キャプテンが言うセリフなんだけどな！"
            $ bond_up("三好", 4)
            $ up("メンタル", 3)
            $ up("無理ゲージ", 3)

    $ se("ボールが床で跳ねる音")
    "空気を入れ終わったボールが、部室の床でぽんと跳ねた。"
    hide miyoshi
    with dissolve
    return

## 職員室：黒田の一言
label ch1_kuroda2:
    $ set_flag("ch1_kuroda2")       # 5/31の試合で、ベンチの黒田が一言だけ声をかける
    scene bg staffroom
    with dissolve
    "職員室のいちばん奥の席で、{rb}黒田{/rb}{rt}くろだ{/rt}が採点をしていた。"
    show kuroda normal
    with dissolve
    kuroda "……なんだ。補習の申し込みか"
    ren "日曜の試合のことです。フォーメーション、決めてもらえないかと思って"
    kuroda "決めない"
    ren "え？"
    kuroda "今のお前らに、フォーメーションは関係ない。どこに立っても、同じだけやられる"
    "黒田は赤ペンを置いて、こっちを見た。"
    kuroda "だから、一つだけ。試合中、一回でいい。顔を上げて、全員の位置を見ろ"
    kuroda "{rb}早瀬{/rb}{rt}はやせ{/rt}。お前、見る前に見えてるタイプだろう"
    "心臓が、どくんと鳴った。"
    "{rb}潮見{/rb}{rt}しおみ{/rt}FCの監督にしか、言われたことのない言葉だった。"

    menu:
        "「……なんで、分かるんですか」":
            kuroda "さあな。数学の教師の勘だ"
            "黒田は、また採点に戻った。"
            "机の下で、黒田の左足が、どこか不自然な角度に伸びていた。"
            $ up("戦術眼", 4)
        "「先生、サッカーやってたんですか」":
            kuroda "……授業の質問以外は、受け付けない"
            "それ以上、何も言わなかった。"
            "でも、机の引き出しのすき間から、色あせたユニフォームの袖が、ほんの少しだけのぞいていた。"
            $ up("戦術眼", 2)
            $ set_flag("黒田の過去")

    hide kuroda
    with dissolve
    return
