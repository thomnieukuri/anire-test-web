## ===========================================================================
## ヒロイン場面テスト（v0.31.1・作者の確認用）
##   ヒロインとのやりとりだけを、はじめから遊ばずに1場面ずつ確かめるためのモード。
##   作者の確認用（Web の dev/。game/author_build.txt があるとき）と、開発中の PC（config.developer）だけ、
##   タイトル画面に「ヒロイン場面」が出る。テスター用・アプリ版には出ない
##
##   ・ヒロインのタブ → 場面を押すと、その章の頭の状態（章えらびと同じ cs_stateN）にして、その場面だけ流す
##   ・終わると一覧に戻る。「タイトルへ」で終了。セーブはしなくてよい
##   ・「気持ちを高くする」がオンのとき、選んだヒロインのときめき・信頼を高くしてから流す
##     （特別な場面・告白の前ぶれ・バレンタインなど、気持ちが高いときだけの場面も見られる）
##   ・場面を足すときは、下の HS_SCENES に1行足す
##     （章, 一覧に出す名前, ラベル, 西暦, 日付, 時間, 先に出す背景〔なければ None〕, 先に入れる値〔なければ {}〕）
## ===========================================================================

default persistent.hs_high = True
default hs_testing = False      # ヒロイン場面テストで流しているあいだ True（12/24 の場面が大晦日へ進まないように。chapter3.rpy の ch3_nye）
default persistent.hs_tab = "ひなた"

init python:
    HS_HEROINES = ["ひなた", "千夏", "紗希", "あげは"]

    ## 「気持ちを高くする」で入れる値（ときめき, 信頼）。特別な場面の目安より上
    HS_HIGH = {"ひなた": (70, 95), "千夏": (70, 90), "紗希": (45, 45), "あげは": (45, 45)}

    _TRIP = {"trip_outfit": "trip"}

    HS_SCENES = {
        "ひなた": [
            ("1", "第1章　5月　帰り道", "ch1_walk_hinata", 2026, "5月12日（火）", "放課後", None, {}),
            ("2", "第2章　7月　坂道・お天気雨", "ch2_hinata_dream", 2026, "7月13日（月）", "放課後", None, {}),
            ("2", "第2章　8月　夏祭りの誘い（トーク）", "ch2_invite_hinata", 2026, "8月14日（金）", "夜", None, {}),
            ("3", "第3章　9月　テーピング「専属でいいよ」", "ch3_hinata_sep", 2026, "9月8日（火）", "放課後", None, {}),
            ("3", "第3章　10月　ジャージを返す", "ch3_hinata_oct", 2026, "10月20日（火）", "放課後", None, {"flags+": {"ひなた_ジャージ": True}}),
            ("3", "第3章　10月　入力中…（トーク）", "ch3_talk_hinata_oct", 2026, "10月20日（火）", "夜", None, {}),
            ("3", "第3章　11月　準決勝の朝のテーピング（特別）", "ch3_hinata_tape", 2026, "11月14日（土）", "朝", "bg locker_room", {}),
            ("3", "第3章　12月　坂道のマフラー", "ch3_hinata_dec", 2026, "12月15日（火）", "放課後", None, {}),
            ("3", "第3章　12月　クリスマスの誘い", "ch3_invite_hinata", 2026, "12月21日（月）", "夜", None, {}),
            ("3", "第3章　12/24　クリスマス", "ch3_xmas_hinata", 2026, "12月24日（木）", "夜", None, {"ch3_xmas": "hinata"}),
            ("3", "第3章　大晦日", "ch3_nye_hinata", 2026, "12月31日（木）", "大晦日", None, {}),
            ("4a", "第4章　1/1　残るの報告", "a4_newyear_hinata", 2027, "1月1日（金）", "夜明け", None, {}),
            ("4a", "第4章　2/13　旅館の自販機（ひなた・千夏）", "a4_feb_vending", 2027, "2月13日（土）", "夜", None, _TRIP),
            ("4a", "第4章　2/13　卓球の罰ゲーム", "a4_feb_pingpong", 2027, "2月13日（土）", "夜", None, _TRIP),
            ("4a", "第4章　2/14　雪うさぎとバレンタイン", "a4_feb_day2", 2027, "2月13日（土）", "夜", None, _TRIP),
            ("4a", "第4章　5月　自由行動（はやせ食堂）", "a4_may_hinata", 2027, "5月12日（水）", "放課後", None, {}),
            ("4a", "第4章　7月　自由行動（坂道）", "a4_jul_hinata", 2027, "7月14日（水）", "放課後", None, {}),
            ("4a", "第4章　7月末　相棒", "a4_trust_hinata", 2027, "7月20日（火）", "夜", None, {}),
            ("4a", "第4章　7月末　告白の前ぶれ", "a4_heart_hinata", 2027, "7月27日（火）", "夜", None, {}),
            ("4a", "第4章　8/15　夏祭り", "a4_fes_hinata", 2027, "8月15日（日）", "夏祭り", "bg festival_night", {}),
        ],
        "千夏": [
            ("1", "第1章　4月　生徒会室（練習の出来事）", "ch1_practice_chika", 2026, "4月13日（月）", "放課後", None, {}),
            ("1", "第1章　5月　生徒会室", "ch1_council", 2026, "5月15日（金）", "放課後", None, {}),
            ("2", "第2章　6/1　ビデオ通話", "ch2_chika_videocall", 2026, "6月1日（月）", "夕方", None, {}),
            ("2", "第2章　6月　生徒会室", "ch2_council", 2026, "6月9日（火）", "放課後", None, {}),
            ("2", "第2章　6月　相合傘", "ch2_chika_umbrella", 2026, "6月9日（火）", "放課後", None, {}),
            ("2", "第2章　8月　夏祭りの誘い（トーク）", "ch2_invite_chika", 2026, "8月14日（金）", "夜", None, {}),
            ("3", "第3章　9月　紺色の傘", "ch3_chika_sep", 2026, "9月10日（木）", "放課後", None, {}),
            ("3", "第3章　10月　署名", "ch3_chika_oct", 2026, "10月21日（水）", "放課後", None, {}),
            ("3", "第3章　11月　居眠り（特別）と手帳の写真", "ch3_chika_nov", 2026, "11月5日（木）", "放課後", None, {}),
            ("3", "第3章　12月　会議の日程", "ch3_chika_dec", 2026, "12月15日（火）", "放課後", None, {}),
            ("3", "第3章　12月　クリスマスの誘い", "ch3_invite_chika", 2026, "12月21日（月）", "夜", None, {}),
            ("3", "第3章　12/24　クリスマス", "ch3_xmas_chika", 2026, "12月24日（木）", "夜", None, {"ch3_xmas": "chika"}),
            ("3", "第3章　大晦日", "ch3_nye_chika", 2026, "12月31日（木）", "大晦日", None, {}),
            ("4a", "第4章　1/1　残るの報告", "a4_newyear_chika", 2027, "1月1日（金）", "夜明け", None, {"a4_chika_call": "{rb}蓮{/rb}{rt}れん{/rt}くん"}),
            ("4a", "第4章　2/13　旅館の自販機（ひなた・千夏）", "a4_feb_vending", 2027, "2月13日（土）", "夜", None, _TRIP),
            ("4a", "第4章　2/13　卓球の罰ゲーム", "a4_feb_pingpong", 2027, "2月13日（土）", "夜", None, _TRIP),
            ("4a", "第4章　2/14　雪うさぎとバレンタイン", "a4_feb_day2", 2027, "2月13日（土）", "夜", None, _TRIP),
            ("4a", "第4章　5月　自由行動（生徒会室）", "a4_may_chika", 2027, "5月12日（水）", "放課後", None, {}),
            ("4a", "第4章　7月　自由行動（生徒会室）", "a4_jul_chika", 2027, "7月14日（水）", "放課後", None, {}),
            ("4a", "第4章　7月末　相棒", "a4_trust_chika", 2027, "7月20日（火）", "夜", None, {}),
            ("4a", "第4章　7月末　告白の前ぶれ", "a4_heart_chika", 2027, "7月27日（火）", "夜", None, {}),
            ("4a", "第4章　8/15　夏祭り", "a4_fes_chika", 2027, "8月15日（日）", "夏祭り", "bg festival_night", {}),
        ],
        "紗希": [
            ("3", "第3章　9月　防波堤とピアノ", "ch3_saki_sep", 2026, "9月14日（月）", "放課後", None, {}),
            ("3", "第3章　10月　発表会のチケット", "ch3_saki_oct", 2026, "10月22日（木）", "放課後", None, {}),
            ("3", "第3章　11月　海風（特別）とイヤホン", "ch3_saki_nov", 2026, "11月5日（木）", "夕方", None, {}),
            ("3", "第3章　12月　窓とドの音", "ch3_saki_dec", 2026, "12月15日（火）", "夕方", None, {}),
            ("3", "第3章　12/24　発表会", "ch3_xmas_saki", 2026, "12月24日（木）", "夜", None, {"ch3_xmas": "saki", "flags+": {"紗希_チケット": True}}),
            ("3", "第3章　大晦日", "ch3_nye_saki", 2026, "12月31日（木）", "大晦日", None, {}),
            ("4a", "第4章　1/1　残るの報告", "a4_newyear_saki", 2027, "1月1日（金）", "夜明け", None, {}),
            ("4a", "第4章　5月　休日の港", "a4_saki_holiday", 2027, "5月23日（日）", "昼", None, {}),
            ("4a", "第4章　7/19　防波堤", "a4_jul_pier", 2027, "7月19日（月）", "夕方", None, {}),
        ],
        "あげは": [
            ("4a", "第4章　4/15　入部", "a4_ageha_join", 2027, "4月15日（木）", "放課後", "bg clubroom", {}),
            ("4a", "第4章　5月　港北駅", "a4_may_ageha", 2027, "5月12日（水）", "放課後", None, {}),
            ("4a", "第4章　練習の出来事　朝礼台から撮る", "a4p_ageha_film", 2027, "5月13日（木）", "放課後", "bg kohoku_ground_day", {}),
            ("4a", "第4章　練習の出来事　ドリンクの濃さ", "a4p_ageha_drink", 2027, "5月13日（木）", "放課後", "bg kohoku_ground_day", {}),
            ("4a", "第4章　7月　追試とプリクラ", "a4_jul_ageha", 2027, "7月14日（水）", "放課後", None, {}),
            ("4a", "第4章　7月末　相棒", "a4_trust_ageha", 2027, "7月20日（火）", "夕方", None, {}),
            ("4a", "第4章　7月末　告白の前ぶれ", "a4_heart_ageha", 2027, "7月27日（火）", "夕方", None, {}),
            ("4a", "第4章　8/15　夏祭り", "a4_fes_ageha", 2027, "8月15日（日）", "夏祭り", "bg festival_night", {}),
        ],
    }

    def hs_available():
        return bool(AUTHOR_BUILD or config.developer)

    def hs_prepare(who, ent):
        """場面の前の準備（章の頭の状態にしたあとに呼ぶ）"""
        ch, title, lab, year, date, time, bg, pre = ent
        heart_fill()
        if persistent.hs_high:
            t, s = HS_HIGH[who]
            store.heart[who]["ときめき"] = max(store.heart[who]["ときめき"], t)
            store.heart[who]["信頼"] = max(store.heart[who]["信頼"], s)
            store.heart[who]["さみしさ"] = 0
        if who not in store.met:
            store.met.append(who)
        if ch == "4a":
            ## 高2への切りかえ（相関図・名鑑）は、第4章の印と日付で決まる
            store.play_marks["chapter4a"] = 0
            if "あげは" not in store.met:
                store.met.append("あげは")
        for k, v in pre.items():
            if k == "flags+":
                store.flags.update(v)
            else:
                setattr(store, k, v)
        store.hs_testing = True
        store.cal_year = year
        store.cal_date = ""
        set_cal(date, time, quiet=True)

screen hs_list():
    modal True
    add "gui/menu_bg.png"
    $ _tab = persistent.hs_tab if persistent.hs_tab in HS_HEROINES else "ひなた"
    frame:
        xpos 290
        ypos 40
        xsize 930
        ysize 640
        background None
        vbox:
            spacing 10
            text "ヒロイン場面テスト（作者の確認用）" size 30 color PEN_RED
            text "場面を押すと、その章の頭の状態にして、その場面だけ流します。終わるとここに戻ります。" size 18 color INK_SOFT
            hbox:
                spacing 10
                for _h in HS_HEROINES:
                    textbutton _h:
                        action SetField(persistent, "hs_tab", _h)
                        text_size 24
                        text_color (PEN_RED if _h == _tab else INK_SOFT)
                        text_hover_color PEN_RED
                null width 30
                textbutton ("■ 気持ちを高くする" if persistent.hs_high else "□ 気持ちを高くする"):
                    action ToggleField(persistent, "hs_high")
                    text_size 20
                    text_color INK
                    text_hover_color PEN_RED
                null width 30
                textbutton "タイトルへ":
                    action Return(None)
                    text_size 20
                    text_color INK
                    text_hover_color PEN_RED
            viewport:
                ysize 480
                mousewheel True
                draggable True
                scrollbars "vertical"
                vbox:
                    spacing 6
                    for _i, _e in enumerate(HS_SCENES[_tab]):
                        if renpy.has_label(_e[2]):
                            button:
                                style "roster_card"
                                xsize 860
                                action Return((_tab, _i))
                                hover_background "#ffffffcc"
                                text _e[1] style "roster_name" size 22

label hs_start:
    $ quick_menu = True
    $ persistent.save_guide_seen = True
    if persistent.choice_hints is None:
        $ persistent.choice_hints = True
label hs_loop:
    scene black
    window hide
    $ music_stop(0.5)
    $ amb_stop()
    $ _hs = renpy.call_screen("hs_list")
    if _hs is None:
        $ renpy.full_restart()
    $ _hs_who, _hs_i = _hs
    $ _hs_ent = HS_SCENES[_hs_who][_hs_i]
    call expression ("cs_state" + _hs_ent[0])
    $ hs_prepare(_hs_who, _hs_ent)
    if _hs_ent[6]:
        scene expression _hs_ent[6]
        with dissolve
    call expression _hs_ent[2]
    window hide
    jump hs_loop
