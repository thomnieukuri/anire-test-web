## mobile.rpy ―― スマホ向けの調整
##   スマホ（画面が小さい／タッチ操作）で遊ぶときだけ使う画面とスタイル。
##   Ren'Py は、スマホでは "small" と "touch" という「バリアント」で動く。
##   ここに書いたものは、そのときだけ、PC 用の同じ名前の画面・スタイルの代わりに使われる。
##
##   PC で確かめるとき：ランチャーの「Android」→「Emulation」の「Phone」で起動する。


################################################################################
## メニューボタン（右上の三本線の付箋）と、付箋のメニュー
##   ボタンを出しっぱなしにすると絵が見えにくいので、画面の右上に
##   「三本線の付箋」（メニューボタン）だけを置く。押すと右側に付箋のメニューが開く。
##   スマホでは、セリフ枠のボタン（ログ・オート・スキップ）も出さない。
################################################################################

## セリフ枠のボタンは、スマホでは出さない（右上のメニューボタンにまとめる）
screen quick_buttons():
    variant "small"
    null

## 右上のメニューボタン（PC・スマホ共通）
screen menu_tab():
    zorder 60
    if quick_menu and not renpy.get_screen("quick_drawer"):
        imagebutton:
            idle "gui/menu_icon.png"
            hover "gui/menu_icon_hover.png"
            xalign 1.0
            xoffset -10
            ypos 8
            action Show("quick_drawer")

## メニューボタンを押すと開く付箋のメニュー。外側をタップすると閉じる
screen quick_drawer():
    zorder 190
    modal True

    ## 外側（暗いところ）をタップしたら閉じる
    button:
        xysize (1280, 720)
        background "#00000066"
        action Hide("quick_drawer")

    frame:
        style "drawer_frame"
        vbox:
            style_prefix "drawer"
            textbutton "1つ戻る" action [Hide("quick_drawer"), Rollback()]
            textbutton "スキップ" action [Hide("quick_drawer"), Skip()]
            textbutton "オート" action [Hide("quick_drawer"), Preference("auto-forward", "toggle")]
            textbutton "セーブ" action [Hide("quick_drawer"), ShowMenu("save")]
            textbutton "ロード" action [Hide("quick_drawer"), ShowMenu("load")]
            textbutton "ログ" action [Hide("quick_drawer"), ShowMenu("history")]
            textbutton "ステータス" action [Hide("quick_drawer"), ShowMenu("status")]
            textbutton "相関図" action [Hide("quick_drawer"), ShowMenu("relations")]
            textbutton "設定" action [Hide("quick_drawer"), ShowMenu("preferences")]

    ## 閉じるボタン（メニューボタンと同じ場所）
    textbutton "×":
        style "drawer_close"
        action Hide("quick_drawer")

init python:
    config.overlay_screens.append("menu_tab")


################################################################################
## 文字とボタンの大きさ（スマホ）
##   色やフォントは screens.rpy で決めているので、init 1 にしてそのあとで作る。
################################################################################

init 1:

    ## 能力値の変化などの付箋
    style toast_text:
        variant "small"
        size 21

    ## 左上の日付
    style hud_date:
        variant "small"
        size 23

    style hud_time:
        variant "small"
        size 21

    ## 行動マップの行き先のタグ
    style map_spot_event:
        variant "small"
        size 20

    style map_spot_done:
        variant "small"
        size 20

    ## セーブ枠
    style slot_time:
        variant "small"
        size 21

    style slot_name:
        variant "small"
        size 18

    style page_button:
        variant "small"
        padding (16, 6, 16, 8)

    style page_button_text:
        variant "small"
        size 26

    ## ログ
    style history_name:
        variant "small"
        size 22

    style history_text:
        variant "small"
        size 26

    ## トーク画面
    style bubble_text:
        variant "small"
        size 21

    style talk_meta:
        variant "small"
        size 14

    style talk_sender:
        variant "small"
        size 16

    style talk_pill_text:
        variant "small"
        size 16

    style talk_title:
        variant "small"
        size 21

    style talk_status:
        variant "small"
        size 16

    ## 返信の選択肢
    style talk_choice_text:
        variant "small"
        size 23

    ## 右上のメニュー（付箋）
    style drawer_frame:
        xalign 1.0
        xoffset -12
        ypos 8
        xysize (330, 676)
        background "gui/drawer.png"
        padding (20, 76, 30, 22)    # 上は「×」ボタンを置く「のり」の部分

    style drawer_vbox:
        spacing 0

    style drawer_button:
        xfill True
        ysize 64
        padding (14, 0, 14, 4)
        hover_background "#ffffff55"

    style drawer_button_text:
        yalign 0.5
        font FONT_JP_B
        size 30
        color INK
        hover_color PEN_RED
        selected_color PEN_RED

    style drawer_close is drawer_button
    style drawer_close:
        xalign 1.0
        xoffset -22
        ypos 14
        xfill False
        xsize 64
        ysize 64
        padding (0, 0, 0, 0)

    style drawer_close_text:
        xalign 0.5
        yalign 0.5
        size 34
        color INK_SOFT
        hover_color PEN_RED

