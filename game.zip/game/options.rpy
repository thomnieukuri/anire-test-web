## options.rpy ―― ゲーム全体の基本設定

define config.name = "アンダードッグ・イレブン 体験版"
define config.version = "0.32.1"
define build.name = "anire"

define config.screen_width = 1280
define config.screen_height = 720

## セーブデータの保存先フォルダ名（変えると以前のセーブが見えなくなるので注意）
define config.save_directory = "anire-trial-2026"

define config.window_title = "アンダードッグ・イレブン 体験版"

## セリフ枠は必要なときだけ自動で出す
define config.window = "auto"

## 画面切り替えの演出
define config.enter_transition = dissolve
define config.exit_transition = dissolve
define config.after_load_transition = None
define config.end_game_transition = dissolve

## 文字送りの初期値（1秒あたりの文字数。0 は一瞬で表示）。設定画面のバーのまん中あたり
default preferences.text_cps = 110
default preferences.afm_time = 15
## 次の文に進んでも、ボイスを最後まで流す
default preferences.voice_sustain = True

## セーブ画面のサムネイルの大きさ
define config.thumbnail_width = 256
define config.thumbnail_height = 144

## 右クリックで開くメニュー
define _game_menu_screen = "save"

## テスト中は能力値の変化を画面に表示する（製品版では False にする）
default persistent.show_param_notify = True

init python:
    ## 配布用ファイルの設定
    build.classify("**~", None)
    build.classify("**.bak", None)
    build.classify("**/.**", None)
    build.classify("**/#**", None)
    build.classify("**/thumbs.db", None)
    build.classify("tools/**", None)        # 立ち絵の加工スクリプトは配布しない

    ## 音のファイルは1つにまとめて（アーカイブ）配布する。
    ## BGM 素材の規約で「遊ぶ人が音のファイルをそのまま取り出せる状態」は禁止のため
    build.archive("audio", "all")
    build.classify("game/audio/**", "audio")
    build.documentation("*.md")
