################################################################################
## 試合前の紹介（中継の形）  v0.44.6
##   試合中のボードの確認帳 第6・7回で決めたもの：
##   はじめ（大会名と対戦カード。実況が煽る）→ 港北（黒田を右に映したまま、11人が一人ずつ降りる → 蓮のところで解説 → 港北の戦い方）
##   → 桜嶺（鬼塚を左に。港北の丸はうすく → 11人が番号で降りる → 注目の2人の顔の札 → 桜嶺の戦い方）
##   → 注目の対決（カットイン C：斜めの分割）→ KICK OFF。約60秒。
##   実況は大川アナ、解説は戸田さん（黒田の現役時代の一つ上の先輩）。
##   タップで次の段へ。右上の「スキップ」で全部飛ばす。同じ試合の2回目からは短い版（はじめ → 注目の対決 → KICK OFF）。
##   出す試合は、各章の山場だけ（体験版は第3章の準決勝。プロローグの中3の決勝はこのあと）
##   使い方：call prematch("ch3_semi")
################################################################################

default persistent.pre_seen = None
default pre_skip = False
default pre_phase = 0
default pre_line = ("", "", "")

init 2 python:
    import time as _pret

    PRE_L = 3.3          # 実況の1行を見せる秒（作者「全体的に速い。少し遅く」）
    PRE_DROP = 0.43      # 港北の選手が一人ずつ降りる間
    PRE_POP = 0.23       # 相手の選手が出る間

    def pre_cfg_ch3_semi():
        half = store.ch3_knee_plan == "half"
        ## 港北の11人（ひざを残す作戦のときは、蓮が下がって小池が上がる。9月の3週間の並び）
        home = [("GK", "大門", (5, 34))]
        if store.ch2_miyoshi_cb == "kiryu":
            home += [("DF", "桐生", (18, 41)), ("DF", "宮下", (18, 27)), ("DF", "三好", (24, 11))]
        else:
            home += [("DF", "三好", (18, 41)), ("DF", "桐生", (18, 27)), ("DF", "宮下", (24, 11))]
        home += [("DF", "森", (24, 57))]
        if half:
            home += [("MF", "蓮", (34, 34)), ("MF", "江藤", (46, 9)), ("MF", "坂口", (46, 59)), ("MF", "小池", (52, 34))]
        else:
            home += [("MF", "小池", (36, 34)), ("MF", "江藤", (46, 9)), ("MF", "坂口", (46, 59)), ("MF", "蓮", (52, 34))]
        home += [("FW", "野口", (70, 26)), ("FW", "鷹野", (70, 42))]
        ren_line = (("解説", "戸田", "真ん中に、1年生の早瀬。……おや、今日はいつもより、だいぶ下がった位置ですね")
                    if half else ("解説", "戸田", "真ん中に、1年生の早瀬。この子が、港北の心臓ですね"))
        return {
            "key": "ch3_semi",
            "bg": "bg stadium_semi_eve",
            "cup": "全国高校サッカー選手権　県予選 準決勝",
            "home_name": "県立港北", "away_name": "桜嶺学園",
            "home_short": "港北", "away_short": "桜嶺",
            "home_col": "#2a5bd7", "away_col": "#f2f2ee",
            "open": [("実況", "大川", "全国高校サッカー選手権、県予選・準決勝。夕方の、県総合運動公園陸上競技場です"),
                     ("実況", "大川", "春まで部員3人。廃部寸前だった県立港北が、王者・桜嶺学園に挑みます！"),
                     ("解説", "戸田", "いやあ、ここまで来るとは、正直、だれも思っていなかったでしょうね")],
            "home_coach": ("gui/tactics/pre_coach_kuroda.webp", "黒田"),
            "away_coach": ("gui/tactics/pre_coach_onizuka.webp", "鬼塚"),
            "home_coach_lines": [("実況", "大川", "港北を率いるのは、黒田監督。元潮見ブルーマリンズ、J1で4年プレーした人です"),
                                 ("解説", "戸田", "黒田は、ぼくの一つ下でしてね。右足一本で、なんでもやる男でした")],
            "away_coach_lines": [("実況", "大川", "対する桜嶺は、鬼塚監督"),
                                 ("解説", "戸田", "……表情が読めない人です。今日も、腕を組んだまま、一歩も動かないでしょう")],
            "home_form": "港北　4−4−2（中盤はひし形）",
            "away_form": "桜嶺　5−4−1",
            "home": home,
            "home_lines": [("実況", "大川", "港北のスタメンです。中盤は、ひし形の4−4−2"), ren_line],
            "away": [("1", (100, 34)), ("2", (88, 8)), ("3", (86, 22)), ("4", (85, 34)), ("5", (86, 46)), ("6", (88, 60)),
                     ("8", (74, 14)), ("7", (73, 28)), ("14", (73, 42)), ("11", (74, 56)), ("10", (60, 34))],
            "away_line": ("実況", "大川", "桜嶺は5−4−1。10番・神城、そして14番・真壁"),
            "stars": [("10", "gui/tactics/pre_card_kamishiro.png", "神城 凌", "U-17代表候補", True),
                      ("14", "gui/tactics/pre_card_makabe.png", "真壁", "桜嶺の1年", False)],
            "home_plan": [((34, 34) if half else (36, 34), (52, 34), 0.0, "y"), ((52, 34), (80, 46), 0.3, "y"), ((70, 42), (86, 46), 0.6, "y")],
            "home_plan_line": ("解説", "戸田", "港北は、奪ったら一本で、鷹野の裏。……これしかないでしょう"),
            "home_plan_tag": ("港北：奪ったら、鷹野の裏へ一本", (60, 50)),
            "away_plan": [((60, 34), (53, 34), 0.0, "r"), ((73, 28), (64, 22), 0.3, "r"), ((73, 42), (64, 47), 0.6, "r")],
            "away_plan_line": ("解説", "戸田", "桜嶺は、前から3人で奪いに来ます"),
            "away_plan_tag": ("桜嶺：前から3人で奪いに来る", (58, 18)),
            "duel_line": ("実況", "大川", "そして、この二人。去年の冬、この同じ競技場の、中学の県大会決勝でぶつかった二人です"),
            "split": ("gui/tactics/pre_split_ren.webp", "早瀬 蓮", "港北　1年",
                      "gui/tactics/pre_split_kamishiro.webp", "神城 凌", "桜嶺　1年"),
        }

    def pre_cfg_pro_final():
        """プロローグ：中3の県大会決勝（短い版だけ。中学なので監督とスタメンの紹介はなし。v0.44.6）"""
        return {
            "key": "pro_final",
            "mini": True,
            "bg": "bg stadium_winter_eve",
            "cup": "県中学校サッカー大会　決勝",
            "home_name": "潮見FC", "away_name": "桜嶺中",
            "home_short": "潮見FC", "away_short": "桜嶺中",
            "home_col": "#7fc4e8", "away_col": "#f2f2ee",
            "open": [("実況", "大川", "中学生の県大会、決勝。冬の、県総合運動公園陸上競技場です"),
                     ("実況", "大川", "町のクラブ・潮見FCが、名門・桜嶺中に挑みます！")],
            "star": ("gui/tactics/pre_star_kamishiro_jr.webp", "10　神城 凌", "U-15 日本代表",
                     [("実況", "大川", "桜嶺中の10番、神城凌。中学3年で、もう年代別の日本代表です"),
                      ("解説", "戸田", "ボールを持つ前に、もう次が見えている。……中学生とは思えませんね")]),
            "duel_line": ("実況", "大川", "迎え撃つ潮見FCの10番、早瀬蓮。この二人の勝負が、試合を決めるでしょう"),
            "split": ("gui/tactics/pre_split_ren_jr.webp", "早瀬 蓮", "潮見FC　10番",
                      "gui/tactics/pre_split_kamishiro_jr.webp", "神城 凌", "桜嶺中　10番"),
        }

    PRE_CFG = {"ch3_semi": pre_cfg_ch3_semi, "pro_final": pre_cfg_pro_final}

    def pre_get(key):
        return PRE_CFG[key]()

    def pre_seen(key):
        return key in (persistent.pre_seen or set())

    def pre_mark(key):
        s = set(persistent.pre_seen or set())
        s.add(key)
        persistent.pre_seen = s

    def pre_wait(sec):
        """待つ（タップで次の段へ）。スキップのあとは待たない"""
        if store.pre_skip:
            return
        renpy.pause(sec)

    def pre_say(line):
        """実況・解説の帯の文を入れかえる（文だけ、出し直して動かす）"""
        if store.pre_skip:
            return
        store.pre_line = tuple(line)
        if not renpy.get_screen("pre_cast_bar"):
            renpy.show_screen("pre_cast_bar")
        renpy.hide_screen("pre_cast_txt")
        renpy.show_screen("pre_cast_txt")

    def pre_lines(lines):
        for l in lines:
            if store.pre_skip:
                return
            pre_say(l)
            pre_wait(PRE_L)

    def pre_phase_to(n):
        store.pre_phase = n
        renpy.restart_interaction()

    def pre_cap(pc):
        p = store.pre_phase
        return {1: (pc["home_name"], pc["home_col"]), 2: (pc["home_form"], pc["home_col"]), 3: (pc["home_short"] + "の戦い方", pc["home_col"]),
                4: (pc["away_name"], pc["away_col"]), 5: (pc["away_form"], pc["away_col"]), 6: (pc["away_form"], pc["away_col"]),
                7: (pc["away_short"] + "の戦い方", pc["away_col"]), 8: ("この試合の注目", "#ffd23f")}.get(p, ("", "#ffd23f"))

label prematch(key):
    $ _pc = pre_get(key)
    $ _short = pre_seen(key)
    $ pre_skip = False
    $ pre_phase = 0
    $ _pre_qm = quick_menu
    $ quick_menu = False
    window hide
    hide screen scoreboard
    scene expression _pc["bg"] at pre_bg_zoom
    with Dissolve(0.6)
    $ bgm("緊迫した試合の曲")
    show screen pre_skip_btn
    show screen pre_title(_pc)
    $ pre_wait(0.6)
    $ pre_lines(_pc["open"][:1] if _short else _pc["open"])
    hide screen pre_title
    if not _short and not pre_skip:
        if _pc.get("mini"):
            ## 短い形の試合（プロローグ）：注目の選手を一人だけ紹介する
            show screen pre_star_big(_pc["star"], _pc["away_col"])
            $ pre_lines(_pc["star"][3])
            hide screen pre_star_big
        else:
            call prematch_full(_pc)
    if not pre_skip:
        $ pre_say(_pc["duel_line"])
        $ pre_wait(PRE_L)
    hide screen pre_cast_txt
    hide screen pre_cast_bar
    hide screen pre_board
    hide screen pre_coach_r
    hide screen pre_coach_l
    if not pre_skip:
        show screen pre_split(_pc["split"], _pc["away_col"])
        $ pre_wait(0.3 + 1.9)
        hide screen pre_split
        show screen pre_kickoff(_pc["home_col"])
        $ pre_wait(2.5)
    hide screen pre_split
    hide screen pre_kickoff
    hide screen pre_star_big
    hide screen pre_skip_btn
    ## v0.44.7：紹介の「注目の対決」で顔を見せたので、試合中の最初の1対1のカットインは短い版にする（重なって見えるため）
    $ _pr = {"ch3_semi": "神城"}.get(key)
    if _pr and tb_cut_seen.get(_pr, 0) < 1:
        $ tb_cut_seen = dict(tb_cut_seen)
        $ tb_cut_seen[_pr] = 1
    $ pre_mark(key)
    $ pre_skip = False
    $ pre_phase = 0
    $ quick_menu = _pre_qm
    return

label prematch_full(pc):
    ## ボードが起き上がる（まだ誰もいない）
    show screen pre_board(pc)
    $ pre_wait(0.7)
    ## ===== 港北：監督を右に映したまま → スタメン → 戦い方 =====
    $ pre_phase_to(1)
    $ renpy.show_screen("pre_coach", "r", pc["home_coach"][0], pc["home_short"], pc["home_coach"][1], pc["home_col"], "#ffffff", _tag="pre_coach_r")
    $ pre_wait(0.3)
    $ pre_lines(pc["home_coach_lines"])
    $ pre_phase_to(2)
    $ pre_say(pc["home_lines"][0])
    $ pre_wait(len(pc["home"]) * PRE_DROP + 0.9)
    $ pre_say(pc["home_lines"][1])
    $ pre_wait(PRE_L)
    $ pre_phase_to(3)
    $ pre_say(pc["home_plan_line"])
    $ pre_wait(PRE_L + 0.6)
    ## ===== 桜嶺：監督を左に。港北の丸はうすく =====
    hide screen pre_coach_r
    $ pre_phase_to(4)
    $ renpy.show_screen("pre_coach", "l", pc["away_coach"][0], pc["away_short"], pc["away_coach"][1], pc["away_col"], tb_text_on(pc["away_col"]), _tag="pre_coach_l")
    $ pre_wait(0.4)
    $ pre_lines(pc["away_coach_lines"])
    $ pre_phase_to(5)
    $ pre_say(pc["away_line"])
    $ pre_wait(len(pc["away"]) * PRE_POP + 0.5)
    $ pre_phase_to(6)
    $ pre_wait(1.4 * len(pc["stars"]) + 1.2)
    $ pre_phase_to(7)
    $ pre_say(pc["away_plan_line"])
    $ pre_wait(PRE_L + 0.6)
    hide screen pre_coach_l
    $ pre_phase_to(8)
    $ pre_wait(0.5)
    return

## ---------------------------------------------------------------------------
## 画面
## ---------------------------------------------------------------------------
screen pre_skip_btn():
    zorder 60
    textbutton "スキップ  ▶▶":
        style "pre_skip"
        text_style "pre_skip_text"
        xalign 1.0 xoffset -24 ypos 18
        action [SetVariable("pre_skip", True), Return(True)]

screen pre_title(pc):
    zorder 42
    vbox at pre_title_in:
        xalign 0.5 ypos 150
        spacing 6
        text pc["cup"] style "pre_cup" xalign 0.5
        hbox:
            xalign 0.5
            frame:
                background Solid(pc["home_col"])
                padding (26, 4)
                text pc["home_name"] style "pre_team" color tb_text_on(pc["home_col"])
            frame:
                background Solid("#141821")
                padding (18, 4)
                text "×" style "pre_team" color "#ffd23f"
            frame:
                background Solid(pc["away_col"])
                padding (26, 4)
                text pc["away_name"] style "pre_team" color tb_text_on(pc["away_col"])

screen pre_cast_bar():
    zorder 44
    fixed at pre_bar_in:
        pos (60, 556) xysize (1160, 104)
        add Solid("#0b1424ee")
        add Solid("#ffd23f") xysize (8, 104)

screen pre_cast_txt():
    zorder 45
    $ _w, _n, _t = pre_line
    fixed at pre_txt_in:
        pos (90, 568) xysize (1110, 90)
        frame:
            background Solid("#c62828" if _w == "実況" else "#2a5bd7")
            padding (10, 2)
            text "%s　%s" % (_w, _n) style "pre_who"
        text _t style "pre_line" ypos 34

screen pre_coach(side, img, team, name, col, ink):
    zorder 41
    fixed at pre_coach_fade:
        xysize (1280, 720)
        if side == "r":
            add "gui/tactics/pre_shade_r.png" pos (820, 130)
            add img zoom 0.93 xanchor 1.0 xpos 1240 ypos 96 at pre_coach_in(500)
            frame at pre_nc_in(60):
                xanchor 1.0 xpos 1224 ypos 438
                background Solid(col)
                padding (18, 6)
                vbox:
                    text team + "　監督" style "pre_nc_sub" color ink xalign 1.0
                    text name style "pre_nc" color ink xalign 1.0
        else:
            add "gui/tactics/pre_shade_l.png" pos (0, 130)
            add img zoom 0.93 xpos 40 ypos 96 at pre_coach_in(-500)
            frame at pre_nc_in(-60):
                xpos 56 ypos 438
                background Solid(col)
                padding (18, 6)
                vbox:
                    text team + "　監督" style "pre_nc_sub" color ink
                    text name style "pre_nc" color ink

screen pre_board(pc):
    zorder 40
    $ _away = pc["away_col"]
    $ _cap, _capc = pre_cap(pc)
    fixed at pre_board_fade:
        xysize (1280, 720)
        add Solid("#00000052")
        add "gui/tactics/pitch_tv_grass.png" at tb_rise
        add "gui/tactics/pitch_glow.png" at tb_glow_draw
        ## 見出し（中継の札）
        if pre_phase >= 1:
            fixed:
                pos (70, 80)
                xysize (tb_cap_w(_cap) + 18, 42)
                hbox:
                    add Solid(_capc) xysize (9, 42)
                    frame:
                        style "tb_caption_d_frame"
                        text _cap style "tb_caption_d"
                    add Solid(_capc) xysize (9, 42)
        ## 港北の11人（一人ずつ降りる。桜嶺の紹介のあいだは、うすく）
        if pre_phase >= 2:
            fixed at (pre_dim_on if 4 <= pre_phase <= 7 else pre_dim_off):
                xysize (1280, 720)
                for _i, (_pos, _nm, _p) in enumerate(pc["home"]):
                    $ _xy = tb_xy_d(_p)
                    $ _face = TB_FACE.get(_nm)
                    fixed at pre_tok_drop(_xy, tb_zoom_d(_p), _i * PRE_DROP):
                        xysize (48, 48)
                        add "gui/tactics/shadow_d.png" xalign 0.5 ypos 34 zoom 0.7
                        if _face:
                            add ("gui/tactics/face_%s.png" % _face) align (0.5, 0.5)
                        else:
                            add "gui/tactics/mag_navy.png" align (0.5, 0.5)
                        if _nm == "蓮":
                            add "gui/tactics/ring_ren.png" align (0.5, 0.5)
                        frame:
                            style "tb_plate"
                            background Frame("gui/tactics/plate_%s.png" % ("ren" if _nm == "蓮" else "h"), 10, 10)
                            text _nm style "tb_label_d"
                    ## GK・DF などの札（降りるたびに。蓮だけ長め）
                    frame at pre_pos_tag(_i * PRE_DROP, 2.6 if _nm == "蓮" else 1.3):
                        xanchor 0.5 xpos _xy[0] ypos (_xy[1] - 58)
                        background Solid("#ffd23f" if _nm == "蓮" else "#0b1f52")
                        padding (8, 1)
                        text (_pos + ("　早瀬 蓮" if _nm == "蓮" else "")) style "pre_pos" color ("#111111" if _nm == "蓮" else "#ffffff")
                    if _nm == "蓮":
                        add "gui/tactics/ring_pulse.png" at pre_ren_pulse(_xy, len(pc["home"]) * PRE_DROP + 0.9)
        ## 港北の戦い方（黄色の矢印）
        if pre_phase == 3:
            use tb_arrow_set(pc["home_plan"])
            $ _tg, _tp = pc["home_plan_tag"]
            $ _txy = tb_xy_d(_tp)
            frame at tb_fade_in(0.25):
                xanchor 0.5 xpos _txy[0] ypos (_txy[1] + 34)
                background Solid("#ffd23f")
                padding (12, 4)
                text _tg style "pre_tag" color "#111111"
        ## 桜嶺の11人（番号で出る）
        if pre_phase >= 5:
            for _i, (_num, _p) in enumerate(pc["away"]):
                fixed at pre_tok_pop(tb_xy_d(_p), tb_zoom_d(_p), _i * PRE_POP):
                    xysize (48, 48)
                    add "gui/tactics/shadow_d.png" xalign 0.5 ypos 34 zoom 0.7
                    add tb_disc_img(_away) align (0.5, 0.5)
                    add ("gui/tactics/mag_rim_g.png" if tb_text_on(_away) == "#1a1a1a" else "gui/tactics/mag_rim_w.png") align (0.5, 0.5)
                    text _num style "tb_disc_num" color tb_text_on(_away)
        ## 注目の2人の顔の札
        if pre_phase == 6:
            for _i, (_num, _img, _nm, _sub, _up) in enumerate(pc["stars"]):
                $ _p = [a[1] for a in pc["away"] if a[0] == _num][0]
                $ _xy = tb_xy_d(_p)
                vbox at pre_star_in(_i * 1.4):
                    xanchor 0.5 xpos _xy[0] ypos ((_xy[1] - 205) if _up else (_xy[1] + 30))
                    spacing 2
                    add _img xalign 0.5
                    frame:
                        xalign 0.5
                        background Solid(_away)
                        padding (10, 1)
                        text "%s　%s" % (_num, _nm) style "pre_star" color tb_text_on(_away)
                    frame:
                        xalign 0.5
                        background Solid("#111111")
                        padding (8, 0)
                        text _sub style "pre_star_sub"
        ## 桜嶺の戦い方（赤い矢印）
        if pre_phase == 7:
            use tb_arrow_set(pc["away_plan"])
            $ _tg, _tp = pc["away_plan_tag"]
            $ _txy = tb_xy_d(_tp)
            frame at tb_fade_in(0.25):
                xanchor 0.5 xpos _txy[0] ypos (_txy[1] - 70)
                background Solid("#c62828")
                padding (12, 4)
                text _tg style "pre_tag" color "#ffffff"

## 注目の選手（短い形の試合）：大きな顔の札
screen pre_star_big(st, away="#f2f2ee"):
    zorder 41
    $ _img, _nm, _sub, _ls = st
    fixed at pre_coach_fade:
        xysize (1280, 720)
        add Solid("#0b142488") pos (0, 64) xysize (1280, 592)
        vbox at pre_star_in(0.1):
            xalign 0.5 ypos 80
            spacing 4
            add _img xalign 0.5 zoom 0.8
            frame:
                xalign 0.5
                background Solid(away)
                padding (18, 2)
                text _nm style "pre_nc" color tb_text_on(away)
            frame:
                xalign 0.5
                background Solid("#111111")
                padding (12, 1)
                text _sub style "pre_star_sub" size 18

## 注目の対決：カットイン C（斜めの分割）
screen pre_split(sp, away="#f2f2ee"):
    zorder 46
    $ _li, _ln, _ls, _ri, _rn, _rs = sp
    fixed at pre_split_fade:
        xysize (1280, 720)
        add Solid("#000000")
        add _li at pre_split_slide(-700)
        add _ri xpos 586 at pre_split_slide(700)
        add "gui/tactics/pre_split_line.png" xpos 578 at tb_fade_in(0.26)
        vbox at pre_split_name(-60):
            pos (60, 548)
            text _ls style "pre_split_sub"
            text _ln style "pre_split_name"
        vbox at pre_split_name(60):
            xanchor 1.0 xpos 1220 ypos 548
            text _rs style "pre_split_sub" xalign 1.0
            text _rn style "pre_split_name" xalign 1.0
        text "VS" style "pre_vs" at pre_vs_slam

screen pre_kickoff(col="#2a5bd7"):
    zorder 46
    add Solid("#ffffff") at pre_flash
    text "KICK OFF" style "pre_ko" outlines [(4, col, 0, 5), (2, "#00000088", 0, 0)] at pre_ko_in

## ---------------------------------------------------------------------------
## 動き
## ---------------------------------------------------------------------------
transform pre_bg_zoom:
    align (0.5, 0.5) zoom 1.12
    easeout 7.0 zoom 1.0

transform pre_title_in:
    on show:
        alpha 0.0 zoom 1.3
        easeout 0.5 alpha 1.0 zoom 1.0
    on hide:
        linear 0.3 alpha 0.0

transform pre_bar_in:
    on show:
        alpha 0.0 yoffset 40
        easeout 0.3 alpha 1.0 yoffset 0
    on hide:
        linear 0.25 alpha 0.0

transform pre_txt_in:
    alpha 0.0 xoffset -12
    easeout 0.22 alpha 1.0 xoffset 0

transform pre_board_fade:
    on show:
        alpha 1.0
    on hide:
        linear 0.25 alpha 0.0

transform pre_coach_fade:
    on show:
        alpha 0.0
        linear 0.4 alpha 1.0
    on hide:
        linear 0.35 alpha 0.0

transform pre_coach_in(dx=500):
    alpha 0.0 xoffset dx
    easeout 0.52 alpha 1.0 xoffset 0

transform pre_nc_in(dx=60):
    alpha 0.0 xoffset dx
    pause 0.3
    easeout 0.35 alpha 1.0 xoffset 0

transform pre_dim_on:
    linear 0.4 alpha 0.32

transform pre_dim_off:
    linear 0.4 alpha 1.0

transform pre_tok_drop(xy, z=1.0, d=0.0):
    subpixel True
    anchor (0.5, 0.5) pos xy zoom z
    alpha 0.0 yoffset -46
    pause d
    easeout 0.28 alpha 1.0 yoffset 4
    ease 0.1 yoffset 0

transform pre_tok_pop(xy, z=1.0, d=0.0):
    subpixel True
    anchor (0.5, 0.5) pos xy
    alpha 0.0 zoom (z * 0.3)
    pause d
    easeout 0.24 alpha 1.0 zoom (z * 1.12)
    ease 0.1 zoom z

transform pre_pos_tag(d=0.0, t=1.3):
    alpha 0.0 yoffset 8
    pause d
    easeout 0.2 alpha 1.0 yoffset 0
    pause (t - 0.45)
    linear 0.25 alpha 0.0

transform pre_ren_pulse(xy, d=0.0):
    anchor (0.5, 0.5) pos (xy[0], xy[1] + 10)
    alpha 0.0
    pause d
    block:
        alpha 0.9 zoom 0.6
        linear 1.3 alpha 0.0 zoom 1.5
        repeat 3

transform pre_star_in(d=0.0):
    alpha 0.0 yoffset 20 zoom 0.8
    pause d
    easeout 0.38 alpha 1.0 yoffset 0 zoom 1.0

transform pre_split_fade:
    on show:
        alpha 1.0
    on hide:
        linear 0.25 alpha 0.0

transform pre_split_slide(dx=-700):
    xoffset dx
    easeout 0.26 xoffset 0

transform pre_split_name(dx=-60):
    alpha 0.0 xoffset dx
    pause 0.2
    easeout 0.3 alpha 1.0 xoffset 0

transform pre_vs_slam:
    align (0.5, 0.47)
    alpha 0.0 zoom 3.0
    pause 0.22
    easeout 0.22 alpha 1.0 zoom 0.9
    ease 0.1 zoom 1.0

transform pre_flash:
    alpha 0.0
    linear 0.15 alpha 0.9
    linear 0.35 alpha 0.0

transform pre_ko_in:
    align (0.5, 0.45)
    alpha 0.0 zoom 2.0
    easeout 0.65 alpha 1.0 zoom 1.0
    linear 1.6 zoom 1.04
    linear 0.35 alpha 0.0

init 2:
    style pre_skip is button:
        background Solid("#0b1424cc")
        hover_background Solid("#c62828")
        padding (16, 6)
    style pre_skip_text is button_text:
        font FONT_JP_B
        size 20
        color "#ffffff"
        hover_color "#ffffff"
    style pre_cup:
        font FONT_JP_B
        size 22
        color "#ffd23f"
        kerning 4
        outlines [(2, "#000000", 0, 2)]
    style pre_team:
        font FONT_JP_B
        size 52
        outlines []
    style pre_who:
        font FONT_JP_B
        size 18
        color "#ffffff"
        outlines []
    style pre_line:
        font FONT_JP_B
        size 26
        color "#ffffff"
        xmaximum 1100
        outlines []
    style pre_nc_sub:
        font FONT_JP_B
        size 16
        outlines []
    style pre_nc:
        font FONT_JP_B
        size 30
        outlines []
    style pre_pos:
        font FONT_JP_B
        size 15
        outlines []
    style pre_tag:
        font FONT_JP_B
        size 20
        outlines []
    style pre_star:
        font FONT_JP_B
        size 18
        outlines []
    style pre_star_sub:
        font FONT_JP_B
        size 13
        color "#ffd23f"
        outlines []
    style pre_split_name:
        font FONT_JP_B
        size 40
        color "#ffffff"
        outlines [(3, "#000000", 0, 3)]
    style pre_split_sub:
        font FONT_JP_B
        size 20
        color "#ffd23f"
        outlines [(2, "#000000", 0, 2)]
    style pre_vs:
        font FONT_JP_B
        size 120
        color "#ffd23f"
        italic True
        outlines [(5, "#c62828", 0, 0), (3, "#000000", 0, 6)]
    style pre_ko:
        font FONT_JP_B
        size 110
        color "#ffffff"
        italic True
        kerning 6
