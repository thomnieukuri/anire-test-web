## extras.rpy ―― 選手名鑑・回想（一枚絵のギャラリー）
##   選手名鑑：ゲーム中のメニュー「相関図」の右上から開く。第2章の作戦ボードの日から見られる
##   回想　　：タイトル画面の「回想」。一度見た一枚絵だけ、もう一度見られる（見ていない絵は「？」）

################################################################################
## 選手名鑑（港北　4−4−2）
################################################################################

## (背番号, ポジション, 名前, 学年, 紹介)
define ROSTER = [
    (1, "GK", "大門 剛", "1年", "元柔道部。身長190センチ。受け身は部でいちばん。ボールは、まだ少し怖い。"),
    (2, "DF", "三好 大地", "3年", "キャプテン。中学の3年間は、ずっと補欠。誰よりも走って、誰よりも声がでかい。"),
    (3, "DF", "桐生", "2年", "名前だけの部員だった先輩。口数は少ないが、つっこみは鋭い。"),
    (4, "DF", "宮下", "2年", "桐生先輩と一緒に、名前だけ置いていた先輩。左のサイドバック。"),
    (5, "DF", "森", "1年", "ゲーセンの5人組。上がりっぱなしの坂口の、尻ぬぐい係。"),
    (6, "MF", "坂口", "1年", "ゲーセンの5人組。右サイドを上がりっぱなしで、ずっとクロスを上げる。口ぐせは「ウケる」。"),
    (7, "MF", "小池", "1年", "ゲーセンの5人組。真ん中の後ろで、パスを散らす係。"),
    (8, "MF", "早瀬 蓮", "1年", "主人公。中学では県選抜。右ひざのケガで、桜嶺の推薦がなくなった。真ん中で、全員にボールを配る。"),
    (9, "MF", "江藤", "1年", "ゲーセンの5人組。左サイド。ドリブルしかしない……と、本人は言っている。"),
    (10, "FW", "鷹野 迅", "1年", "元Jクラブのジュニアユース。口は悪いが、夜に一人で左足を磨いている。"),
    (11, "FW", "野口", "1年", "ゲーセンの5人組。点を取る係。まだ取ったことはない。"),
]

init python:
    def roster_open():
        """選手名鑑が見られるか（作戦ボードの日を過ぎたか）"""
        return bool(store.flags.get("名鑑")) or bool(store.ch2_pos)

screen roster():
    tag menu
    use game_menu("選手名鑑", scroll="viewport"):
        if roster_open():
            text "県立港北高校サッカー部　4−4−2" style "status_head"
            for no, pos, nm, gr, prof in ROSTER:
                frame:
                    style "roster_card"
                    hbox:
                        spacing 16
                        frame:
                            style "roster_badge"
                            background (PEN_RED if nm.startswith("早瀬") else "#2a3f8f")
                            vbox:
                                xalign 0.5
                                yalign 0.5
                                text str(no) style "roster_no"
                                text pos style "roster_pos"
                        vbox:
                            spacing 2
                            xsize 760
                            hbox:
                                spacing 12
                                text nm style "roster_name"
                                text gr style "roster_grade" yalign 1.0
                            text prof style "roster_prof"
        else:
            text "第2章の作戦ボードの日から見られます。" color INK_SOFT size 24
        null height 8
        textbutton "相関図にもどる" style "roster_link" text_style "roster_link_text" action ShowMenu("relations")

init 1:
    style roster_card:
        xfill True
        background "#ffffff88"
        padding (12, 10, 12, 10)
    style roster_badge:
        xysize (78, 78)
        yalign 0.5
    style roster_no:
        xalign 0.5
        font FONT_JP_B
        size 30
        color "#ffffff"
    style roster_pos:
        xalign 0.5
        font FONT_JP_B
        size 16
        color "#ffffff"
    style roster_name:
        font FONT_JP_B
        size 26
        color INK
    style roster_grade:
        size 18
        color INK_SOFT
    style roster_prof:
        size 20
        color INK
        line_spacing 2
    style roster_link:
        padding (10, 6, 10, 6)
        background "#ffffff88"
        hover_background "#ffffffcc"
    style roster_link_text:
        font FONT_JP_B
        size 22
        color PEN_TEAL
        hover_color PEN_RED


################################################################################
## 回想（一枚絵のギャラリー）
################################################################################

## 章ごとに並べる。(章の見出し, [一枚絵の名前…])
define GALLERY = [
    ("プロローグ", ["op_breath", "op_trap", "op_open", "op_kamishiro", "op_cutback", "op_clear", "ren_down"]),
    ("第1章", ["saki_meet", "miyoshi_rain", "bus_hinata", "m531_warmup", "m531_kamishiro", "m531_huddle",
               "m531_tackle", "m531_keeper", "m531_final", "m531_surrounded"]),
    ("第2章", ["daimon_pk", "album_photos", "train_saki", "fw_hinata", "fw_chika", "fw_boys", "fw_saki"]),
]

init python:
    def gallery_seen(name):
        return renpy.seen_image("cg " + name)

    def gallery_count():
        n = 0
        total = 0
        for head, names in GALLERY:
            for nm in names:
                total += 1
                if gallery_seen(nm):
                    n += 1
        return n, total

screen gallery():
    tag menu
    use game_menu("回想", scroll="viewport"):
        $ seen_n, all_n = gallery_count()
        text "見た一枚絵　[seen_n]／[all_n]" color INK_SOFT size 20
        for head, names in GALLERY:
            text head style "status_head"
            hbox:
                box_wrap True
                spacing 10
                box_wrap_spacing 10
                xsize 900
                for nm in names:
                    if gallery_seen(nm):
                        button:
                            style "gallery_thumb"
                            action Show("gallery_view", img="cg " + nm)
                            add Transform("cg " + nm, xysize=(204, 114))
                    else:
                        frame:
                            style "gallery_thumb"
                            background "#00000033"
                            text "？" xalign 0.5 yalign 0.5 size 40 color "#ffffffaa"

## 一枚絵を大きく見る（クリックかタップで閉じる）
screen gallery_view(img):
    modal True
    zorder 200
    add "#000"
    add img xalign 0.5 yalign 0.5
    button:
        xysize (1280, 720)
        action Hide("gallery_view")
    key "game_menu" action Hide("gallery_view")

init 1:
    style gallery_thumb:
        xysize (210, 120)
        padding (3, 3, 3, 3)
        background "#ffffff"
        hover_background PEN_RED
