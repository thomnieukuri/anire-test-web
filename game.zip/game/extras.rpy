## extras.rpy ―― 選手名鑑・回想（一枚絵のギャラリー）
##   選手名鑑：ゲーム中のメニュー「相関図」の右上から開く。第2章の作戦ボードの日から見られる
##   回想　　：タイトル画面の「回想」。一度見た一枚絵だけ、もう一度見られる（見ていない絵は「？」）

################################################################################
## 選手名鑑（港北　4−4−2）
################################################################################

## (背番号, ポジション, 名前, 学年, 紹介)
define ROSTER = [
    (1, "GK", "大門 剛", "1年", "元柔道部。身長190センチ。受け身は部でいちばん。ボールは、まだ少し怖い。"),
    (2, "DF", "三好 大地", "3年", "キャプテン。中学の3年間は、ずっと補欠。誰よりも走って、誰よりも声がでかい。"),
    (3, "DF", "桐生", "2年", "名前だけの部員だった先輩。口数は少ないが、つっこみは鋭い。"),
    (4, "DF", "宮下", "2年", "桐生先輩と一緒に、名前だけ置いていた先輩。左のサイドバック。"),
    (5, "DF", "森", "1年", "ゲーセンの5人組。上がりっぱなしの坂口の、尻ぬぐい係。"),
    (6, "MF", "坂口", "1年", "ゲーセンの5人組。右サイドを上がりっぱなしで、ずっとクロスを上げる。口ぐせは「ウケる」。"),
    (7, "MF", "小池", "1年", "ゲーセンの5人組。真ん中の後ろで、パスを散らす係。"),
    (8, "MF", "早瀬 蓮", "1年", "主人公。中学では県選抜。右ひざのケガで、桜嶺の推薦がなくなった。真ん中で、全員にボールを配る。"),
    (9, "MF", "江藤", "1年", "ゲーセンの5人組。左サイド。ドリブルしかしない……と、本人は言っている。"),
    (10, "FW", "鷹野 迅", "1年", "元Jクラブのジュニアユース。口は悪いが、夜に一人で左足を磨いている。"),
    (11, "FW", "野口", "1年", "ゲーセンの5人組。点を取る係。まだ取ったことはない。"),
]

init python:
    def roster_open():
        """選手名鑑が見られるか（作戦ボードの日を過ぎたか）"""
        return bool(store.flags.get("名鑑")) or bool(store.ch2_pos)

screen roster():
    tag menu
    use game_menu("選手名鑑", scroll="viewport"):
        if roster_open():
            text "県立港北高校サッカー部　4−4−2" style "status_head"
            for no, pos, nm, gr, prof in ROSTER:
                frame:
                    style "roster_card"
                    hbox:
                        spacing 16
                        frame:
                            style "roster_badge"
                            background (PEN_RED if nm.startswith("早瀬") else "#2a3f8f")
                            vbox:
                                xalign 0.5
                                yalign 0.5
                                text str(no) style "roster_no"
                                text pos style "roster_pos"
                        vbox:
                            spacing 2
                            xsize 760
                            hbox:
                                spacing 12
                                text nm style "roster_name"
                                text gr style "roster_grade" yalign 1.0
                            text prof style "roster_prof"
        else:
            text "第2章の作戦ボードの日から見られます。" color INK_SOFT size 24
        null height 8
        textbutton "相関図にもどる" style "roster_link" text_style "roster_link_text" action ShowMenu("relations")

init 1:
    style roster_card:
        xfill True
        background "#ffffff88"
        padding (12, 10, 12, 10)
    style roster_badge:
        xysize (78, 78)
        yalign 0.5
    style roster_no:
        xalign 0.5
        font FONT_JP_B
        size 30
        color "#ffffff"
    style roster_pos:
        xalign 0.5
        font FONT_JP_B
        size 16
        color "#ffffff"
    style roster_name:
        font FONT_JP_B
        size 26
        color INK
    style roster_grade:
        size 18
        color INK_SOFT
    style roster_prof:
        size 20
        color INK
        line_spacing 2
    style roster_link:
        padding (10, 6, 10, 6)
        background "#ffffff88"
        hover_background "#ffffffcc"
    style roster_link_text:
        font FONT_JP_B
        size 22
        color PEN_TEAL
        hover_color PEN_RED


################################################################################
## 回想（一枚絵のギャラリー）
################################################################################

## 章ごとに並べる。(章の見出し, [一枚絵の名前…])
define GALLERY = [
    ("プロローグ", ["op_breath", "op_trap", "op_open", "op_kamishiro", "op_cutback", "op_clear", "ren_down"]),
    ("第1章", ["saki_meet", "miyoshi_rain", "bus_hinata", "m531_warmup", "m531_kamishiro", "m531_huddle",
               "m531_tackle", "m531_keeper", "m531_final", "m531_surrounded"]),
    ("第2章", ["daimon_pk", "album_photos", "train_saki", "fw_hinata", "fw_chika", "fw_boys", "fw_saki"]),
]

init python:
    def gallery_seen(name):
        return renpy.seen_image("cg " + name)

    def gallery_count():
        n = 0
        total = 0
        for head, names in GALLERY:
            for nm in names:
                total += 1
                if gallery_seen(nm):
                    n += 1
        return n, total

screen gallery():
    tag menu
    use game_menu("回想", scroll="viewport"):
        $ seen_n, all_n = gallery_count()
        text "見た一枚絵　[seen_n]／[all_n]" color INK_SOFT size 20
        for head, names in GALLERY:
            text head style "status_head"
            hbox:
                box_wrap True
                spacing 10
                box_wrap_spacing 10
                xsize 900
                for nm in names:
                    if gallery_seen(nm):
                        button:
                            style "gallery_thumb"
                            action Show("gallery_view", img="cg " + nm)
                            add Transform("cg " + nm, xysize=(204, 114))
                    else:
                        frame:
                            style "gallery_thumb"
                            background "#00000033"
                            text "？" xalign 0.5 yalign 0.5 size 40 color "#ffffffaa"

## 一枚絵を大きく見る（クリックかタップで閉じる）
screen gallery_view(img):
    modal True
    zorder 200
    add "#000"
    add img xalign 0.5 yalign 0.5
    button:
        xysize (1280, 720)
        action Hide("gallery_view")
    key "game_menu" action Hide("gallery_view")

init 1:
    style gallery_thumb:
        xysize (210, 120)
        padding (3, 3, 3, 3)
        background "#ffffff"
        hover_background PEN_RED

## スマホ（small）では文字を大きくする
init 1:
    style roster_name:
        variant "small"
        size 30
    style roster_grade:
        variant "small"
        size 22
    style roster_prof:
        variant "small"
        size 24


################################################################################
## サッカーノート（豆知識）
##   話の中でサッカーの言葉が出てきたときに $ learn("offside") と書くと、ノートに1つ増える。
##   中身は、ひなたのノートに、黒田がひとこと書き足した形。メニューの「相関図」の右上から読める
################################################################################

default note_learned = []

## (キー, 見出し, 本文, 黒田のひとこと)
define SOCCER_NOTE = [
    ("b_team", "Bチーム",
     "部員の多い強豪校は、試合に出る順にA・B・Cとチームを分けている。Bチームでも、ほかの高校のレギュラーより強いことがある。",
     "Bに勝っても、まだAがいる"),
    ("interhigh", "インターハイと選手権",
     "高校サッカーの大きな全国大会は、夏のインターハイと、冬の全国高校サッカー選手権。どちらも、まず県の予選を勝ち抜く必要がある。3年生の多くは、冬の選手権が最後の大会になる。",
     "冬まで残れるかは、夏の過ごし方で決まる"),
    ("f442", "4−4−2",
     "DF4人・MF4人・FW2人の並び方。横に4人ずつ並ぶので、守るときに穴ができにくい。昔から多くのチームが使ってきた、基本の形。",
     "形は入れ物だ。中身はお前らが決める"),
    ("cb", "センターバック",
     "DFの真ん中の2人。相手のFWと競り合い、ゴール前を守る最後の砦。抜かれても追いつける足と、まわりを動かす声が大事。",
     "声がでかいのは才能だ"),
    ("sb", "サイドバック",
     "DFの左右の2人。守るだけでなく、タッチラインぞいを駆け上がって攻撃にも加わる。上がったあとの背中のスペースを狙われやすい。",
     "上がったら、誰が埋めるかを決めておけ"),
    ("cmf", "真ん中のMF",
     "フィールドのまん中で、守りから攻めへのつなぎ役。前後左右すべてに顔を出すので、まわりを見る力（戦術眼）がいちばん試される。",
     "ボールを持っていない時間のほうが長い"),
    ("cross", "クロス",
     "サイドから、ゴール前に上げるボール。中で待つFWが頭や足で合わせる。ゴールから遠ざかるように曲がるボールは、キーパーが出にくい。",
     "上げる前に、中を一回見ろ"),
    ("onetwo", "ワンツー",
     "味方にパスを出して走り、すぐに返してもらう、2本のパス。1人の相手を、2人がかりで抜くことができる。",
     "出したら止まるな"),
    ("offside", "オフサイド",
     "パスが出た瞬間に、攻める側の選手が、相手の後ろから2人目（ふつうはいちばん後ろのDF）より相手ゴールに近い場所にいて、プレーに関わると反則。自分の陣地にいるときは関係ない。キーパーの前に立って邪魔をするのも、プレーに関わったことになる。",
     "線は動く。ボールが出る瞬間だけ見ろ"),
    ("pk_shootout", "PK戦",
     "トーナメントで同点のまま終わったとき、PK戦で勝ち上がりを決めることがある。先に蹴るチームはコイントスで決め、交互に5人ずつ蹴る。それでも同点なら、1人ずつのサドンデス。",
     "蹴る前に、もう決めておけ"),
    ("gk_dive", "キーパーの横っ飛び",
     "キーパーは、倒れる前提で横に飛ぶ。上手な選手は、手、肩、腰の順に地面につき、ケガをしにくい。柔道の受け身とよく似ている。",
     "倒れ方を知っているやつは、怖がらない"),
    ("ura", "裏を取る",
     "相手のDFの後ろのスペースに走りこむこと。上がっていった相手の選手がいた場所は、ぽっかり空いていることが多い。",
     "答えは、いつもボールのないところにある"),
    ("knee", "ひざの靭帯",
     "靭帯は、骨と骨をつなぐ、ひものような組織。ひざには前後左右に靭帯があり、サッカーでは着地や切り返しで傷めやすい。痛みが引いても、すぐ全力で動くと、また傷めやすい。",
     "……俺みたいになるな"),
]

init python:
    def learn(key):
        """サッカーノートに1つ増やす。初めてのときだけ、右上に出す"""
        if key in store.note_learned:
            return
        store.note_learned = store.note_learned + [key]
        for k, title, body, kuro in SOCCER_NOTE:
            if k == key:
                toast("サッカーノート：「%s」" % title)
                telop_sound()
                break

    def note_open():
        return len(store.note_learned) > 0

screen soccer_note():
    tag menu
    use game_menu("サッカーノート", scroll="viewport"):
        text "ひなたのノート（ところどころに、黒田先生の字）　%d／%d" % (len(note_learned), len(SOCCER_NOTE)) color INK_SOFT size 20
        for k, title, body, kuro in SOCCER_NOTE:
            frame:
                style "roster_card"
                if k in note_learned:
                    vbox:
                        spacing 4
                        text title style "roster_name"
                        text body style "roster_prof"
                        text "黒田：" + kuro style "note_kuroda"
                else:
                    text "？？？　（まだ書かれていない）" color INK_SOFT size 22
        null height 8
        textbutton "相関図にもどる" style "roster_link" text_style "roster_link_text" action ShowMenu("relations")

init 1:
    style note_kuroda:
        size 19
        color PEN_RED
        italic False
    style note_kuroda:
        variant "small"
        size 22
