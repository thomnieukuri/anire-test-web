## audio.rpy ―― BGM・効果音・環境音
##   台本では、これまでどおり $ bgm("緊迫した試合の曲") や $ se("笛の音") と書く。
##   ここの表で、その言葉に合う音のファイルを選んで鳴らす。
##   表にない言葉のときは、画面右上に「♪ …」「SE：…」と表示する（音を探すときの目印）。
##
##   チャンネル（音の通り道）
##     music   … BGM（設定画面の「BGMの音量」）
##     sound   … 1回だけ鳴る効果音（設定画面の「効果音の音量」）
##     ambient … 雨・波など、鳴りっぱなしの環境音（「効果音の音量」で一緒に変わる）
##     ui      … テロップやシステムの説明が出たときの、小さな合図の音（ほかの効果音を止めないように別にする）
##     ui_text … ふだんの文章を進めたときの、シャーペンの小さな音

init python:
    renpy.music.register_channel("ambient", mixer="sfx", loop=True, tight=True)
    renpy.music.register_channel("ui", mixer="sfx", loop=False)
    ## 文章を進める音は専用のチャンネル（テロップや付箋の音を途中で止めないように）
    renpy.music.register_channel("ui_text", mixer="sfx", loop=False)

    ## BGM（言葉 → ファイル名）。ファイルは game/audio/bgm/ にある
    BGM_TABLE = {
        "緊迫した試合の曲": "match",
        "試合の曲（劣勢）": "match_losing",
        "静かなピアノ": "piano_injury",
        "静かなピアノ（試合の音が遠のく）": "piano_fade",
        "静かなピアノの旋律": "piano_score",
        "日常の静かな曲": "piano_lonely",
        "張りつめた静かな曲": "tension",
        "静かな緊張感のある曲": "tension",
        "重く静かな曲": "serious",
        "あたたかいアコースティックギター": "acoustic_night",
        "明るい春の曲": "spring_morning",
        "明るい部活の曲": "club",
        "のんびりした春の曲": "spring_easy",
        "静かな春の曲": "after_school",
        "作戦会議っぽい軽快な曲": "recruit",
        "とぼけた日常の曲": "goofy",
        "少しとがった曲": "edgy",
        "ゲームセンターの曲": "arcade",
        "静かな夜の曲": "night",
        "試合の曲（終盤）": "match",
        "夏祭りの曲": "festival",
    }

    ## 効果音（言葉 → [(ファイル, チャンネル)]）
    ##   チャンネルが "ambient" のものは、止めるまで鳴り続ける
    SE_TABLE = {
        "笛の音": [("whistle_short", "sound")],
        "キックオフの笛": [("whistle_short", "sound")],
        "前半終了の笛": [("whistle_double", "sound")],
        "担架を呼ぶ笛": [("whistle_double", "sound")],
        "試合終了の笛": [("whistle_end", "sound")],
        "芝を蹴る音": [("spike_grass", "sound")],
        "スパイクが芝をえぐる音": [("slide", "sound")],
        "鈍い衝突音": [("hit_dull", "sound")],
        "ボールを蹴る音": [("kick", "sound")],
        "ボールが転がる音": [("ball_roll", "sound")],
        "ボールが抜けていく音": [("ball_touch", "sound")],
        "ボールが床で跳ねる音": [("ball_touch", "sound")],
        "ボールがポストに当たる音": [("hit_dull", "sound")],
        "ボールを奪われる音": [("slide", "sound")],
        "ネットが揺れる音": [("net", "sound")],
        "小走りの足音": [("steps_run", "sound")],
        "土を蹴る足音": [("steps_soil", "sound")],
        "遠くで土を蹴って走る足音": [("steps_soil_far", "sound")],
        "サンダルが土をこする音": [("sandal_soil", "sound")],
        "畳に人が落ちる音": [("fall", "sound")],
        "固定電話の呼び出し音": [("phone_ring", "sound")],
        "包丁がまな板を叩く音": [("knife", "sound")],
        "トークアプリの通知音": [("talk_notify", "sound")],
        "トークアプリの通知音（連続）": [("talk_notify_multi", "sound")],
        "自転車のブレーキ": [("bike_brake", "sound")],
        "強い海風": [("gust", "sound")],
        "ゲームのゴール音": [("game_goal", "sound")],
        ## 第2章（ElevenLabs のサウンドエフェクトで作成）
        "花火の音": [("fireworks", "sound")],
        "電車がカーブで揺れる音": [("train_curve", "sound")],
        "駅に着く音・ドアが開く音": [("train_arrive", "sound")],
        "体育館の扉が開く音": [("gym_door", "sound")],
        "電車の走る音": [("train_run", "ambient")],
        ## 環境音
        "雨の音": [("rain", "ambient")],
        "波の音、カモメ": [("harbor", "ambient")],
    }

    def bgm(desc):
        """BGM を流す。同じ曲が流れているときは、そのまま続ける。
        「（止まる）」は急に止める（環境音も止めて、しんとさせる）。「（なし）」はゆっくり消す。"""
        if desc == "（止まる）":
            renpy.music.stop("music", fadeout=0.3)
            renpy.music.stop("ambient", fadeout=0.3)
            return
        if desc == "（なし）":
            renpy.music.stop("music", fadeout=2.0)
            return
        name = BGM_TABLE.get(desc)
        if name is None:
            toast("♪ " + desc)
            return
        renpy.music.play("audio/bgm/%s.ogg" % name, channel="music",
                         fadeout=1.0, fadein=1.0, if_changed=True)

    def se(desc):
        """効果音を鳴らす。環境音（雨・波など）は、amb_stop() するまで鳴り続ける。"""
        items = SE_TABLE.get(desc)
        if items is None:
            toast("SE：" + desc)
            return
        for name, ch in items:
            if ch == "ambient":
                renpy.music.play("audio/amb/%s.ogg" % name, channel="ambient",
                                 fadeout=1.5, fadein=1.5, if_changed=True)
            else:
                renpy.sound.play("audio/se/%s.ogg" % name, channel="sound")

    def telop_sound():
        """テロップ（カットイン・能力値の付箋・黒い画面の文）が出たときの、目立たない音"""
        renpy.sound.play("audio/se/telop.ogg", channel="ui")

    def system_sound():
        """システムの説明が出たときの、目立たない音"""
        renpy.sound.play("audio/se/system.ogg", channel="ui")

    def telop_cb(event, interact=True, **kwargs):
        ## 黒い画面の文（mono）を出すたびに鳴らす
        if event == "begin" and interact:
            telop_sound()

    def text_cb(event, interact=True, **kwargs):
        ## ふだんの文章（地の文・セリフ）を出すたびに、シャーペンの小さな音を鳴らす
        if event == "begin" and interact and not renpy.is_skipping():
            renpy.sound.play("audio/se/advance.ogg", channel="ui_text")

    def system_cb(event, interact=True, **kwargs):
        ## システムの説明（tuto）を出すたびに鳴らす
        if event == "begin" and interact:
            system_sound()

    def amb_stop(fade=1.5):
        """雨・波・歓声などの環境音を止める"""
        renpy.music.stop("ambient", fadeout=fade)

    def music_stop(fade=1.5):
        """BGM と環境音をまとめて止める（章の終わりなど）"""
        renpy.music.stop("music", fadeout=fade)
        renpy.music.stop("ambient", fadeout=fade)

## タイトル画面の曲
define config.main_menu_music = "audio/bgm/title.ogg"

## はじめて遊ぶときの音量（セリフのボイスが聞こえやすいように、BGM は少し小さめ）
define config.default_music_volume = 0.52
define config.default_sfx_volume = 0.53
define config.default_voice_volume = 0.77


################################################################################
## クレジット（使わせてもらった素材）
##   魔王魂は「音楽：魔王魂」のクレジット表記が必要。ほかの素材も、感謝をこめて書いておく。
################################################################################

define CREDITS = [
    ("BGM", [
        "音楽：魔王魂",
        "音楽：OpenTracks（旧DOVA-SYNDROME）",
        "　稿屋 隆 ／ J ／ チョコミント ／ Tenkichi ／ もっぴーさうんど ／ ゆーぎり ／ ネコト",
        "音楽：OtoLogic（CC BY 4.0）",
        "音楽：ElevenLabs（夏祭りの曲）",
    ]),
    ("効果音", ["効果音ラボ", "OtoLogic（CC BY 4.0）", "ElevenLabs"]),
    ("ボイス", ["ElevenLabs"]),
    ("フォント", ["Noto Sans CJK JP（SIL Open Font License 1.1）"]),
    ("ゲームエンジン", ["Ren'Py"]),
]

screen credits():
    tag menu
    use game_menu("クレジット", scroll="viewport"):
        vbox:
            spacing 6
            null height 6
            for head, lines in CREDITS:
                text head style "status_head"
                for l in lines:
                    text l size 24 color INK
                null height 14
