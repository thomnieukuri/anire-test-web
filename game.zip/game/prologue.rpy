## prologue.rpy ―― プロローグ「止まった冬」
##   台本：アンイレ 体験版台本（プロローグのタブ）

label prologue:
    scene black
    call show_title("プロローグ", "止まった冬")

    ############################################################################
    ## シーン1：県大会決勝（中3・12月）
    ############################################################################
    $ set_cal("12月14日（日）", "県大会　決勝", quiet=True)

    ## 黒い画面に、ひとことだけ
    $ quick_menu = False
    mono "吐く息が白い。"
    $ quick_menu = True

    scene cg op_breath at cam_push(14.0, 1.06)
    with Dissolve(1.2)
    show screen letterbox

    "十二月の芝は、思っていたよりずっと硬かった。"
    "スパイクの裏から、凍りかけた土の感触が返ってくる。四十分走った足が、まだ止まれないと言っている。"
    "顔を上げると、電光掲示板が見えた。"

    scene bg stadium_winter_eve at cam_pan_r(16.0)
    with dissolve
    $ sb_set("後半", 40, 12, 0, 1, "#7fc4e8", "#f2f2ee", "潮見FC", "桜嶺中")     # 蓮のチーム（水色）対 神城のチーム（白）
    show screen scoreboard

    "後半四十分。スコアは0−1。"
    "電光掲示板の数字が、一秒ずつ俺たちの残り時間を削っていく。"
    "県大会、決勝。"
    "勝てば全国。負ければ、俺の中学サッカーはここで終わる。"

    $ se("笛の音")
    $ bgm("緊迫した試合の曲")

    scene cg op_clear at cam_tilt_up(5.0)
    with dissolve

    "味方のクリアが、センターサークルのあたりで高く跳ねた。"

    show cg op_clear at cam_snap(1.15, 0.5, 0.0)
    "――来る。"
    "誰よりも先に、俺には見えていた。"
    "ボールが落ちる場所。相手のボランチ――真ん中で守る選手――が戻るより早く、そこに入れる。"

    $ se("芝を蹴る音")
    "芝を蹴る。"

    $ se("ボールを蹴る音")       # 胸でボールを受ける音（v0.32.2：作戦ボードのところから、ここへ移した）
    scene cg op_trap at cam_snap(1.1)
    with hpunch

    "胸で受ける。ボールが足もとに吸いついた。"

    scene cg op_open at cam_push(5.0, 1.15)
    with flash
    show screen speedlines

    "前を向いた瞬間、視界が一気に開ける。"

    ## 作戦ボード：蓮が前を向いた瞬間の、全員の位置（水色が蓮のチーム。右へ攻める）
    $ tactics(home="sky", caption="後半40分　0−1", dots=[
        ("h", "", (52, 22)), ("h", "", (50, 48)),
        ("h", "", (80, 15), (90, 13), 0.5, 1.2),
        ("h", "", (79, 55), (91, 57), 0.7, 1.2),
        ("a", "", (66, 46)), ("a", "", (88, 27)), ("a", "", (89, 42)), ("a", "", (95, 34)),
        ("a", "", (102, 34)),
        ("ren", "蓮", (68, 35), (74, 35), 0.2, 0.9),
        ("ball", "", (69.5, 36), (75.5, 36), 0.2, 0.9),
        ],
        arrows=[((80, 15), (91, 13), 0.4, "w"), ((79, 55), (92, 57), 0.6, "w"),
                ((74, 35), (88, 35), 1.2, "y")])
    "右に味方。左にも味方。ゴールまで、あと三十メートル。"
    "いける。"

    hide screen speedlines
    ## 左（上）の外から、金の輪の神城が一直線に来る
    $ se("スパイクが芝をえぐる音")
    $ tactics(home="sky", caption="後半40分　0−1", dots=[
        ("h", "", (52, 22)), ("h", "", (50, 48)),
        ("h", "", (90, 13)), ("h", "", (91, 57)),
        ("a", "", (66, 46)), ("a", "", (88, 27)), ("a", "", (89, 42)), ("a", "", (95, 34)),
        ("a", "", (102, 34)),
        ("ren", "蓮", (74, 35)),
        ("ball", "", (75.5, 36)),
        ("kami", "", (57, 4), (67, 25), 0.15, 0.7),     # 名前はこのあとのカットインで見せる
        ],
        arrows=[((57, 4), (72, 33), 0.0, "r")])
    "そう思った時だった。"

    $ tactics_off()
    scene cg op_kamishiro at cam_snap(1.12, 0.5, 0.4)
    with hpunch

    "左から、白いユニフォームが一直線に迫ってくる。"

    ## カットインは文字を出さずに見せる（セリフ枠と重ならないように）。クリックで次へ
    window auto hide
    $ meet("神城")
    show screen cutin("{rb}神城{/rb}{rt}かみしろ{/rt} {rb}凌{/rb}{rt}りょう{/rt}", "U-15 日本代表")
    pause           # クリック（タップ）するまで、カットインを見せたままにする
    hide screen cutin
    pause 0.3
    "{rb}桜嶺{/rb}{rt}おうりょう{/rt}中、{rb}神城{/rb}{rt}かみしろ{/rt} {rb}凌{/rb}{rt}りょう{/rt}。"
    "同じ中三なのに、もう年代別の日本代表に呼ばれている男。"
    "その目が、ほんの一瞬だけ、スタンドの最前列へ動いた。"
    if persistent.trial_cleared:
        ## 2周目から：最前列にいた人が見える
        "最前列で、腕を組んだ大人が一人、小さくうなずいた。"
    voice "audio/voice/kamishiro_ikasenai.mp3"
    kamishiro "――行かせない"
    "一瞬、目が合った。"

    scene cg op_cutback at cam_jog
    with dissolve

    "速い。でも、見えてる。"
    "右足のアウト――足の外側で、ボールを外に持ち出す。"
    "神城の重心が、半歩だけ外に流れた。"
    "抜ける。"

    ## ここだけ時間がゆっくりになる
    show cg op_cutback at slowmo(5.0)
    "そう確信して、踏み込んだ右足が――"

    $ se("鈍い衝突音")
    hide screen scoreboard
    show cg op_cutback at red_hit
    with flash
    with hard_punch

    "ぶつかった、と思った時には、もう空が見えていた。"

    hide screen letterbox
    scene cg ren_down at cam_pull(10.0, 1.1)
    with Dissolve(1.5)
    $ bgm("（止まる）")

    "音が消えた。"
    "歓声も、笛も、自分の呼吸も。"
    "右ひざの奥で、何かがぷつんと切れたような感覚だけが残っている。"
    kamishiro "……おい"
    kamishiro "おい、大丈夫か！"
    "見下ろしてくる神城の顔は、逆光でよく見えない。"
    "ただ、その声が震えていることだけは分かった。"
    "立たなきゃ。"
    "まだ時間はある。まだ、同点にできる。"
    "地面に手をついた。"
    "右足に、力が入らなかった。"

    $ se("担架を呼ぶ笛")
    scene black
    with Dissolve(1.5)

    ############################################################################
    ## シーン2：病院（同じ日の夜）
    ############################################################################
    $ set_cal("12月14日（日）", "夜", quiet=True)
    scene bg hospital_lobby_night
    with dissolve

    "消毒液の匂いがする。"
    "右ひざには、固い{rb}装具{/rb}{rt}そうぐ{/rt}が巻かれていた。"

    $ se("小走りの足音")
    show hinata breath
    with dissolve

    $ meet("ひなた")
    voice "audio/voice/hinata_ren_breath.mp3"
    hinata "……{rb}蓮{/rb}{rt}れん{/rt}！"
    "{rb}篠宮{/rb}{rt}しのみや{/rt}ひなた。"
    "家が三軒隣で、幼稚園からずっと一緒の幼なじみ。"
    "試合のあと、そのまま走ってきたらしい。頬も耳も、寒さで真っ赤になっている。"

    show hinata teary
    voice "audio/voice/hinata_t_pro_181.mp3"
    hinata "試合、終わったよ"
    hinata "0−1。……そのまま"
    $ bgm("静かなピアノ")       # 負けたと分かったところで曲を入れる
    "そうか。"
    "俺が運ばれたあと、誰も点を取れなかったんだ。"
    hinata "蓮のせいじゃないからね"
    hinata "あれは事故だよ。{rb}神城{/rb}{rt}かみしろ{/rt}くんも、真っ青な顔してた"
    ren "分かってるよ"
    "分かってる。"
    "あいつはボールに行っただけだ。無理に踏み込んだのは、俺のほうだ。"
    voice "audio/voice/hinata_t_pro_192.mp3"
    hinata "お医者さん、なんて？"
    ren "{rb}靭帯{/rb}{rt}じんたい{/rt}がちょっと切れてるって。手術はいらない。春には走れるってさ"

    show hinata stare
    voice "audio/voice/hinata_honto.mp3"
    hinata "……ほんとに？"
    ren "ほんと"
    voice "audio/voice/hinata_t_pro_200.mp3"
    hinata "蓮ってさ、嘘つく時、右の眉毛が上がるんだよ"
    ren "上がってない"
    voice "audio/voice/hinata_t_pro_203.mp3"
    hinata "上がってる。幼稚園の時からずっと見てるんだから"
    "嘘じゃない。半分だけ。"
    "医者は最後に、こうも言っていた。"
    "――元どおりには、たぶん戻らない。"
    "――無理をすれば、次はもっと大きく切れる。その時は手術になる、と。"
    "それは、言わなくていいことだ。"
    hinata "……{rb}桜嶺{/rb}{rt}おうりょう{/rt}の推薦、大丈夫だよね？"
    ren "大丈夫だろ。ケガひとつで取り消すような学校じゃ――"
    "言いかけて、やめた。"
    "自分でも、それが本当かどうか分からなかったから。"

    show hinata forcesmile
    voice "audio/voice/hinata_t_pro_216.mp3"
    hinata "……帰ろ。{rb}千鶴{/rb}{rt}ちづる{/rt}さん、お店閉めて迎えに来てるよ"
    "ひなたが、俺の{rb}松葉杖{/rb}{rt}まつばづえ{/rt}を拾って差し出す。"
    "その指先が、冷たかった。"

    scene black
    with Dissolve(1.0)

    ############################################################################
    ## シーン3：推薦取り消し（中3・1月）
    ############################################################################
    $ bgm("（なし）")           # 病院の曲を、ゆっくり消す
    $ set_cal("1月10日（土）", "はやせ食堂（臨時休業）", quiet=True)
    scene bg shokudo_day
    with dissolve

    "年が明けた。"
    "ひざの腫れは引いて、{rb}松葉杖{/rb}{rt}まつばづえ{/rt}ももう要らない。"
    "ただ、走るのは医者に止められていた。"
    "その日は病院の検査の日で、店は臨時休業にしてあった。"
    "がらんとした店で、妹のゆずはテレビのお笑い番組を見て笑っている。"

    show mother normal
    with dissolve

    $ meet("母")
    "母の{rb}千鶴{/rb}{rt}ちづる{/rt}が、鳴りだした店の電話を取った。"
    voice "audio/voice/haha_hai.mp3"
    haha "はい、はやせ食堂です。……あ、はい。いつもお世話になっております"
    "母の声が、ふだんより一段高くなった。"
    haha "……はい。……ええ。……そうですか"

    show mother down
    "声が、だんだん小さくなっていく。"
    "受話器を置いた母は、こっちを見ないまま言った。"
    haha "{rb}蓮{/rb}{rt}れん{/rt}。……{rb}桜嶺{/rb}{rt}おうりょう{/rt}から"
    haha "推薦、なしになったって"
    $ bgm("日常の静かな曲")     # 推薦がなくなったと分かってから曲を入れる
    ren "……そっか"
    haha "お医者さんの診断書を見て、春からすぐ試合に出られるか分からないから、って"
    "不思議と、涙は出なかった。"
    "ただ、テレビの中の笑い声が、やけにうるさかった。"
    haha "一般入試なら、まだ間に合うよ"
    ren "無理だって。桜嶺の偏差値、知ってるだろ"
    haha "……じゃあ"
    ren "{rb}港北{/rb}{rt}こうほく{/rt}でいいよ。近いし"
    "県立港北高校。家から自転車で十分。"
    "サッカー部は、あるにはある。ここ2年は部員が足りなくて、大会に出ていない。"
    "そこに行くことの意味を、母も俺も分かっていた。"

    hide mother
    with dissolve
    "母は何も言わずに、厨房で明日の仕込みを始めた。"
    $ se("包丁がまな板を叩く音")
    "その音だけが、ずっと店の中に響いていた。"

    scene black
    with dissolve
    $ set_cal("1月10日（土）", "夜", quiet=True)
    scene bg ren_room_night
    with dissolve

    $ se("トークアプリの通知音")
    "知らないアカウントから、メッセージが届いていた。"

    window auto hide
    $ talk_start("神城 凌", "23:04")
    $ talk("神城", "神城です。チームの先輩に連絡先を聞いた")
    $ talk("神城", "桜嶺の話、聞いた")
    $ talk("神城", "ごめん")
    $ talk_system("既読")

    "返す言葉が見つからなかった。"
    "既読をつけたまま、何も返せなかった。"

    window auto hide
    $ talk_end()
    scene black
    with Dissolve(1.0)

    ############################################################################
    ## シーン3.2：2月の自由行動（中3・2月）―― ひなたと母との時間。自由行動の遊び方の練習にもなる
    ############################################################################
    call pro_free_feb
    scene black
    with Dissolve(1.0)

    ############################################################################
    ## シーン3.5：合格発表（3月）―― 1月から4月まで一気にとばないように
    ############################################################################
    $ set_cal("3月19日（木）", "港北高校　合格発表")
    $ coat_on()                 # ひなたはマフラーを巻いている（コートの絵：smile / stare / pout / forcesmile だけ）
    scene bg kohoku_gate_march
    with dissolve
    $ bgm("明るい春の曲")            # v0.32.2：2月の自由行動の曲から切りかえる
    "三月。ひざのリハビリの帰り、坂の上の県立{rb}港北{/rb}{rt}こうほく{/rt}高校の昇降口に、白い紙が貼り出されていた。"
    show hinata smile
    with dissolve
    voice "audio/voice/hinata_t_pro_314.mp3"
    hinata "ほら、蓮！　遅い！　もう見ちゃったよ"
    "ひなたが、マフラーをぐるぐる巻きにしたまま、掲示板の前で手をふっていた。"
    hinata "蓮の番号、あった。わたしのも、あった"
    ren "……自分で見る前に言うなよ"
    show hinata pout
    hinata "だって、蓮の番号、受験票より先に覚えてたもん"
    "受かってうれしい気持ちは、正直あまりなかった。去年の冬までは、ここに来るはずじゃなかった。"
    show hinata smile
    hinata "……ねえ。グラウンド、見ていこうよ"
    "校舎の裏の土のグラウンドは、ゴールのネットが破れて、誰もボールを蹴っていなかった。"
    hinata "サッカー部、あるにはあるんだって。部員、3人だけど"
    ren "……知ってる"
    hinata "お医者さん、4月からジョギングならいいって言ってたよね"
    ren "ジョギングだけな"
    show hinata stare
    hinata "蓮がやるならさ。わたし、マネージャーやる"
    ren "……やるなんて、言ってない"
    show hinata smile
    voice "audio/voice/hinata_t_pro_333.mp3"
    hinata "右の眉毛、上がってるよ"
    "思わず眉に手をやると、ひなたが、春の風みたいに笑った。"
    hide hinata
    with dissolve
    scene black
    with Dissolve(1.0)

    ############################################################################
    ## シーン4：入学前夜（4月）
    ############################################################################
    $ set_cal("4月7日（火）", "入学式の前夜")
    scene bg shokudo_night
    with dissolve
    $ bgm("あたたかいアコースティックギター")

    "四月。明日は、{rb}港北{/rb}{rt}こうほく{/rt}高校の入学式だ。閉店後の店で、母と二人、遅い夕飯を食べていた。"
    "ゆずはもう寝ている。まかないは、店で一番人気のアジフライ定食。"

    show mother smile
    with dissolve
    voice "audio/voice/haha_tabena.mp3"
    haha "ほら、冷めないうちに食べな"
    haha "制服、ちょっと大きかったね"
    ren "すぐ伸びるからって買ったの、母さんだろ"
    voice "audio/voice/haha_fufu.mp3"
    haha "そうだった"
    if flags.get("pro_feb_mother"):
        ## 2月に店を手伝ったときに、父さんの写真の話はしている（v0.32.2：二回言わない）
        "柱の、色あせた写真が目に入った。二月に店を手伝ったときと同じ顔で、父さんが笑っていた。"
    else:
        "柱の、色あせた写真が目に入った。この店の前の道で、最初にボールの蹴り方を教えてくれたのは父さんだった。"
    ## v0.29.11：蓮が中学で潮見FC（町のクラブ）にいた理由
    "小6の冬、{rb}潮見{/rb}{rt}しおみ{/rt}ブルーマリンズのジュニアユースのセレクションに落ちた。背は、クラスで前から三番目だった。"
    "次の週、母さんが店の常連さんに聞いてきたのが、町のクラブの潮見FCだった。そこで3年間、10番をつけた。"

    show mother serious
    haha "ねえ、{rb}蓮{/rb}{rt}れん{/rt}"
    haha "サッカー、続けるの？"
    "箸が止まった。ひざは、もうほとんど痛くない。軽く走るくらいなら、医者の許可も出ている。"
    "でも、港北のサッカー部は部員三人。{rb}桜嶺{/rb}{rt}おうりょう{/rt}のグラウンドは天然芝で、部員は百人を超える。"
    "今ごろ{rb}神城{/rb}{rt}かみしろ{/rt}は、あの芝の上で、春からの練習に参加しているはずだ。"
    haha "お母さんはね、どっちでもいいと思ってる"
    voice "audio/voice/haha_yaritai.mp3"
    haha "やりたいことやりな。それだけ"
    "母の口ぐせだった。昔から、何を決める時も、母はそう言う。"

    ## 最初の選択肢。ここでセーブの案内を出す
    call save_guide

    menu:
        "俺は――"

        "「続ける。まだ終わってない」":
            $ up("メンタル", 5)
            jump prologue_5a

        "「……もう、いいよ」":
            $ up("メンタル", -5)
            $ heart_up("ひなた", "信頼", 5)
            jump prologue_5b


################################################################################
## シーン5−A：「続ける」を選んだ場合
################################################################################
label prologue_5a:
    ren "続ける。まだ終わってない"
    "口に出してみて、初めて分かった。ずっと、誰かにそう言いたかったんだ。"

    show mother smile
    haha "そっか"
    haha "じゃあ明日から、お弁当また大盛りだね"
    ren "……ん"
    haha "お米、高いんだからね。ちゃんと勝ちなよ"
    ren "部員、三人しかいないんだけど"
    haha "じゃあ、まず八人集めな"
    $ set_flag("母_八人")         # 第1章で、千夏先輩に「7人です」と直されたときに思い出す
    "母は、当たり前みたいにそう言って笑った。"
    "部屋に戻って、押し入れの奥からスパイクを出した。決勝の日の芝が、まだ少しだけ靴底にこびりついていた。"

    scene black
    with Dissolve(1.0)

    $ set_cal("4月8日（水）", "入学式の朝")
    scene bg kohoku_gate_morning
    with dissolve
    $ bgm("明るい春の曲")

    show hinata smile
    with dissolve
    voice "audio/voice/hinata_ohayo.mp3"
    hinata "おはよ、{rb}蓮{/rb}{rt}れん{/rt}！"
    voice "audio/voice/hinata_t_pro_426.mp3"
    hinata "……あ。その顔、決めたんだ"
    ren "なんで分かるんだよ"
    voice "audio/voice/hinata_t_pro_429.mp3"
    hinata "幼稚園から見てるって言ったでしょ"
    hinata "入学式終わったら、グラウンド行くよ。わたし、マネージャーやるから"
    ren "……本気だったのかよ"
    voice "audio/voice/hinata_t_pro_433.mp3"
    hinata "3月に言ったじゃん"
    "桜の花びらが、ひなたの肩に落ちる。"
    "県立{rb}港北{/rb}{rt}こうほく{/rt}高校。部員三人のサッカー部。ここから、俺の二回目のキックオフが始まる。"

    jump chapter1


################################################################################
## シーン5−B：「もう、いいよ」を選んだ場合
################################################################################
label prologue_5b:
    ren "……もう、いいよ"
    "自分の声が、思ったより小さかった。"

    show mother sadsmile
    haha "そっか"
    haha "それも、{rb}蓮{/rb}{rt}れん{/rt}が決めたことだね"
    "母はそれ以上、何も言わなかった。それが、いちばんこたえた。"
    "部屋に戻って、スパイクを押し入れのいちばん奥にしまった。もう二度と、出すことはない。そう思った。"

    scene black
    with Dissolve(1.0)

    $ set_cal("4月8日（水）", "入学式の朝")
    scene bg kohoku_gate_morning
    with dissolve
    $ bgm("静かな春の曲")

    show hinata pout
    with dissolve
    voice "audio/voice/hinata_ohayo2.mp3"
    hinata "おはよ、{rb}蓮{/rb}{rt}れん{/rt}"
    "ひなたが突き出してきた大きな紙袋には、押し入れにしまったはずのスパイクが入っていた。"
    ren "……おい。なんでお前がこれ持ってるんだよ"
    voice "audio/voice/hinata_t_pro_468.mp3"
    hinata "{rb}千鶴{/rb}{rt}ちづる{/rt}さんが、朝こっそり渡してくれた"
    hinata "入学式終わったら、グラウンド行くよ。わたし、マネージャーやるって決めたから。蓮は見るだけでいいから"
    ren "見ない"
    hinata "見るの"

    show hinata serious
    hinata "蓮がほんとにやめたいなら、わたしもう何も言わない"
    hinata "でも、嘘ついてる時の顔でやめるのは、許さない"
    "……右の眉毛のことを、まだ覚えてやがる。"
    "桜の花びらの中で、俺は紙袋を受け取った。受け取ってしまった。"

    jump chapter1


################################################################################
## 2月の自由行動（中3）。土曜日が2日。行き先は3つで、1つは行けない
################################################################################

define PRO_FREE_DATES = ["2月7日（土）", "2月14日（土）"]

define PRO_RECAP = "中3の冬。県大会の決勝で、神城と競り合って、右ひざをケガした。\n年が明けて、桜嶺の推薦が取り消された。\n\n春から、近所の県立港北高校に行く。\nサッカー部は、あるにはある。ここ2年は、部員が足りなくて大会に出ていない。\n\n医者には、まだ走るなと言われている。"

## (id, 名前, x, y, 顔, 中身, ラベル)
define PRO_SPOTS = [
    ("slope", "港への坂道", 870, 330, "hinata", "ひなた（リハビリの帰り）", "pro_feb_hinata"),
    ("shokudo", "はやせ食堂", 850, 470, "mother", "母（店の手伝い）", "pro_feb_mother"),
    ("pier", "港の防波堤", 330, 560, None, "ボールを蹴る", "pro_feb_pier"),
]

default pro_day = 1
default pro_dest = ""

init python:
    def pro_spots():
        out = []
        for sid, name, x, y, face, ev, lab in PRO_SPOTS:
            done = store.flags.get(lab)
            d = {"id": sid, "name": name, "x": x, "y": y, "event": "" if done else ev, "enabled": not done}
            if face:
                d["face"] = face
            out.append(d)
        return out

    def pro_spot_label(sid):
        for s in PRO_SPOTS:
            if s[0] == sid:
                return s[6]
        return PRO_SPOTS[0][6]

label pro_free_feb:
    $ recap_text = PRO_RECAP
    $ pro_day = 1
    while pro_day <= len(PRO_FREE_DATES):
        $ amb_stop()
        $ set_cal(PRO_FREE_DATES[pro_day - 1], "土曜の午後")
        $ bgm("のんびりした春の曲")        # v0.32.2：前の場面の悲しいピアノを引きずらないように
        if pro_day == 1:
            ## カレンダーが2月に変わってから、自由行動の説明を出す
            "二月。来月の港北の入試を前にした、数少ない自由な土曜日。"
            window auto hide
            tuto "「自由行動」です。行く場所を、地図から1か所選びます。"
            tuto "人に会える場所には、顔のアイコンが出ます。行った先で、能力や気持ちが少し動きます。"
            tuto "2月の土曜日は2日だけ。行ける場所は3つあるので、どこか1つには行けません。"
        window auto hide
        call screen action_map(pro_spots(), "2月の土曜日、どこへ行く？（残り" + str(len(PRO_FREE_DATES) + 1 - pro_day) + "日）")
        $ pro_dest = pro_spot_label(_return)
        $ set_flag(pro_dest)
        scene black
        with dissolve
        call expression pro_dest
        $ amb_stop()
        $ pro_day += 1
    $ amb_stop()
    return

## 港への坂道：リハビリの帰り、ひなたが待っている（2月14日なら、義理のチョコ）
label pro_feb_hinata:
    scene bg slope_eve
    $ coat_on()
    with dissolve
    $ bgm("あたたかいアコースティックギター")
    "病院のリハビリは、週に二回。ゴムのチューブを引っぱって、片足で立って、ゆっくり座る。それだけで一時間かかる。"
    "帰りの坂の下で、ひなたが自転車にまたがって待っていた。"
    show hinata smile
    with dissolve
    hinata "おつかれ。今日は何回、片足で立てた？"
    ren "……数えてない"
    hinata "うそ。蓮、そういうの絶対数えるもん"
    ren "……三十二回"
    show hinata smile
    hinata "ほらね。先週より八回多い"
    "なんで先週の回数まで、と言いかけてやめた。ひなたのスマホのメモに、俺のリハビリの記録が並んでいるのを、前に一度見たことがある。"
    if PRO_FREE_DATES[pro_day - 1].startswith("2月14日"):
        show hinata pout
        hinata "……あと、これ"
        ## v0.32.2：義理チョコの一枚絵（作者の声）
        hide hinata
        scene cg pro_hinata_choco
        with Dissolve(1.0)
        "自転車のかごから、紙袋が押しつけられた。"
        hinata "義理だからね。リハビリがんばってるで賞。ゆずちゃんのぶんも入ってるから"
        ren "……ゆずのぶんは、ゆずに渡せよ"
        hinata "いいの！"
        scene bg slope_eve
        show hinata pout
        with dissolve
        $ heart_up("ひなた", "ときめき", 3)
        $ set_flag("pro_ひなた_チョコ")
    show hinata stare
    hinata "……ねえ。ひざ、ほんとはどうなの"
    menu:
        "「平気だって。春には走れる」":
            $ lean("野心型")
            show hinata stare
            hinata "……右の眉毛"
            ren "上がってない"
            hinata "……ふーん"
            "ひなたは、それ以上は聞かなかった。聞かないでいてくれるのが、ひなたのやさしさだと分かっていた。"
        "「……ちょっと、こわい」":
            $ lean("求道型")
            show hinata forcesmile
            hinata "……うん"
            ren "走ったら、また切れる気がする。サッカーのことを考えると、ひざのほうが先に返事するんだ"
            hinata "そっか"
            "ひなたは自転車を押して、俺の左側に並んだ。右ひざの側じゃないほうに。"
            show hinata smile
            hinata "こわいって言えるなら、大丈夫だよ。たぶん"
            $ heart_up("ひなた", "信頼", 4)
            $ up("メンタル", 2)
    ## ひなたといると、ストレッチやケアを手伝ってくれる（その人らしい能力が少し上がる）
    $ up("フィジカル", 2)
    $ up("無理ゲージ", -2)
    hide hinata
    with dissolve
    return

## はやせ食堂：店の手伝い。柱の父さんの写真（4月の入学前夜は、この写真を「柱の、色あせた写真」で受ける。父がいない理由は、まだ言わない）
label pro_feb_mother:
    scene bg shokudo_day
    with dissolve
    $ bgm("のんびりした春の曲")
    "土曜の昼の店は、港で働く人たちでいっぱいになる。皿を下げて、水を注いで、レジを打つ。走れなくても、それならできる。"
    show mother normal
    with dissolve
    haha "蓮、三番さんに、からあげ定食ふたつ！"
    ren "はいよ"
    "柱に、少し色あせた父さんの写真が貼ってある。泥だらけのユニフォームで歯を見せて笑う、俺に最初にボールを蹴らせた人だ。"
    show mother smile
    haha "……春から、高校生か。早いね"
    menu:
        "「店、春からも手伝うよ」":
            $ lean("仲間型")
            show mother sadsmile
            haha "……ばか。そういうことを言ってほしいんじゃないよ"
            "母は、布巾を持ったままの手で、俺の頭を軽くはたいた。"
            haha "店は、あたしがやる。あんたは、やりたいことやりな"
            $ up("メンタル", 3)
        "「……その写真、まだ貼ってるんだな」":
            $ lean("求道型")
            show mother normal
            haha "はがす理由が、ないからね"
            "母は、写真のほうを見ないで言った。"
            haha "……あの人なら、今のあんたに、なんて言うんだろうね"
            "答えなかった。答えられなかった。"
            $ up("メンタル", 2)
            $ set_flag("pro_父の写真")
    hide mother
    with dissolve
    "柱の写真の父さんは、ずっと同じ顔で笑っていた。"
    return

## 港の防波堤：一人でボールを蹴る（医者には走るなと言われている）
label pro_feb_pier:
    scene bg harbor_winter_eve
    $ coat_on()
    with dissolve
    $ se("波の音、カモメ")
    "防波堤の先まで、古いボールを持ってきた。医者には、まだ走るなと言われている。止まったまま蹴るだけなら、いい。"
    "コンクリートの壁に向かって、右足の内側で、そっと押し出す。"
    $ se("ボールを蹴る音")
    "ボールは壁に当たって、少しずれて戻ってきた。どこかの家から、ピアノの音。同じところまで弾いて、止まって、また最初から。"
    menu:
        "もう少しだけ、強く蹴る":
            $ lean("野心型")
            $ se("ボールを蹴る音")
            "二回、三回。戻ってくるたびに、少しずつ強く蹴った。"
            "十回目で、右ひざの奥が、ちくりと鳴った。やめておけ、と、ひざのほうが先に言った。"
            $ up("技術", 2)
            $ up("無理ゲージ", 4)
        "今日は、ここまでにする":
            $ lean("求道型")
            "ボールを足の裏で止めて、腰を下ろした。壁でのずれ方を思い出すと、蹴る足首が、少しだけ開いていた。"
            "走れなくても、見ることはできる。"
            $ up("戦術眼", 2)
    "ピアノの音は、また同じところで止まった。"
    return
