## prologue.rpy ―― プロローグ「止まった冬」
##   台本：アンイレ 体験版台本（プロローグのタブ）

label prologue:
    scene black
    call show_title("プロローグ", "止まった冬")

    ############################################################################
    ## シーン1：県大会決勝（中3・12月）
    ############################################################################
    $ set_cal("12月14日（日）", "県大会　決勝", quiet=True)

    ## 黒い画面に、ひとことだけ
    $ quick_menu = False
    mono "吐く息が白い。"
    $ quick_menu = True

    scene cg op_breath at cam_push(14.0, 1.06)
    with Dissolve(1.2)
    show screen letterbox

    "十二月の芝は、思っていたよりずっと硬かった。"

    scene bg stadium_winter_eve at cam_pan_r(16.0)
    with dissolve
    $ sb_set("後半", 40, 12, 0, 1, "#7fc4e8", "#f2f2ee")     # 蓮のチーム（水色）対 神城のチーム（白）
    show screen scoreboard

    "後半四十分。スコアは0−1。"
    "電光掲示板の数字が、一秒ずつ俺たちの残り時間を削っていく。"
    "県大会、決勝。"
    "勝てば全国。負ければ、俺の中学サッカーはここで終わる。"

    $ se("笛の音")
    $ bgm("緊迫した試合の曲")

    scene cg op_clear at cam_tilt_up(5.0)
    with dissolve

    "味方のクリアが、センターサークルのあたりで高く跳ねた。"

    show cg op_clear at cam_snap(1.15, 0.5, 0.0)
    "――来る。"
    "誰よりも先に、俺には見えていた。"
    "ボールが落ちる場所。相手のボランチが戻るより早く、そこに入れる。"

    $ se("芝を蹴る音")
    "芝を蹴る。"

    scene cg op_trap at cam_snap(1.1)
    with hpunch

    "胸で受ける。ボールが足もとに吸いついた。"

    scene cg op_open at cam_push(5.0, 1.15)
    with flash
    show screen speedlines

    "前を向いた瞬間、視界が一気に開ける。"
    "右に味方。左にも味方。ゴールまで、あと三十メートル。"
    "いける。"

    hide screen speedlines
    "そう思った時だった。"

    $ se("スパイクが芝をえぐる音")
    scene cg op_kamishiro at cam_snap(1.12, 0.5, 0.4)
    with hpunch

    "左から、白いユニフォームが一直線に迫ってくる。"

    ## カットインは文字を出さずに見せる（セリフ枠と重ならないように）。クリックで次へ
    window auto hide
    $ meet("神城")
    show screen cutin("{rb}神城{/rb}{rt}かみしろ{/rt} {rb}凌{/rb}{rt}りょう{/rt}", "U-15 日本代表")
    pause           # クリック（タップ）するまで、カットインを見せたままにする
    hide screen cutin
    pause 0.3
    "{rb}神城{/rb}{rt}かみしろ{/rt} {rb}凌{/rb}{rt}りょう{/rt}。"
    "同じ中三なのに、もう年代別の日本代表に呼ばれている男。"
    voice "audio/voice/kamishiro_ikasenai.mp3"
    kamishiro "――行かせない"
    "一瞬、目が合った。"

    scene cg op_cutback at cam_jog
    with dissolve

    "速い。でも、見えてる。"
    "右足のアウトで、ボールを内側に切り返す。"
    "神城の重心が、半歩だけ外に流れた。"
    "抜ける。"

    ## ここだけ時間がゆっくりになる
    show cg op_cutback at slowmo(5.0)
    "そう確信して、踏み込んだ右足が――"

    $ se("鈍い衝突音")
    hide screen scoreboard
    show cg op_cutback at red_hit
    with flash
    with hard_punch

    "ぶつかった、と思った時には、もう空が見えていた。"

    hide screen letterbox
    scene cg ren_down at cam_pull(10.0, 1.1)
    with Dissolve(1.5)
    $ bgm("（止まる）")

    "音が消えた。"
    "歓声も、笛も、自分の呼吸も。"
    "右ひざの奥で、何かがぷつんと切れたような感覚だけが残っている。"
    kamishiro "……おい"
    kamishiro "おい、大丈夫か！"
    "見下ろしてくる神城の顔は、逆光でよく見えない。"
    "ただ、その声が震えていることだけは分かった。"
    "立たなきゃ。"
    "まだ時間はある。まだ、同点にできる。"
    "地面に手をついた。"
    "右足に、力が入らなかった。"

    $ se("担架を呼ぶ笛")
    scene black
    with Dissolve(1.5)

    ############################################################################
    ## シーン2：病院（同じ日の夜）
    ############################################################################
    $ set_cal("12月14日（日）", "夜", quiet=True)
    scene bg hospital_lobby_night
    with dissolve

    "消毒液の匂いがする。"
    "右ひざには、固い{rb}装具{/rb}{rt}そうぐ{/rt}が巻かれていた。"

    $ se("小走りの足音")
    show hinata breath
    with dissolve

    $ meet("ひなた")
    voice "audio/voice/hinata_ren_breath.mp3"
    hinata "……{rb}蓮{/rb}{rt}れん{/rt}！"
    "{rb}篠宮{/rb}{rt}しのみや{/rt}ひなた。"
    "家が三軒隣で、幼稚園からずっと一緒の幼なじみ。"
    "スタンドから、そのまま走ってきたらしい。マフラーが片方ずり落ちている。"

    show hinata teary
    voice "audio/voice/hinata_sigh.mp3"
    hinata "試合、終わったよ"
    hinata "0−1。……そのまま"
    $ bgm("静かなピアノ")       # 負けたと分かったところで曲を入れる
    "そうか。"
    "俺が運ばれたあと、誰も点を取れなかったんだ。"
    hinata "蓮のせいじゃないからね"
    hinata "あれは事故だよ。{rb}神城{/rb}{rt}かみしろ{/rt}くんも、真っ青な顔してた"
    ren "分かってるよ"
    "分かってる。"
    "あいつはボールに行っただけだ。無理に踏み込んだのは、俺のほうだ。"
    voice "audio/voice/hinata_nee.mp3"
    hinata "お医者さん、なんて？"
    ren "{rb}靭帯{/rb}{rt}じんたい{/rt}がちょっと切れてるって。手術はいらない。春には走れるってさ"

    show hinata stare
    voice "audio/voice/hinata_honto.mp3"
    hinata "……ほんとに？"
    ren "ほんと"
    voice "audio/voice/hinata_nn.mp3"
    hinata "蓮ってさ、嘘つく時、右の眉毛が上がるんだよ"
    ren "上がってない"
    voice "audio/voice/hinata_mou.mp3"
    hinata "上がってる。幼稚園の時からずっと見てるんだから"
    "嘘じゃない。半分だけ。"
    "医者は最後に、こうも言っていた。"
    "――無理をすれば、次はもっと大きく切れる。その時は手術になる、と。"
    "それは、言わなくていいことだ。"
    hinata "……{rb}桜嶺{/rb}{rt}おうりょう{/rt}の推薦、大丈夫だよね？"
    ren "大丈夫だろ。ケガひとつで取り消すような学校じゃ――"
    "言いかけて、やめた。"
    "自分でも、それが本当かどうか分からなかったから。"

    show hinata forcesmile
    voice "audio/voice/hinata_un_soft.mp3"
    hinata "……帰ろ。{rb}千鶴{/rb}{rt}ちづる{/rt}さん、お店閉めて迎えに来てるよ"
    "ひなたが、俺の{rb}松葉杖{/rb}{rt}まつばづえ{/rt}を拾って差し出す。"
    "その指先が、少しだけ冷たかった。"

    scene black
    with Dissolve(1.0)

    ############################################################################
    ## シーン3：推薦取り消し（中3・1月）
    ############################################################################
    $ bgm("（なし）")           # 病院の曲を、ゆっくり消す
    $ set_cal("1月10日（土）", "はやせ食堂（定休日）", quiet=True)
    scene bg shokudo_day
    with dissolve

    "年が明けた。"
    "ひざの腫れは引いて、{rb}松葉杖{/rb}{rt}まつばづえ{/rt}ももう要らない。"
    "ただ、走るのは医者に止められていた。"
    "定休日の店で、妹のゆずはテレビのお笑い番組を見て笑っている。"

    show mother normal
    with dissolve

    $ meet("母")
    "母が、鳴りだした店の電話を取った。"
    voice "audio/voice/haha_hai.mp3"
    haha "はい、はやせ食堂です。……あ、はい。いつもお世話になっております"
    "母の声が、ふだんより一段高くなった。"
    haha "……はい。……ええ。……そうですか"

    show mother down
    "声が、だんだん小さくなっていく。"
    "受話器を置いた母は、こっちを見ないまま言った。"
    haha "{rb}蓮{/rb}{rt}れん{/rt}。……{rb}桜嶺{/rb}{rt}おうりょう{/rt}から"
    haha "推薦、なしになったって"
    $ bgm("日常の静かな曲")     # 推薦がなくなったと分かってから曲を入れる
    ren "……そっか"
    haha "お医者さんの診断書を見て、春からすぐ試合に出られるか分からないから、って"
    "不思議と、涙は出なかった。"
    "ただ、テレビの中の笑い声が、やけにうるさかった。"
    haha "一般入試なら、まだ間に合うよ"
    ren "無理だって。桜嶺の偏差値、知ってるだろ"
    haha "……じゃあ"
    ren "{rb}港北{/rb}{rt}こうほく{/rt}でいいよ。近いし"
    "県立港北高校。家から自転車で十分。"
    "サッカー部は、あるにはある。去年は部員が足りなくて、大会に出ていない。"
    "そこに行くことの意味を、母も俺も分かっていた。"

    hide mother
    with dissolve
    "母は何も言わずに、厨房で明日の仕込みを始めた。"
    $ se("包丁がまな板を叩く音")
    "その音だけが、ずっと店の中に響いていた。"

    scene black
    with dissolve
    $ set_cal("1月10日（土）", "夜", quiet=True)
    scene bg ren_room_night
    with dissolve

    $ se("トークアプリの通知音")
    "知らないアカウントから、メッセージが届いていた。"

    window auto hide
    $ talk_start("神城 凌", "23:04")
    $ talk("神城", "神城です。チームの先輩に連絡先を聞いた")
    $ talk("神城", "桜嶺の話、聞いた")
    $ talk("神城", "ごめん")
    $ talk_system("既読")

    "返す言葉が見つからなかった。"
    "既読の文字だけが、画面に残った。"

    window auto hide
    $ talk_end()
    scene black
    with Dissolve(1.0)

    ############################################################################
    ## シーン4：入学前夜（4月）
    ############################################################################
    $ set_cal("4月7日（火）", "入学式の前夜")
    scene bg shokudo_night
    with dissolve
    $ bgm("あたたかいアコースティックギター")

    "四月。明日は、{rb}港北{/rb}{rt}こうほく{/rt}高校の入学式だ。"
    "閉店後の店で、母と二人、遅い夕飯を食べていた。"
    "ゆずはもう寝ている。"
    "今日のまかないは、店で一番人気のアジフライ定食。"

    show mother smile
    with dissolve
    voice "audio/voice/haha_tabena.mp3"
    haha "ほら、冷めないうちに食べな"
    haha "制服、ちょっと大きかったね"
    ren "すぐ伸びるからって買ったの、母さんだろ"
    voice "audio/voice/haha_fufu.mp3"
    haha "そうだった"
    "母が笑う。"
    "店の壁には、色あせた写真が一枚、ずっと貼られている。"
    "小さな俺と、ボールを抱えた父さん。"
    "この店の前の道で、最初にボールの蹴り方を教えてくれたのは父さんだった。"

    show mother serious
    haha "ねえ、{rb}蓮{/rb}{rt}れん{/rt}"
    haha "サッカー、続けるの？"
    "箸が止まった。"
    "ひざは、もうほとんど痛くない。軽く走るくらいなら、医者の許可も出ている。"
    "でも。"
    "港北のサッカー部は、部員が三人しかいないらしい。"
    "{rb}桜嶺{/rb}{rt}おうりょう{/rt}のグラウンドは天然芝で、部員は百人を超える。"
    "今ごろ{rb}神城{/rb}{rt}かみしろ{/rt}は、あの芝の上で、春からの練習に参加しているはずだ。"
    haha "お母さんはね、どっちでもいいと思ってる"
    voice "audio/voice/haha_yaritai.mp3"
    haha "やりたいことやりな。それだけ"
    "母の口ぐせだった。"
    "昔から、何を決める時も、母はそう言う。"

    ## 最初の選択肢。ここでセーブの案内を出す
    call save_guide

    menu:
        "俺は――"

        "「続ける。まだ終わってない」":
            $ up("メンタル", 5)
            jump prologue_5a

        "「……もう、いいよ」":
            $ up("メンタル", -5)
            $ heart_up("ひなた", "信頼", 5)
            jump prologue_5b


################################################################################
## シーン5−A：「続ける」を選んだ場合
################################################################################
label prologue_5a:
    ren "続ける。まだ終わってない"
    "口に出してみて、初めて分かった。"
    "ずっと、誰かにそう言いたかったんだ。"

    show mother smile
    haha "そっか"
    haha "じゃあ明日から、お弁当また大盛りだね"
    ren "……ん"
    haha "お米、高いんだからね。ちゃんと勝ちなよ"
    ren "部員、三人しかいないんだけど"
    haha "じゃあ、まず八人集めな"
    "母は、当たり前みたいにそう言って笑った。"
    "部屋に戻って、押し入れの奥からスパイクを出した。"
    "決勝の日の芝が、まだ少しだけ靴底にこびりついていた。"

    scene black
    with Dissolve(1.0)

    $ set_cal("4月8日（水）", "入学式の朝")
    scene bg kohoku_gate_morning
    with dissolve
    $ bgm("明るい春の曲")

    show hinata smile
    with dissolve
    voice "audio/voice/hinata_ohayo.mp3"
    hinata "おはよ、{rb}蓮{/rb}{rt}れん{/rt}！"
    voice "audio/voice/hinata_a.mp3"
    hinata "……あ。その顔、決めたんだ"
    ren "なんで分かるんだよ"
    voice "audio/voice/hinata_fufu.mp3"
    hinata "幼稚園から見てるって言ったでしょ"
    hinata "入学式終わったら、グラウンド行くよ。私、マネージャーやるから"
    ren "は？　聞いてないぞ"
    voice "audio/voice/hinata_ehehe.mp3"
    hinata "今言った"
    "桜の花びらが、ひなたの肩に落ちる。"
    "県立{rb}港北{/rb}{rt}こうほく{/rt}高校。部員三人のサッカー部。"
    "ここから、俺の二回目のキックオフが始まる。"

    jump chapter1


################################################################################
## シーン5−B：「もう、いいよ」を選んだ場合
################################################################################
label prologue_5b:
    ren "……もう、いいよ"
    "自分の声が、思ったより小さかった。"

    show mother sadsmile
    haha "そっか"
    haha "それも、{rb}蓮{/rb}{rt}れん{/rt}が決めたことだね"
    "母はそれ以上、何も言わなかった。"
    "それが、いちばんこたえた。"
    "部屋に戻って、スパイクを押し入れのいちばん奥にしまった。"
    "もう二度と、出すことはない。"
    "そう思った。"

    scene black
    with Dissolve(1.0)

    $ set_cal("4月8日（水）", "入学式の朝")
    scene bg kohoku_gate_morning
    with dissolve
    $ bgm("静かな春の曲")

    show hinata pout
    with dissolve
    voice "audio/voice/hinata_ohayo2.mp3"
    hinata "おはよ、蓮"
    "ひなたが、大きな紙袋を突き出してきた。"
    "中には、押し入れにしまったはずのスパイクが入っていた。"
    ren "……おい。なんでお前がこれ持ってるんだよ"
    voice "audio/voice/hinata_hora.mp3"
    hinata "{rb}千鶴{/rb}{rt}ちづる{/rt}さんが、朝こっそり渡してくれた"
    hinata "入学式終わったら、グラウンド行くよ。見るだけでいいから"
    ren "見ない"
    hinata "見るの"

    show hinata serious
    hinata "蓮がほんとにやめたいなら、私もう何も言わない"
    hinata "でも、嘘ついてる時の顔でやめるのは、許さない"
    "……右の眉毛のことを、まだ覚えてやがる。"
    "桜の花びらの中で、俺は紙袋を受け取った。"
    "受け取ってしまった。"

    jump chapter1
