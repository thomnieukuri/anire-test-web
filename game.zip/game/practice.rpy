## practice.rpy ―― 自由行動の「練習メニュー」（v0.29.0）
##   黒田が練習を見るようになった6月から、自由行動の1日は
##     ① 練習メニューを選ぶ（技術・フィジカル・戦術眼・メンタル）→ 軽い出来事で、毎回だれかに会う
##     ② 行動マップで、会いに行く人を選ぶ
##     ③ 夜のトーク
##   の順に進む（第2章 ch2_free_loop・第3章 ch3_free_loop から call practice_day(month)）。
##   第1章（黒田が来る前）は練習なしで、人を選ぶだけ。
##
##   上がる数値（選んだメニューの能力 +PRACTICE_GAIN、ひざの無理ゲージは PRACTICE_MENUS の値）は practice_finish で一度に足す。
##   出来事の中では、絆・ヒロインの信頼などの小さな上げ下げだけを書く（能力はここで足すので、出来事では上げない）。
##   ※ 第1章・第2章・第3章から移した場面（ch1_practice_* ch2_pr_* ch3_pr_* ch2_pier*）は、もとの数値を残しているものがある。
##
##   出来事は、まだ見ていないものから出る（同じメニューを続けて選んでも、毎回ちがう人に会う）。
##   全部見たら、そのメニューの中で最初から。月の条件（○月だけ、○月から）は PRACTICE_EVENTS の3つ目。
##   その月に必ず最初に出したいもの（6月の防波堤のピアノ、12月の三好先輩のいない練習など）は PRACTICE_FIRST。

define PRACTICE_GAIN = 2

## (能力, 選択肢の文, ひざの無理ゲージ)
define PRACTICE_MENUS = [
    ("技術", "技術の練習（パス・トラップ・シュート）", 2),
    ("フィジカル", "フィジカルの練習（走りこみ・体幹）", 3),
    ("戦術眼", "戦術眼の練習（作戦ボード・試合の映像）", 0),
    ("メンタル", "メンタルの練習（PK・声出し・防波堤）", -1),
]

## 夏（第2章）と、秋冬（第3章）
define PRACTICE_SUMMER = ("jun", "jul", "aug")
define PRACTICE_AUTUMN = ("sep", "oct", "nov", "dec")

## (ラベル, メニュー, 出す月)
define PRACTICE_EVENTS = [
    ## ── 技術 ──
    ("pr_takano_onetwo", "技術", PRACTICE_SUMMER),
    ("pr_eto_1on1", "技術", PRACTICE_SUMMER),
    ("pr_koike_long", "技術", PRACTICE_SUMMER),
    ("pr_noguchi_shoot", "技術", PRACTICE_SUMMER),
    ("ch1_practice_solo", "技術", PRACTICE_SUMMER),
    ("pr_takano_14", "技術", ("sep", "oct", "nov")),
    ("pr_sakaguchi_cross", "技術", PRACTICE_AUTUMN),
    ("pr_kuroda_trap", "技術", PRACTICE_AUTUMN),
    ("pr_noguchi_after", "技術", ("oct", "nov", "dec")),
    ("ch2_pr_face", "技術", PRACTICE_AUTUMN),
    ## ── フィジカル ──
    ("ch1_practice_miyoshi", "フィジカル", PRACTICE_SUMMER),
    ("ch1_practice_hinata_time", "フィジカル", ("jun", "jul")),
    ("pr_daimon_core", "フィジカル", PRACTICE_SUMMER),
    ("pr_mori_last", "フィジカル", PRACTICE_SUMMER),
    ("ch2_pr_run", "フィジカル", PRACTICE_SUMMER),
    ("ch3_pr_run", "フィジカル", PRACTICE_AUTUMN),
    ("pr_hinata_note", "フィジカル", PRACTICE_AUTUMN),
    ("pr_kiryu_stairs", "フィジカル", PRACTICE_AUTUMN),
    ("pr_miyoshi_last", "フィジカル", ("sep", "oct", "nov")),
    ## ── 戦術眼 ──
    ("ch2_pr_kiryu", "戦術眼", PRACTICE_SUMMER),
    ("ch2_pr_side", "戦術眼", PRACTICE_SUMMER),
    ("ch1_practice_kuroda", "戦術眼", PRACTICE_SUMMER),
    ("pr_koike_video", "戦術眼", PRACTICE_SUMMER),
    ("pr_miyashita_side", "戦術眼", PRACTICE_SUMMER),
    ("pr_chika_papers", "戦術眼", ("jul",)),
    ("ch3_pr_set", "戦術眼", PRACTICE_AUTUMN),
    ("ch3_pr_mark", "戦術眼", PRACTICE_AUTUMN),
    ("pr_kuroda_sakurei", "戦術眼", ("nov",)),
    ("pr_koike_volante", "戦術眼", PRACTICE_AUTUMN),
    ## ── メンタル ──
    ("ch2_pier", "メンタル", ("jun",)),
    ("ch2_pier_jul", "メンタル", ("jul",)),
    ("pr_daimon_pk", "メンタル", ("jun",)),
    ("pr_miyoshi_voice", "メンタル", PRACTICE_SUMMER),
    ("pr_gang_stretch", "メンタル", PRACTICE_SUMMER),
    ("pr_hinata_way", "メンタル", PRACTICE_SUMMER),
    ("pr_kuroda_before", "メンタル", PRACTICE_AUTUMN),
    ("ch3_pr_gk", "メンタル", ("sep", "oct", "nov")),
    ("ch3_pr_captain", "メンタル", ("dec",)),
    ("pr_pier_piano", "メンタル", PRACTICE_AUTUMN),
    ("pr_gang_back", "メンタル", ("oct",)),
]

## その月にそのメニューを初めて選んだとき、必ず先に出すもの
define PRACTICE_FIRST = {
    "jun": ["ch2_pier"],
    "jul": ["ch2_pier_jul"],
    "dec": ["ch3_pr_captain"],
}

default practice_seen = []
default practice_menu = ""
default practice_month = ""
default practice_lab = ""
default practice_tuto_done = False

init python:

    def practice_pick(menu, month):
        """そのメニュー・その月に出せる出来事から、まだ見ていないものを1つ選ぶ"""
        pool = [lab for lab, m, months in PRACTICE_EVENTS if m == menu and month in months]
        first = [lab for lab in PRACTICE_FIRST.get(month, ()) if lab in pool and lab not in store.practice_seen]
        if first:
            lab = first[0]
        else:
            left = [lab for lab in pool if lab not in store.practice_seen]
            if not left:
                ## 全部見たら、そのメニューの中で最初から（ほかのメニューの「見た」は残す）
                store.practice_seen = [x for x in store.practice_seen if x not in pool]
                left = list(pool)
            lab = renpy.random.choice(left)
        store.practice_seen = store.practice_seen + [lab]
        return lab

    def practice_muri(menu, month):
        """そのメニューでたまる無理ゲージ（11月はひざが腫れているので、技術とフィジカルは倍）"""
        for key, _text, muri in PRACTICE_MENUS:
            if key == menu:
                if month == "nov" and muri > 0:
                    return muri * 2
                return muri
        return 0


## 自由行動の1日のはじめ：練習メニューを選んで、軽い出来事を1つ見る
label practice_day(month):
    $ practice_month = month
    scene bg kohoku_ground_eve
    with dissolve
    $ bgm("明るい部活の曲")
    window auto hide
    if not practice_tuto_done:
        $ practice_tuto_done = True
        tuto "6月からは、{rb}黒田{/rb}{rt}くろだ{/rt}が練習を見ます。自由行動の日は、まず練習メニューを1つ選び、そのあと行動マップで会いに行く人を選びます。"
        tuto "選んだ能力が上がります。技術とフィジカルは、ひざに少し負担がかかります。メンタルの練習は、ひざを休める日にもなります。"
    menu:
        "今日の練習メニューは？"
        "技術の練習（パス・トラップ・シュート）" (nochosen=True):
            $ practice_menu = "技術"  # 分岐マップ・ヒント用：up("技術", 2) up("無理ゲージ", 2)
        "フィジカルの練習（走りこみ・体幹）" (nochosen=True):
            $ practice_menu = "フィジカル"  # 分岐マップ・ヒント用：up("フィジカル", 2) up("無理ゲージ", 3)
        "戦術眼の練習（作戦ボード・試合の映像）" (nochosen=True):
            $ practice_menu = "戦術眼"  # 分岐マップ・ヒント用：up("戦術眼", 2)
        "メンタルの練習（PK・声出し・防波堤）" (nochosen=True):
            $ practice_menu = "メンタル"  # 分岐マップ・ヒント用：up("メンタル", 2) up("無理ゲージ", -1)
    $ practice_lab = practice_pick(practice_menu, month)
    call expression practice_lab
    $ up(practice_menu, PRACTICE_GAIN)
    $ _muri = practice_muri(practice_menu, month)
    if _muri:
        $ up("無理ゲージ", _muri)
    if month == "nov" and _muri > 0:
        "練習のあと、右ひざを氷で冷やした。いつもより、冷たさが奥まで届かない。"
    call tuto_stats
    $ amb_stop()
    return


################################################################################
## 技術
################################################################################

## 鷹野とワンツー（夏）
label pr_takano_onetwo:
    "ワンツーの練習。相手は{rb}鷹野{/rb}{rt}たかの{/rt}だった。"
    show takano jersey_narrow
    with dissolve
    takano "……遅え。返すの、半歩遅え"
    ren "お前が走り出すのが早いんだよ"
    takano "早くねえ。お前のパスが、ちょうどいいとこに来ねえだけだ"
    "言い合いながら、二十本続けた。"
    "最後の三本だけ、鷹野は何も言わなかった。"
    hide takano
    with dissolve
    $ bond_up("鷹野", 1)
    return

## 江藤と1対1（夏）
label pr_eto_1on1:
    "1対1の練習。向かいに立ったのは、{rb}江藤{/rb}{rt}えとう{/rt}だった。"
    show eto jersey
    with dissolve
    eto "……ドリブルしかしない"
    ren "知ってる"
    "知っていても、止められなかった。江藤は、ボールを持つと急に別人になる。"
    "五本目で、やっとつま先が届いた。"
    eto "……今の、ずるい"
    ren "ずるくない。足を出しただけだ"
    hide eto
    with dissolve
    return

## 小池のロングパス（夏）
label pr_koike_long:
    "ロングパスの練習。{rb}小池{/rb}{rt}こいけ{/rt}と、ハーフラインをはさんで蹴り合った。"
    show koike jersey
    with dissolve
    koike "早瀬、今の、どこ狙ったっすか"
    ren "お前の胸"
    koike "俺の頭の、二メートル上でした"
    "小池のボールは、毎回ちゃんと足もとに落ちてくる。"
    koike "……たぶん、届く。って思って蹴ると、届くんすよ"
    ren "それ、ほんとに「たぶん」か？"
    koike "たぶん"
    hide koike
    with dissolve
    return

## 野口のシュート練習（夏）
label pr_noguchi_shoot:
    "居残りのシュート練習。{rb}野口{/rb}{rt}のぐち{/rt}が、一人でゴールに向かっていた。"
    show noguchi jersey
    with dissolve
    noguchi "……早瀬。クロス、上げてくれ"
    "右から、何本も上げた。野口の足は、そのたびにボールの少し下を空振りした。"
    if practice_month == "aug":
        noguchi "合宿の紅白戦のは、たまたまだ。たまたまを、たまたまじゃなくしたい"
    else:
        noguchi "点取る係なのに、取ったことがねえんだよ"
    "二十本目。ボールが、やっとネットを揺らした。"
    noguchi "……今の、見たか"
    ren "見た"
    hide noguchi
    with dissolve
    return

## 鷹野と、14番対策の1対1（9〜11月）
label pr_takano_14:
    "居残りの1対1。{rb}鷹野{/rb}{rt}たかの{/rt}が、何度も同じ形で仕掛けてきた。"
    show takano jersey_narrow
    with dissolve
    if flags.get("真壁"):
        takano "{rb}真壁{/rb}{rt}まかべ{/rt}は、こうやって体を当ててくる。……お前、やれ"
    else:
        takano "桜嶺の14番は、こうやって体を当ててくる。……お前、やれ"
    "言われたとおりに肩を当てる。鷹野は、半歩も下がらなかった。"
    takano "……軽い。もっと来い"
    "十本目、鷹野が初めてよろけた。"
    takano "……それでいい"
    hide takano
    with dissolve
    $ bond_up("鷹野", 1)
    return

## 坂口のクロスは、ニアかファーか（秋冬）
label pr_sakaguchi_cross:
    "クロスの練習。右サイドから、{rb}坂口{/rb}{rt}さかぐち{/rt}が何本も上げた。"
    show sakaguchi jersey
    with dissolve
    sakaguchi "蓮、ニアとファー、どっちに欲しい？"
    ren "……蹴る前に、俺のほうを見ないでくれ。相手にばれる"
    sakaguchi "うわ、それ黒田先生にも言われた。ウケる"
    "次の一本、坂口はこっちを見ないで蹴った。ボールは、ちょうど走りこんだ場所に落ちてきた。"
    sakaguchi "……今の、ゲームより気持ちいいかも"
    hide sakaguchi
    with dissolve
    $ bond_up("坂口", 1)
    return

## 黒田のトラップ講座（秋冬）
label pr_kuroda_trap:
    "トラップの練習。{rb}黒田{/rb}{rt}くろだ{/rt}が、ボールを高く放り上げた。"
    show kuroda normal
    with dissolve
    kuroda "{rb}早瀬{/rb}{rt}はやせ{/rt}。止めるな。次に蹴る方向へ、置け"
    "落ちてきたボールを、足の裏で受ける。止まった。"
    kuroda "止めたな"
    "もう一本。今度は、右へ置くつもりで触った。ボールは、勝手に一歩先へ転がった。"
    kuroda "それだ。止めた分だけ、相手が寄ってくる"
    hide kuroda
    with dissolve
    return

## 公式戦で初ゴールを決めたあとの野口（10月から）
label pr_noguchi_after:
    "シュート練習。{rb}野口{/rb}{rt}のぐち{/rt}の蹴る音が、夏とちがっていた。"
    show noguchi jersey
    with dissolve
    noguchi "……1回戦のあれ、まだ夢かもしれねえと思ってる"
    ren "夢じゃない。スコアボードに、ちゃんと出てた"
    noguchi "……そっか"
    "野口は、前髪をかき上げて、次のボールを置いた。"
    noguchi "じゃあ、二点目も取らねえとな"
    hide noguchi
    with dissolve
    return


################################################################################
## フィジカル
################################################################################

## 大門と、柔道式の体幹（夏）
label pr_daimon_core:
    "体幹のトレーニング。{rb}大門{/rb}{rt}だいもん{/rt}が、柔道部のやり方を教えてくれた。"
    show daimon jersey
    with dissolve
    daimon "早瀬くん、そのまま……うつぶせで、ひじとつま先だけで……"
    "一分。腹が震える。大門は、涼しい顔をしていた。"
    daimon "柔道部では、これを五分やってました。僕、投げられてばっかりだったので、ここだけは……"
    ren "……五分は、無理だ"
    daimon "あっ、す、すみません！　じゃあ、三分で……"
    hide daimon
    with dissolve
    $ bond_up("大門", 1)
    return

## 森と、最後尾の20周（夏）
label pr_mori_last:
    "グラウンド20周。いちばん後ろを、{rb}森{/rb}{rt}もり{/rt}が走っていた。"
    show mori jersey
    with dissolve
    mori "……早瀬、先、行っていいよ。俺、最後でいいっす"
    ren "最後でいいなら、俺も最後でいい"
    mori "……変なやつ"
    "二人で最後尾を走った。森は、一度も歩かなかった。"
    mori "坂口がさ。上がりっぱなしで戻ってこないの、知ってるだろ。……戻る係は、走れないとだめなんだよ"
    hide mori
    with dissolve
    return

## ひなたが、ひざの記録をつける（秋冬）
label pr_hinata_note:
    "走りこみの前。ベンチで、ひなたが例のノートを開いていた。"
    show hinata normal
    with dissolve
    hinata "蓮、右ひざ。今日、何点？"
    ren "……何点って"
    hinata "十点満点で。痛くないのが十点"
    if hidden["無理ゲージ"] >= 45:
        ren "……八点"
        show hinata stare
        hinata "うそ。右の眉毛、上がった"
        hinata "今日は走るの半分。わたしが決めたから"
        "言い返せなかった。ひなたのノートは、だいたい正しい。"
        $ up("無理ゲージ", -3)
    else:
        ren "……八点"
        show hinata smile
        hinata "うん。ほんとに八点の顔してる"
        "ひなたは、ノートの小さなグラフに点を一つ足した。"
    hide hinata
    with dissolve
    $ heart_up("ひなた", "信頼", 1)
    return

## 桐生の階段ダッシュ（秋冬）
label pr_kiryu_stairs:
    "校舎の外階段で、ダッシュの往復。前を走っていたのは、{rb}桐生{/rb}{rt}きりゅう{/rt}先輩だった。"
    show kiryu jersey
    with dissolve
    "先輩は、何も言わずに上がって、何も言わずに下りてくる。"
    ren "……先輩、何本目ですか"
    kiryu "数えてない。数えると、やめたくなる"
    "それだけ言って、また上がっていった。"
    hide kiryu
    with dissolve
    return

## 三好の、最後の大会の走りこみ（9〜11月）
label pr_miyoshi_last:
    "夕方の坂道ダッシュ。{rb}三好{/rb}{rt}みよし{/rt}先輩が、いちばん前を走っていた。"
    show miyoshi smile
    with dissolve
    miyoshi "蓮！　あと一本！"
    ren "先輩、それ、三回目のあと一本です"
    miyoshi "最後の大会だからな！　一本でも多く走っとかないと、あとで後悔するだろ！"
    "先輩は、笑いながら坂を駆け上がっていった。"
    "その背中は、春よりずっと速かった。"
    hide miyoshi
    with dissolve
    $ bond_up("三好", 1)
    return


################################################################################
## 戦術眼
################################################################################

## 小池と、部室で試合のビデオ（夏）
label pr_koike_video:
    scene bg clubroom
    with dissolve
    "雨で外の練習がなくなった日。部室で、去年の大会の録画を見た。"
    show koike jersey
    with dissolve
    koike "早瀬、ここ。ボール持ってない人、見てたっすか"
    ren "……見てなかった"
    koike "ゲームだと、ボール持ってない人のほうが大事なんすよ。画面の端で、勝手に走ってるやつ"
    "小池は一時停止して、画面の端の小さな選手を指さした。"
    koike "こいつが走ったから、パスが通ってる。……たぶん"
    hide koike
    with dissolve
    return

## 宮下が笑いながら説明する、サイドの上がり下がり（夏）
label pr_miyashita_side:
    "守備の練習。左サイドバックの{rb}宮下{/rb}{rt}みやした{/rt}先輩が、ラインの上げ下げを説明してくれた。"
    show miyashita jersey
    with dissolve
    miyashita "サイドバックはね、前が上がったら、ちょっとだけ待つの。それで……ふふっ"
    ren "……何がおかしいんですか"
    miyashita "ごめん、三好先輩がね、昨日これを全部「気合い」で説明してて……ふふっ、思い出しちゃって"
    "笑いながらだったけれど、先輩の説明は、黒田の説明と同じくらい分かりやすかった。"
    hide miyashita
    with dissolve
    return

## 千夏が、合宿の体育館の書類を届けに来る（7月）
label pr_chika_papers:
    "練習の途中。グラウンドの入り口に、{rb}千夏{/rb}{rt}ちか{/rt}先輩が立っていた。"
    show chika normal
    with dissolve
    chika "早瀬くん。合宿で体育館に泊まるための書類です。参加する11人の名前の確認をお願いします"
    "受け取った紙には、11人の名前が、きれいな字で並んでいた。名前の横に、ポジションまで書いてある。"
    ren "……これ、作戦ボードの並びですか"
    show chika narrow
    chika "黒田先生のボードを、写させてもらいました。名簿は、試合と同じ並びのほうが、読み間違えませんから"
    "先輩は、それだけ言って、校舎へ戻っていった。"
    "紙のいちばん下の、小さな4−4−2の図。11人の位置は、一つも間違っていなかった。"
    hide chika
    with dissolve
    $ heart_up("千夏", "信頼", 1)
    return

## 黒田と、桜嶺の試合の映像（11月）
label pr_kuroda_sakurei:
    scene bg staffroom
    with dissolve
    "練習のあと、{rb}黒田{/rb}{rt}くろだ{/rt}に職員室へ呼ばれた。机の上のパソコンに、桜嶺の試合が映っていた。"
    show kuroda normal
    with dissolve
    kuroda "{rb}早瀬{/rb}{rt}はやせ{/rt}。桜嶺が、いちばん嫌がることは何だと思う"
    ren "……点を取られること、ですか"
    kuroda "ちがう。思いどおりにならないことだ"
    kuroda "あいつらは、全部が計算どおりに動く。だから、計算の外から来るボールに弱い"
    "黒田は、画面を止めた。白いユニフォームの中に、一か所だけ、誰もいない場所があった。"
    hide kuroda
    with dissolve
    return

## 小池と、ボランチの位置取り（秋冬）
label pr_koike_volante:
    "位置取りの練習。{rb}小池{/rb}{rt}こいけ{/rt}と、真ん中の二人の距離を合わせた。"
    show koike jersey
    with dissolve
    koike "早瀬が前に出たら、俺が一歩下がる。早瀬が下がったら、俺が……"
    ren "前に出る"
    koike "いや、そのまま。俺、前に出ると、たぶん迷子になるんで"
    "黒田が、遠くで小さくうなずいたのが見えた。"
    hide koike
    with dissolve
    return


################################################################################
## メンタル
################################################################################

## 大門とPK（6月）
label pr_daimon_pk:
    "PKの練習。ゴールの前で、{rb}大門{/rb}{rt}だいもん{/rt}が両手を広げていた。"
    show daimon jersey
    with dissolve
    daimon "は、早瀬くん。蹴る前に、どっちに蹴るか、教えてもらえませんか"
    ren "それじゃ練習にならない"
    daimon "で、ですよね……"
    "一本目、大門は目をつぶった。ボールは、その横を抜けていった。"
    ren "目、つぶるな。ボールが来るのを、最後まで見ろ"
    daimon "……はい。最後まで、見ます"
    "十本目。大門の手が、初めてボールに触れた。"
    hide daimon
    with dissolve
    $ bond_up("大門", 1)
    return

## 三好の声出し（夏）
label pr_miyoshi_voice:
    "練習の最後。{rb}三好{/rb}{rt}みよし{/rt}先輩が、全員をセンターサークルに集めた。"
    show miyoshi smile
    with dissolve
    miyoshi "声出しの練習だ！　試合中、黙ったら負けだからな！"
    miyoshi "蓮！　お前からだ！"
    ren "……何を言えばいいんですか"
    miyoshi "何でもいい！　一番言いたいことを、一番でかい声で！"
    "少し考えて、腹の底から言った。"
    ren "――勝つぞ"
    "一瞬、誰も何も言わなかった。それから、全員が同じ言葉を叫んだ。"
    hide miyoshi
    with dissolve
    $ bond_up("三好", 1)
    return

## 坂口たちとストレッチ（夏）
label pr_gang_stretch:
    "練習のあとのストレッチ。{rb}坂口{/rb}{rt}さかぐち{/rt}たち5人が、輪になって座っていた。"
    show sakaguchi jersey
    with dissolve
    sakaguchi "蓮もこっち来いよ。今、ゲーセンの新しい台の話してたとこ"
    "輪に入ると、話はすぐに、サッカーゲームの話から本物のサッカーの話になった。"
    "誰がどこに走れば、パスが通るのか。ゲームの話のはずなのに、黒田の作戦ボードと同じことを言っていた。"
    sakaguchi "……なんか、ゲームより今のほうが、ちょっと楽しいかも。ウケる"
    hide sakaguchi
    with dissolve
    $ bond_up("坂口", 1)
    return

## ひなたと、帰り道の一言（夏）
label pr_hinata_way:
    scene bg slope_eve
    with dissolve
    "練習の帰り。港への坂道で、ひなたが自転車を押していた。"
    show hinata normal
    with dissolve
    hinata "今日、蓮、黒田先生に何回呼ばれた？"
    ren "……三回"
    hinata "四回だよ。わたし、数えてたもん"
    hinata "でもね、呼ばれるの、蓮がいちばん多いの。それって、見られてるってことでしょ"
    "坂の下で、港の明かりがついた。"
    hide hinata
    with dissolve
    $ heart_up("ひなた", "信頼", 1)
    return

## 黒田「試合の前に何を考える」（秋冬）
label pr_kuroda_before:
    "練習のあと、ベンチで{rb}黒田{/rb}{rt}くろだ{/rt}が缶コーヒーを飲んでいた。"
    show kuroda peek
    with dissolve
    kuroda "{rb}早瀬{/rb}{rt}はやせ{/rt}。試合の前の夜、何を考えてる"
    ren "……負けたときのこと、です"
    kuroda "そうか"
    kuroda "俺は、最初のワンプレーのことだけ考えてた。最初に触るボールを、どこに置くか。それだけだ"
    kuroda "一つ目がうまくいけば、二つ目は勝手に来る"
    hide kuroda
    with dissolve
    return

## 防波堤で、遠くのピアノの音（秋冬）
label pr_pier_piano:
    scene bg harbor_sunset
    with dissolve
    $ se("波の音、カモメ")
    "練習のあと、港の防波堤で一人、決勝の映像を頭の中で流した。"
    "ボールをもらう。前を向く。左から来る白いユニフォーム。"
    "何度流しても、同じところで、ひざが熱くなる。"
    "遠くの家の窓から、ピアノの音が聞こえてきた。"
    "曲は、最後まで止まらなかった。気がつくと、頭の中の映像も止まっていた。"
    $ amb_stop()
    return

## 坂口たちが戻ってきたあと（10月）
label pr_gang_back:
    "練習のあと、{rb}坂口{/rb}{rt}さかぐち{/rt}が一人、ゴール裏でボールを蹴っていた。"
    show sakaguchi jersey
    with dissolve
    sakaguchi "……蓮。9月のこと、ちゃんと言ってなかった"
    sakaguchi "グループ、勝手に抜けて……ごめん"
    ren "戻ってきたなら、それでいい"
    sakaguchi "……ウケる。蓮、それ、三好先輩みたいなこと言ってる"
    "坂口は、ボールを蹴り上げて、自分で胸で止めた。少しだけ、笑っていた。"
    hide sakaguchi
    with dissolve
    $ bond_up("坂口", 1)
    return
