## chapter3_more.rpy ―― 第3章の追加場面（v0.20.0）
##   ・9月の苦難：格下との練習試合の負け → 坂口が辞めかける → 黒田の地味な特訓
##   ・選手権の1回戦・2回戦・準々決勝を、ほかの場所から見る（はやせ食堂・職員室・生徒会室・スタンド）
##   ・桜嶺戦の前振り：前の夜 → 朝の食堂 → バス → 会場とロッカールーム → 入場（神城）
##   ・関係が冷えたヒロインに、ほかの人が近づく「兆し」（12月の終わり）

## 登場人物（常連のおじさん・教頭先生・柏木など）は characters.rpy で定義している

default ch3_sakaguchi = ""    # 坂口が辞めかけたとき（game：ゲームで勝負 / honest：正直に言う）
default ch3_huddle = ""       # 桜嶺戦の前、ロッカールームの円陣で言ったこと（ouryo / miyoshi / love）
default ch3_sign = ""         # 12月の終わりに見た「兆し」（hinata / chika / saki / 空）


################################################################################
## 9月の苦難（1）：格下に負ける（9月19日・土）
################################################################################
label ch3_slump:
    scene black
    with dissolve
    $ set_cal("9月19日（土）", "練習試合　対 潮見北高校")
    scene bg kohoku_ground_eve
    with dissolve
    $ bgm("明るい部活の曲")
    "土曜の午後。{rb}港北{/rb}{rt}こうほく{/rt}のグラウンドに、練習試合の相手が来た。"
    "県立{rb}潮見北{/rb}{rt}しおみきた{/rt}高校。去年の選手権は、地区予選の1回戦で負けている。"
    show sakaguchi jersey at right
    with dissolve
    sakaguchi "北高って、去年うちと同じくらいだったとこっしょ。楽勝じゃん"
    show miyoshi smile at left
    with dissolve
    miyoshi "油断すんな！　……って言いたいけど、正直、負ける気はしない"
    hide sakaguchi
    hide miyoshi
    with dissolve
    "夏の合宿で、俺たちは走れるようになった。"
    "全員が、そう思っていた。"

    $ se("キックオフの笛")
    $ bgm("緊迫した試合の曲")
    scene bg kohoku_ground_eve at cam_jog
    with dissolve
    "最初の10分は、ずっとこっちのボールだった。"
    "全員が前に走る。{rb}三好{/rb}{rt}みよし{/rt}先輩まで、センターラインを越えていく。"
    "前半15分。相手のキーパーが大きく蹴ったボールが、地面で一度はねた。"
    $ se("ボールを蹴る音")
    "うしろには、{rb}大門{/rb}{rt}だいもん{/rt}しかいなかった。"
    $ se("ネットが揺れる音")
    scene bg kohoku_ground_eve at cam_snap(1.15)
    with hpunch
    "0−1。"
    scene bg kohoku_ground_eve at cam_jog
    with dissolve
    "後半も、同じだった。"
    "攻めて、攻めて、取られて、一本のパスで、また大門と一対一。"
    $ se("ネットが揺れる音")
    scene bg kohoku_ground_eve at cam_snap(1.15)
    with hpunch
    "0−2。"
    $ se("試合終了の笛")
    $ bgm("（止まる）")
    scene bg kohoku_ground_eve
    with dissolve
    "シュートは、こっちが15本。向こうは3本。"
    "それで、0−2だった。"

    show kuroda normal
    with dissolve
    kuroda "……集まれ"
    "{rb}黒田{/rb}{rt}くろだ{/rt}は、作戦ボードを出さなかった。かわりに、土の上にしゃがんで、指で線を一本引いた。"
    kuroda "夏で、お前らは走れるようになった。それは本当だ"
    kuroda "でも今日、全員が、ボールに向かって走ってた"
    kuroda "11人が、同じ一つのボールを見てる。だから、うしろが空く"
    "誰も、言い返さなかった。"
    kuroda "走れるのと、戦えるのは、ちがう"
    $ learn("counter")
    hide kuroda
    with dissolve
    show sakaguchi jersey at right
    with dissolve
    sakaguchi "……だる"
    "{rb}坂口{/rb}{rt}さかぐち{/rt}が、ビブスを地面に投げた。"
    hide sakaguchi
    with dissolve
    "それを拾ったのは、大門だった。"
    $ up("メンタル", -2)

    ## その夜：坂口たちが抜ける
    scene black
    with dissolve
    $ set_cal("9月20日（日）", "夜")
    scene bg ren_room_night
    with dissolve
    $ bgm("静かな夜の曲")
    $ se("トークアプリの通知音")
    window auto hide
    $ talk_start("港北サッカー部（12）", "21:30")
    $ talk("坂口", "おれら5人、しばらく練習パスで")
    $ talk("三好", "は？？？")
    $ talk("坂口", "北高に負けんなら、ゲーセンで負けるほうがまし")
    $ talk("坂口", "そっちは100円で済むし")
    $ talk_system("坂口が退出しました")
    $ talk_system("江藤が退出しました")
    $ talk_system("小池が退出しました")
    "灰色の文字が、一行ずつ増えていった。"
    "{rb}森{/rb}{rt}もり{/rt}と{rb}野口{/rb}{rt}のぐち{/rt}の名前は、最後まで残っていた。でも、何も書きこまなかった。"
    $ talk("三好", "明日も練習ある")
    $ talk("三好", "来いよ")
    window auto hide
    $ talk_end()
    "11人。一人でも欠けたら、11人では戦えない。"
    "5人欠けたら、それはもう、サッカー部じゃなかった。"

    ## 9月21日：6人の練習 → ゲームセンター（1回目の説得は、どう言っても届かない）
    scene black
    with dissolve
    $ set_cal("9月21日（月）", "連休の練習")
    scene bg kohoku_ground_eve
    with dissolve
    $ bgm("（なし）")
    "連休の練習に来たのは、6人だった。"
    "三好先輩は、いつもの倍の声を出していた。"
    "誰も、坂口たちの話をしなかった。"
    "練習のあと、俺は駅前に向かった。"

    scene bg game_center
    with dissolve
    $ bgm("ゲームセンターの曲")
    "駅前のゲームセンター。いちばん奥の、サッカーゲームの台。"
    "5人は、そこにいた。"
    show sakaguchi normal
    with dissolve
    sakaguchi "……来ると思った。{rb}蓮{/rb}{rt}れん{/rt}って、そういうとこあるよな"
    sakaguchi "説教なら、いいよ。わかってるから"
    "坂口は、画面から目を離さなかった。"
    sakaguchi "夏さ、マジで強くなったと思ったんだよ。合宿で、11人で、なんか、いけるって"
    sakaguchi "で、北高に0−2。……ダサくね？"
    sakaguchi "がんばってダサいのが、いちばんダサいんだよ"
    "ゲームの中で、坂口のチームがゴールを決めた。誰も、喜ばなかった。"
    menu:
        "「ゲームで勝負しろ。俺が勝ったら、明日来い」":
            $ ch3_sakaguchi = "game"
            $ lean("野心型")
            sakaguchi "……は？　蓮、これ、俺らのホームだけど"
            ren "知ってる"
            "100円玉を、台に入れた。"
            $ se("ゲームのゴール音")
            if check("戦術眼", 54) or bond.get("坂口", 0) >= 30:
                "5月にやったときより、坂口の動きが読めた。"
                "坂口は、困ったら必ず右に逃げる。……サッカーのときと、同じだった。"
                "3−2。最後の1点は、右に逃げたところを取った。"
                sakaguchi "……マジかよ"
                "坂口は、しばらく画面の点数を見ていた。それから、台からはなれた。"
                sakaguchi "勝ったら行く、なんて、俺、言ってねえし"
                $ set_flag("ch3_坂口_ゲーム", "win")
            else:
                "1−4。完敗だった。"
                sakaguchi "……ウケる。負けてんじゃん、蓮"
                sakaguchi "負けたやつの言うこと、聞く理由ないよな"
                $ set_flag("ch3_坂口_ゲーム", "lose")
        "「辞めたいなら止めない。でも、11人目はお前しかいない」":
            $ ch3_sakaguchi = "honest"
            $ lean("仲間型")
            ren "5人で辞めたら、試合に出られない。……でも、それはどうでもいい"
            ren "坂口がいないと、右が空く。あそこは、お前の場所だ"
            "坂口の手が、止まった。"
            "ゲームの中の選手が、勝手に走って、勝手に取られた。"
            sakaguchi "……お前さ。そういうの、ずるいって"
            sakaguchi "ずるいけど。……今は、無理"
            "うしろで、{rb}江藤{/rb}{rt}えとう{/rt}が何か言いかけて、やめた。"
    sakaguchi "帰れよ。……閉店まで、ここにいるから"
    hide sakaguchi
    with dissolve
    "ゲームセンターを出ると、外はもう暗かった。"
    "自動ドアのむこうで、電子音のゴールが、何回も鳴っていた。"
    $ up("メンタル", -2)

    ## 9月23日：6人の練習
    scene black
    with dissolve
    $ set_cal("9月23日（水）", "祝日の練習")
    scene bg kohoku_ground_eve
    with dissolve
    $ bgm("（なし）")
    "6人では、ミニゲームもできなかった。"
    "3対3をやると、グラウンドがやけに広い。パスを出す先が、いつも一つしかない。"
    show kuroda normal
    with dissolve
    kuroda "……土曜の、{rb}潮見南{/rb}{rt}しおみみなみ{/rt}との練習試合。断っておいた"
    "誰も、何も言わなかった。"
    hide kuroda
    with dissolve
    "{rb}三好{/rb}{rt}みよし{/rt}先輩の声は、もう半分かすれていた。それでも、一人で11人分しゃべっていた。"
    "練習のあと、大門が、部室の前で5枚のビブスを洗っていた。誰も着ていない、5枚。"
    show daimon worried
    with dissolve
    daimon "……乾かしておかないと、戻ってきたとき、くさいので"
    hide daimon
    with dissolve
    "グループトークの既読は、ずっと6のままだった。"

    ## 9月24日：生徒会室。登録の締め切り（9/21〜23 は連休）
    scene black
    with dissolve
    $ set_cal("9月24日（木）", "放課後")
    scene bg student_council
    with dissolve
    $ bgm("張りつめた静かな曲")
    show chika normal
    with dissolve
    chika "早瀬くん。選手権予選の、登録メンバーの最終確認のことです"
    chika "締め切りは、28日の月曜日。11人の名前と、本人の署名がそろわなければ、出場は取り消しになります"
    ren "……知ってます"
    show chika narrow
    chika "黒田先生の出席簿で、連休の練習の出席が、6人になっていました"
    "名簿は、毎日見ている。――前に、そう言っていた。"
    chika "……あと4日です。私は、待つことしかできません"
    hide chika
    with dissolve

    ## その夜：江藤から
    scene black
    with dissolve
    $ set_cal("9月24日（木）", "夜", quiet=True)
    scene bg ren_room_night
    with dissolve
    $ bgm("静かな夜の曲")
    $ se("トークアプリの通知音")
    window auto hide
    $ talk_start("江藤", "22:41")
    $ talk("江藤", "江藤です。坂口には言うなよ")
    $ talk("江藤", "あいつ、毎日ゲーセンで同じ台やってる。サッカーのやつ")
    if flags.get("ch3_坂口_ゲーム") == "win":
        $ talk("江藤", "右に逃げるクセ、直そうとしてる。蓮に読まれたの、相当くやしかったっぽい")
    elif ch3_sakaguchi == "game":
        $ talk("江藤", "蓮に勝ったのに、ぜんぜんうれしそうじゃなかった")
    else:
        $ talk("江藤", "「右が空く」って、ずっとぶつぶつ言ってる")
    $ talk("江藤", "明日、もう一回だけ来てくれ。たぶん、次は大丈夫")
    $ talk_me("行く")
    window auto hide
    $ talk_end()

    ## 9月25日：2回目
    scene black
    with dissolve
    $ set_cal("9月25日（金）", "夕方")
    scene bg game_center
    with dissolve
    $ bgm("ゲームセンターの曲")
    "同じ台の前に、坂口は一人で座っていた。ほかの4人は、少しはなれたベンチにいた。"
    show sakaguchi normal
    with dissolve
    sakaguchi "……江藤だろ。あいつ、口軽いんだよ"
    if ch3_sakaguchi == "game":
        ren "もう一回やろう。今度は、俺が負けたら、もう来ない"
        "坂口は、黙って100円玉を二枚、台に入れた。"
        $ se("ゲームのゴール音")
        "2−2のまま、残り10秒。坂口が、ボールを持った。"
        "右には、逃げなかった。まっすぐ、真ん中に切りこんできた。"
        "3−2。坂口の勝ちだった。"
        sakaguchi "……右、直したんだよ。お前に読まれたから"
        sakaguchi "グラウンドでも、直せっかな"
        ren "直せる。毎日、見てるやつがいる"
        "坂口は、台にひじをついて、少しだけ笑った。"
        sakaguchi "……しゃあない。明日、行くわ。全員で"
        $ bond_up("坂口", 6 if flags.get("ch3_坂口_ゲーム") == "win" else 5)
    else:
        "俺は、カバンから青いビブスを一枚出して、台の上に置いた。番号は、坂口の6。"
        ren "大門が、毎日洗ってる。5枚。……誰も着てないのに"
        ren "締め切りは、28日だ"
        "坂口は、ビブスを見たまま、しばらく動かなかった。"
        sakaguchi "……お前ら、ほんと、ずりいって"
        "うしろで、{rb}江藤{/rb}{rt}えとう{/rt}が鼻をすすった。{rb}小池{/rb}{rt}こいけ{/rt}が、それを見ないふりをした。"
        sakaguchi "俺らのこと、そういうふうに待ってるやつ、今までいなかったんだよ"
        sakaguchi "……明日、行くわ。全員で"
        $ bond_up("坂口", 8)
        $ up("メンタル", 2)
    hide sakaguchi
    with dissolve

    ## 9月26日：5人が戻ってくる
    scene black
    with dissolve
    $ set_cal("9月26日（土）", "練習")
    scene bg kohoku_ground_eve
    with dissolve
    $ bgm("明るい部活の曲")
    "次の日。練習が始まって10分たったころ、5人が、ばらばらにグラウンドに来た。"
    show miyoshi smile at left
    with dissolve
    miyoshi "遅刻だ！　外周5周！"
    "三好先輩のかすれた声は、怒っているはずなのに、ずっと笑っていた。"
    show daimon jersey at right
    with dissolve
    daimon "あ、あの……坂口くんのビブス、洗っておきました"
    show sakaguchi jersey
    with dissolve
    sakaguchi "……知ってる。大門、お前、そういうとこな"
    daimon "す、すみません……？"
    sakaguchi "ほめてんの"
    hide miyoshi
    hide daimon
    hide sakaguchi
    with dissolve
    "グループトークに、灰色の文字が三行、増えた。"
    "「三好が坂口を招待しました」\n「三好が江藤を招待しました」\n「三好が小池を招待しました」"
    "既読は、また11に戻った。"
    "締め切りの、二日前だった。"
    $ set_flag("ch3_坂口_戻った", ch3_sakaguchi)
    return


################################################################################
## 9月の苦難（2）：黒田の地味な特訓（9月29日〜10月9日）
################################################################################
label ch3_drill:
    scene black
    with dissolve
    $ set_cal("9月30日（水）", "放課後")
    scene bg kohoku_ground_eve
    with dissolve
    $ bgm("作戦会議っぽい軽快な曲")
    show kuroda board
    with dissolve
    kuroda "今日から10日、ボールは使わない"
    sakaguchi "は？"
    kuroda "守備の約束を、三つだけ覚えろ。……三つだけだ。お前らの頭でも入る"
    kuroda "一つ。ボールを持ったやつより先に、隣を見ろ"
    kuroda "二つ。隣との間は、3メートル。広がるな、縮まるな"
    kuroda "三つ。取られたら、5秒だけ、全員で取り返しに行け。5秒たったら、戻れ"
    $ learn("zone")
    hide kuroda
    with dissolve

    scene cg practice_rope at cam_pan_r(14.0)
    with Dissolve(1.0)
    "{rb}黒田{/rb}{rt}くろだ{/rt}が持ってきたのは、10メートルのロープだった。"
    if ch2_miyoshi_cb == "kiryu":
        "うしろの4人――三好先輩、桐生先輩、宮下先輩、{rb}森{/rb}{rt}もり{/rt}の腰を、一本のロープでつなぐ。"
    else:
        "うしろの4人――三好先輩、桐生先輩、{rb}宮下{/rb}{rt}みやした{/rt}先輩、{rb}森{/rb}{rt}もり{/rt}の腰を、一本のロープでつなぐ。"
    "一人が前に出すぎると、ロープが引っぱる。うしろに残りすぎても、引っぱられる。"
    miyashita "ふふっ……電車ごっこじゃん"
    kiryu "……笑うと、ロープがゆれる"
    "最初の日、4人は何度も転んだ。"
    show kuroda normal
    with dissolve
    kuroda "{rb}早瀬{/rb}{rt}はやせ{/rt}。見てるだけなら、お前も入れ"
    hide kuroda
    with dissolve
    menu:
        "ロープの前に立って、声を出す役をやる":
            $ bond_up("三好", 4)
            $ up("戦術眼", 1)
            ren "右、出すぎ！　三好先輩、一歩下がって！"
            miyoshi "おう！　……って、蓮、俺より声でかくないか？"
            "三好先輩は、なぜかうれしそうだった。"
            "その日から、ロープの前で叫ぶのが、俺の係になった。"
        "いちばん後ろで、ロープの端を持ってつなぐ":
            $ bond_up("大門", 4)
            $ up("フィジカル", 1)
            "ロープの端を持って、4人のうしろに立った。ゴールの前の、{rb}大門{/rb}{rt}だいもん{/rt}のとなり。"
            "うしろから見ると、誰が一歩遅れているのか、よく分かった。"
            daimon "……早瀬くんが後ろにいると、なんか、安心します"
            kiryu "……大門、それ、キーパーが言うことじゃない"
    "三日目、転ばなくなった。"
    "一週間目、ロープがたるまなくなった。"

    scene bg kohoku_gate_autumn
    with dissolve
    $ set_cal("10月3日（土）", "朝")
    "朝は、走った。黒田は自転車で後ろからついてきて、ずっとあくびをしていた。"
    "{rb}坂口{/rb}{rt}さかぐち{/rt}たちは、一度も遅刻しなかった。……二回しか。"

    scene bg kohoku_ground_eve
    with dissolve
    $ set_cal("10月9日（金）", "夕方")
    "10日目の夕方、黒田はロープをほどいた。"
    "ほどかれたあとも、4人は、3メートルの間をあけたまま走っていた。"
    show kuroda normal
    with dissolve
    kuroda "……地味だったろ"
    show miyoshi smile at left
    with dissolve
    miyoshi "地味でした！！"
    kuroda "勝つのは、だいたい地味なほうだ"
    hide miyoshi
    with dissolve
    kuroda "明日から、選手権だ"
    hide kuroda
    with dissolve
    $ up("戦術眼", 4)
    $ up("フィジカル", 2)
    return


################################################################################
## 選手権予選1回戦（10月10日・土）――はやせ食堂から
################################################################################
label ch3_r1:
    scene black
    with Dissolve(1.0)
    $ set_cal("10月10日（土）", "選手権予選1回戦　対 緑ヶ丘高校")
    $ bgm("（なし）")
    mono "10月。選手権予選が始まった。"
    mono "――同じころ。{rb}港北{/rb}{rt}こうほく{/rt}の商店街。"
    scene bg shokudo_day
    with Dissolve(1.0)
    $ bgm("とぼけた日常の曲")
    "昼の客がはけた、はやせ食堂。"
    "カウンターの上に、スマホが一台、立てかけてあった。"
    show mother normal
    with dissolve
    jouren "おかみさん、それ、{rb}蓮{/rb}{rt}れん{/rt}くんの試合かい"
    haha "ネットで、ただで見られるんですって。ひなたちゃんが、入れていってくれて"
    jouren "どれどれ。……おお、青いのが港北か"
    haha "……あの子、どこにいるのかしら。みんな同じ服で、わからないのよ"
    jouren "ほら、真ん中の。ひざに白いの巻いてる"
    show mother sadsmile
    "おかみさんは、しばらく黙って、画面に顔を近づけた。"
    $ se("ネットが揺れる音")
    jouren "入った！　入ったよ、おかみさん！"
    jouren "今の誰だ、あのひょろっと背の高い……"
    haha "{rb}野口{/rb}{rt}のぐち{/rt}くん。……昔、うちでカレーを三杯食べた子"
    "後半に、もう一点。"
    $ se("試合終了の笛")
    show mother smile
    haha "……勝った。勝ったわよ"
    "おかみさんは、エプロンのすそで、スマホの画面をふいた。"
    jouren "おかみさん、泣いてんのかい"
    haha "玉ねぎを切ってたからです"
    jouren "今、なんにも切ってなかったろ"
    hide mother
    with dissolve
    scene black
    with dissolve
    mono "1回戦、2−0。野口が、公式戦で初めてゴールを決めた。"
    $ set_flag("野口_初ゴール")
    mono "うしろの4人は、80分間、3メートルの間を空けたままだった。"
    return


################################################################################
## 選手権予選2回戦（10月11日・日）――職員室から
################################################################################
label ch3_r2:
    scene black
    with Dissolve(1.0)
    $ set_cal("10月11日（日）", "選手権予選2回戦　対 県立工業")
    mono "――次の日。日曜日の、{rb}港北{/rb}{rt}こうほく{/rt}高校。"
    scene bg staffroom
    with Dissolve(1.0)
    $ bgm("とぼけた日常の曲")
    "日曜の職員室で、部活の当番の先生が、放送の機械に小さなラジオをつないでいた。"
    kyoto "……何をしているんですか"
    gendai "地元のFMが、選手権の中継をしてるんです。今、後半のアディショナルタイムで！"
    "教頭先生が止める前に、校内放送のスイッチが入った。"
    "グラウンドの野球部も、柔道場の柔道部も、スピーカーの下で足を止めた。"
    "『――県立工業、最後のシュート！　港北のキーパー{rb}大門{/rb}{rt}だいもん{/rt}、横っ飛び！　止めました！　今日三本目！』"
    judo_senpai "大門ーっ！"
    "柔道場のほうから、地鳴りみたいな声が聞こえた。"
    $ se("試合終了の笛")
    "『試合終了！　1−0、港北高校が3回戦へ！』"
    kyoto "…………"
    "教頭先生は、何も言わずに、放送のスイッチを切った。"
    "それから、自分の机の予定表の、3回戦の日付の横に、こっそり『応援』と書きこんだ。"
    scene black
    with dissolve
    mono "2回戦、1−0。後半、{rb}大門{/rb}{rt}だいもん{/rt}が三本止めた。"
    mono "{rb}港北{/rb}{rt}こうほく{/rt}が、二つ勝った。"
    $ set_flag("教頭_応援")
    return


################################################################################
## 準々決勝（10月31日・土）――生徒会室と、スタンドから
################################################################################
label ch3_qf:
    scene black
    with Dissolve(1.0)
    $ set_cal("10月31日（土）", "選手権予選準々決勝　対 潮見南")
    $ bgm("（なし）")
    mono "準々決勝。相手は、去年のベスト4、県立{rb}潮見{/rb}{rt}しおみ{/rt}南。"
    mono "――同じころ。土曜日の、生徒会室。"
    scene bg student_council
    with Dissolve(1.0)
    $ bgm("張りつめた静かな曲")
    "文化祭の片づけの書類が、机の上に山になっていた。"
    show chika normal
    with dissolve
    "{rb}千夏{/rb}{rt}ちか{/rt}は、ノートパソコンの画面と書類を、交互に見ていた。"
    "画面には、県の高校サッカーの速報のページ。"
    "前半28分。潮見南 1−0 {rb}港北{/rb}{rt}こうほく{/rt}。"
    chika "……"
    "書類に判を押す。押す場所を、一回まちがえた。"
    "後半。スコアが変わっていないか、ページを更新する指が、だんだん速くなっていく。"
    "後半21分。1−1。"
    show chika narrow
    chika "……っ"
    "後半40分。"
    "『港北・{rb}江藤{/rb}{rt}えとう{/rt}、ドリブルで3人を抜いて――』"
    chika "江藤くんのドリブルは、3回までのはずです……！"
    chika "部の練習メニューの申請に、書いてありました。4回目は約束違反――"
    "『――クロス、ゴール！　1−2！』"
    show chika soft
    chika "――っ、よし！"
    "生徒会室に、自分の声だけが響いた。"
    chika "……今のは、生徒会とは関係ありません"
    "誰もいない部屋で、千夏は、だれにともなく言った。"
    hide chika
    with dissolve

    mono "――同じころ。競技場の、いちばん上のスタンド。"
    scene bg pref_stand_day at cam_pan_r(16.0)
    with Dissolve(1.0)
    $ bgm("静かなピアノの旋律")
    "白いブレザーの女の子が、手すりにもたれていた。"
    "{rb}桜嶺{/rb}{rt}おうりょう{/rt}の制服。でも、今日は桜嶺の試合ではなかった。"
    "青いユニフォームの、真ん中。右ひざの白いテーピング。"
    voice "audio/voice/saki_baka.mp3"
    saki_v "……ばか。走りすぎ"
    "試合終了の笛が鳴る前に、[saki_call]はスタンドを降りていった。"
    $ set_flag("紗希_準々決勝を見た")
    scene black
    with dissolve
    mono "2−1。{rb}港北{/rb}{rt}こうほく{/rt}が、県のベスト4に入った。"
    mono "次は、準決勝。相手は――{rb}桜嶺{/rb}{rt}おうりょう{/rt}。"
    return


################################################################################
## 桜嶺戦の前の夜（11月13日・金）
################################################################################
label ch3_semi_eve:
    scene black
    with Dissolve(1.0)
    $ set_cal("11月13日（金）", "夜")
    scene bg ren_room_night
    with dissolve
    $ bgm("静かな夜の曲")
    "眠れなかった。"
    "部屋の電気を消して、また点けた。"
    scene cg item_spikes at item_close
    with Dissolve(0.8)
    "机の上に、明日のスパイク。その横に、中学のときのスパイク。"
    "あの決勝から、一度も箱から出していなかった。"
    "かかとの内側に、マジックで書いた名前。もう、半分消えている。"
    scene bg ren_room_night
    with dissolve
    $ se("トークアプリの通知音（連続）")
    window auto hide
    $ talk_start("港北サッカー部（12）", "22:10")
    $ talk("三好", "明日は全員、朝めし食ってこい！！")
    $ talk("坂口", "三好先輩、それ今日5回目")
    $ talk("大門", "眠れません")
    $ talk("宮下", "わろた")
    $ talk("桐生", "……寝ろ")
    $ talk("鷹野", "寝ろ")
    window auto hide
    $ talk_end()
    "{rb}鷹野{/rb}{rt}たかの{/rt}の「寝ろ」は、{rb}桐生{/rb}{rt}きりゅう{/rt}先輩の3秒あとだった。"

    ## いちばん近いヒロインから、ひとこと
    $ _hs = sorted([h for h in ("ひなた", "千夏", "紗希") if heart_total(h) >= 25], key=lambda h: -heart_total(h))
    if _hs and _hs[0] == "千夏":
        $ se("トークアプリの通知音")
        window auto hide
        $ talk_start("千夏", "22:31")
        $ talk("千夏", "明日の試合、生徒会から応援の申請が出ています")
        $ talk("千夏", "……私が出しました")
        $ talk("千夏", "勝ってください。それだけです")
        $ talk_me("はい")
        $ talk("千夏", "……おやすみなさい。今のは、生徒会とは関係ありません")
        window auto hide
        $ talk_end()
    elif _hs and _hs[0] == "紗希" and flags.get("紗希_名前を聞いた"):
        "[saki_call]の連絡先は、知らない。"
        "カーテンを開けると、港への坂の上に、小さな明かりが一つだけ見えた。"
        "ピアノの家の窓だった。こんな時間まで、まだ点いていた。"
        "音は、ここまでは届かない。"
        "それでも、何を弾いているのか、わかる気がした。"
    else:
        $ se("トークアプリの通知音")
        window auto hide
        $ talk_start("ひなた", "22:48")
        $ talk("ひなた", "テーピング、明日バスの中で巻くから。ひざ、ちゃんと出しといてね")
        $ talk("ひなた", "あと、寝坊したら窓から入る")
        $ talk_me("やめろ")
        $ talk("ひなた", "じゃあ寝て。……おやすみ、蓮")
        window auto hide
        $ talk_end()
    "スマホを伏せて、天井を見た。"
    "中3の決勝の前の夜と、同じ天井だった。"
    "でも、あの夜は、こんなにうるさくなかった。"
    return


################################################################################
## 桜嶺戦の朝（11月14日・土）：食堂 → バス → 会場 → ロッカールーム
################################################################################
label ch3_semi_morning:
    scene black
    with dissolve
    $ set_cal("11月14日（土）", "朝")
    scene bg shokudo_day
    with dissolve
    $ bgm("あたたかいアコースティックギター")
    "朝6時。まだのれんを出す前の、はやせ食堂。"
    show mother normal
    with dissolve
    haha "はい、お弁当。……おにぎり、四つにしといた"
    ren "多いって"
    haha "あんたが残したこと、ないでしょ"
    "母は、それ以上、何も言わなかった。"
    "試合を見に来るとも、来ないとも言わなかった。"
    "店の戸を開けたとき、背中に声がした。"
    show mother smile
    haha "……行ってらっしゃい"
    "あの冬の朝と、同じ言葉だった。"
    "でも、あのときより、少しだけ大きな声だった。"
    hide mother
    with dissolve

    scene bg bus_team_morning
    with Dissolve(1.0)
    $ bgm("（なし）")
    "学校の前から、バスに乗った。{rb}黒田{/rb}{rt}くろだ{/rt}が、どこかから安く借りてきた、古いバスだった。"
    "誰も、しゃべらなかった。{rb}三好{/rb}{rt}みよし{/rt}先輩さえも。"
    "{rb}坂口{/rb}{rt}さかぐち{/rt}がイヤホンを片方だけ外して、{rb}大門{/rb}{rt}だいもん{/rt}に渡した。大門はそれを耳に当てて、目をつぶった。"
    "{rb}鷹野{/rb}{rt}たかの{/rt}は、窓の外だけを見ていた。"
    show hinata serious
    with dissolve
    "となりの席で、ひなたが、俺のひざにテーピングを巻いていた。"
    hinata "……今日は、二周多く巻いとくね"
    ren "いつもより？"
    hinata "いつもより。……今日は、いつもじゃないから"
    "ひなたの指が、ほんの少しだけふるえていた。"
    "俺は、気づかないふりをした。"
    hide hinata
    with dissolve
    "霜の降りた田んぼの向こうに、白くて大きな屋根が見えてきた。"
    "県総合運動公園、陸上競技場。"
    "去年の冬、中学の県大会の決勝をやった場所。"
    "俺のひざが、終わった場所。"

    scene bg stadium_gate_morning
    with Dissolve(1.5)
    $ bgm("張りつめた静かな曲")
    $ se("スタンドの応援（太鼓）")
    "バスを降りると、入口の向こうから、もう太鼓の音が聞こえていた。"
    scene bg stadium_stand_day at cam_pan_r(16.0)
    with Dissolve(1.0)
    "天然芝の匂い。"
    "スタンドの半分が、白と金で埋まっていた。"
    "{rb}桜嶺{/rb}{rt}おうりょう{/rt}の応援団。そろいのジャンパー。太鼓。全員が同じ声で歌っている。"
    "{rb}港北{/rb}{rt}こうほく{/rt}の側は、柔道部の先輩たちと、知らない大人が何人か。"
    "それと、背広の上にコートを着た、教頭先生。"
    sakaguchi "……教頭、来てんじゃん"
    miyoshi "教頭先生な！！"
    "いちばん端の席に、古いフィルムカメラを構えた、見覚えのある背中があった。"
    if flags.get("千夏_旗"):
        "足もとに、丸めた布のようなものが置いてあった。……たぶん、旗ではない。たぶん。"
    show sakaguchi match at right
    with dissolve
    sakaguchi "……ここ、テレビで見たことある"
    "{rb}坂口{/rb}{rt}さかぐち{/rt}の声が、かすかにふるえていた。"
    hide sakaguchi
    with dissolve

    scene bg locker_room
    with Dissolve(1.0)
    $ bgm("（なし）")
    "ロッカールームは、{rb}港北{/rb}{rt}こうほく{/rt}の部室の三倍くらい広かった。"
    "誰かのスパイクの音だけが、コンクリートに響く。"
    $ se("スタンドの応援（太鼓）")
    "壁の向こうから、桜嶺の応援の太鼓が、ずっと聞こえていた。"
    ## 気持ちが強いときだけ：ひなたが、ひざにテーピングを巻く
    if heart_total("ひなた") >= CH3_SPECIAL_HINATA:
        call ch3_hinata_tape
    show kuroda normal
    with dissolve
    kuroda "……円になれ"
    "{rb}黒田{/rb}{rt}くろだ{/rt}の手には、何もなかった。"
    kuroda "桜嶺は強い。お前らより、ずっと強い"
    kuroda "5月は、0−9だった。あれから半年たった"
    kuroda "半年でできることは、全部やった。走るのも。ロープも"
    kuroda "だから今日は、勝ち負けの前に、一つだけ見せてこい"
    kuroda "……お前らが、ちゃんと試合ができるってことを"
    hide kuroda
    with dissolve
    show miyoshi match
    with dissolve
    miyoshi "……{rb}蓮{/rb}{rt}れん{/rt}。なんか言え"
    ren "俺ですか"
    miyoshi "いいから。俺が言うと、たぶん泣く"
    "11人の目が、俺を見ていた。"
    menu:
        "「5月の0−9を、今日で終わらせよう」":
            $ ch3_huddle = "ouryo"
            $ lean("野心型")
            $ up("メンタル", 3)
            ren "5月の0−9を、今日で終わらせよう。あれが、俺たちの最後の負け方じゃない"
            takano "……当たり前だ"
        "「三好先輩の最後を、今日にしない」":
            $ ch3_huddle = "miyoshi"
            $ lean("仲間型")
            $ bond_up("三好", 5)
            ren "三好先輩の最後の試合を、今日にしない。……それだけです"
            miyoshi "……おまえ、ほんと、そういうの……"
            "三好先輩は、上を向いて、目をぱちぱちさせた。"
        "「楽しもう。この芝で、11人で」":
            $ ch3_huddle = "love"
            $ lean("求道型")
            $ up("メンタル", 3)
            ren "楽しもう。この芝で、11人で"
            sakaguchi "……それ、いちばんむずいやつ"
            daimon "で、でも、いちばん、いいです"
    miyoshi "――港北ーっ！"
    "「おうっ！」"
    "11人の声が、コンクリートの壁にはね返った。"
    "太鼓の音が、一瞬、聞こえなくなった。"
    hide miyoshi
    with dissolve
    $ amb_stop(2.0)
    return


################################################################################
## 準決勝の朝：ひなたのテーピング（ひなたの気持ちが強いときだけ）
################################################################################
label ch3_hinata_tape:
    "ロッカールームの隅のベンチで、ひなたがテーピングのロールを二本、並べていた。"
    voice "audio/voice/hinata_hora.mp3"
    hinata "ほら、座って。ひざ、出して"
    scene cg hinata_taping at cam_push(10.0, 1.05)
    with Dissolve(1.0)
    "ひなたが、俺の前にひざまずいた。"
    "近い。前髪の先が、ひざにかかる。テーピングを引っぱるたびに、ひなたの息が、すねに当たった。"
    "シャンプーの、甘い匂いがした。……いつもの、ひなたの匂いだった。"
    hinata "……動かないで。曲がっちゃう"
    "ひなたの指が、ひざの皿のまわりを、ゆっくりなぞっていく。俺より、俺のひざを知っている指だった。"
    menu:
        "「……近い」":
            $ heart_up("ひなた", "ときめき", 5)
            hinata "……い、今さら？　夏から、ずっとわたしが巻いてるじゃん"
            "そう言いながら、ひなたの耳が、みるみる赤くなった。"
        "「ありがとう。いつも」":
            $ heart_up("ひなた", "信頼", 5)
            hinata "……うん。今日の分は、とくべつ丁寧にした"
    "最後に、ひなたはテーピングの上から、ひざを一回だけ、ぽんとたたいた。"
    voice "audio/voice/hinata_ikko.mp3"
    hinata "いってらっしゃい"
    scene bg locker_room
    with dissolve
    $ set_flag("ひなた_テーピング")
    return


################################################################################
## 入場（桜嶺戦）：通路で、神城と並ぶ
################################################################################
default ch3_numpos = "背中"

label ch3_semi_entrance:
    scene black
    with dissolve
    $ set_cal("11月14日（土）", "選手権予選準決勝　対 桜嶺学園")
    if ch3_knee_plan == "half":
        ## 前半は下がり目で出るとき：試合前のアップで、ボールを拾いに来た神城と話す → 入場の通路
        scene bg stadium_stand_day at cam_push(10.0, 1.04)
        with Dissolve(1.2)
        $ bgm("張りつめた静かな曲")
        $ se("スタンドの応援（太鼓）")
        "試合前のアップ。ひざをならすために、俺だけ先に、ベンチの前でひなたの出すボールを軽く蹴っていた。"
        "足もとに、白いボールが一つ、転がってきた。{rb}桜嶺{/rb}{rt}おうりょう{/rt}のマークの入った、アップ用のボール。"
        "拾い上げると、それを追ってきた白と金のジャージが、目の前で止まった。"
        show kamishiro match
        with dissolve
    else:
        ## 背番号：10番をつけたときは「10」、鷹野に渡したときは「8」の絵
        scene expression ("cg ch3_entrance" if flags.get("背番号10") == "ren" else "cg ch3_entrance8") at cam_push(12.0, 1.05)
        with Dissolve(1.2)
        $ bgm("張りつめた静かな曲")
        $ se("スタンドの応援（太鼓）")
        "選手入場の通路。白と金の列と、青の列が、横に並ぶ。"
        "通路の先が、白く光っていた。歓声が、通路の中まで流れこんでくる。"
        "となりに、あいつがいた。"
    $ meet("神城")
    voice "audio/voice/kamishiro_osoi.mp3"
    kamishiro "……遅い"
    ren "何がだよ"
    kamishiro "来るのが。……この芝に"
    $ ch3_numpos = "胸" if ch3_knee_plan == "half" else "背中"
    if flags.get("背番号10") == "takano":
        "{rb}神城{/rb}{rt}かみしろ{/rt}の目が、俺の[ch3_numpos]の番号で止まった。"
        kamishiro "10番、つけてないんだな"
        ren "点を取るやつがつける番号だ"
        kamishiro "……お前が、それを言うのか"
    elif flags.get("背番号10") == "ren":
        "神城の目が、俺の[ch3_numpos]の番号で止まった。"
        kamishiro "まだ10番か"
        ren "悪いか"
        kamishiro "……いや。似合ってる。あの冬と、同じだ"
    scene cg ch3_kamishiro_ankle at cam_push(6.0, 1.04)
    with dissolve
    "神城の左の足首に、ソックスの上からでもわかるくらい、テーピングが何重にも巻かれていた。"
    ren "……足、どうした"
    kamishiro "なんでもない"
    if ch3_knee_plan == "half":
        scene bg stadium_stand_day
        show kamishiro match
        with dissolve
        "神城は、{rb}桜嶺{/rb}{rt}おうりょう{/rt}のベンチのほうを見ないようにして、小さな声で言った。"
    else:
        scene expression ("cg ch3_entrance" if flags.get("背番号10") == "ren" else "cg ch3_entrance8")
        with dissolve
        "神城は、前を向いたまま、小さな声で言った。"
    kamishiro "……監督には、言うな"
    $ set_flag("神城_足首")
    if ch3_knee_plan == "half":
        "神城は、俺の手からボールを取ると、走ってもどっていった。"
        hide kamishiro
        with dissolve
        scene expression ("cg ch3_entrance" if flags.get("背番号10") == "ren" else "cg ch3_entrance8") at cam_push(12.0, 1.05)
        with Dissolve(1.2)
        "選手入場の通路。白と金の列と、青の列が、横に並ぶ。"
        "となりに、また神城がいた。今度は、どちらも何も言わなかった。"
        "笛が鳴って、列が動き出した。"
    else:
        "笛が鳴って、列が動き出した。"
    return


################################################################################
## 12月の終わり：関係が冷えたヒロインに、ほかの人が近づく「兆し」
##   クリスマスの鉢合わせで選ばれなかった人か、さみしさが15以上でときめきを上回っている人のうち、いちばん冷えた一人だけ
################################################################################
init python:
    def ch3_sign_target():
        hid = {"ひなた": "hinata", "千夏": "chika", "紗希": "saki"}
        cands = []
        for h in ("ひなた", "千夏", "紗希"):
            hv = store.heart[h]
            ## 鉢合わせで選ばれなかった人か、さみしさが15以上で、ときめきより大きい人（クリスマスを過ごした人はのぞく）
            lonely = hv["さみしさ"] >= 15 and hv["さみしさ"] >= hv["ときめき"]
            cold = (store.ch3_xmas_left == hid[h]) or (lonely and store.ch3_xmas != hid[h])
            if h == "紗希" and not store.flags.get("紗希_名前を聞いた"):
                cold = False
            if cold and heart_total(h) >= 20:
                cands.append((hv["さみしさ"] - heart_total(h) * 0.2, hid[h]))
        if not cands:
            return ""
        return sorted(cands, reverse=True)[0][1]

label ch3_sign:
    $ ch3_sign = ch3_sign_target()
    if not ch3_sign:
        return
    scene black
    with dissolve
    $ set_cal("12月28日（月）", "夕方")
    $ set_flag("兆し", ch3_sign)
    jump expression "ch3_sign_" + ch3_sign

label ch3_sign_hinata:
    scene bg shotengai_eve
    $ coat_on()
    with dissolve
    $ bgm("日常の静かな曲")
    "年末の商店街は、いつもより人が多かった。"
    "人ごみの向こうに、見覚えのあるポニーテールが見えた。"
    "ひなたが、知らない男の人と並んで歩いていた。"
    "大学生くらい。紺色のダッフルコート。手に、何かの学校のパンフレット。"
    show hinata smile
    with dissolve
    hinata "あ、蓮。……えっと、こちら、{rb}柏木{/rb}{rt}かしわぎ{/rt}さん"
    hinata "理学療法の学校のオープンキャンパスで、案内してくれた先輩"
    kashiwagi "どうも。……ひなたちゃん、案内のあいだ、ずっと{rb}蓮{/rb}{rt}れん{/rt}くんの話してたよ"
    show hinata pout
    hinata "してないです！　ひざの話をしてただけです！"
    "ひなたは、柏木さんの腕を軽くたたいた。"
    "たたける距離なんだ、と思った。"
    hide hinata
    with dissolve
    "柏木さんが先に歩いていったあと、ひなたは、ふと立ち止まった。"
    show hinata forcesmile
    with dissolve
    hinata "……あのさ、蓮"
    hinata "朝、迎えに行くの、しばらくやめるね"
    ren "なんで"
    hinata "学校の見学とか、資格の勉強も始めたいし。……それに"
    "ひなたは、その先を言わなかった。"
    hinata "ほら、蓮も、もう一人で起きられるでしょ"
    "笑って手を振って、ひなたは人ごみの中に戻っていった。"
    "いつもなら、俺の家の方向に曲がる角を、まっすぐ行った。"
    hide hinata
    with dissolve
    return

label ch3_sign_chika:
    scene bg kohoku_station_gate_eve
    $ coat_on()
    with dissolve
    $ bgm("日常の静かな曲")
    "駅前に、その冬はじめての雪がちらついていた。"
    "改札の前で、紺色の傘が開いた。"
    "見覚えのある傘だった。9月の雨の日、生徒会室の傘立てにあった傘。"
    "その傘を持っていたのは、知らない3年の男子だった。"
    "傘の下に、{rb}千夏{/rb}{rt}ちか{/rt}先輩がいた。"
    show chika normal
    with dissolve
    chika "……{rb}早瀬{/rb}{rt}はやせ{/rt}くん"
    chika "こちら、{rb}相良{/rb}{rt}さがら{/rt}くん。前の副会長です"
    sagara "どうも。{rb}七瀬{/rb}{rt}ななせ{/rt}から、サッカー部の話はよく聞いてます。申請書の字が汚いとか"
    show chika narrow
    chika "それは{rb}三好{/rb}{rt}みよし{/rt}くんの話です"
    chika "……相良くんの受験の、模試の答え合わせを手伝っています。駅前の図書館で"
    chika "来年、同じ大学を受けるつもりなので"
    chika "それだけです"
    "千夏先輩は、いつもの声で言った。"
    "でも、「見回り」とも「生徒会とは関係ありません」とも、言わなかった。"
    hide chika
    with dissolve
    "紺色の傘は、二人の上で、少しだけ千夏先輩のほうに傾いていた。"
    return

label ch3_sign_saki:
    scene bg slope_eve
    $ coat_on()
    with dissolve
    $ bgm("静かなピアノの旋律")
    "港への坂道の途中。ピアノの家の前に、[saki_call]がいた。"
    "となりに、バイオリンのケースを背負った男子が立っていた。"
    "[saki_call]の楽譜のかばんを、その男子が持っていた。"
    show saki normal
    with dissolve
    saki "……見ないで"
    ren "見てない"
    saki "見てた"
    himuro "同じ教室の、{rb}氷室{/rb}{rt}ひむろ{/rt}です。今度、二人で合わせるんで"
    show saki frown
    saki "……練習の帰り。関係ないでしょ"
    "[saki_call]は、それだけ言って、坂を下りていった。"
    "かばんは、氷室が持ったままだった。"
    "[saki_call]は、一度も振り返らなかった。"
    hide saki
    with dissolve
    return
