## ch1_arcade.rpy ―― 第1章 ゲーセンのサッカーゲーム（v0.44.3・全体の見直し）
##   作者の決定（第1章 仲間集めの確認帳）：坂口たちとの「3本目の残り10秒」を、本当に遊べるミニゲームにする。案A「パスでつなぐ」を台本に合わせた形。
##   ・始まりは、蓮の操作する選手がゴール前でパスを受けたところ。残り10秒
##   ・横の味方をタップするとパス（白のそばを通すと取られる）。ゴールの上か下をタップするとシュート（キーパーのいないほうへ）
##   ・白にボールを取られる／10秒たつ／キーパーに止められる と負け。負けても5人は入る（入り方が変わる）
##   ・pick：最後に打ったのが蓮なら "shoot"、パスした味方なら "pass"、打てなかったら ""
##   ・見た目（作者「ゲームらしい見た目にしよ」11/26）：ドット絵の選手・観客席・ネット・ブラウン管の走査線・筐体の看板（絵は images/arcade/。tools なしで作った PNG）

default ch1_dm = 0               # 大門の会話（待つと＋、急ぐと−）
default ch1_tk1 = ""             # 鷹野との勝負：3分の選択（pass / self / wait）
default ch1_tk2 = ""             # 鷹野との勝負：最後の選択（stop / two / let）
default ch1_arcade_win = True    # ゲーセンのゲームに勝ったか
default persistent.tuto_wait_seen = False

init python:
    import math

    class ArcadeGame(object):
        W, H = 960, 470
        GOAL_X = 940
        GOAL_TOP, GOAL_BOT = 178, 292

        def __init__(self):
            self.mates = [[520.0, 268.0, "蓮"], [600.0, 105.0, "味方"]]
            self.foes = [[690.0, 180.0, 55.0], [740.0, 80.0, 30.0]]   # x, y, 速さ
            self.gk = [912.0, 256.0]          # キーパーは少し下（蓮の側）に寄っている＝上がねらい目
            self.hold = 0
            self.ball = [534.0, 268.0]
            self.fly = None          # パスかシュートの途中
            self.t = 10.0
            self.running = False
            self.done = False
            self.result = ""
            self.msg = "タップでスタート"
            self.pick = ""
            self.flash = 0.0
            self.tick = 0            # 点滅などの見た目用

        ## ---- 操作 ----
        def start(self):
            if not self.running and not self.done:
                self.running = True
                self.msg = ""
                renpy.restart_interaction()

        def pass_to(self, i):
            if not self.running or self.fly or i == self.hold:
                return
            h = self.mates[self.hold]
            m = self.mates[i]
            self.fly = {"kind": "pass", "sx": h[0], "sy": h[1], "tx": m[0], "ty": m[1], "p": 0.0, "to": i}
            se("ボールを蹴る音")

        def can_shoot(self):
            return self.running and not self.fly and self.mates[self.hold][0] >= 470

        def shoot(self, high):
            if not self.can_shoot():
                return
            h = self.mates[self.hold]
            ty = self.GOAL_TOP + 16 if high else self.GOAL_BOT - 16
            self.pick = "shoot" if self.hold == 0 else "pass"
            ## シュートを打った瞬間の、キーパーとの距離と、白がコースをふさいでいるか
            blocked = any(self._seg_dist(f[0], f[1], h[0], h[1], self.GOAL_X, ty) < 22 for f in self.foes)
            save = abs(self.gk[1] - ty) < 34
            self.fly = {"kind": "shot", "sx": h[0], "sy": h[1], "tx": self.GOAL_X, "ty": ty, "p": 0.0,
                        "ok": (not blocked) and (not save), "blocked": blocked}

        ## ---- 1こま進める（1/30秒ごと） ----
        def step(self):
            self.tick += 1
            if not self.running:
                renpy.restart_interaction()
                return
            dt = 1.0 / 30
            self.t -= dt
            h = self.mates[self.hold]
            ## 白：一人目はボールを持つ人へ、二人目はパスのコースへ寄る
            f1, f2 = self.foes
            self._move_to(f1, h[0], h[1], f1[2] * dt)
            o = self.mates[1 - self.hold]
            self._move_to(f2, (h[0] + o[0]) / 2.0, (h[1] + o[1]) / 2.0, f2[2] * dt)
            ## キーパー：ボールの高さに、ゆっくりついてくる
            tgt = 235 + (self.ball[1] - 235) * 0.4
            self.gk[1] += max(-70 * dt, min(70 * dt, tgt - self.gk[1]))
            ## 味方は、少しずつ前へ
            for i, m in enumerate(self.mates):
                if i != self.hold and not self.fly:
                    m[0] = min(820.0, m[0] + 20 * dt)
            if self.fly:
                F = self.fly
                F["p"] += dt * (3.0 if F["kind"] == "pass" else 3.6)
                p = min(1.0, F["p"])
                self.ball = [F["sx"] + (F["tx"] - F["sx"]) * p, F["sy"] + (F["ty"] - F["sy"]) * p]
                if F["kind"] == "pass":
                    for f in self.foes:
                        if math.hypot(f[0] - self.ball[0], f[1] - self.ball[1]) < 24:
                            self._end("lose", "白にカットされた……")
                            return
                    if p >= 1.0:
                        self.hold = F["to"]
                        self.fly = None
                elif p >= 1.0:
                    if F["ok"]:
                        self._end("win", "ゴール！！")
                    elif F["blocked"]:
                        self._end("lose", "白の足に当たった……")
                    else:
                        self._end("lose", "キーパーに止められた……")
                    return
            else:
                self.ball = [h[0] + 14, h[1] + 6]
                for f in self.foes:
                    if math.hypot(f[0] - h[0], f[1] - h[1]) < 30:
                        self._end("lose", "白にボールを取られた……")
                        return
            if self.t <= 0 and self.running:
                self.t = 0
                self._end("lose", "時間切れ……")
                return
            renpy.restart_interaction()

        def _end(self, res, msg):
            self.running = False
            self.done = True
            self.result = res
            self.msg = msg
            renpy.restart_interaction()

        def _move_to(self, f, tx, ty, d):
            dx, dy = tx - f[0], ty - f[1]
            l = math.hypot(dx, dy)
            if l > 0.1:
                k = min(1.0, d / l)
                f[0] += dx * k
                f[1] += dy * k

        def _seg_dist(self, px, py, ax, ay, bx, by):
            dx, dy = bx - ax, by - ay
            l = dx * dx + dy * dy
            t = ((px - ax) * dx + (py - ay) * dy) / l if l else 0.0
            t = max(0.0, min(1.0, t))
            return math.hypot(px - (ax + t * dx), py - (ay + t * dy))

## ---- 見た目（v0.44.3：ドット絵のゲーセン風） ----
image arc_pitch = "images/arcade/pitch.png"
image arc_crowd = "images/arcade/crowd.png"
image arc_scan = "images/arcade/scanlines.png"

transform arc_blink(t=0.5):
    alpha 1.0
    pause t
    alpha 0.15
    pause t
    repeat

transform arc_pop:
    zoom 0.6 alpha 0.0
    easein 0.18 zoom 1.15 alpha 1.0
    easeout 0.12 zoom 1.0

## 選手1人（足もとを (x, y) に合わせる）
screen arc_player(x, y, img, ring=False, arrow=False):
    add "images/arcade/shadow.png" xpos int(x) ypos int(y) + 20 anchor (0.5, 0.5)
    if ring:
        add "images/arcade/ring.png" xpos int(x) ypos int(y) + 21 anchor (0.5, 0.5) at arc_blink(0.25)
    add img xpos int(x) ypos int(y) + 24 anchor (0.5, 1.0)
    if arrow:
        text "▼" size 22 color "#ffe14d" outlines [(2, "#000000", 0, 0)] xpos int(x) ypos int(y) - 38 anchor (0.5, 0.5) at arc_blink(0.3)

screen arcade_game(g):
    modal True
    zorder 60
    add Solid("#05070ce6")
    timer 1.0 / 30 repeat True action Function(g.step)
    fixed:
        xysize (1040, 700)
        xalign 0.5
        yalign 0.5
        ## 筐体：看板
        add Solid("#0d0e14") xysize (1040, 700)
        add Solid("#e8231f") pos (0, 0) xysize (1040, 62)
        add Solid("#ffe14d") pos (0, 58) xysize (1040, 4)
        text "激闘！サッカースタジアム":
            font FONT_JP_B
            size 38
            color "#ffffff"
            outlines [(4, "#0b1f52", 0, 0), (7, "#ffe14d", 0, 0)]
            xalign 0.5
            ypos 6
        text "1P" size 22 color "#ffe14d" font FONT_JP_B xpos 26 ypos 18
        text "COM" size 22 color "#ffe14d" font FONT_JP_B xpos 1014 xanchor 1.0 ypos 18
        ## 画面（ブラウン管）
        fixed:
            pos (20, 74)
            xysize (1000, 600)
            add Solid("#15161d")
            add "arc_crowd" pos (20, 8)
            fixed:
                pos (20, 62)
                xysize (960, 471)
                add "arc_pitch"
                ## 白（相手）とキーパー
                for _f in g.foes:
                    use arc_player(_f[0], _f[1], "images/arcade/p_foe.png")
                use arc_player(g.gk[0], g.gk[1], "images/arcade/p_gk.png")
                ## 青（こっち）。ボールを持っている人に、黄色の輪と▼
                for _i, _m in enumerate(g.mates):
                    use arc_player(_m[0], _m[1], ("images/arcade/p_ren.png" if _i == 0 else "images/arcade/p_mate.png"),
                                   ring=(_i == g.hold and not g.fly), arrow=(_i == g.hold and g.running and not g.fly))
                ## ボール
                add "images/arcade/ball.png" xpos int(g.ball[0]) ypos int(g.ball[1]) + 14 anchor (0.5, 0.5)
                ## 押せるところ
                if g.running and not g.fly:
                    for _i, _m in enumerate(g.mates):
                        if _i != g.hold:
                            button:
                                pos (int(_m[0]) - 52, int(_m[1]) - 50)
                                xysize (104, 104)
                                background Solid("#4fa8ff38")
                                hover_background Solid("#4fa8ff70")
                                action Function(g.pass_to, _i)
                                text "PASS" size 20 color "#ffffff" align (0.5, 1.0) yoffset 18 font FONT_JP_B outlines [(3, "#0b1f52", 0, 0)] at arc_blink(0.4)
                    if g.can_shoot():
                        button:
                            pos (868, g.GOAL_TOP - 70)
                            xysize (92, 120)
                            background Solid("#ffe14d30")
                            hover_background Solid("#ffe14d70")
                            action Function(g.shoot, True)
                            text "▲\nSHOOT" size 18 color "#ffe14d" align (0.5, 0.5) text_align 0.5 font FONT_JP_B outlines [(3, "#000000", 0, 0)]
                        button:
                            pos (868, 240)
                            xysize (92, 120)
                            background Solid("#ffe14d30")
                            hover_background Solid("#ffe14d70")
                            action Function(g.shoot, False)
                            text "SHOOT\n▼" size 18 color "#ffe14d" align (0.5, 0.5) text_align 0.5 font FONT_JP_B outlines [(3, "#000000", 0, 0)]
            ## 上のスコア（観客席の上にかぶせる）
            fixed:
                pos (20, 8)
                xysize (960, 54)
                add Solid("#000000b0")
                text "港北FC" size 24 color "#5b9bff" font FONT_JP_B xpos 24 yalign 0.5 outlines [(2, "#000000", 0, 0)]
                text "1 − 1" size 30 color "#ffffff" font FONT_JP_B xpos 250 yalign 0.5 outlines [(2, "#000000", 0, 0)]
                text "坂口FC" size 24 color "#f2f2ee" font FONT_JP_B xpos 380 yalign 0.5 outlines [(2, "#000000", 0, 0)]
                text "3本目" size 20 color "#ffe14d" font FONT_JP_B xpos 540 yalign 0.5
                text ("TIME %04.1f" % max(0.0, g.t)) size 32 color ("#ff5a4d" if g.t < 3 else "#ffe14d") font FONT_JP_B xalign 0.97 yalign 0.5 outlines [(2, "#000000", 0, 0)]
            ## ブラウン管の走査線
            add "arc_scan"
            ## 真ん中の文字
            if g.done and g.result == "win":
                text "GOAL!!" size 120 color "#ffe14d" font FONT_JP_B outlines [(6, "#e8231f", 0, 0), (10, "#0b1f52", 0, 0)] xalign 0.5 ypos 190 at arc_pop
            elif g.done:
                text g.msg size 46 color "#ffffff" font FONT_JP_B outlines [(5, "#0b1f52", 0, 0)] xalign 0.5 ypos 230 at arc_pop
            elif not g.running:
                text "PUSH START" size 64 color "#ffe14d" font FONT_JP_B outlines [(5, "#0b1f52", 0, 0)] xalign 0.5 ypos 200 at arc_blink(0.45)
                text "青い味方をタップでパス　／　ゴールの「▲」「▼」をタップでシュート" size 22 color "#ffffff" font FONT_JP_B outlines [(3, "#0b1f52", 0, 0)] xalign 0.5 ypos 552
        ## 筐体の下（ボタンの飾り）
        text "あと10秒。ボールを持っている選手を、あなたが動かす" size 18 color "#9aa3b3" font FONT_JP_B xalign 0.5 ypos 676
        if not g.running and not g.done:
            button:
                xysize (1040, 700)
                background None
                action Function(g.start)
    if g.done:
        timer 1.8 action Return(g.result)
