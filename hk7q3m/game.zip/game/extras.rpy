## extras.rpy ―― 選手名鑑・回想（一枚絵のギャラリー）
##   選手名鑑：ゲーム中のメニュー「相関図」の右上から開く。第2章の作戦ボードの日から見られる
##   回想　　：タイトル画面の「回想」。一度見た一枚絵だけ、もう一度見られる（見ていない絵は「？」）

################################################################################
## 選手名鑑（港北　4−4−2。第4章からは 4−2−3−1）
################################################################################

## (背番号, ポジション, 名前, 学年, 紹介)
define ROSTER = [
    (1, "GK", "大門 剛", "1年", "元柔道部。身長190センチ。受け身は部でいちばん。ボールは、まだ少し怖い。"),
    (2, "DF", "三好 大地", "3年", "キャプテン。中学の3年間は、ずっと補欠。誰よりも走って、誰よりも声がでかい。"),
    (3, "DF", "桐生", "2年", "名前だけの部員だった先輩。口数は少ないが、つっこみは鋭い。"),
    (4, "DF", "宮下", "2年", "笑い上戸。三好先輩が何か言うたびに、しゃがんで笑いをこらえている。左のサイドバック。"),
    (5, "DF", "森", "1年", "ゲーセンの5人組。坊主頭で、ぽっちゃり、たれ目。上がりっぱなしの坂口の、尻ぬぐい係。"),
    (6, "MF", "坂口", "1年", "ゲーセンの5人組。右サイドを上がりっぱなしで、ずっとクロスを上げる。口ぐせは「ウケる」。"),
    (7, "MF", "小池", "1年", "ゲーセンの5人組。黒ぶちメガネの、眠そうな目をしたやせっぽち。口ぐせは「たぶん」。真ん中の後ろで、パスを散らす係。"),
    (8, "MF", "早瀬 蓮", "1年", "主人公。中学では県選抜。右ひざのケガで、桜嶺の推薦がなくなった。真ん中で、全員にボールを配る。"),
    (9, "MF", "江藤", "1年", "ゲーセンの5人組。茶色のくせ毛に日焼け、笑うと八重歯。左サイド。ドリブルしかしない……と、本人は言っている。"),
    (10, "FW", "鷹野 迅", "1年", "元Jクラブのジュニアユース。口は悪いが、サッカーには誰よりもまじめ。"),
    (11, "FW", "野口", "1年", "ゲーセンの5人組。目が隠れるほど前髪の長い、ひょろっとしたのっぽ。点を取る係。公式戦では、まだ取ったことがない。"),
]

## 第4章（ルートA・高2）の名鑑（v0.30.0）。学年が上がり、三好が卒業し、新しい1年が入った 4−2−3−1（chapter4a_2.rpy の a4_board_new と同じ並び）
##   1年の背番号：倉田 12、赤坂 13、小早川 15
define ROSTER_A4 = [
    (1, "GK", "大門 剛", "2年", "元柔道部。身長190センチ。今年は、いちばんうしろから全員に声を出す係。1年の倉田に、手本にされている。"),
    (3, "DF", "桐生", "3年", "センターバック。口数は少ないが、つっこみは鋭い。最後の一年。"),
    (4, "DF", "宮下", "3年", "笑い上戸。今年は桐生先輩と並ぶセンターバック。三好先輩がいなくなって、笑う回数が少しだけ減った。"),
    (5, "DF", "森", "2年", "ゲーセンの5人組。右のサイドバック。上がりっぱなしの坂口の尻ぬぐい係は、今年も変わらない。"),
    (11, "DF", "野口", "2年", "ゲーセンの5人組。目が隠れるほど前髪の長いのっぽ。今年から左のサイドバックに下がった。「前で走れるやつは、後ろでも走れる」"),
    (7, "MF", "小池", "2年", "ゲーセンの5人組。黒ぶちメガネ。小早川と二人で、真ん中の後ろからボールを拾って散らす。"),
    (15, "MF", "小早川 陸", "1年", "港北の最後の新入生。中学ではボランチ。去年の冬の準決勝を、スタンドで見ていた。首を振る回数を、声に出して数える。"),
    (6, "MF", "坂口", "2年", "ゲーセンの5人組。右サイド。クロスを蹴る前に、もうこっちを見ない。口ぐせは「ウケる」。"),
    (9, "MF", "江藤", "2年", "ゲーセンの5人組。左サイド。ドリブルしかしない……と、まだ本人は言っている。"),
    (8, "MF", "早瀬 蓮", "2年", "主人公。今年はトップ下。鷹野のすぐうしろで、ボールを受けてから考える時間を半分にする。"),
    (10, "FW", "鷹野 迅", "2年", "元Jクラブのジュニアユース。口は悪いが、サッカーには誰よりもまじめ。1年の赤坂に、毎日勝負を挑まれている。"),
    (12, "GK", "倉田", "1年", "控えのキーパー。体は大きいのに、気が弱い。大門を手本にしていて、ベンチからは大門より大きな声を出す。"),
    (13, "FW", "赤坂", "1年", "生意気な1年のフォワード。鷹野に勝ち逃げされたのが悔しくて入部した。「俺、走れますよ」"),
]

define ROSTER_A4_NEW = {"小早川 陸": "小早川", "倉田": "倉田", "赤坂": "赤坂"}

## 選手名鑑の顔写真（トークのアイコン gui/talk/avatar/〜.png と同じ丸い顔）。v0.29.12。第4章の人は v0.30.0
define ROSTER_FACE = {"大門 剛": "daimon", "三好 大地": "miyoshi", "桐生": "kiryu", "宮下": "miyashita", "森": "mori",
                      "坂口": "sakaguchi", "小池": "koike", "早瀬 蓮": "ren", "江藤": "eto", "鷹野 迅": "takano", "野口": "noguchi",
                      "小早川 陸": "kobayakawa", "倉田": "kurata", "赤坂": "akasaka"}

## 選手名鑑のランク（v0.37.0。作者の声「他の選手たちのステータスは？　見せかけだけにはなると思うけど」）
##   選手ひとりずつの能力値は、操作には関わらない読みもの。話の進み方（第2章／第3章／高2）でランクが上がる
##   (とくいなこと, {時期: (総合, とくいのランク)})。蓮だけは、本当の能力値から出す（chapter_result.rpy の chres_rank）
define ROSTER_RANK = {
    "大門 剛": ("高さ", {"ch2": ("E", "B"), "ch3": ("D", "B"), "a4": ("C", "B+")}),
    "三好 大地": ("スタミナ", {"ch2": ("E", "B"), "ch3": ("D", "B+")}),
    "桐生": ("読み", {"ch2": ("E", "C"), "ch3": ("D", "C"), "a4": ("D+", "C+")}),
    "宮下": ("守備", {"ch2": ("E", "D"), "ch3": ("D", "D+"), "a4": ("D+", "C")}),
    "森": ("カバー", {"ch2": ("E", "D"), "ch3": ("E+", "D+"), "a4": ("D", "C")}),
    "坂口": ("クロス", {"ch2": ("E", "C"), "ch3": ("D", "C+"), "a4": ("D+", "B")}),
    "小池": ("パス", {"ch2": ("E", "D"), "ch3": ("E+", "D+"), "a4": ("D", "C")}),
    "江藤": ("ドリブル", {"ch2": ("E", "C"), "ch3": ("D", "C"), "a4": ("D+", "C+")}),
    "鷹野 迅": ("シュート", {"ch2": ("D+", "B"), "ch3": ("C", "B+"), "a4": ("C+", "A")}),
    "野口": ("裏への走り", {"ch2": ("E", "D"), "ch3": ("E+", "D+"), "a4": ("D", "C")}),
    "小早川 陸": ("パス", {"a4": ("D+", "C")}),
    "倉田": ("高さ", {"a4": ("E", "C")}),
    "赤坂": ("スピード", {"a4": ("D", "B")}),
}

init python:
    def roster_stage():
        """名鑑のランクの時期：第2章（ch2）／第3章から（ch3）／高2（a4）"""
        if roster_is_a4():
            return "a4"
        marks = getattr(store, "play_marks", None) or {}
        if "chapter3" in marks or store.cal_year > 2026:
            return "ch3"
        return "ch2"

    def roster_rank(nm):
        """(総合, とくいなこと, とくいのランク) か None"""
        if nm.startswith("早瀬"):
            st = store.stats
            best = max(STAT_KEYS, key=lambda k: st.get(k, 0))
            return (chres_rank(chres_ovr([st.get(k, 0) for k in STAT_KEYS])), best, chres_rank(st.get(best, 0)))
        r = ROSTER_RANK.get(nm)
        if not r:
            return None
        sp, by = r
        stage = roster_stage()
        v = by.get(stage) or by.get("ch3") or by.get("ch2")
        if not v:
            return None
        return (v[0], sp, v[1])

    def roster_rows():
        """選手名鑑の並び。第2章で蓮が10番をつけたときは、蓮と鷹野の背番号を入れかえる
        背番号10を決める前（1回戦の朝より前）は、蓮と鷹野の背番号を「？」（None）にする"""
        a4 = roster_is_a4()
        rows = [(no, pos, nm, gr, (roster_a4_prof(nm, prof) if a4 else roster_prof(nm, prof))) for no, pos, nm, gr, prof in (ROSTER_A4 if a4 else ROSTER)]
        if a4:
            ## 新しい1年は、入部して会ってから載せる（meet で met に入った人だけ）
            met = getattr(store, "met", None) or []
            rows = [r for r in rows if r[2] not in ROSTER_A4_NEW or ROSTER_A4_NEW[r[2]] in met]
        if not store.flags.get("背番号10"):
            rows = [((None if nm.startswith("早瀬") or nm.startswith("鷹野") else no), pos, nm, gr, prof)
                    for no, pos, nm, gr, prof in rows]
        elif store.flags.get("背番号10") == "ren":
            swap = {8: 10, 10: 8}
            rows = [((swap.get(no, no) if nm.startswith("早瀬") or nm.startswith("鷹野") else no), pos, nm, gr, prof)
                    for no, pos, nm, gr, prof in rows]
            if not a4:
                rows.sort(key=lambda r: r[0])
        return rows

    def roster_is_a4():
        """高2の名鑑にするか。第4章（ルートA）の4月7日（入学式）から（v0.31.1：それまでは1/1 に切りかわり、卒業前の三好が消えていた。
        判定は relations.rpy の grade_up_done と同じ）"""
        return grade_up_done()

    def roster_formation_a4():
        """名鑑の見出しの並び（4−2−3−1）。第4章で並びを変えた 5月10日から"""
        if not grade_up_done():
            return False
        if store.cal_year > 2027:
            return True
        d = _doy(store.cal_date)
        return d is not None and d >= _doy("5月10日")

    def roster_prof(nm, prof):
        """紹介文を、話の進み方（フラグ）で書き分ける。当てはまらなければ ROSTER の文のまま"""
        f = store.flags
        if nm.startswith("鷹野") and f.get("ch2_takano_night"):
            return "元Jクラブのジュニアユース。口は悪いが、夜に一人で左足を磨いている。"
        if nm == "宮下" and store.ch2_miyoshi_cb == "kiryu":
            return "笑い上戸。三好先輩が何か言うたびに、しゃがんで笑いをこらえている。三好先輩が左に回ってからは、桐生先輩と並ぶセンターバック。"
        if nm == "野口" and f.get("野口_初ゴール"):
            return "ゲーセンの5人組。目が隠れるほど前髪の長い、ひょろっとしたのっぽ。点を取る係。選手権の1回戦で、自分の公式戦で初めてのゴールを決めた。"
        return prof

    def roster_a4_prof(nm, prof):
        """第4章の紹介文を、勧誘で回った場所（a4_recruit）で書き分ける。当てはまらなければ ROSTER_A4 の文のまま"""
        recruit = getattr(store, "a4_recruit", None) or []
        if nm == "赤坂" and "ground" not in recruit:
            return "生意気な1年のフォワード。桜嶺のセレクションを蹴って、すぐ出られる港北に来た。入部届を、鷹野の顔の前に突きつけた。「俺、走れますよ」"
        return prof

    def roster_open():
        """選手名鑑が見られるか（作戦ボードの日を過ぎたか）"""
        return bool(store.flags.get("名鑑")) or bool(store.ch2_pos)

## ピッチの上の位置（ピッチの幅・高さに対する割合。下が港北のゴール）。v0.37.0（確認ページ第15回で R1「ピッチ」に決まった）
##   ここにない人（控え）は、ピッチの右の「ベンチ」に並べる。ベンチの人がいないときは、ベンチの列を出さない
define ROSTER_POS_442 = {"大門 剛": (0.5, 0.9), "宮下": (0.14, 0.7), "桐生": (0.38, 0.75), "三好 大地": (0.62, 0.75), "森": (0.86, 0.7),
                         "小池": (0.5, 0.57), "江藤": (0.18, 0.45), "坂口": (0.82, 0.45), "早瀬 蓮": (0.5, 0.35),
                         "鷹野 迅": (0.33, 0.15), "野口": (0.67, 0.15)}
define ROSTER_POS_4231 = {"大門 剛": (0.5, 0.9), "野口": (0.14, 0.7), "桐生": (0.38, 0.75), "宮下": (0.62, 0.75), "森": (0.86, 0.7),
                          "小池": (0.34, 0.58), "小早川 陸": (0.66, 0.58), "江藤": (0.17, 0.39), "早瀬 蓮": (0.5, 0.37), "坂口": (0.83, 0.39),
                          "鷹野 迅": (0.5, 0.15)}

init python:
    def roster_layout():
        """(ピッチに出す人 [(行, x, y)], ベンチの人 [行], 並びの名前)"""
        rows = roster_rows()
        if roster_is_a4():
            pos, fm = dict(ROSTER_POS_4231), ("4−2−3−1" if roster_formation_a4() else "4−4−2")
        else:
            pos, fm = dict(ROSTER_POS_442), "4−4−2（中盤はひし形）"
            if store.ch2_miyoshi_cb == "kiryu":
                ## 三好の相談で「真ん中は桐生先輩たちに」：三好が左、宮下が真ん中
                pos["三好 大地"], pos["宮下"] = pos["宮下"], pos["三好 大地"]
        on, bench = [], []
        for r in rows:
            if r[2] in pos:
                on.append((r, pos[r[2]][0], pos[r[2]][1]))
            else:
                bench.append(r)
        return on, bench, fm

screen roster_face(r, x, y, sel, w=60, on_paper=False):
    $ _no, _pos, _nm, _gr, _prof = r
    button:
        pos (x, y)
        anchor (0.5, 0.5)
        background None
        padding (0, 0, 0, 0)
        action SetScreenVariable("sel", _nm)
        vbox:
            spacing 1
            fixed:
                xysize (w + 10, w + 8)
                if sel == _nm:
                    add Transform("gui/roster/sel.png", size=(w + 10, w + 10)) pos (0, -1)
                add Transform("gui/talk/avatar/%s.png" % ROSTER_FACE.get(_nm, "ren"), size=(w, w)) pos (5, 5)
                frame:
                    pos (0, -2)
                    padding (5, 0, 5, 1)
                    background (PEN_RED if _nm.startswith("早瀬") else "#2a5bd7")
                    text (str(_no) if _no else "？") style "roster_fno"
            text _nm.split(" ")[0] style ("roster_fname_p" if on_paper else "roster_fname") xalign 0.5

screen roster():
    tag menu
    default sel = "早瀬 蓮"
    use game_menu("選手名鑑"):
        if roster_open():
            $ _on, _bench, _fm = roster_layout()
            $ _pw = 470 if _bench else 610
            fixed:
                xysize (900, 568)
                ## ピッチ
                add ("gui/roster/pitch_n.png" if _bench else "gui/roster/pitch.png") pos (0, 0)
                for _r, _x, _y in _on:
                    use roster_face(_r, int(_pw * _x), int(556 * _y), sel)
                ## ベンチ（控えがいるときだけ）
                if _bench:
                    frame:
                        pos (480, 0)
                        xysize (130, 556)
                        background "#ffffffb0"
                        vbox:
                            xalign 0.5
                            ypos 10
                            spacing 14
                            frame:
                                xalign 0.5
                                padding (12, 2, 12, 3)
                                background INK_SOFT
                                text "ベンチ" size 16 font FONT_JP_B color "#ffffff"
                            for _r in _bench:
                                fixed:
                                    xysize (110, 96)
                                    use roster_face(_r, 55, 46, sel, on_paper=True)
                ## 右の紙（選んだ人のこと）
                use roster_detail(sel)
        else:
            text "第2章の作戦ボードの日から見られます。" color INK_SOFT size 24

    if roster_open():
        $ _fm2 = roster_layout()[2]
        text "県立港北高校サッカー部　" + _fm2 style "rel_legend" xpos 476 ypos 62
    hbox:
        xanchor 1.0
        xpos 1236
        ypos 52
        textbutton "相関図にもどる" style "roster_link" text_style "roster_link_text" action ShowMenu("relations")

screen roster_detail(sel):
    $ _r = [r for r in roster_rows() if r[2] == sel]
    frame:
        style "rel_detail"
        background "#fffdf6"
        if _r:
            $ _no, _pos, _nm, _gr, _prof = _r[0]
            $ _rk = roster_rank(_nm)
            vbox:
                xalign 0.5
                ypos 18
                xsize 236
                spacing 8
                add Transform("gui/talk/avatar/%s.png" % ROSTER_FACE.get(_nm, "ren"), size=(110, 110)) xalign 0.5
                text "%s　%s　%s" % ((str(_no) if _no else "？"), _pos, _gr) style "roster_dsub" xalign 0.5
                text _nm style "roster_dname" xalign 0.5
                if _rk:
                    hbox:
                        xalign 0.5
                        spacing 14
                        vbox:
                            spacing 2
                            text "総合" style "roster_dsub" xalign 0.5
                            frame:
                                style "roster_drk"
                                text _rk[0] style "roster_drk_t"
                        vbox:
                            spacing 2
                            text _rk[1] style "roster_dsub" xalign 0.5
                            frame:
                                style "roster_drk"
                                background PEN_TEAL
                                text _rk[2] style "roster_drk_t"
                null height 2
                text _prof style "roster_dprof"

init 1:
    style roster_card:
        xfill True
        background "#ffffff88"
        padding (12, 10, 12, 10)
    style roster_badge:
        xysize (78, 78)
        yalign 0.5
    style roster_no:
        xalign 0.5
        font FONT_JP_B
        size 30
        color "#ffffff"
    style roster_pos:
        xalign 0.5
        font FONT_JP_B
        size 16
        color "#ffffff"
    style roster_name:
        font FONT_JP_B
        size 26
        color INK
    style roster_grade:
        size 18
        color INK_SOFT
    style roster_prof:
        size 20
        color INK
        line_spacing 2
    style roster_fno:
        font FONT_JP_B
        size 13
        color "#ffffff"
    style roster_fname:
        font FONT_JP_B
        size 14
        color "#ffffff"
        outlines [(2, "#00000088", 0, 1)]
    style roster_fname_p:
        font FONT_JP_B
        size 14
        color INK
    style roster_dsub:
        size 15
        color INK_SOFT
    style roster_dname:
        font FONT_JP_B
        size 26
        color INK
    style roster_drk:
        background PEN_RED
        padding (14, 2, 14, 2)
        xminimum 64
        xalign 0.5
    style roster_drk_t:
        xalign 0.5
        font FONT_JP_B
        size 30
        color "#ffffff"
    style roster_dprof:
        size 16
        color INK
        line_spacing 4
        xmaximum 236
    style roster_rk:
        background PEN_RED
        padding (8, 0, 8, 0)
        xminimum 42
    style roster_rk_t:
        xalign 0.5
        font FONT_JP_B
        size 18
        color "#ffffff"
    style roster_rk_l:
        size 16
        color INK_SOFT
    style roster_link:
        padding (10, 6, 10, 6)
        background "#ffffff88"
        hover_background "#ffffffcc"
    style roster_link_text:
        font FONT_JP_B
        size 22
        color PEN_TEAL
        hover_color PEN_RED


################################################################################
## 回想（一枚絵のギャラリー）
################################################################################

## 章ごとに並べる。(章の見出し, [一枚絵の名前…])
define GALLERY = [
    ("プロローグ", ["op_breath", "op_trap", "op_open", "op_kamishiro", "op_cutback", "op_clear", "ren_down", "pro_hinata_choco"]),
    ("第1章", ["saki_meet", "miyoshi_rain", "bus_hinata", "m531_warmup", "m531_kamishiro", "m531_huddle",
               "m531_tackle", "m531_keeper", "m531_goal2", "m531_goal3", "m531_goal4", "m531_final", "m531_surrounded", "practice_chaos",
               "practice_sakaguchi", "practice_daimon", "practice_bench", "practice_miyoshi", "practice_takano"]),
    ("第2章", ["chika_video", "chika_video_fall", "chika_umbrella", "hinata_jersey", "kuroda_kick", "kuroda_kick_goal", "ch2m_concede", "ch2m_header", "ch2m_tip", "ch2m_post", "ch2m_bar", "ch2m_offside", "daimon_pk", "ch2s_concede", "ch2s_counter1", "ch2s_counter2", "ch2s_takano", "ch2s_hold", "ch2s_legs1", "ch2s_legs2", "album_photos", "gym_futons", "gym_miyoshi", "gym_takano", "gym_door_light", "train_saki", "fw_hinata", "fw_chika", "fw_boys", "fw_saki"]),
    ("第3章", ["ch3d_slump", "practice_rope", "ch3d_r1_phone", "ch3d_r1_goal", "ch3d_r2_memo", "ch3m_save", "ch3m_kiryu_head", "ch3m_miyoshi_clear", "ch3m_concede", "ch3m_daimon_down", "ch3m_equalizer", "ch3m_head_miyoshi", "ch3m_head_takano", "ch3m_ren_finish", "ch3m_rebound", "ch3m_ren_shot", "ch3m_takano_fk", "ch3m_celebrate", "ch3m_celebrate_miyoshi", "ch3m_celebrate_takano", "ch3m_daimon_catch", "ch3d_qf_eto", "ch3d_qf_saki", "ch3_entrance", "ch3s_kami_shot", "ch3s_concede15", "ch3s_daimon_catch22", "ch3s_post22", "ch3s_kami_back", "ch3s_turn", "ch3s_kami_steal", "ch3s_mid_save", "ch3s_takano_wide", "ch3s_takano_beat", "ch3s_takano_bar", "ch3s_makabe_steal", "ch3s_ren_bar", "ch3s_takano_save", "ch3s_concede40", "ch3s_daimon_catch62", "ch3s_concede62", "ch3s_knee", "ch3s_block75", "ch3s_concede75", "ch3s_goal_takano_back", "ch3s_last_face", "ch3s_last_self", "ch3s_goal_self", "ch3s_goal_takano", "ch3s_goal_daimon", "ch3s_goal_jiku", "ch3s_stoppage_sign", "ch3s_stoppage_goal", "ch3_kamishiro_ankle", "ch3_kamishiro_ankle_pitch", "ch3_kamishiro_face", "hinata_taping", "chika_sleep", "saki_wind", "saki_piano", "miyoshi_lying", "saki_recital", "hinata_video", "ch3_armband", "ch3_newyear"]),
    ("第4章A", ["a4_train_daimon", "a4_train_takano", "a4_train_sakaguchi", "feb_group", "feb_vending", "a4_pong", "a4_kuroda_lobby", "a4_mid_hinata", "a4_mid_chika", "feb_snowbunny", "a4_val_hinata", "a4_val_chika", "kamishiro_grab", "ageha_purikura", "ch4q_daimon", "ch4q_akasaka", "ch4q_takano", "ch4q_bench", "ch4q_save", "a4_heart_hinata", "a4_heart_chika", "a4_heart_ageha", "a4_fes_hinata", "a4_fes_chika", "a4_fes_ageha"]),
    ("第5章A", ["a5_mother_night", "a5_fest_hinata", "a5_fest_chika", "a5_fest_ageha", "a5_xmas_hinata", "a5_xmas_hinata_hand", "a5_xmas_chika", "a5_xmas_ageha", "a5_chika_video2", "a5_chika_video_sleep", "a5_val_hinata", "a5_val_chika", "a5_val_ageha", "a5_grad_chika"]),
    ("第6章A", ["a6_empty_class", "a6_ih_win", "a6_fes_hinata", "a6_fes_chika", "a6_fes_ageha", "a6_kuroda_box", "a6_final_entrance", "a6_onizuka_sign", "a6_kamishiro_block", "a6_final_goal", "a6_fw_managers", "a6_fw_daimon", "a6_fw_sakaguchi", "a6_fw_ren", "a6_nat_stadium", "a6_hatsumode_hinata"]),
    ## ルートB（桜嶺へ移る）。11/8 に足した（作者の決定：見た一枚絵だけ開く）
    ("第4章B", ["b4_dorm_bunk", "b4_bibs", "b4_kamishiro_tape", "b4_reika_meet", "b4_reika_car", "b4_reika_office", "b4_stand_kohoku", "b4_ih_hinata", "b4_trust_saki", "b4_heart_saki", "b4_heart_ageha", "b4_kamishiro_camp", "b4_kamishiro_night", "b4_fes_saki", "b4_fes_ageha", "b4_fes_reika"]),
    ("第5章B", ["b5_fest_saki", "b5_fest_ageha", "b5_fest_reika", "b5_rooftop_brother", "b5_saki_pier", "b5_ward_kuroda", "b5_ward_reika", "b5_stand_semi", "b5_first_goal", "b5_final_knee", "b5_xmas_saki", "b5_xmas_ageha", "b5_xmas_reika", "b5_val_saki", "b5_val_ageha", "b5_grad_ichinose"]),
    ("第6章B", ["b6_white_bib", "b6_white_bib2", "b6_fence_koba", "b6_ih_takano", "b6_reika_retire", "b6_fes_saki", "b6_fes_ageha", "b6_fes_reika", "b6_rooftop", "b6_final_entrance", "b6_onizuka_sign", "b6_shield", "b6_final_whistle", "b6_saki_pier", "b6_honda_letter", "b6_nat_final", "b6_envelopes"]),
    ("終章B", ["fin_b_envelopes_room", "fin_b_truth", "fin_b_gate", "fin_ep_euro", "fin_ep_king", "fin_ep_lone", "fin_ep_detour", "fin_ep_bench", "fin_ep_kickoff"]),
]

init python:
    def gallery_seen(name):
        ## 背番号などで絵が2種類ある一枚絵は、どちらかを見ていれば開く（〜8 は背番号8の絵）
        return renpy.seen_image("cg " + name) or renpy.seen_image("cg " + name + "8")

    def gallery_count():
        n = 0
        total = 0
        for head, names in GALLERY:
            for nm in names:
                total += 1
                if gallery_seen(nm):
                    n += 1
        return n, total

screen gallery():
    tag menu
    use game_menu("回想", scroll="viewport"):
        $ seen_n, all_n = gallery_count()
        text "見た一枚絵　[seen_n]／[all_n]" color INK_SOFT size 20
        for head, names in GALLERY:
            text head style "status_head"
            hbox:
                box_wrap True
                spacing 10
                box_wrap_spacing 10
                xsize 850
                for nm in names:
                    if gallery_seen(nm):
                        button:
                            style "gallery_thumb"
                            action Show("gallery_view", img="cg " + nm)
                            add Transform("cg " + nm, xysize=(196, 110))
                    else:
                        frame:
                            style "gallery_thumb"
                            background "#00000033"
                            text "？" xalign 0.5 yalign 0.5 size 40 color "#ffffffaa"
        ## カレンダーの絵（日付が進むときに出る「裏側の絵」。見た絵だけ開く。v0.37.0）
        $ _cal_seen = persistent.cal_pics_seen or set()
        text "カレンダーの絵　%d／%d" % (len([p for p in CAL_PICS if p["id"] in _cal_seen]), len(CAL_PICS)) style "status_head"
        hbox:
            box_wrap True
            spacing 10
            box_wrap_spacing 10
            xsize 850
            for p in CAL_PICS:
                if p["id"] in _cal_seen:
                    button:
                        style "gallery_thumb"
                        action Show("gallery_view", img="calpic " + p["id"])
                        add Transform("calpic " + p["id"], xysize=(196, 110))
                else:
                    frame:
                        style "gallery_thumb"
                        background "#00000033"
                        text "？" xalign 0.5 yalign 0.5 size 40 color "#ffffffaa"

## 一枚絵を大きく見る（クリックかタップで閉じる）
screen gallery_view(img):
    modal True
    zorder 200
    add "#000"
    add img xalign 0.5 yalign 0.5
    button:
        xysize (1280, 720)
        action Hide("gallery_view")
    key "game_menu" action Hide("gallery_view")

init 1:
    style gallery_thumb:
        xysize (202, 116)
        padding (3, 3, 3, 3)
        background "#ffffff"
        hover_background PEN_RED

## スマホ（small）では文字を大きくする
init 1:
    style roster_name:
        variant "small"
        size 30
    style roster_grade:
        variant "small"
        size 22
    style roster_prof:
        variant "small"
        size 24


################################################################################
## サッカーノート（豆知識）
##   話の中でサッカーの言葉が出てきたときに $ learn("offside") と書くと、ノートに1つ増える。
##   中身は、ひなたのノートに、黒田がひとこと書き足した形。メニューの「相関図」の右上から読める
################################################################################

default note_learned = []

## (キー, 見出し, 本文, 黒田のひとこと)
define SOCCER_NOTE = [
    ("b_team", "Bチーム",
     "部員の多い強豪校は、試合に出る順にA・B・Cとチームを分けている。Bチームでも、ほかの高校のレギュラーより強いことがある。",
     "Bに勝っても、まだAがいる"),
    ("interhigh", "インターハイと選手権",
     "高校サッカーの大きな全国大会は、夏のインターハイと、冬の全国高校サッカー選手権。どちらも、まず県の予選を勝ち抜く必要がある。3年生の多くは、冬の選手権が最後の大会になる。",
     "冬まで残れるかは、夏の過ごし方で決まる"),
    ("f442", "4−4−2",
     "DF4人・MF4人・FW2人の並び方。昔から多くのチームが使ってきた、基本の形。港北は、中盤の4人をひし形（後ろに1人・左右に1人ずつ・前に1人）に置く「ダイヤモンド型」で、前の1人がトップ下に近い役割になる。",
     "形は入れ物だ。中身はお前らが決める"),
    ("cb", "センターバック",
     "DFの真ん中の2人。相手のFWと競り合い、ゴール前を守る最後の砦。抜かれても追いつける足と、まわりを動かす声が大事。",
     "声がでかいのは才能だ"),
    ("sb", "サイドバック",
     "DFの左右の2人。守るだけでなく、タッチラインぞいを駆け上がって攻撃にも加わる。上がったあとの背中のスペースを狙われやすい。",
     "上がったら、誰が埋めるかを決めておけ"),
    ("cmf", "真ん中のMF",
     "フィールドのまん中で、守りから攻めへのつなぎ役。前後左右すべてに顔を出すので、まわりを見る力（戦術眼）がいちばん試される。",
     "ボールを持っていない時間のほうが長い"),
    ("cross", "クロス",
     "サイドから、ゴール前に上げるボール。中で待つFWが頭や足で合わせる。ゴールから遠ざかるように曲がるボールは、キーパーが出にくい。",
     "上げる前に、中を一回見ろ"),
    ("onetwo", "ワンツー",
     "味方にパスを出して走り、すぐに返してもらう、2本のパス。1人の相手を、2人がかりで抜くことができる。",
     "出したら止まるな"),
    ("offside", "オフサイド",
     "パスが出た瞬間に、攻める側の選手が、相手の後ろから2人目（ふつうはいちばん後ろのDF）より相手ゴールに近い場所にいて、プレーに関わると反則。自分の陣地にいるときは関係ない。キーパーの前に立って邪魔をするのも、プレーに関わったことになる。きわどいときは、副審はプレーが終わるまで旗を上げずに待つ。だから、ゴールのあとで取り消されることがある。",
     "線は動く。ボールが出る瞬間だけ見ろ"),
    ("pk_shootout", "PK戦",
     "トーナメントで同点のまま終わったとき、PK戦で勝ち上がりを決めることがある。先に蹴るチームはコイントスで決め、交互に5人ずつ蹴る。それでも同点なら、1人ずつのサドンデス。",
     "蹴る前に、もう決めておけ"),
    ("gk_dive", "キーパーの横っ飛び",
     "キーパーは、倒れる前提で横に飛ぶ。上手な選手は、手、肩、腰の順に地面につき、ケガをしにくい。柔道の受け身とよく似ている。",
     "倒れ方を知っているやつは、怖がらない"),
    ("ura", "裏を取る",
     "相手のDFの後ろのスペースに走りこむこと。上がっていった相手の選手がいた場所は、ぽっかり空いていることが多い。",
     "答えは、いつもボールのないところにある"),
    ("setpiece", "セットプレー",
     "コーナーキックやフリーキックなど、止まったボールから始まるプレー。何度も練習した形をそのまま使えるので、力の差があっても点を取りやすい。強いチームとの試合では、得点の多くがセットプレーから生まれる。",
     "動いてる試合で勝てないなら、止めて勝て"),
    ("zone", "ゾーンで守る",
     "守るとき、相手の選手ではなく「場所」を受け持つやり方。ボールが落ちてくる場所を読んで、先に立っておく。読みのいい選手ほど、走らずに守れる。",
     "足が遅いなら、先に行け"),
    ("counter", "カウンター",
     "相手の攻撃をしのいだあと、ボールを奪った瞬間に一気に攻めること。相手の選手が前に出ているので、後ろが手薄になっている。走れるチームの武器。",
     "奪った瞬間が、いちばん相手が弱い"),
    ("manmark", "マンマーク",
     "相手の決まった一人に、ずっとついて守るやり方。エースを自由にさせないために使う。ついている側は、相手より先に動かないと置いていかれる。",
     "ボールじゃなく、そいつの目を見ろ"),
    ("captain", "キャプテンマーク",
     "キャプテンが腕に巻く腕章。試合中に審判と話せるのは、基本的にキャプテンだけ。チームの声になる、という印でもある。",
     "巻いたやつが、一番最後まで走れ"),
    ("junior_youth", "ジュニアユース",
     "プロのサッカークラブが持っている、中学生のチーム（高校生はユース）。学校の部活とはちがい、選ばれた選手だけが入れる。上がれるのは、さらにその中の一部だけ。",
     "上に行けなかったやつのほうが、多い"),
    ("top_shita", "トップ下",
     "FWのすぐうしろ、相手のゴールに近い真ん中の位置。点に直結するパスや、自分のシュートで勝負する、いちばん目立つ場所の一つ。",
     "目立つ場所ほど、つぶされる"),
    ("last_line", "最終ライン",
     "いちばんうしろに並ぶDFの列。この線の高さで、オフサイドの位置も、チーム全体の広さも決まる。下がりすぎると、前の選手との間があく。",
     "線を上げるのは、勇気だ"),
    ("near", "ニアとファー",
     "ボールを蹴る位置から見て、ゴールの手前側がニア、奥側がファー。クロスに合わせるとき、ニアに走りこむと、キーパーより先に触れやすい。",
     "迷ったら、ニアに飛びこめ"),
    ("knee", "ひざの靭帯",
     "靭帯は、骨と骨をつなぐ、ひものような組織。ひざには前後左右に靭帯があり、サッカーでは着地や切り返しで傷めやすい。痛みが引いても、すぐ全力で動くと、また傷めやすい。",
     "……俺みたいになるな"),
]

init python:
    def learn(key):
        """サッカーノートに1つ増やす。初めてのときだけ、右上に出す"""
        if key in store.note_learned:
            return
        store.note_learned = store.note_learned + [key]
        for k, title, body, kuro in SOCCER_NOTE:
            if k == key:
                toast("サッカーノート：「%s」" % title)
                telop_sound()
                break

    def note_open():
        return len(store.note_learned) > 0 or len(store.plays_learned) > 0

screen soccer_note():
    tag menu
    use game_menu("サッカーノート", scroll="viewport"):
        ## v0.35.1：覚えたプレー（plays.rpy）
        if plays_learned:
            text "覚えたプレー（蓮の字）" style "roster_name"
            for k, name, body, where in PLAYS:
                if k in plays_learned:
                    frame:
                        style "roster_card"
                        vbox:
                            spacing 4
                            text (name + ("　――　使えた %d回" % plays_used.get(k, 0) if plays_used.get(k, 0) else "　――　まだ試合で使っていない")) style "roster_name"
                            text body style "roster_prof"
                            text "覚えたところ：" + where style "note_kuroda"
            null height 8
        text "ひなたのノート（ところどころに、黒田先生の字）　%d／%d" % (len(note_learned), len(SOCCER_NOTE)) color INK_SOFT size 20
        for k, title, body, kuro in SOCCER_NOTE:
            frame:
                style "roster_card"
                if k in note_learned:
                    vbox:
                        spacing 4
                        text title style "roster_name"
                        text body style "roster_prof"
                        text "黒田：" + kuro style "note_kuroda"
                else:
                    text "？？？　（まだ書かれていない）" color INK_SOFT size 22
        null height 8
        textbutton "相関図にもどる" style "roster_link" text_style "roster_link_text" action ShowMenu("relations")

init 1:
    style note_kuroda:
        size 19
        color PEN_RED
        italic False
    style note_kuroda:
        variant "small"
        size 22


################################################################################
## 章えらび（体験版を最後まで遊ぶと、タイトル画面に出る）
##   その章までの能力や関係は「ふつうに遊んだくらい」の値で始まる
################################################################################

define CHAPTER_LIST = [
    ("プロローグ「止まった冬」", "start", "中3の冬。県大会の決勝と、ケガ"),
    ("第1章「はじまりの十一人」", "cs_chapter1", "高1の春。11人を集めて、桜嶺Bと練習試合"),
    ("第2章「泥だらけの夏」", "cs_chapter2", "高1の夏。初めての公式戦、合宿、潮見港の花火大会"),
    ("第3章「冬の扉」", "cs_chapter3", "高1の冬。選手権予選、桜嶺との準決勝、大晦日の選択"),
]

## 作者の確認用（Web の dev/ だけ）：game/author_build.txt があるとき。テスト用に「買ったことにする」が使える（store_unlock.rpy）
define AUTHOR_BUILD = renpy.loadable("author_build.txt")

screen chapter_select():
    tag menu
    use game_menu("章えらび"):
        vbox:
            spacing 14
            text "章の頭から始めます。その章までの能力や関係は、ふつうに遊んだくらいの値になります。" color INK_SOFT size 20
            ## v0.30.0：有料の章は、買ったあとに選べる。買っていないときは、アプリ版（とテスト用）だけ「製品版」の印つきで出し、押すと購入画面
            $ _paid = [(t, l, s) for (t, l, s) in CHAPTER_LIST_PAID if renpy.has_label(l)]
            $ _show_paid = full_unlocked() or store_available() or iap_testable()
            for title, lab, sub in CHAPTER_LIST + (_paid if _show_paid else []):
                $ _locked = (title, lab, sub) in _paid and not full_unlocked()
                button:
                    style "roster_card"
                    action (Start("unlock_from_menu") if _locked else Start(lab))
                    hover_background "#ffffffcc"
                    vbox:
                        spacing 4
                        text (title + ("　{size=-4}{color=#cd4646}製品版{/color}{/size}" if _locked else "")) style "roster_name"
                        text sub style "roster_prof"

## 章えらびとヒロイン場面テスト（heroine_test.rpy）で使う、その章の頭の状態（v0.31.1 で分けた）
label cs_state1:
    $ met = ["神城", "ひなた", "母"]
    $ persistent.save_guide_seen = True
    return

label cs_chapter1:
    $ quick_menu = True
    $ music_stop(1.5)
    call cs_state1
    jump chapter1

label cs_state2:
    $ persistent.save_guide_seen = True
    $ met = ["神城", "ひなた", "母", "三好", "千夏", "黒田", "大門", "鷹野", "坂口", "紗希"]
    $ stats = {"技術": 44, "フィジカル": 33, "戦術眼": 47, "メンタル": 38}
    $ hidden = {"無理ゲージ": 28, "注目度": 12}
    $ bond = {"鷹野": 12, "大門": 14, "三好": 18, "坂口": 10, "神城": 10}
    $ heart = {"ひなた": {"ときめき": 16, "信頼": 38, "さみしさ": 0}, "千夏": {"ときめき": 5, "信頼": 8, "さみしさ": 0}, "紗希": {"ときめき": 3, "信頼": 3, "さみしさ": 0}}
    $ flags = {"紗希_名前を聞いた": True, "黒田の過去": 1, "千夏_友だち": False}
    $ tuto_stats_done = True
    $ night_tuto_done = True
    return

label cs_chapter2:
    $ quick_menu = True
    $ music_stop(1.5)
    call cs_state2
    if persistent.choice_hints is None:
        call choice_hint_ask
    jump chapter2

label cs_state3:
    $ persistent.save_guide_seen = True
    $ met = ["神城", "ひなた", "母", "三好", "千夏", "黒田", "大門", "鷹野", "坂口", "紗希"]
    $ stats = {"技術": 50, "フィジカル": 42, "戦術眼": 52, "メンタル": 46}
    $ hidden = {"無理ゲージ": 34, "注目度": 20}
    $ bond = {"鷹野": 30, "大門": 32, "三好": 34, "坂口": 22, "神城": 10}
    $ heart = {"ひなた": {"ときめき": 26, "信頼": 50, "さみしさ": 0}, "千夏": {"ときめき": 16, "信頼": 22, "さみしさ": 0}, "紗希": {"ときめき": 12, "信頼": 12, "さみしさ": 0}}
    $ flags = {"紗希_名前を聞いた": True, "黒田の過去": 2, "名鑑": True, "背番号10": "takano", "神城_取り消し": True, "紗希_再会": True, "千夏_友だち": True}
    $ saki_call = "紗希"
    $ ch2_pos = "center"
    $ ch2_knee = "honest"
    $ ch2_miyoshi_cb = "stay"
    $ note_learned = ["b_team", "interhigh", "f442", "cb", "sb", "cmf", "cross", "onetwo", "offside", "pk_shootout", "gk_dive", "knee"]
    $ tuto_stats_done = True
    $ night_tuto_done = True
    $ practice_tuto_done = True
    return

label cs_chapter3:
    $ quick_menu = True
    $ music_stop(1.5)
    call cs_state3
    if persistent.choice_hints is None:
        call choice_hint_ask
    jump chapter3

## 第4章（ルートA）から：第3章の終わりで港北に残った状態。最初の場面だけ変わる「大晦日に話した人」は選べる
label cs_state4a:
    $ persistent.save_guide_seen = True
    $ met = ["神城", "ひなた", "母", "三好", "千夏", "黒田", "大門", "鷹野", "坂口", "紗希", "宮下", "桐生", "森", "小池", "江藤", "野口"]
    $ stats = {"技術": 58, "フィジカル": 50, "戦術眼": 60, "メンタル": 55}
    $ hidden = {"無理ゲージ": 40, "注目度": 30}
    $ bond = {"鷹野": 45, "大門": 45, "三好": 48, "坂口": 35, "神城": 12}
    $ heart = {"ひなた": {"ときめき": 35, "信頼": 60, "さみしさ": 0}, "千夏": {"ときめき": 28, "信頼": 40, "さみしさ": 0}, "紗希": {"ときめき": 22, "信頼": 30, "さみしさ": 0}}
    $ flags = {"紗希_名前を聞いた": True, "黒田の過去": 3, "名鑑": True, "背番号10": "takano", "神城_取り消し": True, "紗希_再会": True, "千夏_友だち": True}
    $ saki_call = "紗希"
    $ ch2_pos = "center"
    $ ch2_knee = "honest"
    $ ch2_miyoshi_cb = "stay"
    $ ch3_semi = "1−2"
    $ ch3_armband = "ren"
    $ ch3_route = "stay"
    ## 体験版で一度見た案内（練習・夜のトーク・能力）は、もう出さない
    $ tuto_stats_done = True
    $ night_tuto_done = True
    $ practice_tuto_done = True
    $ note_learned = ["b_team", "interhigh", "f442", "cb", "sb", "cmf", "cross", "onetwo", "offside", "pk_shootout", "gk_dive", "knee"]
    return

label cs_chapter4a:
    $ quick_menu = True
    $ music_stop(1.5)
    call cs_state4a
    scene black
    if iap_testable():
        tuto "（作者の確認用）第4章の最初の場面は、大晦日に話した相手で変わります。"
    menu:
        "大晦日に話した相手は？"
        "ひなた":
            $ ch3_nye = "hinata"
        "千夏":
            $ ch3_nye = "chika"
        "紗希":
            $ ch3_nye = "saki"
        "鷹野":
            $ ch3_nye = "takano"
        "母さん":
            $ ch3_nye = "mother"
    $ ch3_xmas = ch3_nye if ch3_nye in ("hinata", "chika", "saki") else "boys"
    if persistent.choice_hints is None:
        call choice_hint_ask
    jump chapter4a


## 第4章（ルートB）から：第3章の終わりで桜嶺へ移った状態（v0.35.1）
label cs_state4b:
    call cs_state4a
    $ ch3_route = "move"
    $ ch3_nye = "saki"
    $ ch3_xmas = "saki"
    $ flags["紗希_チケット"] = True
    return

label cs_chapter4b:
    $ quick_menu = True
    $ music_stop(1.5)
    call cs_state4b
    scene black
    if iap_testable():
        tuto "（作者の確認用）第4章Bの最初の場面は、大晦日に話した相手で変わります。"
    menu:
        "大晦日に話した相手は？"
        "ひなた":
            $ ch3_nye = "hinata"
        "千夏":
            $ ch3_nye = "chika"
        "紗希":
            $ ch3_nye = "saki"
        "母さん":
            $ ch3_nye = "mother"
    $ ch3_xmas = ch3_nye if ch3_nye in ("hinata", "chika", "saki") else "boys"
    if persistent.choice_hints is None:
        call choice_hint_ask
    jump chapter4b

## 第5章（ルートB）から：第4章Bの終わり＝8/31 の状態。ふつうに遊んだくらいの値（v0.35.1）
label cs_state5b:
    call cs_state4b
    python:
        for _n in ("あげは", "本田", "一ノ瀬", "麗華", "小早川"):
            if _n not in met:
                met.append(_n)
        stats = {"技術": 66, "フィジカル": 58, "戦術眼": 64, "メンタル": 60}
        hidden = {"無理ゲージ": 58, "注目度": 40}
        bond.update({"神城": 40, "鷹野": 30, "大門": 34})
        heart["紗希"] = {"ときめき": 40, "信頼": 48, "さみしさ": 0}
        heart["あげは"] = {"ときめき": 26, "信頼": 26, "さみしさ": 0}
        heart["麗華"] = {"ときめき": 24, "信頼": 24, "さみしさ": 0}
        b4_rank = 1
        b4_test3 = "pass"
        b4_test_a = "pass"
        b4_tell = "saki"
        b4_saki_contact = True
        b4_reika = "lover"
        b4_kamishiro = "together"
        b4_honda = "stay"
        b4_knee = "tell"
        b4_trust_answer = {"紗希": "honest"}
    return

label cs_chapter5b:
    $ quick_menu = True
    $ music_stop(1.5)
    call cs_state5b
    scene black
    if iap_testable():
        tuto "（作者の確認用）第5章Bの場面は、第4章Bで選んだことで変わります。"
    menu:
        "麗華とは？"
        "付き合っている":
            $ b4_reika = "lover"
        "付き合っていない（4/9 に断った）":
            $ b4_reika = "refused"
    menu:
        "7/17 の昇格テストは？"
        "Aチームに上がった":
            $ b4_rank = 1
        "上がれなかった（Bチーム）":
            $ b4_rank = 2
            $ b4_test_a = "fail"
    menu:
        "8/30 の検診のあと、鬼塚には？"
        "話した":
            $ b4_knee = "tell"
        "「問題ありませんでした」と言った":
            $ b4_knee = "hide"
    if persistent.choice_hints is None:
        call choice_hint_ask
    jump chapter5b


################################################################################
## 試合のふり返り（ひなたのノート）
##   試合のあとに、選んだことと結果を並べて見せる。選択が試合にどう効いたかが分かるように
##   例：call screen match_report("1回戦　港北 1−1（PK 4−3）白浜工業", [("勝因", "大門の横っ飛び"), ...], "ひなたのひとこと")
################################################################################

screen match_report(title, rows, memo=""):
    ## ひなたが書いたルーズリーフ（gui/report_note.png。罫線は y=100 から 42px ごと）。文字は罫線の上に書く
    modal True
    zorder 150
    add "#00000088"
    fixed at report_in:
        xysize (956, 656)
        xalign 0.5
        yalign 0.5
        add "gui/report_note.png"
        ## 上のマスキングテープ
        frame:
            style "report_tape"
            text "試合のふり返り　ひなたのノート" style "report_head"
        vbox:
            xpos 112
            ypos 100 - 42 - 4
            spacing 0
            text title style "report_title"
            for k, v in rows:
                hbox:
                    spacing 14
                    text k style "report_key"
                    text v style "report_val"
            if memo:
                text memo style "report_memo"
        text "タップで閉じる" style "report_hint"
    key "dismiss" action Return()
    button:
        xysize (1280, 720)
        background None
        action Return()

transform report_in:
    alpha 0.0 yoffset 18
    easeout 0.3 alpha 1.0 yoffset 0

init 1:
    style report_tape is frame:
        xpos 300
        ypos -14
        background Frame("gui/banner_tape.png", 20, 10)
        padding (26, 6, 26, 9)
    style report_head:
        font FONT_JP_B
        size 20
        color INK
    ## 文字の高さ（行の高さ）を、罫線の間隔 42px にそろえる
    style report_title:
        font FONT_JP_B
        size 26
        line_spacing 4
        color INK
    style report_key:
        font FONT_JP_B
        size 22
        line_spacing 10
        color PEN_RED
        min_width 170
    style report_val:
        size 22
        line_spacing 10
        color INK
        xsize 620
    style report_memo:
        font FONT_JP_B
        size 22
        line_spacing 10
        color PEN_TEAL
        xsize 790
    style report_hint:
        size 16
        color INK_SOFT
        xalign 1.0
        yalign 1.0
        xoffset -40
        yoffset -26
    style report_val:
        variant "small"
        size 24
        line_spacing 8
    style report_key:
        variant "small"
        size 24
        line_spacing 8
    style report_memo:
        variant "small"
        size 24
        line_spacing 8
